/* symlink.c - create symbolic links corresponding to all the schema names */
/* used in an EXPRESS file */
/* Author: Don Libes, NIST, 20-Mar-1993 */

// include <sys/param.h>
#include <stdlib.h>
#include <stdio.h>
#include "express.h"

extern char *sys_errlist[];
extern int errno;

void create_links(Express model)
{
   DictionaryEntry de;
   Schema s;
   char linksrc[_MAX_PATH];
   char linkname[_MAX_PATH];
   char dir[_MAX_PATH];
   char dir2[_MAX_PATH];
   extern char *getcwd();

   getcwd(dir2, _MAX_PATH);
   /* get rid of "/auto" added by automounter */
   /* At NIST, tribble doesn't automount things */
   if (0 == strncmp("/auto/", dir2, 6)) {
      strcpy(dir, dir2 + 5);
   }
   else {
      strcpy(dir, dir2);
   }

   sprintf(linksrc, "%s/%s", dir, model->u.express->filename);

   DICTdo_init(model->symbol_table, &de);
   while (0 != (s = (Schema) DICTdo(&de))) {

      char lower[_MAX_PATH];
      char *dest,
      *src;
      /* convert to schema name lowercase */

      dest = lower;
      for (src = s->symbol.name; *src; src++)
         *dest++ = tolower(*src);
      *dest = '\0';

      sprintf(linkname, "%s.exp", lower);
#ifdef NOTNOW
      if (-1 == symlink(linksrc, linkname)) {
         fprintf(stderr, "symlink(%s,%s) failed: %s\n",
                 linksrc, linkname, sys_errlist[errno]);
         exit(1);
      }
#endif
   }
   exit(0);
}

void EXPRESSinit_init()
{
   EXPRESSbackend = create_links;
}
