
# line 2 "expparse.y"

static char rcsid[] = "$Id: expparse.y,v 1.13 1994/05/11 19:50:00 libes Exp $";

/*
 * YACC grammar for Express parser.
 *
 * This software was developed by U.S. Government employees as part of
 * their official duties and is not subject to copyright.
 *
 * $Log: expparse.y,v $
 * Revision 1.13  1994/05/11  19:50:00  libes
 * numerous fixes
 *
 * Revision 1.12  1993/10/15  18:47:26  libes
 * CADDETC certified
 *
 * Revision 1.10  1993/03/19  20:53:57  libes
 * one more, with feeling
 *
 * Revision 1.9  1993/03/19  20:39:51  libes
 * added unique to parameter types
 *
 * Revision 1.8  1993/02/16  03:17:22  libes
 * reorg'd alg bodies to not force artificial begin/ends
 * added flag to differentiate parameters in scopes
 * rewrote query to fix scope handling
 * added support for Where type
 *
 * Revision 1.7  1993/01/19  22:44:17  libes
 * *** empty log message ***
 *
 * Revision 1.6  1992/08/27  23:36:35  libes
 * created fifo for new schemas that are parsed
 * connected entity list to create of oneof
 *
 * Revision 1.5  1992/08/18  17:11:36  libes
 * rm'd extraneous error messages
 *
 * Revision 1.4  1992/06/08  18:05:20  libes
 * prettied up interface to print_objects_when_running
 *
 * Revision 1.3  1992/05/31  23:31:13  libes
 * implemented ALIAS resolution
 *
 * Revision 1.2  1992/05/31  08:30:54  libes
 * multiple files
 *
 * Revision 1.1  1992/05/28  03:52:25  libes
 * Initial revision
 */


#include "linklist.h"
#include "stack.h"
#include "express.h"
#include "schema.h"
#include "entity.h"
#include "resolve.h"

extern int print_objects_while_running;

int tag_count;                  /* use this to count tagged GENERIC types in the formal */
 /* argument lists.  Gross, but much easier to do it this */
 /* way then with the 'help' of yacc. */

/*SUPPRESS 61*/
/* Type current_type;	/* pass type placeholder down */
 /* this allows us to attach a dictionary to it only when */
 /* we decide we absolutely need one */

Express yyresult;               /* hook to everything built by parser */

Symbol *interface_schema;       /* schema of interest in use/ref clauses */
void (*interface_func) ();      /* func to attach rename clauses */

/* record schemas found in a single parse here, allowing them to be */
/* differentiated from other schemas parsed earlier */
Linked_List PARSEnew_schemas;

extern int yylineno;

static void yyerror PROTO((char *));
static void yyerror2 PROTO((char CONST *));

Boolean yyeof = false;

#ifdef FLEX
extern char *exp_yytext;
#else /* LEX */
extern char exp_yytext[];
#endif /* FLEX */

#define MAX_SCOPE_DEPTH	20      /* max number of scopes that can be nested */

static struct scope {
   struct Scope *this;
   char type;                   /* one of OBJ_XXX */
   struct scope *pscope;        /* pointer back to most recent scope */
   /* that has a printable name - for better */
   /* error messages */
} scopes[MAX_SCOPE_DEPTH], *scope;
#define CURRENT_SCOPE (scope->this)
#define PREVIOUS_SCOPE ((scope-1)->this)
#define CURRENT_SCHEMA (scope->this->u.schema)
#define CURRENT_SCOPE_NAME		(OBJget_symbol(scope->pscope->this,scope->pscope->type)->name)
#define CURRENT_SCOPE_TYPE_PRINTABLE	(OBJget_type(scope->pscope->type))

/* ths = new scope to enter */
/* sym = name of scope to enter into parent.  Some scopes (i.e., increment) */
/*       are not named, in which case sym should be 0 */
/*	 This is useful for when a diagnostic is printed, an earlier named */
/* 	 scoped can be used */
/* typ = type of scope */
#define PUSH_SCOPE(ths,sym,typ) \
	if (sym) DICTdefine(scope->this->symbol_table,(sym)->name,(Generic)ths,sym,typ);\
	ths->superscope = scope->this; \
	scope++;		\
	scope->type = typ;	\
	scope->pscope = (sym?scope:(scope-1)->pscope); \
	scope->this = ths; \
	if (sym) { \
		ths->symbol = *(sym); \
	}
#define POP_SCOPE() scope--

/* PUSH_SCOPE_DUMMY just pushes the scope stack with nothing actually on it */
/* Necessary for situations when a POP_SCOPE is unnecessary but inevitable */
#define PUSH_SCOPE_DUMMY() scope++

/* normally the superscope is added by PUSH_SCOPE, but some things (types) */
/* bother to get pushed so fix them this way */
#define SCOPEadd_super(ths) ths->superscope = scope->this;

#define ERROR(code)	ERRORreport(code, yylineno)

/* structured types for parse node decorations */


# line 296 "expparse.y"
typedef union {
   /* simple (single-valued) node types */

   Binary binary;
   Case_Item case_item;
   Expression expression;
   Integer iVal;
   Linked_List list;
   Logical logical;
   Op_Code op_code;
   Qualified_Attr *qualified_attr;
   Real rVal;
   Statement statement;
   Symbol *symbol;
   char *string;
   Type type;
   TypeBody typebody;
   Variable variable;
   Where where;

   struct type_either {
      Type type;
      TypeBody body;
   } type_either;               /* either one of these can be returned */

   struct {
 unsigned optional:
       1;
 unsigned unique:
       1;
 unsigned fixed:
       1;
 unsigned var:
       1;                       /* when formal is "VAR" */
   } type_flags;

   struct {
      Linked_List attributes;
      Linked_List unique;
      Linked_List where;
   } entity_body;

   struct {
      Expression subtypes;
      Linked_List supertypes;
      Boolean abstract;
   } subsuper_decl;

   struct {
      Expression subtypes;
      Boolean abstract;
   } subtypes;

   struct {
      Expression lower_limit;
      Expression upper_limit;
   } upper_lower;
} exp_YYSTYPE;
#ifdef __cplusplus
#  include <stdio.h>
extern "C" {
   extern void yyerror(char *);
   extern int exp_yylex();
}
#endif /* __cplusplus */
# define TOK_OR 257
# define TOK_XOR 258
# define TOK_AND 259
# define TOK_ANDOR 260
# define TOK_EQUAL 261
# define TOK_GREATER_EQUAL 262
# define TOK_GREATER_THAN 263
# define TOK_IN 264
# define TOK_INST_EQUAL 265
# define TOK_INST_NOT_EQUAL 266
# define TOK_LESS_EQUAL 267
# define TOK_LESS_THAN 268
# define TOK_LIKE 269
# define TOK_NOT_EQUAL 270
# define TOK_MINUS 271
# define TOK_PLUS 272
# define TOK_DIV 273
# define TOK_MOD 274
# define TOK_REAL_DIV 275
# define TOK_TIMES 276
# define TOK_CONCAT_OP 277
# define TOK_EXP 278
# define TOK_NOT 279
# define TOK_DOT 280
# define TOK_BACKSLASH 281
# define TOK_LEFT_BRACKET 282
# define TOK_ABSTRACT 283
# define TOK_AGGREGATE 284
# define TOK_ALIAS 285
# define TOK_ALL_IN 286
# define TOK_ARRAY 287
# define TOK_AS 288
# define TOK_ASSIGNMENT 289
# define TOK_BAG 290
# define TOK_BEGIN 291
# define TOK_BINARY 292
# define TOK_BOOLEAN 293
# define TOK_BY 294
# define TOK_CASE 295
# define TOK_COLON 296
# define TOK_COMMA 297
# define TOK_CONSTANT 298
# define TOK_CONTEXT 299
# define TOK_E 300
# define TOK_DERIVE 301
# define TOK_ELSE 302
# define TOK_END 303
# define TOK_END_ALIAS 304
# define TOK_END_CASE 305
# define TOK_END_CONSTANT 306
# define TOK_END_CONTEXT 307
# define TOK_END_ENTITY 308
# define TOK_END_FUNCTION 309
# define TOK_END_IF 310
# define TOK_END_LOCAL 311
# define TOK_END_MODEL 312
# define TOK_END_PROCEDURE 313
# define TOK_END_REPEAT 314
# define TOK_END_RULE 315
# define TOK_END_SCHEMA 316
# define TOK_END_TYPE 317
# define TOK_ENTITY 318
# define TOK_ENUMERATION 319
# define TOK_ESCAPE 320
# define TOK_FIXED 321
# define TOK_FOR 322
# define TOK_FROM 323
# define TOK_FUNCTION 324
# define TOK_GENERIC 325
# define TOK_IF 326
# define TOK_INCLUDE 327
# define TOK_INTEGER 328
# define TOK_INVERSE 329
# define TOK_LEFT_CURL 330
# define TOK_LEFT_PAREN 331
# define TOK_LIST 332
# define TOK_LOCAL 333
# define TOK_LOGICAL 334
# define TOK_MODEL 335
# define TOK_NUMBER 336
# define TOK_OF 337
# define TOK_ONEOF 338
# define TOK_OPTIONAL 339
# define TOK_OTHERWISE 340
# define TOK_PI 341
# define TOK_PROCEDURE 342
# define TOK_QUERY 343
# define TOK_QUESTION_MARK 344
# define TOK_REAL 345
# define TOK_REFERENCE 346
# define TOK_REPEAT 347
# define TOK_RETURN 348
# define TOK_RIGHT_BRACKET 349
# define TOK_RIGHT_CURL 350
# define TOK_RIGHT_PAREN 351
# define TOK_RULE 352
# define TOK_SCHEMA 353
# define TOK_SELECT 354
# define TOK_SEMICOLON 355
# define TOK_SET 356
# define TOK_SKIP 357
# define TOK_STRING 358
# define TOK_SUBTYPE 359
# define TOK_SUCH_THAT 360
# define TOK_SUPERTYPE 361
# define TOK_THEN 362
# define TOK_TO 363
# define TOK_TYPE 364
# define TOK_UNIQUE 365
# define TOK_UNTIL 366
# define TOK_USE 367
# define TOK_VAR 368
# define TOK_WHERE 369
# define TOK_WHILE 370
# define TOK_STRING_LITERAL 371
# define TOK_STRING_LITERAL_ENCODED 372
# define TOK_BUILTIN_FUNCTION 373
# define TOK_BUILTIN_PROCEDURE 374
# define TOK_IDENTIFIER 375
# define TOK_SELF 376
# define TOK_INTEGER_LITERAL 377
# define TOK_REAL_LITERAL 378
# define TOK_LOGICAL_LITERAL 379
# define TOK_BINARY_LITERAL 380
#define yyclearin exp_yychar = -1
#define yyerrok exp_yyerrflag = 0
extern int exp_yychar;
#ifndef YYMAXDEPTH
#define YYMAXDEPTH 150
#endif

/* __YYSCLASS defines the scoping/storage class for global objects
 * that are NOT renamed by the -p option.  By default these names
 * are going to be 'static' so that multi-definition errors
 * will not occur with multiple parsers.
 * If you want (unsupported) access to internal names you need
 * to define this to be null so it implies 'extern' scope.
 * This should not be used in conjunction with -p.
 */
#ifndef __YYSCLASS
# define __YYSCLASS static
#endif
exp_YYSTYPE exp_yylval;
__YYSCLASS exp_YYSTYPE exp_yyval;
typedef int yytabelem;
# define YYERRCODE 256

# line 1878 "expparse.y"

static void yyerror(string)
char *string;
{
   char buf[200];
   Symbol sym;

   strcpy(buf, string);

   if (yyeof)
      strcat(buf, " at end of input");
   else if (exp_yytext[0] == 0)
      strcat(buf, " at null character");
   else if (exp_yytext[0] < 040 || exp_yytext[0] >= 0177)
      sprintf(buf + strlen(buf), " before character 0%o", exp_yytext[0]);
   else
      sprintf(buf + strlen(buf), " before `%s'", exp_yytext);

   sym.line = yylineno;
   sym.filename = current_filename;
   ERRORreport_with_symbol(ERROR_syntax, &sym, buf, CURRENT_SCOPE_TYPE_PRINTABLE, CURRENT_SCOPE_NAME);
}

static void yyerror2(t)
char CONST *t;                  /* token or 0 to indicate no more tokens */
{
   char buf[200];
   Symbol sym;
   static int first = 1;        /* true if first suggested replacement */
   static char tokens[4000] = "";   /* error message, saying */
   /* "expecting <token types>" */

   if (t) {                     /* subsequent token? */
      if (first)
         first = 0;
      else
         strcat(tokens, " or ");
      strcat(tokens, t);
   }
   else {
      strcpy(buf, "syntax error");
      if (yyeof)
         strcat(buf, " at end of input");
      else if (exp_yytext[0] == 0)
         strcat(buf, " at null character");
      else if (exp_yytext[0] < 040 || exp_yytext[0] >= 0177)
         sprintf(buf + strlen(buf), " near character 0%o", exp_yytext[0]);
      else
         sprintf(buf + strlen(buf), " near `%s'", exp_yytext);

      if (0 == strlen(tokens))
         yyerror("syntax error");
      sym.line = yylineno - (exp_yytext[0] == '\n');
      sym.filename = current_filename;
      ERRORreport_with_symbol(ERROR_syntax_expecting, &sym, buf, tokens
                              ,CURRENT_SCOPE_TYPE_PRINTABLE, CURRENT_SCOPE_NAME);
   }
}
__YYSCLASS yytabelem exp_yyexca[] = {
   -1, 1,
   0, -1,
   -2, 0,
   -1, 104,
   331, 215,
   355, 215,
   -2, 147,
   -1, 153,
   331, 130,
   -2, 147,
   -1, 189,
   331, 130,
   -2, 147,
};
# define YYNPROD 329
# define YYLAST 1200
__YYSCLASS yytabelem exp_yyact[] = {

   81, 229, 568, 570, 319, 301, 567, 298, 80, 82,
   454, 109, 22, 24, 25, 511, 152, 462, 78, 362,
   393, 356, 341, 325, 438, 320, 266, 273, 625, 571,
   140, 323, 48, 569, 571, 439, 316, 317, 324, 314,
   610, 159, 645, 199, 48, 242, 243, 241, 198, 246,
   248, 245, 252, 250, 251, 247, 244, 253, 249, 639,
   111, 46, 627, 49, 47, 614, 455, 110, 512, 542,
   363, 518, 507, 505, 124, 49, 47, 145, 147, 402,
   297, 128, 281, 299, 280, 182, 119, 46, 77, 76,
   180, 181, 72, 71, 70, 103, 69, 68, 191, 11,
   194, 93, 200, 202, 12, 190, 609, 96, 125, 199,
   154, 95, 188, 316, 317, 192, 79, 212, 213, 19,
   343, 184, 463, 103, 103, 140, 165, 164, 292, 357,
   536, 509, 62, 113, 163, 64, 97, 166, 103, 185,
   186, 187, 98, 603, 201, 232, 234, 420, 464, 23,
   239, 493, 457, 254, 8, 178, 23, 195, 19, 127,
   48, 537, 515, 100, 101, 443, 444, 21, 23, 205,
   431, 23, 642, 102, 641, 447, 564, 267, 40, 504,
   7, 23, 502, 274, 41, 175, 160, 500, 20, 498,
   105, 104, 47, 58, 286, 486, 177, 577, 176, 48,
   279, 23, 42, 451, 296, 443, 444, 358, 64, 434,
   63, 430, 289, 23, 23, 327, 294, 326, 295, 530,
   471, 344, 335, 616, 38, 447, 169, 170, 179, 580,
   189, 47, 167, 168, 171, 172, 128, 360, 345, 364,
   346, 128, 412, 93, 315, 351, 443, 444, 354, 96,
   355, 578, 321, 95, 352, 350, 391, 524, 365, 366,
   367, 368, 369, 370, 371, 372, 373, 374, 375, 376,
   377, 231, 378, 531, 472, 231, 228, 209, 97, 448,
   404, 228, 388, 51, 98, 409, 276, 228, 228, 115,
   231, 114, 414, 231, 410, 231, 411, 519, 282, 418,
   334, 528, 48, 452, 445, 100, 101, 318, 390, 415,
   416, 432, 277, 195, 127, 102, 237, 223, 50, 127,
   103, 219, 217, 441, 628, 278, 632, 103, 446, 449,
   629, 427, 105, 104, 47, 211, 425, 121, 442, 353,
   210, 458, 423, 421, 359, 235, 460, 456, 233, 348,
   230, 328, 214, 13, 459, 149, 595, 556, 128, 117,
   321, 203, 128, 594, 128, 321, 116, 379, 380, 381,
   382, 383, 384, 385, 386, 387, 310, 468, 489, 474,
   73, 284, 482, 242, 243, 241, 488, 246, 248, 245,
   252, 250, 251, 247, 244, 253, 249, 620, 550, 551,
   534, 205, 436, 435, 480, 206, 205, 227, 274, 477,
   605, 573, 552, 544, 491, 517, 429, 392, 494, 476,
   495, 339, 613, 492, 255, 487, 75, 293, 221, 490,
   184, 499, 185, 186, 187, 503, 127, 496, 506, 497,
   127, 183, 127, 473, 479, 291, 228, 501, 606, 440,
   523, 526, 638, 525, 576, 258, 103, 532, 326, 257,
   258, 466, 516, 443, 444, 469, 120, 470, 128, 520,
   521, 513, 94, 151, 128, 347, 529, 185, 186, 187,
   193, 533, 538, 549, 539, 321, 321, 321, 285, 553,
   236, 541, 543, 107, 197, 53, 546, 61, 554, 545,
   555, 52, 44, 126, 478, 558, 215, 218, 560, 561,
   557, 15, 563, 40, 222, 118, 559, 481, 56, 41,
   128, 28, 8, 128, 562, 6, 572, 565, 43, 16,
   155, 103, 582, 103, 450, 216, 67, 42, 65, 66,
   579, 581, 583, 329, 5, 9, 127, 39, 74, 55,
   106, 338, 127, 34, 619, 123, 590, 596, 112, 38,
   591, 587, 593, 37, 322, 27, 108, 599, 592, 604,
   600, 535, 601, 602, 617, 611, 10, 540, 14, 608,
   146, 17, 615, 260, 262, 261, 259, 257, 258, 103,
   148, 18, 103, 27, 103, 621, 622, 361, 127, 196,
   122, 127, 204, 36, 4, 3, 2, 624, 626, 330,
   35, 630, 631, 633, 33, 623, 32, 165, 164, 321,
   31, 636, 30, 574, 240, 163, 575, 637, 166, 45,
   634, 220, 29, 165, 164, 640, 635, 26, 643, 238,
   646, 163, 547, 57, 166, 54, 178, 647, 648, 1,
   224, 256, 331, 225, 226, 275, 588, 607, 132, 242,
   243, 241, 178, 246, 248, 245, 252, 250, 251, 247,
   244, 253, 249, 131, 300, 130, 175, 160, 264, 263,
   260, 262, 261, 259, 257, 258, 129, 177, 303, 176,
   48, 290, 175, 160, 268, 269, 270, 288, 336, 165,
   164, 302, 349, 177, 99, 176, 48, 163, 174, 60,
   166, 271, 422, 424, 426, 428, 59, 169, 170, 179,
   333, 189, 47, 167, 168, 171, 172, 92, 178, 91,
   90, 89, 88, 169, 170, 179, 413, 189, 47, 167,
   168, 171, 172, 264, 263, 260, 262, 261, 259, 257,
   258, 403, 165, 164, 87, 86, 85, 618, 175, 160,
   163, 84, 589, 166, 83, 342, 514, 453, 406, 177,
   508, 176, 48, 437, 313, 433, 510, 566, 242, 243,
   241, 178, 246, 248, 245, 252, 250, 251, 247, 244,
   253, 249, 522, 527, 340, 287, 311, 312, 150, 169,
   170, 179, 485, 189, 47, 167, 168, 171, 172, 407,
   408, 175, 160, 264, 263, 260, 262, 261, 259, 257,
   258, 405, 177, 309, 176, 48, 304, 208, 272, 305,
   162, 138, 133, 141, 419, 157, 142, 161, 138, 133,
   141, 612, 158, 142, 173, 138, 133, 597, 156, 207,
   484, 483, 169, 170, 179, 0, 153, 47, 167, 168,
   171, 172, 0, 0, 308, 332, 0, 134, 0, 0,
   0, 306, 265, 137, 134, 136, 23, 0, 143, 0,
   137, 134, 136, 0, 135, 143, 0, 137, 0, 136,
   0, 135, 0, 0, 0, 307, 0, 139, 135, 0,
   337, 0, 144, 0, 139, 0, 0, 0, 0, 144,
   0, 139, 0, 0, 140, 0, 0, 0, 0, 0,
   0, 140, 0, 0, 0, 242, 243, 241, 140, 246,
   248, 245, 252, 250, 251, 247, 244, 253, 249, 242,
   243, 241, 0, 246, 248, 245, 252, 250, 251, 247,
   244, 253, 249, 242, 243, 241, 0, 246, 248, 245,
   252, 250, 251, 247, 244, 253, 249, 242, 243, 241,
   0, 246, 248, 245, 252, 250, 251, 247, 244, 253,
   249, 242, 243, 241, 0, 246, 248, 245, 252, 250,
   251, 247, 244, 253, 249, 242, 243, 241, 0, 246,
   248, 245, 252, 250, 251, 247, 244, 253, 249, 0,
   0, 0, 0, 0, 0, 0, 242, 243, 241, 644,
   246, 248, 245, 252, 250, 251, 247, 244, 253, 249,
   0, 0, 0, 461, 264, 263, 260, 262, 261, 259,
   257, 258, 0, 0, 242, 243, 241, 417, 246, 248,
   245, 252, 250, 251, 247, 244, 253, 249, 242, 243,
   241, 389, 246, 248, 245, 252, 250, 251, 247, 244,
   253, 249, 0, 0, 586, 264, 263, 260, 262, 261,
   259, 257, 258, 0, 0, 0, 0, 585, 0, 0,
   0, 0, 0, 0, 242, 243, 241, 475, 246, 248,
   245, 252, 250, 251, 247, 244, 253, 249, 584, 242,
   243, 241, 548, 246, 248, 245, 252, 250, 251, 247,
   244, 253, 249, 0, 283, 0, 0, 0, 0, 0,
   242, 243, 241, 467, 246, 248, 245, 252, 250, 251,
   247, 244, 253, 249, 0, 396, 398, 395, 465, 400,
   401, 397, 394, 0, 399, 264, 263, 260, 262, 261,
   259, 257, 258, 0, 242, 243, 241, 598, 246, 248,
   245, 252, 250, 251, 247, 244, 253, 249, 241, 0,
   246, 248, 245, 252, 250, 251, 247, 244, 253, 249,
246, 248, 245, 252, 250, 251, 247, 244, 253, 249};
__YYSCLASS yytabelem exp_yypact[] = {

   -3000, -3000, -3000, -173, -3000, -3000, -3000, -276, -267, 37,
   -179, -206, -206, -206, -3000, 195, -3000, -3000, -3000, -312,
   -5, -40, -3000, -3000, -3000, -3000, -3000, -3000, -3000, -3000,
   -3000, -3000, -3000, -3000, -140, -151, -140, -140, -278, -279,
   -281, -282, -283, 195, 74, -312, 130, -3000, -3000, -3000,
   -286, -287, -253, -184, -140, -3000, -3000, -3000, -308, -206,
   -224, -3000, -228, -46, -48, 57, 46, -253, 205, 15,
   -3000, -3000, -3000, -206, -3000, 553, -206, -206, 40, 481,
   -3000, -184, -184, -3000, -3000, -3000, -3000, -3000, -3000, -3000,
   -3000, -3000, -3000, -290, 152, 428, -184, -206, 428, -174,
   -327, -187, -206, -3000, -3000, -3000, -3000, 50, -308, 109,
   -3000, -3000, -3000, -60, 9, 4, -206, -206, 35, -3000,
   -3000, -9, -10, -10, -3000, 139, -3000, -3000, -3000, -3000,
   -3000, -3000, -3000, -3000, -14, -14, -3000, -3000, -14, -14,
   -3000, 164, 13, 11, 8, -3000, -15, -3000, -15, -206,
   481, -3000, 521, 128, 542, 197, -3000, -3000, -3000, -3000,
   428, -3000, -3000, 428, 428, 428, 362, -3000, -3000, -3000,
   -3000, -3000, -3000, -3000, -18, 428, -19, -3000, -3000, -3000,
   -3000, -3000, 3, 428, -3000, -291, -293, 428, 787, -3000,
   78, -3000, 126, -206, -3000, 346, -261, -238, 138, 428,
   -3000, 428, -3000, -206, -3000, -295, 539, 68, -262, -24,
   -300, -345, -3000, -3000, -206, 34, 546, -3000, 125, -248,
   -206, 428, -3000, 428, -3000, 28, 28, -82, 428, -83,
   553, 428, -87, -236, -130, 553, -206, -305, -206, -3000,
   -3000, 428, 428, 428, 428, 428, 428, 428, 428, 428,
   428, 428, 428, 428, -3000, 428, 428, 428, 428, 428,
   428, 428, 428, 428, 428, 428, -3000, 710, 197, 197,
   197, -3000, -41, 121, 907, -3000, 884, -296, -312, 521,
   -3000, -3000, 472, -3000, -206, -184, -3000, -55, -3000, 907,
   -238, -206, 428, 428, 907, 696, -3000, -3000, -142, -3000,
   -3000, -3000, -3000, -3000, 6, 5, -1, -6, 120, -126,
   -206, -3000, -120, 106, -339, -3000, -3000, 168, -300, -13,
   -3000, -3000, -27, -300, -3000, -72, -3000, -3000, -206, -3000,
   -3000, -3000, -134, -3000, -3000, -3000, -3000, -28, -309, 539,
   -199, -3000, -308, -3000, -3000, 521, 682, -3000, -3000, -3000,
   -217, 852, 553, -3000, 837, -236, 553, -3000, 553, -3000,
   -3000, -77, -3000, 155, -3000, 929, 919, 919, -3000, -3000,
   -3000, -3000, -3000, -3000, -3000, -3000, -3000, -3000, 521, 804,
   177, 177, 182, 182, 182, 182, 310, 310, 801, -3000,
   -3000, 428, 428, 428, -3000, -3000, -3000, -3000, -3000, -3000,
   -3000, -3000, 158, -141, -3000, -3000, 428, 77, -145, -3000,
   76, -3000, 428, -206, -184, 907, -212, -206, -3000, -206,
   428, -217, -148, 539, -150, -236, -155, 539, -158, -302,
   539, -303, -3000, -234, -307, -339, -177, -339, -3000, 119,
   -304, -54, -3000, -300, -300, -300, -94, -345, -3000, -3000,
   -206, -30, -345, -78, -3000, -3000, -206, -3000, -248, 104,
   -3000, -3000, 553, -235, -178, 428, -3000, 428, 553, -3000,
   -3000, -305, -3000, -306, -3000, 428, 117, 907, 884, 428,
   -3000, 763, -206, -3000, -3000, 102, 116, 907, -206, -184,
   907, -184, 43, 428, -3000, -3000, 907, 539, -217, -3000,
   539, 539, -236, -3000, 539, -3000, -3000, -161, -253, -342,
   -307, -3000, 115, -3000, 553, -3000, -3000, 553, 174, -3000,
   -3000, -3000, -100, 204, -3000, -3000, -3000, -3000, -308, -122,
   -309, -206, -3000, -3000, 539, -3000, -3000, -3000, 759, 738,
   -3000, -3000, -3000, 724, 428, 428, 402, -184, -3000, -3000,
   -42, 428, -42, -3000, 53, 42, -206, 873, -3000, 539,
   -3000, -3000, 539, -3000, 539, -3000, -342, -3000, -154, 114,
   -3000, 167, -3000, -250, -206, 133, -310, -300, -3000, -128,
   -3000, -3000, -3000, -3000, -3000, -3000, -3000, 907, 407, -3000,
   93, -3000, 907, -3000, -206, -206, -3000, -3000, 428, -3000,
   -3000, -3000, -3000, -347, -3000, -347, -313, 2, -3000, -7,
   -11, -3000, -206, 428, -3000, 204, -3000, -3000, -3000, 428,
   -206, -3000, -3000, 907, -3000, -3000, -154, 172, -316, -345,
   -163, -165, -345, -3000, 907, 668, -3000, -3000, -333, -206,
-3000, -345, -345, -3000, -3000, -3000, -3000, -3000, -3000};
__YYSCLASS yytabelem exp_yypgo[] = {

   0, 851, 850, 849, 27, 848, 35, 847, 844, 16,
   842, 472, 41, 841, 837, 835, 834, 514, 830, 110,
   530, 26, 4, 445, 494, 501, 480, 828, 827, 810,
   809, 802, 798, 797, 796, 795, 22, 507, 794, 11,
   23, 793, 8, 497, 18, 792, 777, 6, 776, 775,
   774, 773, 770, 767, 2, 20, 17, 475, 766, 765,
   21, 3, 764, 761, 756, 755, 754, 732, 731, 730,
   729, 727, 9, 716, 709, 25, 708, 704, 108, 5,
   7, 701, 83, 698, 688, 503, 686, 675, 674, 673,
   658, 657, 652, 651, 407, 1, 15, 24, 10, 473,
   649, 495, 645, 549, 518, 643, 0, 642, 511, 637,
   521, 632, 629, 502, 622, 620, 616, 614, 610, 609,
   606, 605, 604, 603, 600, 599, 19, 597, 490, 591,
   590, 581, 580, 578, 576, 574, 566, 493, 564, 563,
   555, 554, 553, 551, 545, 544, 543, 536, 535, 534,
515, 506};
__YYSCLASS yytabelem exp_yyr1[] = {

   0, 25, 102, 102, 102, 101, 101, 26, 26, 5,
   5, 4, 27, 27, 27, 27, 84, 84, 85, 85,
   85, 85, 107, 62, 86, 63, 78, 78, 78, 28,
   28, 87, 87, 82, 82, 82, 82, 82, 82, 82,
   108, 108, 109, 109, 109, 7, 7, 93, 1, 29,
   29, 30, 31, 31, 2, 2, 64, 65, 8, 8,
   112, 113, 113, 104, 103, 103, 103, 103, 33, 33,
   97, 51, 51, 3, 114, 118, 119, 66, 6, 6,
   50, 50, 58, 58, 34, 120, 100, 121, 121, 9,
   9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
   9, 9, 9, 9, 19, 19, 19, 19, 19, 19,
   19, 19, 19, 35, 35, 59, 59, 36, 37, 37,
   38, 38, 80, 80, 80, 80, 10, 115, 124, 123,
   76, 76, 88, 88, 88, 88, 88, 88, 88, 88,
   88, 81, 81, 39, 39, 12, 12, 12, 67, 67,
   110, 125, 94, 13, 126, 126, 127, 127, 128, 129,
   130, 129, 131, 132, 131, 133, 133, 134, 134, 14,
   91, 91, 91, 91, 91, 48, 48, 96, 49, 49,
   95, 89, 89, 15, 15, 15, 15, 15, 15, 15,
   16, 136, 136, 137, 137, 105, 79, 40, 40, 41,
   138, 56, 56, 56, 56, 56, 57, 57, 17, 17,
   68, 68, 116, 140, 139, 77, 77, 21, 21, 21,
   21, 141, 18, 55, 55, 55, 55, 55, 55, 55,
   55, 69, 69, 70, 70, 135, 111, 98, 53, 53,
   143, 142, 144, 144, 122, 122, 145, 83, 106, 90,
   90, 71, 72, 72, 72, 72, 72, 72, 72, 72,
   72, 72, 42, 42, 42, 73, 73, 73, 73, 43,
   74, 74, 74, 22, 22, 22, 45, 45, 75, 75,
   75, 92, 92, 92, 92, 146, 146, 148, 149, 147,
   150, 117, 151, 117, 11, 11, 20, 20, 20, 20,
   20, 20, 20, 20, 20, 20, 20, 60, 60, 61,
   61, 54, 54, 47, 47, 46, 46, 52, 52, 23,
23, 99, 99, 32, 32, 44, 44, 24, 24};
__YYSCLASS yytabelem exp_yyr2[] = {

   0, 5, 2, 2, 2, 0, 4, 7, 5, 5,
   7, 3, 3, 7, 7, 11, 7, 11, 3, 3,
   3, 3, 1, 19, 11, 9, 3, 3, 3, 1,
   5, 9, 7, 3, 5, 5, 3, 3, 7, 7,
   0, 4, 2, 2, 2, 1, 5, 11, 7, 1,
   5, 5, 3, 7, 1, 7, 13, 9, 3, 3,
   13, 0, 4, 8, 2, 2, 2, 2, 1, 5,
   11, 3, 5, 11, 13, 5, 7, 5, 3, 11,
   3, 7, 1, 3, 11, 1, 4, 0, 4, 3,
   7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
   7, 7, 7, 7, 3, 7, 7, 7, 7, 7,
   7, 7, 7, 3, 7, 1, 3, 9, 1, 7,
   3, 7, 3, 3, 3, 3, 5, 9, 1, 15,
   3, 3, 3, 9, 11, 7, 9, 9, 11, 7,
   9, 3, 7, 3, 7, 3, 3, 3, 13, 17,
   7, 13, 11, 5, 3, 7, 2, 6, 6, 9,
   1, 12, 9, 1, 12, 2, 2, 0, 4, 15,
   3, 7, 9, 9, 7, 3, 5, 13, 1, 5,
   11, 11, 9, 3, 3, 3, 3, 3, 3, 3,
   5, 9, 11, 0, 4, 9, 3, 3, 7, 7,
   2, 1, 3, 3, 5, 5, 1, 3, 1, 7,
   7, 5, 9, 1, 11, 3, 3, 5, 5, 7,
   11, 1, 19, 3, 3, 3, 3, 3, 3, 3,
   3, 17, 15, 5, 11, 3, 11, 3, 3, 7,
   1, 17, 4, 6, 9, 2, 7, 9, 3, 9,
   7, 5, 3, 3, 3, 3, 3, 3, 3, 3,
   3, 3, 1, 5, 5, 1, 3, 3, 5, 11,
   5, 11, 13, 3, 7, 7, 3, 7, 3, 9,
   7, 3, 3, 3, 3, 2, 3, 1, 1, 12,
   1, 10, 1, 12, 5, 3, 3, 5, 3, 3,
   3, 7, 3, 3, 5, 5, 5, 1, 3, 3,
   11, 3, 7, 5, 9, 3, 5, 1, 5, 1,
5, 5, 9, 3, 5, 1, 5, 1, 5};
__YYSCLASS yytabelem exp_yychk[] = {

   -3000, -100, -120, -121, -122, -145, -110, 353, 327, -144,
   -134, 375, 371, 316, -133, -108, -104, -131, -129, 298,
   367, 346, -106, 355, -106, -106, -109, -103, -110, -111,
   -114, -115, -116, -117, -142, -118, -123, -139, 364, 352,
   318, 324, 342, -108, -113, -112, -12, 376, 344, 375,
   323, 323, -25, -101, -102, -103, -104, -105, 333, -73,
   -74, -43, 283, 361, 359, -25, -25, -147, 375, 375,
   375, 375, 375, 306, -113, 296, 375, 375, -44, 369,
   -42, -106, -72, -62, -63, -64, -65, -66, -67, -68,
   -69, -70, -71, 285, -11, 295, 291, 320, 326, -77,
   347, 348, 357, -12, 375, 374, -101, -137, -136, -39,
   375, -106, -43, 361, 337, 337, 309, 313, -150, -44,
   261, 322, -124, -140, -106, -78, -85, -82, -79, -86,
   -87, -89, -90, 293, 328, 345, 336, 334, 292, 358,
   375, 287, 290, 332, 356, -106, -132, -106, -130, 315,
   -32, -99, -9, 375, -19, -20, -5, -15, -10, -12,
   331, -14, -18, 279, 272, 271, 282, 377, 378, 371,
   372, 379, 380, -8, -76, 330, 343, 341, 300, 373,
   -42, -42, 375, 289, -21, 280, 281, 282, -9, 375,
   -42, -106, -9, -26, -106, 331, -125, -24, 375, 370,
   -106, 331, -106, 311, -137, 297, 296, -3, -28, 337,
   331, 331, -106, -106, 317, -151, -148, 331, -37, 331,
   -37, 289, -17, 331, -17, -17, -17, -94, 282, -95,
   337, 282, -95, 337, -95, 337, -128, 331, -128, -106,
   -99, 259, 257, 258, 268, 263, 261, 267, 262, 270,
   265, 266, 264, 269, -106, 296, -93, 277, 278, 276,
   273, 275, 274, 272, 271, 330, -21, -9, -20, -20,
   -20, 349, -27, -4, -9, -26, -19, 331, 322, -9,
   375, 375, -19, 337, 303, 362, -106, -35, 351, -9,
   -24, -23, 366, 289, -9, -9, -106, 375, -80, -82,
   -88, -79, -81, -84, 287, 290, 332, 356, 325, 284,
   308, -34, -33, -50, 301, -6, 375, 376, 331, -22,
   -75, -12, -138, 331, 338, -40, -79, -106, 317, -146,
   -119, -92, 319, -85, -82, -79, -83, 354, -143, 296,
   -38, -36, -59, 368, -106, -9, -9, -57, 321, -57,
   337, -9, 337, -78, -9, 337, -60, 365, 337, -78,
   -106, -127, -126, 375, -106, -9, -9, -9, -9, -9,
   -9, -9, -9, -9, -9, -9, -9, -9, -9, -19,
   -19, -19, -19, -19, -19, -19, -19, -19, -9, 351,
   349, 297, 296, -55, 268, 263, 261, 267, 262, 270,
   265, 266, 375, -11, -106, 349, 296, -30, -29, -106,
   -42, 351, 297, -23, -106, -9, -9, 351, -106, -16,
   289, 337, -94, 337, -94, 337, -94, 337, -94, 296,
   337, 296, -106, -49, 329, 297, 296, -51, -97, -6,
   281, -22, 351, 259, 260, 331, -22, 297, 351, -106,
   -149, 337, 331, -53, -98, 375, -80, 351, -106, -39,
   -106, 351, -56, 339, 365, 296, -78, 296, -60, -78,
   -78, 297, 351, 288, -106, 296, -4, -9, -19, 286,
   -106, -19, 305, -1, -2, -31, 340, -9, 310, 302,
   -9, -106, -42, 363, -106, -106, -9, -56, 337, -80,
   337, -60, 337, -80, 337, 375, -80, 375, -52, 365,
   -48, -96, 375, -6, -58, 339, -97, 296, 375, 351,
   -75, -75, -45, -22, 351, -79, -106, -41, 331, -40,
   297, 351, -106, -36, 296, -78, 365, 339, -9, -9,
   -78, -126, 375, -9, 296, -55, -9, -107, 349, -106,
   296, 297, 296, -106, -42, -42, 314, -9, -80, -56,
   -80, -80, -60, -80, 337, -44, -46, -47, -54, 375,
   -61, 376, -96, 296, -78, -78, 280, 297, 351, -39,
   351, -98, -106, -80, 349, 349, 350, -9, -19, 360,
   -42, -72, -9, -72, 310, 314, -106, -7, 294, -80,
   -80, -80, -47, 297, -106, 296, 281, -91, -79, 356,
   290, -106, -13, 289, 375, -22, 351, -135, 350, -141,
   304, -106, -106, -9, -61, 375, -54, 375, 322, 337,
   -95, -95, 337, -106, -9, -9, -106, -106, 280, 375,
-79, 337, 337, -79, 351, 375, -106, -79, -79};
__YYSCLASS yytabelem exp_yydef[] = {

   85, -2, 87, 86, 88, 167, 245, 0, 0, 0,
   40, 0, 0, 0, 168, 242, 40, 165, 166, 61,
   0, 0, 246, 248, 150, 244, 41, 42, 43, 44,
   64, 65, 66, 67, 5, 265, 5, 5, 0, 0,
   0, 0, 0, 243, 0, 61, 0, 145, 146, 147,
   0, 0, 325, 262, 5, 2, 3, 4, 193, 0,
   266, 267, 0, 0, 0, 0, 0, 290, 0, 0,
   75, 128, 213, 0, 62, 0, 163, 160, 0, 0,
   1, 262, 262, 252, 253, 254, 255, 256, 257, 258,
   259, 260, 261, 0, 0, 0, 262, 0, 0, 0,
   327, 0, 0, 295, -2, 216, 6, 0, 193, 0,
   143, 29, 268, 270, 0, 0, 0, 0, 0, 292,
   287, 0, 118, 118, 63, 0, 26, 27, 28, 18,
   19, 20, 21, 33, 208, 208, 36, 37, 208, 208,
   196, 0, 0, 0, 0, 162, 0, 159, 0, 0,
   326, 323, 0, -2, 89, 104, 296, 298, 299, 300,
   0, 302, 303, 0, 0, 0, 0, 183, 184, 185,
   186, 187, 188, 189, 0, 0, 0, 58, 59, 131,
   263, 264, 0, 0, 294, 0, 0, 0, 0, -2,
   0, 77, 0, 0, 211, 0, 327, 319, 0, 0,
   233, 0, 251, 0, 194, 0, 0, 0, 68, 0,
   0, 0, 127, 212, 0, 0, 0, 240, 0, 115,
   0, 0, 34, 0, 35, 206, 206, 0, 0, 0,
   0, 0, 0, 307, 0, 0, 0, 0, 0, 236,
   324, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 321, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 297, 0, 304, 305,
   306, 9, 0, 12, 11, 126, 0, 0, 0, 0,
   217, 218, 0, 49, 0, 262, 210, 0, 8, 113,
   319, 0, 0, 0, 328, 0, 195, 144, 0, 122,
   123, 124, 125, 132, 0, 0, 0, 0, 141, 0,
   0, 30, 178, 0, 0, 80, 78, 0, 0, 0,
   273, 278, 0, 0, 200, 0, 197, 291, 0, 288,
   285, 286, 0, 281, 282, 283, 284, 0, 0, 0,
   0, 120, 0, 116, 214, 0, 0, 38, 207, 39,
   201, 0, 0, 32, 0, 307, 0, 308, 0, 250,
   164, 0, 156, 154, 161, 90, 91, 92, 93, 94,
   95, 96, 97, 98, 99, 100, 101, 102, 0, 103,
   105, 106, 107, 108, 109, 110, 111, 112, 0, 301,
   10, 0, 0, 0, 223, 224, 225, 226, 227, 228,
   229, 230, 0, 0, 25, 219, 0, 0, 54, 57,
   0, 7, 0, 0, 262, 320, 0, 0, 191, 0,
   0, 201, 0, 0, 0, 307, 0, 0, 0, 0,
   0, 0, 74, 317, 0, 0, 82, 69, 71, 0,
   0, 0, 271, 0, 0, 0, 0, 0, 269, 293,
   0, 0, 0, 0, 238, 237, 0, 119, 115, 0,
   60, 209, 0, 202, 203, 0, 31, 0, 0, 182,
   249, 0, 158, 0, 322, 0, 14, 13, 0, 0,
   22, 0, 0, 50, 51, 0, 0, 52, 0, 262,
   114, 262, 0, 0, 234, 192, 190, 0, 201, 135,
   0, 0, 307, 139, 0, 142, 16, 0, 325, 0,
   179, 175, 0, 81, 0, 83, 72, 0, 0, 272,
   274, 275, 0, 276, 280, 198, 289, 76, 0, 0,
   0, 0, 129, 121, 0, 24, 204, 205, 0, 0,
   181, 157, 155, 0, 0, 0, 0, 262, 220, 56,
   0, 0, 0, 148, 0, 0, 0, 45, 133, 0,
   136, 137, 0, 140, 0, 73, 318, 315, 0, 309,
   311, 0, 176, 0, 0, 0, 0, 0, 279, 0,
   247, 239, 241, 117, 152, 180, 47, 15, 0, 221,
   0, 48, 53, 55, 0, 0, 232, 151, 0, 134,
   138, 17, 316, 0, 313, 0, 0, 0, 170, 0,
   0, 84, 0, 0, 79, 277, 199, 169, 235, 0,
   0, 149, 231, 46, 312, 309, 0, 0, 0, 0,
   0, 0, 0, 70, 153, 0, 23, 314, 0, 0,
171, 0, 0, 174, 222, 310, 177, 172, 173};
typedef struct {
   char *t_name;
   int t_val;
} yytoktype;
#ifndef YYDEBUG
#	define YYDEBUG	0             /* don't allow debugging */
#endif

#if YYDEBUG

__YYSCLASS yytoktype yytoks[] =
{
   "TOK_OR", 257,
   "TOK_XOR", 258,
   "TOK_AND", 259,
   "TOK_ANDOR", 260,
   "TOK_EQUAL", 261,
   "TOK_GREATER_EQUAL", 262,
   "TOK_GREATER_THAN", 263,
   "TOK_IN", 264,
   "TOK_INST_EQUAL", 265,
   "TOK_INST_NOT_EQUAL", 266,
   "TOK_LESS_EQUAL", 267,
   "TOK_LESS_THAN", 268,
   "TOK_LIKE", 269,
   "TOK_NOT_EQUAL", 270,
   "TOK_MINUS", 271,
   "TOK_PLUS", 272,
   "TOK_DIV", 273,
   "TOK_MOD", 274,
   "TOK_REAL_DIV", 275,
   "TOK_TIMES", 276,
   "TOK_CONCAT_OP", 277,
   "TOK_EXP", 278,
   "TOK_NOT", 279,
   "TOK_DOT", 280,
   "TOK_BACKSLASH", 281,
   "TOK_LEFT_BRACKET", 282,
   "TOK_ABSTRACT", 283,
   "TOK_AGGREGATE", 284,
   "TOK_ALIAS", 285,
   "TOK_ALL_IN", 286,
   "TOK_ARRAY", 287,
   "TOK_AS", 288,
   "TOK_ASSIGNMENT", 289,
   "TOK_BAG", 290,
   "TOK_BEGIN", 291,
   "TOK_BINARY", 292,
   "TOK_BOOLEAN", 293,
   "TOK_BY", 294,
   "TOK_CASE", 295,
   "TOK_COLON", 296,
   "TOK_COMMA", 297,
   "TOK_CONSTANT", 298,
   "TOK_CONTEXT", 299,
   "TOK_E", 300,
   "TOK_DERIVE", 301,
   "TOK_ELSE", 302,
   "TOK_END", 303,
   "TOK_END_ALIAS", 304,
   "TOK_END_CASE", 305,
   "TOK_END_CONSTANT", 306,
   "TOK_END_CONTEXT", 307,
   "TOK_END_ENTITY", 308,
   "TOK_END_FUNCTION", 309,
   "TOK_END_IF", 310,
   "TOK_END_LOCAL", 311,
   "TOK_END_MODEL", 312,
   "TOK_END_PROCEDURE", 313,
   "TOK_END_REPEAT", 314,
   "TOK_END_RULE", 315,
   "TOK_END_SCHEMA", 316,
   "TOK_END_TYPE", 317,
   "TOK_ENTITY", 318,
   "TOK_ENUMERATION", 319,
   "TOK_ESCAPE", 320,
   "TOK_FIXED", 321,
   "TOK_FOR", 322,
   "TOK_FROM", 323,
   "TOK_FUNCTION", 324,
   "TOK_GENERIC", 325,
   "TOK_IF", 326,
   "TOK_INCLUDE", 327,
   "TOK_INTEGER", 328,
   "TOK_INVERSE", 329,
   "TOK_LEFT_CURL", 330,
   "TOK_LEFT_PAREN", 331,
   "TOK_LIST", 332,
   "TOK_LOCAL", 333,
   "TOK_LOGICAL", 334,
   "TOK_MODEL", 335,
   "TOK_NUMBER", 336,
   "TOK_OF", 337,
   "TOK_ONEOF", 338,
   "TOK_OPTIONAL", 339,
   "TOK_OTHERWISE", 340,
   "TOK_PI", 341,
   "TOK_PROCEDURE", 342,
   "TOK_QUERY", 343,
   "TOK_QUESTION_MARK", 344,
   "TOK_REAL", 345,
   "TOK_REFERENCE", 346,
   "TOK_REPEAT", 347,
   "TOK_RETURN", 348,
   "TOK_RIGHT_BRACKET", 349,
   "TOK_RIGHT_CURL", 350,
   "TOK_RIGHT_PAREN", 351,
   "TOK_RULE", 352,
   "TOK_SCHEMA", 353,
   "TOK_SELECT", 354,
   "TOK_SEMICOLON", 355,
   "TOK_SET", 356,
   "TOK_SKIP", 357,
   "TOK_STRING", 358,
   "TOK_SUBTYPE", 359,
   "TOK_SUCH_THAT", 360,
   "TOK_SUPERTYPE", 361,
   "TOK_THEN", 362,
   "TOK_TO", 363,
   "TOK_TYPE", 364,
   "TOK_UNIQUE", 365,
   "TOK_UNTIL", 366,
   "TOK_USE", 367,
   "TOK_VAR", 368,
   "TOK_WHERE", 369,
   "TOK_WHILE", 370,
   "TOK_STRING_LITERAL", 371,
   "TOK_STRING_LITERAL_ENCODED", 372,
   "TOK_BUILTIN_FUNCTION", 373,
   "TOK_BUILTIN_PROCEDURE", 374,
   "TOK_IDENTIFIER", 375,
   "TOK_SELF", 376,
   "TOK_INTEGER_LITERAL", 377,
   "TOK_REAL_LITERAL", 378,
   "TOK_LOGICAL_LITERAL", 379,
   "TOK_BINARY_LITERAL", 380,
   "-unknown-", -1              /* ends search */
};

__YYSCLASS char *yyreds[] =
{
   "-no such reduction-",
   "action_body : action_body_item_rep statement_rep",
   "action_body_item : declaration",
   "action_body_item : constant_decl",
   "action_body_item : local_decl",
   "action_body_item_rep : /* empty */",
   "action_body_item_rep : action_body_item action_body_item_rep",
   "actual_parameters : TOK_LEFT_PAREN expression_list TOK_RIGHT_PAREN",
   "actual_parameters : TOK_LEFT_PAREN TOK_RIGHT_PAREN",
   "aggregate_initializer : TOK_LEFT_BRACKET TOK_RIGHT_BRACKET",
   "aggregate_initializer : TOK_LEFT_BRACKET aggregate_init_body TOK_RIGHT_BRACKET",
   "aggregate_init_element : expression",
   "aggregate_init_body : aggregate_init_element",
   "aggregate_init_body : aggregate_init_element TOK_COLON expression",
   "aggregate_init_body : aggregate_init_body TOK_COMMA aggregate_init_element",
   "aggregate_init_body : aggregate_init_body TOK_COMMA aggregate_init_element TOK_COLON expression",
   "aggregate_type : TOK_AGGREGATE TOK_OF parameter_type",
   "aggregate_type : TOK_AGGREGATE TOK_COLON TOK_IDENTIFIER TOK_OF parameter_type",
   "aggregation_type : array_type",
   "aggregation_type : bag_type",
   "aggregation_type : list_type",
   "aggregation_type : set_type",
   "alias_statement : TOK_ALIAS TOK_IDENTIFIER TOK_FOR general_ref semicolon",
   "alias_statement : TOK_ALIAS TOK_IDENTIFIER TOK_FOR general_ref semicolon statement_rep TOK_END_ALIAS semicolon",
   "array_type : TOK_ARRAY index_spec TOK_OF optional_or_unique attribute_type",
   "assignment_statement : general_ref TOK_ASSIGNMENT expression semicolon",
   "attribute_type : aggregation_type",
   "attribute_type : basic_type",
   "attribute_type : defined_type",
   "explicit_attr_list : /* empty */",
   "explicit_attr_list : explicit_attr_list explicit_attribute",
   "bag_type : TOK_BAG limit_spec TOK_OF attribute_type",
   "bag_type : TOK_BAG TOK_OF attribute_type",
   "basic_type : TOK_BOOLEAN",
   "basic_type : TOK_INTEGER precision_spec",
   "basic_type : TOK_REAL precision_spec",
   "basic_type : TOK_NUMBER",
   "basic_type : TOK_LOGICAL",
   "basic_type : TOK_BINARY precision_spec optional_fixed",
   "basic_type : TOK_STRING precision_spec optional_fixed",
   "block_list : /* empty */",
   "block_list : block_list block_member",
   "block_member : declaration",
   "block_member : include_directive",
   "block_member : rule_decl",
   "by_expression : /* empty */",
   "by_expression : TOK_BY expression",
   "cardinality_op : TOK_LEFT_CURL expression TOK_COLON expression TOK_RIGHT_CURL",
   "case_action : case_labels TOK_COLON statement",
   "case_action_list : /* empty */",
   "case_action_list : case_action_list case_action",
   "case_block : case_action_list case_otherwise",
   "case_labels : expression",
   "case_labels : case_labels TOK_COMMA expression",
   "case_otherwise : /* empty */",
   "case_otherwise : TOK_OTHERWISE TOK_COLON statement",
   "case_statement : TOK_CASE expression TOK_OF case_block TOK_END_CASE semicolon",
   "compound_statement : TOK_BEGIN statement_rep TOK_END semicolon",
   "constant : TOK_PI",
   "constant : TOK_E",
   "constant_body : identifier TOK_COLON attribute_type TOK_ASSIGNMENT expression semicolon",
   "constant_body_list : /* empty */",
   "constant_body_list : constant_body constant_body_list",
   "constant_decl : TOK_CONSTANT constant_body_list TOK_END_CONSTANT semicolon",
   "declaration : entity_decl",
   "declaration : function_decl",
   "declaration : procedure_decl",
   "declaration : type_decl",
   "derive_decl : /* empty */",
   "derive_decl : TOK_DERIVE derived_attribute_rep",
   "derived_attribute : attribute_decl TOK_COLON attribute_type initializer semicolon",
   "derived_attribute_rep : derived_attribute",
   "derived_attribute_rep : derived_attribute_rep derived_attribute",
   "entity_body : explicit_attr_list derive_decl inverse_clause unique_clause where_rule",
   "entity_decl : entity_header subsuper_decl semicolon entity_body TOK_END_ENTITY semicolon",
   "entity_header : TOK_ENTITY TOK_IDENTIFIER",
   "enumeration_type : TOK_ENUMERATION TOK_OF nested_id_list",
   "escape_statement : TOK_ESCAPE semicolon",
   "attribute_decl : TOK_IDENTIFIER",
   "attribute_decl : TOK_SELF TOK_BACKSLASH TOK_IDENTIFIER TOK_DOT TOK_IDENTIFIER",
   "attribute_decl_list : attribute_decl",
   "attribute_decl_list : attribute_decl_list TOK_COMMA attribute_decl",
   "optional : /* empty */",
   "optional : TOK_OPTIONAL",
   "explicit_attribute : attribute_decl_list TOK_COLON optional attribute_type semicolon",
   "express_file : /* empty */",
   "express_file : schema_decl_list",
   "schema_decl_list : /* empty */",
   "schema_decl_list : schema_decl_list schema_decl",
   "expression : simple_expression",
   "expression : expression TOK_AND expression",
   "expression : expression TOK_OR expression",
   "expression : expression TOK_XOR expression",
   "expression : expression TOK_LESS_THAN expression",
   "expression : expression TOK_GREATER_THAN expression",
   "expression : expression TOK_EQUAL expression",
   "expression : expression TOK_LESS_EQUAL expression",
   "expression : expression TOK_GREATER_EQUAL expression",
   "expression : expression TOK_NOT_EQUAL expression",
   "expression : expression TOK_INST_EQUAL expression",
   "expression : expression TOK_INST_NOT_EQUAL expression",
   "expression : expression TOK_IN expression",
   "expression : expression TOK_LIKE expression",
   "expression : simple_expression cardinality_op simple_expression",
   "simple_expression : unary_expression",
   "simple_expression : simple_expression TOK_CONCAT_OP simple_expression",
   "simple_expression : simple_expression TOK_EXP simple_expression",
   "simple_expression : simple_expression TOK_TIMES simple_expression",
   "simple_expression : simple_expression TOK_DIV simple_expression",
   "simple_expression : simple_expression TOK_REAL_DIV simple_expression",
   "simple_expression : simple_expression TOK_MOD simple_expression",
   "simple_expression : simple_expression TOK_PLUS simple_expression",
   "simple_expression : simple_expression TOK_MINUS simple_expression",
   "expression_list : expression",
   "expression_list : expression_list TOK_COMMA expression",
   "var : /* empty */",
   "var : TOK_VAR",
   "formal_parameter : var id_list TOK_COLON parameter_type",
   "formal_parameter_list : /* empty */",
   "formal_parameter_list : TOK_LEFT_PAREN formal_parameter_rep TOK_RIGHT_PAREN",
   "formal_parameter_rep : formal_parameter",
   "formal_parameter_rep : formal_parameter_rep semicolon formal_parameter",
   "parameter_type : basic_type",
   "parameter_type : conformant_aggregation",
   "parameter_type : defined_type",
   "parameter_type : generic_type",
   "function_call : function_id actual_parameters",
   "function_decl : function_header action_body TOK_END_FUNCTION semicolon",
   "function_header : TOK_FUNCTION TOK_IDENTIFIER",
   "function_header : TOK_FUNCTION TOK_IDENTIFIER formal_parameter_list TOK_COLON parameter_type semicolon",
   "function_id : TOK_IDENTIFIER",
   "function_id : TOK_BUILTIN_FUNCTION",
   "conformant_aggregation : aggregate_type",
   "conformant_aggregation : TOK_ARRAY TOK_OF optional_or_unique parameter_type",
   "conformant_aggregation : TOK_ARRAY index_spec TOK_OF optional_or_unique parameter_type",
   "conformant_aggregation : TOK_BAG TOK_OF parameter_type",
   "conformant_aggregation : TOK_BAG index_spec TOK_OF parameter_type",
   "conformant_aggregation : TOK_LIST TOK_OF unique parameter_type",
   "conformant_aggregation : TOK_LIST index_spec TOK_OF unique parameter_type",
   "conformant_aggregation : TOK_SET TOK_OF parameter_type",
   "conformant_aggregation : TOK_SET index_spec TOK_OF parameter_type",
   "generic_type : TOK_GENERIC",
   "generic_type : TOK_GENERIC TOK_COLON TOK_IDENTIFIER",
   "id_list : TOK_IDENTIFIER",
   "id_list : id_list TOK_COMMA TOK_IDENTIFIER",
   "identifier : TOK_SELF",
   "identifier : TOK_QUESTION_MARK",
   "identifier : TOK_IDENTIFIER",
   "if_statement : TOK_IF expression TOK_THEN statement_rep TOK_END_IF semicolon",
   "if_statement : TOK_IF expression TOK_THEN statement_rep TOK_ELSE statement_rep TOK_END_IF semicolon",
   "include_directive : TOK_INCLUDE TOK_STRING_LITERAL semicolon",
   "increment_control : TOK_IDENTIFIER TOK_ASSIGNMENT expression TOK_TO expression by_expression",
   "index_spec : TOK_LEFT_BRACKET expression TOK_COLON expression TOK_RIGHT_BRACKET",
   "initializer : TOK_ASSIGNMENT expression",
   "rename : TOK_IDENTIFIER",
   "rename : TOK_IDENTIFIER TOK_AS TOK_IDENTIFIER",
   "rename_list : rename",
   "rename_list : rename_list TOK_COMMA rename",
   "parened_rename_list : TOK_LEFT_PAREN rename_list TOK_RIGHT_PAREN",
   "reference_clause : TOK_REFERENCE TOK_FROM TOK_IDENTIFIER semicolon",
   "reference_clause : TOK_REFERENCE TOK_FROM TOK_IDENTIFIER",
   "reference_clause : TOK_REFERENCE TOK_FROM TOK_IDENTIFIER parened_rename_list semicolon",
   "use_clause : TOK_USE TOK_FROM TOK_IDENTIFIER semicolon",
   "use_clause : TOK_USE TOK_FROM TOK_IDENTIFIER",
   "use_clause : TOK_USE TOK_FROM TOK_IDENTIFIER parened_rename_list semicolon",
   "interface_specification : use_clause",
   "interface_specification : reference_clause",
   "interface_specification_list : /* empty */",
   "interface_specification_list : interface_specification_list interface_specification",
   "interval : TOK_LEFT_CURL simple_expression rel_op simple_expression rel_op simple_expression right_curl",
   "set_or_bag_of_entity : defined_type",
   "set_or_bag_of_entity : TOK_SET TOK_OF defined_type",
   "set_or_bag_of_entity : TOK_SET limit_spec TOK_OF defined_type",
   "set_or_bag_of_entity : TOK_BAG limit_spec TOK_OF defined_type",
   "set_or_bag_of_entity : TOK_BAG TOK_OF defined_type",
   "inverse_attr_list : inverse_attr",
   "inverse_attr_list : inverse_attr_list inverse_attr",
   "inverse_attr : TOK_IDENTIFIER TOK_COLON set_or_bag_of_entity TOK_FOR TOK_IDENTIFIER semicolon",
   "inverse_clause : /* empty */",
   "inverse_clause : TOK_INVERSE inverse_attr_list",
   "limit_spec : TOK_LEFT_BRACKET expression TOK_COLON expression TOK_RIGHT_BRACKET",
   "list_type : TOK_LIST limit_spec TOK_OF unique attribute_type",
   "list_type : TOK_LIST TOK_OF unique attribute_type",
   "literal : TOK_INTEGER_LITERAL",
   "literal : TOK_REAL_LITERAL",
   "literal : TOK_STRING_LITERAL",
   "literal : TOK_STRING_LITERAL_ENCODED",
   "literal : TOK_LOGICAL_LITERAL",
   "literal : TOK_BINARY_LITERAL",
   "literal : constant",
   "local_initializer : TOK_ASSIGNMENT expression",
   "local_variable : id_list TOK_COLON parameter_type semicolon",
   "local_variable : id_list TOK_COLON parameter_type local_initializer semicolon",
   "local_body : /* empty */",
   "local_body : local_variable local_body",
   "local_decl : TOK_LOCAL local_body TOK_END_LOCAL semicolon",
   "defined_type : TOK_IDENTIFIER",
   "defined_type_list : defined_type",
   "defined_type_list : defined_type_list TOK_COMMA defined_type",
   "nested_id_list : TOK_LEFT_PAREN id_list TOK_RIGHT_PAREN",
   "oneof_op : TOK_ONEOF",
   "optional_or_unique : /* empty */",
   "optional_or_unique : TOK_OPTIONAL",
   "optional_or_unique : TOK_UNIQUE",
   "optional_or_unique : TOK_OPTIONAL TOK_UNIQUE",
   "optional_or_unique : TOK_UNIQUE TOK_OPTIONAL",
   "optional_fixed : /* empty */",
   "optional_fixed : TOK_FIXED",
   "precision_spec : /* empty */",
   "precision_spec : TOK_LEFT_PAREN expression TOK_RIGHT_PAREN",
   "proc_call_statement : procedure_id actual_parameters semicolon",
   "proc_call_statement : procedure_id semicolon",
   "procedure_decl : procedure_header action_body TOK_END_PROCEDURE semicolon",
   "procedure_header : TOK_PROCEDURE TOK_IDENTIFIER",
   "procedure_header : TOK_PROCEDURE TOK_IDENTIFIER formal_parameter_list semicolon",
   "procedure_id : TOK_IDENTIFIER",
   "procedure_id : TOK_BUILTIN_PROCEDURE",
   "qualifier : TOK_DOT TOK_IDENTIFIER",
   "qualifier : TOK_BACKSLASH TOK_IDENTIFIER",
   "qualifier : TOK_LEFT_BRACKET simple_expression TOK_RIGHT_BRACKET",
   "qualifier : TOK_LEFT_BRACKET simple_expression TOK_COLON simple_expression TOK_RIGHT_BRACKET",
   "query_expression : TOK_QUERY TOK_LEFT_PAREN TOK_IDENTIFIER TOK_ALL_IN expression TOK_SUCH_THAT",
   "query_expression : TOK_QUERY TOK_LEFT_PAREN TOK_IDENTIFIER TOK_ALL_IN expression TOK_SUCH_THAT expression TOK_RIGHT_PAREN",
   "rel_op : TOK_LESS_THAN",
   "rel_op : TOK_GREATER_THAN",
   "rel_op : TOK_EQUAL",
   "rel_op : TOK_LESS_EQUAL",
   "rel_op : TOK_GREATER_EQUAL",
   "rel_op : TOK_NOT_EQUAL",
   "rel_op : TOK_INST_EQUAL",
   "rel_op : TOK_INST_NOT_EQUAL",
   "repeat_statement : TOK_REPEAT increment_control while_control until_control semicolon statement_rep TOK_END_REPEAT semicolon",
   "repeat_statement : TOK_REPEAT while_control until_control semicolon statement_rep TOK_END_REPEAT semicolon",
   "return_statement : TOK_RETURN semicolon",
   "return_statement : TOK_RETURN TOK_LEFT_PAREN expression TOK_RIGHT_PAREN semicolon",
   "right_curl : TOK_RIGHT_CURL",
   "rule_decl : rule_header action_body where_rule TOK_END_RULE semicolon",
   "rule_formal_parameter : TOK_IDENTIFIER",
   "rule_formal_parameter_list : rule_formal_parameter",
   "rule_formal_parameter_list : rule_formal_parameter_list TOK_COMMA rule_formal_parameter",
   "rule_header : TOK_RULE TOK_IDENTIFIER TOK_FOR TOK_LEFT_PAREN",
   "rule_header : TOK_RULE TOK_IDENTIFIER TOK_FOR TOK_LEFT_PAREN rule_formal_parameter_list TOK_RIGHT_PAREN semicolon",
   "schema_body : interface_specification_list block_list",
   "schema_body : interface_specification_list constant_decl block_list",
   "schema_decl : schema_header schema_body TOK_END_SCHEMA semicolon",
   "schema_decl : include_directive",
   "schema_header : TOK_SCHEMA TOK_IDENTIFIER semicolon",
   "select_type : TOK_SELECT TOK_LEFT_PAREN defined_type_list TOK_RIGHT_PAREN",
   "semicolon : TOK_SEMICOLON",
   "set_type : TOK_SET limit_spec TOK_OF attribute_type",
   "set_type : TOK_SET TOK_OF attribute_type",
   "skip_statement : TOK_SKIP semicolon",
   "statement : alias_statement",
   "statement : assignment_statement",
   "statement : case_statement",
   "statement : compound_statement",
   "statement : escape_statement",
   "statement : if_statement",
   "statement : proc_call_statement",
   "statement : repeat_statement",
   "statement : return_statement",
   "statement : skip_statement",
   "statement_rep : /* empty */",
   "statement_rep : semicolon statement_rep",
   "statement_rep : statement statement_rep",
   "subsuper_decl : /* empty */",
   "subsuper_decl : supertype_decl",
   "subsuper_decl : subtype_decl",
   "subsuper_decl : supertype_decl subtype_decl",
   "subtype_decl : TOK_SUBTYPE TOK_OF TOK_LEFT_PAREN defined_type_list TOK_RIGHT_PAREN",
   "supertype_decl : TOK_ABSTRACT TOK_SUPERTYPE",
   "supertype_decl : TOK_SUPERTYPE TOK_OF TOK_LEFT_PAREN supertype_expression TOK_RIGHT_PAREN",
   "supertype_decl : TOK_ABSTRACT TOK_SUPERTYPE TOK_OF TOK_LEFT_PAREN supertype_expression TOK_RIGHT_PAREN",
   "supertype_expression : supertype_factor",
   "supertype_expression : supertype_expression TOK_AND supertype_factor",
   "supertype_expression : supertype_expression TOK_ANDOR supertype_factor",
   "supertype_expression_list : supertype_expression",
   "supertype_expression_list : supertype_expression_list TOK_COMMA supertype_expression",
   "supertype_factor : identifier",
   "supertype_factor : oneof_op TOK_LEFT_PAREN supertype_expression_list TOK_RIGHT_PAREN",
   "supertype_factor : TOK_LEFT_PAREN supertype_expression TOK_RIGHT_PAREN",
   "type : aggregation_type",
   "type : basic_type",
   "type : defined_type",
   "type : select_type",
   "type_item_body : enumeration_type",
   "type_item_body : type",
   "type_item : TOK_IDENTIFIER TOK_EQUAL",
   "type_item : TOK_IDENTIFIER TOK_EQUAL type_item_body",
   "type_item : TOK_IDENTIFIER TOK_EQUAL type_item_body semicolon",
   "type_decl : TOK_TYPE type_item",
   "type_decl : TOK_TYPE type_item TOK_END_TYPE semicolon",
   "type_decl : TOK_TYPE type_item where_rule",
   "type_decl : TOK_TYPE type_item where_rule TOK_END_TYPE semicolon",
   "general_ref : general_ref qualifier",
   "general_ref : identifier",
   "unary_expression : aggregate_initializer",
   "unary_expression : unary_expression qualifier",
   "unary_expression : literal",
   "unary_expression : function_call",
   "unary_expression : identifier",
   "unary_expression : TOK_LEFT_PAREN expression TOK_RIGHT_PAREN",
   "unary_expression : interval",
   "unary_expression : query_expression",
   "unary_expression : TOK_NOT unary_expression",
   "unary_expression : TOK_PLUS unary_expression",
   "unary_expression : TOK_MINUS unary_expression",
   "unique : /* empty */",
   "unique : TOK_UNIQUE",
   "qualified_attr : TOK_IDENTIFIER",
   "qualified_attr : TOK_SELF TOK_BACKSLASH TOK_IDENTIFIER TOK_DOT TOK_IDENTIFIER",
   "qualified_attr_list : qualified_attr",
   "qualified_attr_list : qualified_attr_list TOK_COMMA qualified_attr",
   "labelled_attrib_list : qualified_attr_list semicolon",
   "labelled_attrib_list : TOK_IDENTIFIER TOK_COLON qualified_attr_list semicolon",
   "labelled_attrib_list_list : labelled_attrib_list",
   "labelled_attrib_list_list : labelled_attrib_list_list labelled_attrib_list",
   "unique_clause : /* empty */",
   "unique_clause : TOK_UNIQUE labelled_attrib_list_list",
   "until_control : /* empty */",
   "until_control : TOK_UNTIL expression",
   "where_clause : expression semicolon",
   "where_clause : TOK_IDENTIFIER TOK_COLON expression semicolon",
   "where_clause_list : where_clause",
   "where_clause_list : where_clause_list where_clause",
   "where_rule : /* empty */",
   "where_rule : TOK_WHERE where_clause_list",
   "while_control : /* empty */",
   "while_control : TOK_WHILE expression",
};
#endif /* YYDEBUG */
#define YYFLAG  (-3000)
/* @(#) $Revision: 70.7 $ */

/*
** Skeleton parser driver for yacc output
*/

#if defined(NLS) && !defined(NL_SETN)
#include <msgbuf.h>
#endif

#ifndef nl_msg
#define nl_msg(i,s) (s)
#endif

/*
** yacc user known macros and defines
*/
#define YYERROR		goto yyerrlab

#ifndef __RUNTIME_YYMAXDEPTH
#define YYACCEPT	return(0)
#define YYABORT		return(1)
#else
#define YYACCEPT	{free_stacks(); return(0);}
#define YYABORT		{free_stacks(); return(1);}
#endif

#define YYBACKUP( newtoken, newvalue )\
{\
	if ( exp_yychar >= 0 || ( exp_yyr2[ yytmp ] >> 1 ) != 1 )\
	{\
		yyerror( (nl_msg(30001,"syntax error - cannot backup")) );\
		goto yyerrlab;\
	}\
	exp_yychar = newtoken;\
	yystate = *yyps;\
	exp_yylval = newvalue;\
	goto yynewstate;\
}
#define YYRECOVERING()	(!!exp_yyerrflag)
#ifndef YYDEBUG
#	define YYDEBUG	1             /* make debugging available */
#endif

/*
** user known globals
*/
int exp_yydebug;                /* set to 1 to get debugging */

/*
** driver internal defines
*/
/* define for YYFLAG now generated by yacc program. */
/*#define YYFLAG		(FLAGVAL)*/

/*
** global variables used by the parser
*/
# ifndef __RUNTIME_YYMAXDEPTH
__YYSCLASS exp_YYSTYPE exp_yyv[YYMAXDEPTH];  /* value stack */
__YYSCLASS int yys[YYMAXDEPTH]; /* state stack */
# else
__YYSCLASS exp_YYSTYPE *exp_yyv;/* pointer to malloc'ed value stack */
__YYSCLASS int *yys;            /* pointer to malloc'ed stack stack */

#if defined(__STDC__) || defined (__cplusplus)
#include <stdlib.h>
#else
extern char *malloc();
extern char *realloc();
extern void free();
#endif /* __STDC__ or __cplusplus */


static int allocate_stacks();
static void free_stacks();
# ifndef YYINCREMENT
# define YYINCREMENT (YYMAXDEPTH/2) + 10
# endif
# endif /* __RUNTIME_YYMAXDEPTH */
long yymaxdepth = YYMAXDEPTH;

__YYSCLASS exp_YYSTYPE *yypv;   /* top of value stack */
__YYSCLASS int *yyps;           /* top of state stack */

__YYSCLASS int yystate;         /* current state */
__YYSCLASS int yytmp;           /* extra var (lasts between blocks) */

int exp_yynerrs;                /* number of errors */
__YYSCLASS int exp_yyerrflag;   /* error recovery flag */
int exp_yychar;                 /* current input token number */



/*
** exp_yyparse - return 0 if worked, 1 if syntax error not recovered from
*/
int exp_yyparse()
{
   register exp_YYSTYPE *yypvt; /* top of value stack for $vars */

   /* * Initialize externals - exp_yyparse may be called more than once */
# ifdef __RUNTIME_YYMAXDEPTH
   if (allocate_stacks())
      YYABORT;
# endif
   yypv = &exp_yyv[-1];
   yyps = &yys[-1];
   yystate = 0;
   yytmp = 0;
   exp_yynerrs = 0;
   exp_yyerrflag = 0;
   exp_yychar = -1;

   goto yystack;
   {
      register exp_YYSTYPE *yy_pv;  /* top of value stack */
      register int *yy_ps;      /* top of state stack */
      register int yy_state;    /* current state */
      register int yy_n;        /* internal state number info */

      /* * get globals into registers. * branch to here only if YYBACKUP was called. */
yynewstate:
      yy_pv = yypv;
      yy_ps = yyps;
      yy_state = yystate;
      goto yy_newstate;

      /* * get globals into registers. * either we just started, or we just finished a reduction */
yystack:
      yy_pv = yypv;
      yy_ps = yyps;
      yy_state = yystate;

      /* * top of for (;;) loop while no reductions done */
yy_stack:
      /* * put a state and value onto the stacks */
#if YYDEBUG
      /* * if debugging, look up token value in list of value vs. * name pairs.  0 and negative (-1) are special
       * values. * Note: linear search is used since time is not a real * consideration while debugging. */
      if (exp_yydebug) {
         register int yy_i;

         printf("State %d, token ", yy_state);
         if (exp_yychar == 0)
            printf("end-of-file\n");
         else if (exp_yychar < 0)
            printf("-none-\n");
         else {
            for (yy_i = 0; yytoks[yy_i].t_val >= 0;
                 yy_i++) {
               if (yytoks[yy_i].t_val == exp_yychar)
                  break;
            }
            printf("%s\n", yytoks[yy_i].t_name);
         }
      }
#endif /* YYDEBUG */
      if (++yy_ps >= &yys[yymaxdepth]) {  /* room on stack? */
# ifndef __RUNTIME_YYMAXDEPTH
         yyerror((nl_msg(30002, "yacc stack overflow")));
         YYABORT;
# else
         /* save old stack bases to recalculate pointers */
         exp_YYSTYPE *exp_yyv_old = exp_yyv;
         int *yys_old = yys;
         yymaxdepth += YYINCREMENT;
         yys = (int *) realloc(yys, yymaxdepth * sizeof(int));
         exp_yyv = (exp_YYSTYPE *) realloc(exp_yyv, yymaxdepth * sizeof(exp_YYSTYPE));
         if (yys == 0 || exp_yyv == 0) {
            yyerror((nl_msg(30002, "yacc stack overflow")));
            YYABORT;
         }
         /* Reset pointers into stack */
         yy_ps = (yy_ps - yys_old) + yys;
         yyps = (yyps - yys_old) + yys;
         yy_pv = (yy_pv - exp_yyv_old) + exp_yyv;
         yypv = (yypv - exp_yyv_old) + exp_yyv;
# endif

      }
      *yy_ps = yy_state;
      *++yy_pv = exp_yyval;

      /* * we have a new state - find out what to do */
yy_newstate:
      if ((yy_n = exp_yypact[yy_state]) <= YYFLAG)
         goto exp_yydefault;    /* simple state */
#if YYDEBUG
      /* * if debugging, need to mark whether new token grabbed */
      yytmp = exp_yychar < 0;
#endif
      if ((exp_yychar < 0) && ((exp_yychar = exp_yylex()) < 0))
         exp_yychar = 0;        /* reached EOF */
#if YYDEBUG
      if (exp_yydebug && yytmp) {
         register int yy_i;

         printf("Received token ");
         if (exp_yychar == 0)
            printf("end-of-file\n");
         else if (exp_yychar < 0)
            printf("-none-\n");
         else {
            for (yy_i = 0; yytoks[yy_i].t_val >= 0;
                 yy_i++) {
               if (yytoks[yy_i].t_val == exp_yychar)
                  break;
            }
            printf("%s\n", yytoks[yy_i].t_name);
         }
      }
#endif /* YYDEBUG */
      if (((yy_n += exp_yychar) < 0) || (yy_n >= YYLAST))
         goto exp_yydefault;
      if (exp_yychk[yy_n = exp_yyact[yy_n]] == exp_yychar) {   /* valid shift */
         exp_yychar = -1;
         exp_yyval = exp_yylval;
         yy_state = yy_n;
         if (exp_yyerrflag > 0)
            exp_yyerrflag--;
         goto yy_stack;
      }

exp_yydefault:
      if ((yy_n = exp_yydef[yy_state]) == -2) {
#if YYDEBUG
         yytmp = exp_yychar < 0;
#endif
         if ((exp_yychar < 0) && ((exp_yychar = exp_yylex()) < 0))
            exp_yychar = 0;     /* reached EOF */
#if YYDEBUG
         if (exp_yydebug && yytmp) {
            register int yy_i;

            printf("Received token ");
            if (exp_yychar == 0)
               printf("end-of-file\n");
            else if (exp_yychar < 0)
               printf("-none-\n");
            else {
               for (yy_i = 0;
                    yytoks[yy_i].t_val >= 0;
                    yy_i++) {
                  if (yytoks[yy_i].t_val
                      == exp_yychar) {
                     break;
                  }
               }
               printf("%s\n", yytoks[yy_i].t_name);
            }
         }
#endif /* YYDEBUG */
         /* * look through exception table */
         {
            register int *yyxi = exp_yyexca;

            while ((*yyxi != -1) ||
                   (yyxi[1] != yy_state)) {
               yyxi += 2;
            }
            while ((*(yyxi += 2) >= 0) &&
                   (*yyxi != exp_yychar));
            if ((yy_n = yyxi[1]) < 0)
               YYACCEPT;
         }
      }

      /* * check for syntax error */
      if (yy_n == 0) {          /* have an error */
         /* no worry about speed here! */
         switch (exp_yyerrflag) {
         case 0:                /* new error */
            yyerror((nl_msg(30003, "syntax error")));
            exp_yynerrs++;
            goto skip_init;
      yyerrlab:
            /* * get globals into registers. * we have a user generated syntax type error */
            yy_pv = yypv;
            yy_ps = yyps;
            yy_state = yystate;
            exp_yynerrs++;
      skip_init:
         case 1:
         case 2:                /* incompletely recovered error */
            /* try again... */
            exp_yyerrflag = 3;
            /* * find state where "error" is a legal * shift action */
            while (yy_ps >= yys) {
               yy_n = exp_yypact[*yy_ps] + YYERRCODE;
               if (yy_n >= 0 && yy_n < YYLAST &&
                   exp_yychk[exp_yyact[yy_n]] == YYERRCODE) {
                  /* * simulate shift of "error" */
                  yy_state = exp_yyact[yy_n];
                  goto yy_stack;
               }
               /* * current state has no shift on * "error", pop stack */
#if YYDEBUG
#	define _POP_ "Error recovery pops state %d, uncovers state %d\n"
               if (exp_yydebug)
                  printf(_POP_, *yy_ps,
                         yy_ps[-1]);
#	undef _POP_
#endif
               yy_ps--;
               yy_pv--;
            }
            /* * there is no state on stack with "error" as * a valid shift.  give up. */
            YYABORT;
         case 3:                /* no shift yet; eat a token */
#if YYDEBUG
            /* * if debugging, look up token in list of * pairs.  0 and negative shouldn't occur, * but since timing
             * doesn't matter when * debugging, it doesn't hurt to leave the * tests here. */
            if (exp_yydebug) {
               register int yy_i;

               printf("Error recovery discards ");
               if (exp_yychar == 0)
                  printf("token end-of-file\n");
               else if (exp_yychar < 0)
                  printf("token -none-\n");
               else {
                  for (yy_i = 0;
                       yytoks[yy_i].t_val >= 0;
                       yy_i++) {
                     if (yytoks[yy_i].t_val
                         == exp_yychar) {
                        break;
                     }
                  }
                  printf("token %s\n",
                         yytoks[yy_i].t_name);
               }
            }
#endif /* YYDEBUG */
            if (exp_yychar == 0)/* reached EOF. quit */
               YYABORT;
            exp_yychar = -1;
            goto yy_newstate;
         }
      }                         /* end if ( yy_n == 0 ) */
      /* * reduction by production yy_n * put stack tops, etc. so things right after switch */
#if YYDEBUG
      /* * if debugging, print the string that is the user's * specification of the reduction which is just about * to
       * be done. */
      if (exp_yydebug)
         printf("Reduce by (%d) \"%s\"\n",
                yy_n, yyreds[yy_n]);
#endif
      yytmp = yy_n;             /* value to switch over */
      yypvt = yy_pv;            /* $vars top of value stack */
      /* * Look in goto table for next state * Sorry about using yy_state here as temporary * register variable, but
       * why not, if it works... * If exp_yyr2[ yy_n ] doesn't have the low order bit * set, then there is no action to
       * be done for * this reduction.  So, no saving & unsaving of * registers done.  The only difference between the *
       * code just after the if and the body of the if is * the goto yy_stack in the body.  This way the test * can be
       * made before the choice of what to do is needed. */
      {
         /* length of production doubled with extra bit */
         register int yy_len = exp_yyr2[yy_n];

         if (!(yy_len & 01)) {
            yy_len >>= 1;
            exp_yyval = (yy_pv -= yy_len)[1];   /* $$ = $1 */
            yy_state = exp_yypgo[yy_n = exp_yyr1[yy_n]] +
               *(yy_ps -= yy_len) + 1;
            if (yy_state >= YYLAST ||
                exp_yychk[yy_state =
                          exp_yyact[yy_state]] != -yy_n) {
               yy_state = exp_yyact[exp_yypgo[yy_n]];
            }
            goto yy_stack;
         }
         yy_len >>= 1;
         exp_yyval = (yy_pv -= yy_len)[1];   /* $$ = $1 */
         yy_state = exp_yypgo[yy_n = exp_yyr1[yy_n]] +
            *(yy_ps -= yy_len) + 1;
         if (yy_state >= YYLAST ||
             exp_yychk[yy_state = exp_yyact[yy_state]] != -yy_n) {
            yy_state = exp_yyact[exp_yypgo[yy_n]];
         }
      }
      /* save until reenter driver code */
      yystate = yy_state;
      yyps = yy_ps;
      yypv = yy_pv;
   }
   /* * code supplied by user is placed in this switch */
   switch (yytmp) {

   case 1:
# line 354 "expparse.y"
      {
         exp_yyval.list = yypvt[-0].list;
      } break;
   case 7:
# line 385 "expparse.y"
      {
         exp_yyval.list = yypvt[-1].list;
      } break;
   case 8:
# line 387 "expparse.y"
      {
         exp_yyval.list = 0;    /* LISTcreate(); */
         /* NULL would do, except that we'll end */
         /* up stuff the call name in as the 1st */
         /* arg, so we might as well create the */
         /* list now */
      } break;
   case 9:
# line 397 "expparse.y"
      {
         exp_yyval.expression = EXPcreate(Type_Aggregate);
         exp_yyval.expression->u.list = LISTcreate();
      } break;
   case 10:
# line 400 "expparse.y"
      {
         exp_yyval.expression = EXPcreate(Type_Aggregate);
         exp_yyval.expression->u.list = yypvt[-1].list;
      } break;
   case 11:
# line 405 "expparse.y"
      {
         exp_yyval.expression = yypvt[-0].expression;
      } break;
   case 12:
# line 417 "expparse.y"
      {
         exp_yyval.list = LISTcreate();
         LISTadd(exp_yyval.list, (Generic) yypvt[-0].expression);
      } break;
   case 13:
# line 420 "expparse.y"
      {
         exp_yyval.list = LISTcreate();
         LISTadd(exp_yyval.list, (Generic) yypvt[-2].expression);
         LISTadd(exp_yyval.list, (Generic) yypvt[-0].expression);
         yypvt[-2].expression->type->u.type->body->flags.repeat = 1;
      } break;
   case 14:
# line 425 "expparse.y"
      {
         exp_yyval.list = yypvt[-2].list;
         LISTadd_last(exp_yyval.list, (Generic) yypvt[-0].expression);
      } break;
   case 15:
# line 428 "expparse.y"
      {
         exp_yyval.list = yypvt[-4].list;
         LISTadd_last(exp_yyval.list, (Generic) yypvt[-2].expression);
         LISTadd_last(exp_yyval.list, (Generic) yypvt[-0].expression);
         yypvt[-2].expression->type->u.type->body->flags.repeat = 1;
      } break;
   case 16:
# line 435 "expparse.y"
      {
         exp_yyval.typebody = TYPEBODYcreate(aggregate_);
         exp_yyval.typebody->base = yypvt[-0].type;
      } break;
   case 17:
# line 438 "expparse.y"
      {
         Type t = TYPEcreate_user_defined_tag(yypvt[-0].type, CURRENT_SCOPE, yypvt[-2].symbol);
         SCOPEadd_super(t);
         exp_yyval.typebody = TYPEBODYcreate(aggregate_);
         exp_yyval.typebody->tag = t;
         exp_yyval.typebody->base = yypvt[-0].type;
      } break;
   case 18:
# line 446 "expparse.y"
      {
         exp_yyval.typebody = yypvt[-0].typebody;
      } break;
   case 19:
# line 448 "expparse.y"
      {
         exp_yyval.typebody = yypvt[-0].typebody;
      } break;
   case 20:
# line 450 "expparse.y"
      {
         exp_yyval.typebody = yypvt[-0].typebody;
      } break;
   case 21:
# line 452 "expparse.y"
      {
         exp_yyval.typebody = yypvt[-0].typebody;
      } break;
   case 22:
# line 456 "expparse.y"
      {
         struct Scope *s = SCOPEcreate_tiny(OBJ_ALIAS);
         /* scope doesn't really have/need a name */
         /* I suppose that naming it by the alias is fine */
         /* SUPPRESS 622 */
         PUSH_SCOPE(s, (Symbol *) 0, OBJ_ALIAS);
      } break;
   case 23:
# line 463 "expparse.y"
      {
         Expression e = EXPcreate_from_symbol(Type_Attribute, yypvt[-7].symbol);
         Variable v = VARcreate(e, Type_Unknown);
         v->initializer = yypvt[-5].expression;
         DICTdefine(CURRENT_SCOPE->symbol_table, yypvt[-7].symbol->name,
                    (Generic) v, yypvt[-7].symbol, OBJ_VARIABLE);
         exp_yyval.statement = ALIAScreate(CURRENT_SCOPE, v, yypvt[-2].list);
         POP_SCOPE();
      } break;
   case 24:
# line 474 "expparse.y"
      {
         exp_yyval.typebody = TYPEBODYcreate(array_);
         exp_yyval.typebody->flags.optional = yypvt[-1].type_flags.optional;
         exp_yyval.typebody->flags.unique = yypvt[-1].type_flags.unique;
         exp_yyval.typebody->upper = yypvt[-3].upper_lower.upper_limit;
         exp_yyval.typebody->lower = yypvt[-3].upper_lower.lower_limit;
         exp_yyval.typebody->base = yypvt[-0].type;
      } break;
   case 25:
# line 483 "expparse.y"
      {
         exp_yyval.statement = ASSIGNcreate(yypvt[-3].expression, yypvt[-1].expression);
      } break;
   case 26:
# line 487 "expparse.y"
      {
         exp_yyval.type = TYPEcreate_from_body_anonymously(yypvt[-0].typebody);
         SCOPEadd_super(exp_yyval.type);
      } break;
   case 27:
# line 490 "expparse.y"
      {
         exp_yyval.type = TYPEcreate_from_body_anonymously(yypvt[-0].typebody);
         SCOPEadd_super(exp_yyval.type);
      } break;
   case 28:
# line 493 "expparse.y"
      {
         exp_yyval.type = yypvt[-0].type;
      } break;
   case 29:
# line 497 "expparse.y"
      {
         exp_yyval.list = LISTcreate();
      } break;
   case 30:
# line 499 "expparse.y"
      {
         exp_yyval.list = yypvt[-1].list;
         LISTadd_last(exp_yyval.list, (Generic) yypvt[-0].list);
      } break;
   case 31:
# line 504 "expparse.y"
      {
         exp_yyval.typebody = TYPEBODYcreate(bag_);
         exp_yyval.typebody->base = yypvt[-0].type;
         exp_yyval.typebody->upper = yypvt[-2].upper_lower.upper_limit;
         exp_yyval.typebody->lower = yypvt[-2].upper_lower.lower_limit;
      } break;
   case 32:
# line 509 "expparse.y"
      {
         exp_yyval.typebody = TYPEBODYcreate(bag_);
         exp_yyval.typebody->base = yypvt[-0].type;
      } break;
   case 33:
# line 514 "expparse.y"
      {
         exp_yyval.typebody = TYPEBODYcreate(boolean_);
      } break;
   case 34:
# line 516 "expparse.y"
      {
         exp_yyval.typebody = TYPEBODYcreate(integer_);
         exp_yyval.typebody->precision = yypvt[-0].expression;
      } break;
   case 35:
# line 519 "expparse.y"
      {
         exp_yyval.typebody = TYPEBODYcreate(real_);
         exp_yyval.typebody->precision = yypvt[-0].expression;
      } break;
   case 36:
# line 522 "expparse.y"
      {
         exp_yyval.typebody = TYPEBODYcreate(number_);
      } break;
   case 37:
# line 524 "expparse.y"
      {
         exp_yyval.typebody = TYPEBODYcreate(logical_);
      } break;
   case 38:
# line 526 "expparse.y"
      {
         exp_yyval.typebody = TYPEBODYcreate(binary_);
         exp_yyval.typebody->precision = yypvt[-1].expression;
         exp_yyval.typebody->flags.fixed = yypvt[-0].type_flags.fixed;
      } break;
   case 39:
# line 530 "expparse.y"
      {
         exp_yyval.typebody = TYPEBODYcreate(string_);
         exp_yyval.typebody->precision = yypvt[-1].expression;
         exp_yyval.typebody->flags.fixed = yypvt[-0].type_flags.fixed;
      } break;
   case 45:
# line 545 "expparse.y"
      {
         exp_yyval.expression = LITERAL_ONE;
      } break;
   case 46:
# line 547 "expparse.y"
      {
         exp_yyval.expression = yypvt[-0].expression;
      } break;
   case 47:
# line 551 "expparse.y"
      {
         exp_yyval.upper_lower.lower_limit = yypvt[-3].expression;
         exp_yyval.upper_lower.upper_limit = yypvt[-1].expression;
      } break;
   case 48:
# line 556 "expparse.y"
      {
         exp_yyval.case_item = CASE_ITcreate(yypvt[-2].list, yypvt[-0].statement);
         SYMBOLset(exp_yyval.case_item);
      } break;
   case 49:
# line 561 "expparse.y"
      {
         exp_yyval.list = LISTcreate();
      } break;
   case 50:
# line 563 "expparse.y"
      {
         yyerrok;
         exp_yyval.list = yypvt[-1].list;
         LISTadd_last(exp_yyval.list, (Generic) yypvt[-0].case_item);
      } break;
   case 51:
# line 572 "expparse.y"
      {
         exp_yyval.list = yypvt[-1].list;
         if (yypvt[-0].case_item)
            LISTadd_last(exp_yyval.list, (Generic) yypvt[-0].case_item);
      } break;
   case 52:
# line 577 "expparse.y"
      {
         exp_yyval.list = LISTcreate();
         LISTadd_last(exp_yyval.list, (Generic) yypvt[-0].expression);
      } break;
   case 53:
# line 580 "expparse.y"
      {
         yyerrok;
         exp_yyval.list = yypvt[-2].list;
         LISTadd_last(exp_yyval.list, (Generic) yypvt[-0].expression);
      } break;
   case 54:
# line 597 "expparse.y"
      {
         exp_yyval.case_item = (Case_Item) 0;
      } break;
   case 55:
# line 599 "expparse.y"
      {
         exp_yyval.case_item = CASE_ITcreate(LIST_NULL, yypvt[-0].statement);
         SYMBOLset(exp_yyval.case_item);
      } break;
   case 56:
# line 605 "expparse.y"
      {
         exp_yyval.statement = CASEcreate(yypvt[-4].expression, yypvt[-2].list);
      } break;
   case 57:
# line 609 "expparse.y"
      {
         exp_yyval.statement = COMP_STMTcreate(yypvt[-2].list);
      } break;
   case 58:
# line 613 "expparse.y"
      {
         exp_yyval.expression = LITERAL_PI;
      } break;
   case 59:
# line 615 "expparse.y"
      {
         exp_yyval.expression = LITERAL_E;
      } break;
   case 60:
# line 621 "expparse.y"
      {
         Variable v;
         yypvt[-5].expression->type = yypvt[-3].type;
         v = VARcreate(yypvt[-5].expression, yypvt[-3].type);
         v->initializer = yypvt[-1].expression;
         v->flags.constant = 1;
         DICTdefine(CURRENT_SCOPE->symbol_table,
                    yypvt[-5].expression->symbol.name,
                    (Generic) v, &yypvt[-5].expression->symbol, OBJ_VARIABLE);
      } break;
   case 68:
# line 648 "expparse.y"
      {
         exp_yyval.list = LISTcreate();
      } break;
   case 69:
# line 650 "expparse.y"
      {
         exp_yyval.list = yypvt[-0].list;
      } break;
   case 70:
# line 654 "expparse.y"
      {
         exp_yyval.variable = VARcreate(yypvt[-4].expression, yypvt[-2].type);
         exp_yyval.variable->initializer = yypvt[-1].expression;
      } break;
   case 71:
# line 660 "expparse.y"
      {
         exp_yyval.list = LISTcreate();
         LISTadd_last(exp_yyval.list, (Generic) yypvt[-0].variable);
      } break;
   case 72:
# line 663 "expparse.y"
      {
         exp_yyval.list = yypvt[-1].list;
         LISTadd_last(exp_yyval.list, (Generic) yypvt[-0].variable);
      } break;
   case 73:
# line 675 "expparse.y"
      {
         exp_yyval.entity_body.attributes = yypvt[-4].list;
         /* this is flattened out in entity_decl - DEL */
         LISTadd_last(exp_yyval.entity_body.attributes, (Generic) yypvt[-3].list);
         if (yypvt[-2].list != LIST_NULL) {
            LISTadd_last(exp_yyval.entity_body.attributes, (Generic) yypvt[-2].list);
         }
         exp_yyval.entity_body.unique = yypvt[-1].list;
         exp_yyval.entity_body.where = yypvt[-0].list;
      } break;
   case 74:
# line 687 "expparse.y"
      {
         CURRENT_SCOPE->u.entity->subtype_expression = yypvt[-4].subsuper_decl.subtypes;
         CURRENT_SCOPE->u.entity->supertype_symbols = yypvt[-4].subsuper_decl.supertypes;
         LISTdo(yypvt[-2].entity_body.attributes, l, Linked_List)
            LISTdo(l, a, Variable)
            ENTITYadd_attribute(CURRENT_SCOPE, a);
         LISTod;
         LISTod;
         CURRENT_SCOPE->u.entity->abstract = yypvt[-4].subsuper_decl.abstract;
         CURRENT_SCOPE->u.entity->unique = yypvt[-2].entity_body.unique;
         CURRENT_SCOPE->where = yypvt[-2].entity_body.where;
         POP_SCOPE();
      } break;
   case 75:
# line 704 "expparse.y"
      {
         Entity e = ENTITYcreate(yypvt[-0].symbol);
         if (print_objects_while_running & OBJ_ENTITY_BITS) {
            fprintf(stdout, "parse: %s (entity)\n", yypvt[-0].symbol->name);
         }
         PUSH_SCOPE(e, yypvt[-0].symbol, OBJ_ENTITY);
      } break;
   case 76:
# line 712 "expparse.y"
      {
         int value = 0;
         Expression x;
         Symbol *tmp;
         TypeBody tb;
         tb = TYPEBODYcreate(enumeration_);
         CURRENT_SCOPE->u.type->head = 0;
         CURRENT_SCOPE->u.type->body = tb;
         tb->list = yypvt[-0].list;
         if (!CURRENT_SCOPE->symbol_table) {
            CURRENT_SCOPE->symbol_table = DICTcreate(25);
         }
         LISTdo_links(yypvt[-0].list, id)
            tmp = (Symbol *) id->data;
         id->data = (Generic) (x = EXPcreate(CURRENT_SCOPE));
         x->symbol = *(tmp);
         x->u.integer = ++value;
         /* define both in enum scope and scope of */
         /* 1st visibility */
         DICT_define(CURRENT_SCOPE->symbol_table,
                     x->symbol.name,
                     (Generic) x, &x->symbol, OBJ_EXPRESSION);
         DICTdefine(PREVIOUS_SCOPE->symbol_table, x->symbol.name,
                    (Generic) x, &x->symbol, OBJ_EXPRESSION);
         SYMBOL_destroy(tmp);
         LISTod;
      } break;
   case 77:
# line 739 "expparse.y"
      {
         exp_yyval.statement = STATEMENT_ESCAPE;
      } break;
   case 78:
# line 743 "expparse.y"
      {
         exp_yyval.expression = EXPcreate(Type_Attribute);
         exp_yyval.expression->symbol = *yypvt[-0].symbol;
         SYMBOL_destroy(yypvt[-0].symbol);
      } break;
   case 79:
# line 747 "expparse.y"
      {
         exp_yyval.expression = EXPcreate(Type_Expression);
         exp_yyval.expression->e.op1 = EXPcreate(Type_Expression);
         exp_yyval.expression->e.op1->e.op_code = OP_GROUP;
         exp_yyval.expression->e.op1->e.op1 = EXPcreate(Type_Self);
         exp_yyval.expression->e.op1->e.op2 = EXPcreate_from_symbol(Type_Entity, yypvt[-2].symbol);
         SYMBOL_destroy(yypvt[-2].symbol);
         exp_yyval.expression->e.op_code = OP_DOT;
         exp_yyval.expression->e.op2 = EXPcreate_from_symbol(Type_Attribute, yypvt[-0].symbol);
         SYMBOL_destroy(yypvt[-0].symbol);
      } break;
   case 80:
# line 760 "expparse.y"
      {
         exp_yyval.list = LISTcreate();
         LISTadd_last(exp_yyval.list, (Generic) yypvt[-0].expression);
      } break;
   case 81:
# line 763 "expparse.y"
      {
         exp_yyval.list = yypvt[-2].list;
         LISTadd_last(exp_yyval.list, (Generic) yypvt[-0].expression);
      } break;
   case 82:
# line 768 "expparse.y"
      {
         exp_yyval.type_flags.optional = 0;
      } break;
   case 83:
# line 770 "expparse.y"
      {
         exp_yyval.type_flags.optional = 1;
      } break;
   case 84:
# line 775 "expparse.y"
      {
         Variable v;
         LISTdo_links(yypvt[-4].list, attr)
            v = VARcreate((Expression) attr->data, yypvt[-1].type);
         v->flags.optional = yypvt[-2].type_flags.optional;
         attr->data = (Generic) v;
         LISTod;
      } break;
   case 85:
# line 799 "expparse.y"
      {
         scope = scopes;
         /* no need to define scope->this */
         scope->this = yyresult;
         scope->pscope = scope;
         scope->type = OBJ_EXPRESS;
         yyresult->symbol.name = yyresult->u.express->filename;
         yyresult->symbol.filename = yyresult->u.express->filename;
         yyresult->symbol.line = 1;
      } break;
   case 89:
# line 816 "expparse.y"
      {
         exp_yyval.expression = yypvt[-0].expression;
      } break;
   case 90:
# line 818 "expparse.y"
      {
         yyerrok;
         exp_yyval.expression = BIN_EXPcreate(OP_AND, yypvt[-2].expression, yypvt[-0].expression);
      } break;
   case 91:
# line 821 "expparse.y"
      {
         yyerrok;
         exp_yyval.expression = BIN_EXPcreate(OP_OR, yypvt[-2].expression, yypvt[-0].expression);
      } break;
   case 92:
# line 824 "expparse.y"
      {
         yyerrok;
         exp_yyval.expression = BIN_EXPcreate(OP_XOR, yypvt[-2].expression, yypvt[-0].expression);
      } break;
   case 93:
# line 827 "expparse.y"
      {
         yyerrok;
         exp_yyval.expression = BIN_EXPcreate(OP_LESS_THAN, yypvt[-2].expression, yypvt[-0].expression);
      } break;
   case 94:
# line 830 "expparse.y"
      {
         yyerrok;
         exp_yyval.expression = BIN_EXPcreate(OP_GREATER_THAN, yypvt[-2].expression, yypvt[-0].expression);
      } break;
   case 95:
# line 833 "expparse.y"
      {
         yyerrok;
         exp_yyval.expression = BIN_EXPcreate(OP_EQUAL, yypvt[-2].expression, yypvt[-0].expression);
      } break;
   case 96:
# line 836 "expparse.y"
      {
         yyerrok;
         exp_yyval.expression = BIN_EXPcreate(OP_LESS_EQUAL, yypvt[-2].expression, yypvt[-0].expression);
      } break;
   case 97:
# line 839 "expparse.y"
      {
         yyerrok;
         exp_yyval.expression = BIN_EXPcreate(OP_GREATER_EQUAL, yypvt[-2].expression, yypvt[-0].expression);
      } break;
   case 98:
# line 842 "expparse.y"
      {
         yyerrok;
         exp_yyval.expression = BIN_EXPcreate(OP_NOT_EQUAL, yypvt[-2].expression, yypvt[-0].expression);
      } break;
   case 99:
# line 845 "expparse.y"
      {
         yyerrok;
         exp_yyval.expression = BIN_EXPcreate(OP_INST_EQUAL, yypvt[-2].expression, yypvt[-0].expression);
      } break;
   case 100:
# line 848 "expparse.y"
      {
         yyerrok;
         exp_yyval.expression = BIN_EXPcreate(OP_INST_NOT_EQUAL, yypvt[-2].expression, yypvt[-0].expression);
      } break;
   case 101:
# line 851 "expparse.y"
      {
         yyerrok;
         exp_yyval.expression = BIN_EXPcreate(OP_IN, yypvt[-2].expression, yypvt[-0].expression);
      } break;
   case 102:
# line 854 "expparse.y"
      {
         yyerrok;
         exp_yyval.expression = BIN_EXPcreate(OP_LIKE, yypvt[-2].expression, yypvt[-0].expression);
      } break;
   case 103:
# line 857 "expparse.y"
      {
         yyerrok;
      } break;
   case 104:
# line 864 "expparse.y"
      {
         exp_yyval.expression = yypvt[-0].expression;
      } break;
   case 105:
# line 866 "expparse.y"
      {
         yyerrok;
         exp_yyval.expression = BIN_EXPcreate(OP_CONCAT, yypvt[-2].expression, yypvt[-0].expression);
      } break;
   case 106:
# line 869 "expparse.y"
      {
         yyerrok;
         exp_yyval.expression = BIN_EXPcreate(OP_EXP, yypvt[-2].expression, yypvt[-0].expression);
      } break;
   case 107:
# line 872 "expparse.y"
      {
         yyerrok;
         exp_yyval.expression = BIN_EXPcreate(OP_TIMES, yypvt[-2].expression, yypvt[-0].expression);
      } break;
   case 108:
# line 875 "expparse.y"
      {
         yyerrok;
         exp_yyval.expression = BIN_EXPcreate(OP_DIV, yypvt[-2].expression, yypvt[-0].expression);
      } break;
   case 109:
# line 878 "expparse.y"
      {
         yyerrok;
         exp_yyval.expression = BIN_EXPcreate(OP_REAL_DIV, yypvt[-2].expression, yypvt[-0].expression);
      } break;
   case 110:
# line 881 "expparse.y"
      {
         yyerrok;
         exp_yyval.expression = BIN_EXPcreate(OP_MOD, yypvt[-2].expression, yypvt[-0].expression);
      } break;
   case 111:
# line 884 "expparse.y"
      {
         yyerrok;
         exp_yyval.expression = BIN_EXPcreate(OP_PLUS, yypvt[-2].expression, yypvt[-0].expression);
      } break;
   case 112:
# line 887 "expparse.y"
      {
         yyerrok;
         exp_yyval.expression = BIN_EXPcreate(OP_MINUS, yypvt[-2].expression, yypvt[-0].expression);
      } break;
   case 113:
# line 901 "expparse.y"
      {
         exp_yyval.list = LISTcreate();
         LISTadd_last(exp_yyval.list, (Generic) yypvt[-0].expression);
      } break;
   case 114:
# line 904 "expparse.y"
      {
         exp_yyval.list = yypvt[-2].list;
         LISTadd_last(exp_yyval.list, (Generic) yypvt[-0].expression);
      } break;
   case 115:
# line 909 "expparse.y"
      {
         exp_yyval.type_flags.var = 1;
      } break;
   case 116:
# line 911 "expparse.y"
      {
         exp_yyval.type_flags.var = 0;
      } break;
   case 117:
# line 915 "expparse.y"
      {
         Symbol *tmp;
         Expression e;
         Variable v;
         exp_yyval.list = yypvt[-2].list;
         LISTdo_links(exp_yyval.list, param)
            tmp = (Symbol *) param->data;
/*				e = EXPcreate_from_symbol($4,tmp);*/
         e = EXPcreate_from_symbol(Type_Attribute, tmp);
         v = VARcreate(e, yypvt[-0].type);
         v->flags.optional = yypvt[-3].type_flags.var;
         v->flags.parameter = true;
         param->data = (Generic) v;

         /* link it in to the current scope's dict */
         DICTdefine(CURRENT_SCOPE->symbol_table,
                    tmp->name, (Generic) v,
                    tmp, OBJ_VARIABLE);

         /* see explanation of this in TYPEresolve func */
         /* $4->refcount++; */
         LISTod;
      } break;
   case 118:
# line 938 "expparse.y"
      {
         exp_yyval.list = LIST_NULL;
      } break;
   case 119:
# line 940 "expparse.y"
      {
         exp_yyval.list = yypvt[-1].list;
      } break;
   case 120:
# line 944 "expparse.y"
      {
         exp_yyval.list = yypvt[-0].list;
      } break;
   case 121:
# line 946 "expparse.y"
      {
         exp_yyval.list = yypvt[-2].list;
         LISTadd_all(exp_yyval.list, yypvt[-0].list);
      } break;
   case 122:
# line 951 "expparse.y"
      {
         exp_yyval.type = TYPEcreate_from_body_anonymously(yypvt[-0].typebody);
         SCOPEadd_super(exp_yyval.type);
      } break;
   case 123:
# line 954 "expparse.y"
      {
         exp_yyval.type = TYPEcreate_from_body_anonymously(yypvt[-0].typebody);
         SCOPEadd_super(exp_yyval.type);
      } break;
   case 124:
# line 957 "expparse.y"
      {
         exp_yyval.type = yypvt[-0].type;
      } break;
   case 125:
# line 959 "expparse.y"
      {
         exp_yyval.type = yypvt[-0].type;
      } break;
   case 126:
# line 963 "expparse.y"
      {
         exp_yyval.expression = EXPcreate(Type_Funcall);
         exp_yyval.expression->symbol = *yypvt[-1].symbol;
         SYMBOL_destroy(yypvt[-1].symbol);
         exp_yyval.expression->u.funcall.list = yypvt[-0].list;
      } break;
   case 127:
# line 970 "expparse.y"
      {
         CURRENT_SCOPE->u.func->body = yypvt[-2].list;
         POP_SCOPE();
      } break;
   case 128:
# line 977 "expparse.y"
      {
         Function f = ALGcreate(OBJ_FUNCTION);
         tag_count = 0;
         if (print_objects_while_running & OBJ_FUNCTION_BITS)
            fprintf(stdout, "parse: %s (function)\n", yypvt[-0].symbol->name);

         PUSH_SCOPE(f, yypvt[-0].symbol, OBJ_FUNCTION);
      } break;
   case 129:
# line 982 "expparse.y"
      {
         Function f = CURRENT_SCOPE;
         f->u.func->parameters = yypvt[-3].list;
         f->u.func->pcount = LISTget_length(yypvt[-3].list);
         f->u.func->return_type = yypvt[-1].type;
         f->u.func->tag_count = tag_count;
      } break;
   case 130:
# line 991 "expparse.y"
      {
         exp_yyval.symbol = yypvt[-0].symbol;
      } break;
   case 131:
# line 993 "expparse.y"
      {
         exp_yyval.symbol = yypvt[-0].symbol;
      } break;
   case 132:
# line 997 "expparse.y"
      {
         exp_yyval.typebody = yypvt[-0].typebody;
      } break;
   case 133:
# line 999 "expparse.y"
      {
         exp_yyval.typebody = TYPEBODYcreate(array_);
         exp_yyval.typebody->flags.optional = yypvt[-1].type_flags.optional;
         exp_yyval.typebody->flags.unique = yypvt[-1].type_flags.unique;
         exp_yyval.typebody->base = yypvt[-0].type;
      } break;
   case 134:
# line 1004 "expparse.y"
      {
         exp_yyval.typebody = TYPEBODYcreate(array_);
         exp_yyval.typebody->flags.optional = yypvt[-1].type_flags.optional;
         exp_yyval.typebody->flags.unique = yypvt[-1].type_flags.unique;
         exp_yyval.typebody->base = yypvt[-0].type;
         exp_yyval.typebody->upper = yypvt[-3].upper_lower.upper_limit;
         exp_yyval.typebody->lower = yypvt[-3].upper_lower.lower_limit;
      } break;
   case 135:
# line 1011 "expparse.y"
      {
         exp_yyval.typebody = TYPEBODYcreate(bag_);
         exp_yyval.typebody->base = yypvt[-0].type;
      } break;
   case 136:
# line 1014 "expparse.y"
      {
         exp_yyval.typebody = TYPEBODYcreate(bag_);
         exp_yyval.typebody->base = yypvt[-0].type;
         exp_yyval.typebody->upper = yypvt[-2].upper_lower.upper_limit;
         exp_yyval.typebody->lower = yypvt[-2].upper_lower.lower_limit;
      } break;
   case 137:
# line 1019 "expparse.y"
      {
         exp_yyval.typebody = TYPEBODYcreate(list_);
         exp_yyval.typebody->flags.unique = yypvt[-1].type_flags.unique;
         exp_yyval.typebody->base = yypvt[-0].type;
      } break;
   case 138:
# line 1023 "expparse.y"
      {
         exp_yyval.typebody = TYPEBODYcreate(list_);
         exp_yyval.typebody->base = yypvt[-0].type;
         exp_yyval.typebody->flags.unique = yypvt[-1].type_flags.unique;
         exp_yyval.typebody->upper = yypvt[-3].upper_lower.upper_limit;
         exp_yyval.typebody->lower = yypvt[-3].upper_lower.lower_limit;
      } break;
   case 139:
# line 1029 "expparse.y"
      {
         exp_yyval.typebody = TYPEBODYcreate(set_);
         exp_yyval.typebody->base = yypvt[-0].type;
      } break;
   case 140:
# line 1032 "expparse.y"
      {
         exp_yyval.typebody = TYPEBODYcreate(set_);
         exp_yyval.typebody->base = yypvt[-0].type;
         exp_yyval.typebody->upper = yypvt[-2].upper_lower.upper_limit;
         exp_yyval.typebody->lower = yypvt[-2].upper_lower.lower_limit;
      } break;
   case 141:
# line 1039 "expparse.y"
      {
         exp_yyval.type = Type_Generic;
      } break;
   case 142:
# line 1041 "expparse.y"
      {
         TypeBody g = TYPEBODYcreate(generic_);
         exp_yyval.type = TYPEcreate_from_body_anonymously(g);
         SCOPEadd_super(exp_yyval.type);
         g->tag = TYPEcreate_user_defined_tag(exp_yyval.type, CURRENT_SCOPE, yypvt[-0].symbol);
         SCOPEadd_super(g->tag);
      } break;
   case 143:
# line 1051 "expparse.y"
      {
         exp_yyval.list = LISTcreate();
         LISTadd_last(exp_yyval.list, (Generic) yypvt[-0].symbol);
      } break;
   case 144:
# line 1054 "expparse.y"
      {
         yyerrok;
         exp_yyval.list = yypvt[-2].list;
         LISTadd_last(exp_yyval.list, (Generic) yypvt[-0].symbol);
      } break;
   case 145:
# line 1069 "expparse.y"
      {
         exp_yyval.expression = EXPcreate(Type_Self);
      } break;
   case 146:
# line 1071 "expparse.y"
      {
         exp_yyval.expression = LITERAL_INFINITY;
      } break;
   case 147:
# line 1073 "expparse.y"
      {
         exp_yyval.expression = EXPcreate(Type_Identifier);
         exp_yyval.expression->symbol = *(yypvt[-0].symbol);
         SYMBOL_destroy(yypvt[-0].symbol);
      } break;
   case 148:
# line 1079 "expparse.y"
      {
         exp_yyval.statement = CONDcreate(yypvt[-4].expression, yypvt[-2].list, STATEMENT_LIST_NULL);
      } break;
   case 149:
# line 1082 "expparse.y"
      {
         exp_yyval.statement = CONDcreate(yypvt[-6].expression, yypvt[-4].list, yypvt[-2].list);
      } break;
   case 150:
# line 1091 "expparse.y"
      {
         SCANinclude_file(yypvt[-1].string);
      } break;
   case 151:
# line 1096 "expparse.y"
      {
         Increment i = INCR_CTLcreate(yypvt[-5].symbol, yypvt[-3].expression, yypvt[-1].expression, yypvt[-0].expression);
         /* scope doesn't really have/need a name, I suppose */
         /* naming it by the iterator variable is fine */
         PUSH_SCOPE(i, (Symbol *) 0, OBJ_INCREMENT);
      } break;
   case 152:
# line 1104 "expparse.y"
      {
         exp_yyval.upper_lower.lower_limit = yypvt[-3].expression;
         exp_yyval.upper_lower.upper_limit = yypvt[-1].expression;
      } break;
   case 153:
# line 1115 "expparse.y"
      {
         exp_yyval.expression = yypvt[-0].expression;
      } break;
   case 154:
# line 1119 "expparse.y"
      {
         (*interface_func) (CURRENT_SCOPE, interface_schema, yypvt[-0].symbol, yypvt[-0].symbol);
      } break;
   case 155:
# line 1121 "expparse.y"
      {
         (*interface_func) (CURRENT_SCOPE, interface_schema, yypvt[-2].symbol, yypvt[-0].symbol);
      } break;
   case 159:
# line 1132 "expparse.y"
      {
         if (!CURRENT_SCHEMA->reflist)
            CURRENT_SCHEMA->reflist = LISTcreate();
         LISTadd(CURRENT_SCHEMA->reflist, (Generic) yypvt[-1].symbol);
      } break;
   case 160:
# line 1135 "expparse.y"
      {
         interface_schema = yypvt[-0].symbol;
         interface_func = SCHEMAadd_reference;
      } break;
   case 162:
# line 1140 "expparse.y"
      {
         if (!CURRENT_SCHEMA->uselist)
            CURRENT_SCHEMA->uselist = LISTcreate();
         LISTadd(CURRENT_SCHEMA->uselist, (Generic) yypvt[-1].symbol);
      } break;
   case 163:
# line 1143 "expparse.y"
      {
         interface_schema = yypvt[-0].symbol;
         interface_func = SCHEMAadd_use;
      } break;
   case 169:
# line 1158 "expparse.y"
      {
         Expression tmp1,
          tmp2;

         exp_yyval.expression = (Expression) 0;
         tmp1 = BIN_EXPcreate(yypvt[-4].op_code, yypvt[-5].expression, yypvt[-3].expression);
         tmp2 = BIN_EXPcreate(yypvt[-2].op_code, yypvt[-3].expression, yypvt[-1].expression);
         exp_yyval.expression = BIN_EXPcreate(OP_AND, tmp1, tmp2);
      } break;
   case 170:
# line 1170 "expparse.y"
      {
         exp_yyval.type_either.type = yypvt[-0].type;
         exp_yyval.type_either.body = 0;
      } break;
   case 171:
# line 1173 "expparse.y"
      {
         exp_yyval.type_either.type = 0;
         exp_yyval.type_either.body = TYPEBODYcreate(set_);
         exp_yyval.type_either.body->base = yypvt[-0].type;
      } break;
   case 172:
# line 1177 "expparse.y"
      {
         exp_yyval.type_either.type = 0;
         exp_yyval.type_either.body = TYPEBODYcreate(set_);
         exp_yyval.type_either.body->base = yypvt[-0].type;
         exp_yyval.type_either.body->upper = yypvt[-2].upper_lower.upper_limit;
         exp_yyval.type_either.body->lower = yypvt[-2].upper_lower.lower_limit;
      } break;
   case 173:
# line 1183 "expparse.y"
      {
         exp_yyval.type_either.type = 0;
         exp_yyval.type_either.body = TYPEBODYcreate(bag_);
         exp_yyval.type_either.body->base = yypvt[-0].type;
         exp_yyval.type_either.body->upper = yypvt[-2].upper_lower.upper_limit;
         exp_yyval.type_either.body->lower = yypvt[-2].upper_lower.lower_limit;
      } break;
   case 174:
# line 1189 "expparse.y"
      {
         exp_yyval.type_either.type = 0;
         exp_yyval.type_either.body = TYPEBODYcreate(bag_);
         exp_yyval.type_either.body->base = yypvt[-0].type;
      } break;
   case 175:
# line 1195 "expparse.y"
      {
         exp_yyval.list = LISTcreate();
         LISTadd_last(exp_yyval.list, (Generic) yypvt[-0].variable);
      } break;
   case 176:
# line 1198 "expparse.y"
      {
         exp_yyval.list = yypvt[-1].list;
         LISTadd_last(exp_yyval.list, (Generic) yypvt[-0].variable);
      } break;
   case 177:
# line 1204 "expparse.y"
      {
         Expression e = EXPcreate(Type_Attribute);
         e->symbol = *yypvt[-5].symbol;
         SYMBOL_destroy(yypvt[-5].symbol);
         if (yypvt[-3].type_either.type)
            exp_yyval.variable = VARcreate(e, yypvt[-3].type_either.type);
         else {
            Type t = TYPEcreate_from_body_anonymously(yypvt[-3].type_either.body);
            SCOPEadd_super(t);
            exp_yyval.variable = VARcreate(e, t);
         }
         exp_yyval.variable->inverse_symbol = yypvt[-1].symbol;
      } break;
   case 178:
# line 1216 "expparse.y"
      {
         exp_yyval.list = LIST_NULL;
      } break;
   case 179:
# line 1218 "expparse.y"
      {
         exp_yyval.list = yypvt[-0].list;
      } break;
   case 180:
# line 1223 "expparse.y"
      {
         exp_yyval.upper_lower.lower_limit = yypvt[-3].expression;
         exp_yyval.upper_lower.upper_limit = yypvt[-1].expression;
      } break;
   case 181:
# line 1237 "expparse.y"
      {
         exp_yyval.typebody = TYPEBODYcreate(list_);
         exp_yyval.typebody->base = yypvt[-0].type;
         exp_yyval.typebody->flags.unique = yypvt[-1].type_flags.unique;
         exp_yyval.typebody->lower = yypvt[-3].upper_lower.lower_limit;
         exp_yyval.typebody->upper = yypvt[-3].upper_lower.upper_limit;
      } break;
   case 182:
# line 1243 "expparse.y"
      {
         exp_yyval.typebody = TYPEBODYcreate(list_);
         exp_yyval.typebody->base = yypvt[-0].type;
         exp_yyval.typebody->flags.unique = yypvt[-1].type_flags.unique;
      } break;
   case 183:
# line 1249 "expparse.y"
      {
         if (yypvt[-0].iVal == 0)
            exp_yyval.expression = LITERAL_ZERO;
         else if (yypvt[-0].iVal == 1)
            exp_yyval.expression = LITERAL_ONE;
         else {
            exp_yyval.expression = EXPcreate_simple(Type_Integer);
            /* SUPPRESS 112 */
            exp_yyval.expression->u.integer = (int) yypvt[-0].iVal;
            resolved_all(exp_yyval.expression);
         }
      } break;
   case 184:
# line 1260 "expparse.y"
      {
         if (yypvt[-0].rVal == 0.0)
            exp_yyval.expression = LITERAL_ZERO;
         else {
            exp_yyval.expression = EXPcreate_simple(Type_Real);
            exp_yyval.expression->u.real = yypvt[-0].rVal;
            resolved_all(exp_yyval.expression);
         }
      } break;
   case 185:
# line 1268 "expparse.y"
      {
         exp_yyval.expression = EXPcreate_simple(Type_String);
         exp_yyval.expression->symbol.name = yypvt[-0].string;
         resolved_all(exp_yyval.expression);
      } break;
   case 186:
# line 1272 "expparse.y"
      {
         exp_yyval.expression = EXPcreate_simple(Type_String_Encoded);
         exp_yyval.expression->symbol.name = yypvt[-0].string;
         resolved_all(exp_yyval.expression);
      } break;
   case 187:
# line 1276 "expparse.y"
      {
         exp_yyval.expression = EXPcreate_simple(Type_Logical);
         exp_yyval.expression->u.logical = yypvt[-0].logical;
         resolved_all(exp_yyval.expression);
      } break;
   case 188:
# line 1280 "expparse.y"
      {
         exp_yyval.expression = EXPcreate_simple(Type_Binary);
         exp_yyval.expression->symbol.name = yypvt[-0].binary;
         resolved_all(exp_yyval.expression);
      } break;
   case 189:
# line 1284 "expparse.y"
      {
         exp_yyval.expression = yypvt[-0].expression;
      } break;
   case 190:
# line 1288 "expparse.y"
      {
         exp_yyval.expression = yypvt[-0].expression;
      } break;
   case 191:
# line 1292 "expparse.y"
      {
         Expression e;
         Variable v;
         LISTdo(yypvt[-3].list, sym, Symbol *)
         /* convert symbol to name-expression */
            e = EXPcreate(Type_Attribute);
         e->symbol = *sym;
         SYMBOL_destroy(sym);
         v = VARcreate(e, yypvt[-1].type);
         DICTdefine(CURRENT_SCOPE->symbol_table,
                    e->symbol.name, (Generic) v, &e->symbol, OBJ_VARIABLE);
         LISTod;
         LISTfree(yypvt[-3].list);
      } break;
   case 192:
# line 1302 "expparse.y"
      {
         Expression e;
         Variable v;
         LISTdo(yypvt[-4].list, sym, Symbol *)
            e = EXPcreate(Type_Attribute);
         e->symbol = *sym;
         SYMBOL_destroy(sym);
         v = VARcreate(e, yypvt[-2].type);
         v->initializer = yypvt[-1].expression;
         DICTdefine(CURRENT_SCOPE->symbol_table,
                    e->symbol.name, (Generic) v, &e->symbol, OBJ_VARIABLE);
         LISTod;
         LISTfree(yypvt[-4].list);
      } break;
   case 195:
# line 1318 "expparse.y"
      {
      } break;
   case 196:
# line 1324 "expparse.y"
      {
         exp_yyval.type = TYPEcreate_name(yypvt[-0].symbol);
         SCOPEadd_super(exp_yyval.type);
         SYMBOL_destroy(yypvt[-0].symbol);
      } break;
   case 197:
# line 1330 "expparse.y"
      {
         exp_yyval.list = LISTcreate();
         LISTadd(exp_yyval.list, (Generic) yypvt[-0].type);
      } break;
   case 198:
# line 1333 "expparse.y"
      {
         exp_yyval.list = yypvt[-2].list;
         LISTadd_last(exp_yyval.list, (Generic) yypvt[-0].type);
      } break;
   case 199:
# line 1338 "expparse.y"
      {
         exp_yyval.list = yypvt[-1].list;
      } break;
   case 201:
# line 1345 "expparse.y"
      {
         exp_yyval.type_flags.unique = 0;
         exp_yyval.type_flags.optional = 0;
      } break;
   case 202:
# line 1347 "expparse.y"
      {
         exp_yyval.type_flags.unique = 0;
         exp_yyval.type_flags.optional = 1;
      } break;
   case 203:
# line 1349 "expparse.y"
      {
         exp_yyval.type_flags.unique = 1;
         exp_yyval.type_flags.optional = 0;
      } break;
   case 204:
# line 1351 "expparse.y"
      {
         exp_yyval.type_flags.unique = 1;
         exp_yyval.type_flags.optional = 1;
      } break;
   case 205:
# line 1353 "expparse.y"
      {
         exp_yyval.type_flags.unique = 1;
         exp_yyval.type_flags.optional = 1;
      } break;
   case 206:
# line 1357 "expparse.y"
      {
         exp_yyval.type_flags.fixed = 0;
      } break;
   case 207:
# line 1359 "expparse.y"
      {
         exp_yyval.type_flags.fixed = 1;
      } break;
   case 208:
# line 1363 "expparse.y"
      {
         exp_yyval.expression = (Expression) 0;
      } break;
   case 209:
# line 1365 "expparse.y"
      {
         exp_yyval.expression = yypvt[-1].expression;
      } break;
   case 210:
# line 1373 "expparse.y"
      {
         exp_yyval.statement = PCALLcreate(yypvt[-1].list);
         exp_yyval.statement->symbol = *(yypvt[-2].symbol);
      } break;
   case 211:
# line 1376 "expparse.y"
      {
         exp_yyval.statement = PCALLcreate((Linked_List) 0);
         exp_yyval.statement->symbol = *(yypvt[-1].symbol);
      } break;
   case 212:
# line 1382 "expparse.y"
      {
         CURRENT_SCOPE->u.proc->body = yypvt[-2].list;
         POP_SCOPE();
      } break;
   case 213:
# line 1390 "expparse.y"
      {
         Procedure p = ALGcreate(OBJ_PROCEDURE);
         tag_count = 0;
         if (print_objects_while_running & OBJ_PROCEDURE_BITS) {
            fprintf(stdout, "parse: %s (procedure)\n", yypvt[-0].symbol->name);
         }

         PUSH_SCOPE(p, yypvt[-0].symbol, OBJ_PROCEDURE);
      } break;
   case 214:
# line 1397 "expparse.y"
      {
         CURRENT_SCOPE->u.proc->parameters = yypvt[-1].list;
         CURRENT_SCOPE->u.proc->pcount = LISTget_length(yypvt[-1].list);
         CURRENT_SCOPE->u.proc->tag_count = tag_count;
      } break;
   case 215:
# line 1404 "expparse.y"
      {
         exp_yyval.symbol = yypvt[-0].symbol;
      } break;
   case 216:
# line 1406 "expparse.y"
      {
         exp_yyval.symbol = yypvt[-0].symbol;
      } break;
   case 217:
# line 1411 "expparse.y"
      {
         exp_yyval.expression = BIN_EXPcreate(OP_DOT, (Expression) 0, (Expression) 0);
         exp_yyval.expression->e.op2 = EXPcreate(Type_Identifier);
         exp_yyval.expression->e.op2->symbol = *yypvt[-0].symbol;
         SYMBOL_destroy(yypvt[-0].symbol);
      } break;
   case 218:
# line 1415 "expparse.y"
      {
         exp_yyval.expression = BIN_EXPcreate(OP_GROUP, (Expression) 0, (Expression) 0);
         exp_yyval.expression->e.op2 = EXPcreate(Type_Identifier);
         exp_yyval.expression->e.op2->symbol = *yypvt[-0].symbol;
         SYMBOL_destroy(yypvt[-0].symbol);
      } break;
   case 219:
# line 1419 "expparse.y"
      {
         exp_yyval.expression = BIN_EXPcreate(OP_ARRAY_ELEMENT, (Expression) 0, (Expression) 0);
         exp_yyval.expression->e.op2 = yypvt[-1].expression;
      } break;
   case 220:
# line 1423 "expparse.y"
      {
         exp_yyval.expression = TERN_EXPcreate(OP_SUBCOMPONENT, (Expression) 0, (Expression) 0, (Expression) 0);
         exp_yyval.expression->e.op2 = yypvt[-3].expression;
         exp_yyval.expression->e.op3 = yypvt[-1].expression;
      } break;
   case 221:
# line 1431 "expparse.y"
      {
         exp_yyval.expression = QUERYcreate(yypvt[-3].symbol, yypvt[-1].expression);
         SYMBOL_destroy(yypvt[-3].symbol);
         PUSH_SCOPE(exp_yyval.expression->u.query->scope, (Symbol *) 0, OBJ_QUERY);
      } break;
   case 222:
# line 1437 "expparse.y"
      {
         exp_yyval.expression = yypvt[-2].expression; /* nice syntax, eh? */
         exp_yyval.expression->u.query->expression = yypvt[-1].expression;
         POP_SCOPE();
      } break;
   case 223:
# line 1445 "expparse.y"
      {
         exp_yyval.op_code = OP_LESS_THAN;
      } break;
   case 224:
# line 1447 "expparse.y"
      {
         exp_yyval.op_code = OP_GREATER_THAN;
      } break;
   case 225:
# line 1449 "expparse.y"
      {
         exp_yyval.op_code = OP_EQUAL;
      } break;
   case 226:
# line 1451 "expparse.y"
      {
         exp_yyval.op_code = OP_LESS_EQUAL;
      } break;
   case 227:
# line 1453 "expparse.y"
      {
         exp_yyval.op_code = OP_GREATER_EQUAL;
      } break;
   case 228:
# line 1455 "expparse.y"
      {
         exp_yyval.op_code = OP_NOT_EQUAL;
      } break;
   case 229:
# line 1457 "expparse.y"
      {
         exp_yyval.op_code = OP_INST_EQUAL;
      } break;
   case 230:
# line 1459 "expparse.y"
      {
         exp_yyval.op_code = OP_INST_NOT_EQUAL;
      } break;
   case 231:
# line 1466 "expparse.y"
      {
         exp_yyval.statement = LOOPcreate(CURRENT_SCOPE, yypvt[-5].expression, yypvt[-4].expression, yypvt[-2].list);
         /* matching PUSH_SCOPE is in increment_control */
         POP_SCOPE();
      } break;
   case 232:
# line 1471 "expparse.y"
      {
         exp_yyval.statement = LOOPcreate((struct Scope *) 0, yypvt[-5].expression, yypvt[-4].expression, yypvt[-2].list);
      } break;
   case 233:
# line 1477 "expparse.y"
      {
         exp_yyval.statement = RETcreate((Expression) 0);
      } break;
   case 234:
# line 1480 "expparse.y"
      {
         exp_yyval.statement = RETcreate(yypvt[-2].expression);
      } break;
   case 235:
# line 1484 "expparse.y"
      {
         yyerrok;
      } break;
   case 236:
# line 1488 "expparse.y"
      {
         RULEput_body(CURRENT_SCOPE, yypvt[-3].list);
         RULEput_where(CURRENT_SCOPE, yypvt[-2].list);
         POP_SCOPE();
      } break;
   case 237:
# line 1496 "expparse.y"
      {
         Expression e;
         Type t;
         /* it's true that we know it will be an */
         /* entity_ type later */
         TypeBody tb = TYPEBODYcreate(set_);
         tb->base = TYPEcreate_name(yypvt[-0].symbol);
         SCOPEadd_super(tb->base);
         t = TYPEcreate_from_body_anonymously(tb);
         SCOPEadd_super(t);
         e = EXPcreate_from_symbol(t, yypvt[-0].symbol);
         exp_yyval.variable = VARcreate(e, t);
         exp_yyval.variable->flags.parameter = true;
         /* link it in to the current scope's dict */
         DICTdefine(CURRENT_SCOPE->symbol_table,
                    yypvt[-0].symbol->name, (Generic) exp_yyval.variable, yypvt[-0].symbol, OBJ_VARIABLE);
      } break;
   case 238:
# line 1514 "expparse.y"
      {
         exp_yyval.list = LISTcreate();
         LISTadd(exp_yyval.list, (Generic) yypvt[-0].variable);
      } break;
   case 239:
# line 1517 "expparse.y"
      {
         exp_yyval.list = yypvt[-2].list;
         LISTadd_last(exp_yyval.list, (Generic) yypvt[-0].variable);
      } break;
   case 240:
# line 1522 "expparse.y"
      {
         Rule r = ALGcreate(OBJ_RULE);
         if (print_objects_while_running & OBJ_RULE_BITS) {
            fprintf(stdout, "parse: %s (rule)\n", yypvt[-2].symbol->name);
         }
         PUSH_SCOPE(r, yypvt[-2].symbol, OBJ_RULE);
      } break;
   case 241:
# line 1529 "expparse.y"
      {
         CURRENT_SCOPE->u.rule->parameters = yypvt[-2].list;
      } break;
   case 244:
# line 1540 "expparse.y"
      {
         POP_SCOPE();
      } break;
   case 246:
# line 1547 "expparse.y"
      {
         Schema schema = DICTlookup(CURRENT_SCOPE->symbol_table, yypvt[-1].symbol->name);

         if (print_objects_while_running & OBJ_SCHEMA_BITS) {
            fprintf(stdout, "parse: %s (schema)\n", yypvt[-1].symbol->name);
         }
         if (EXPRESSignore_duplicate_schemas && schema) {
            SCANskip_to_end_schema();
            PUSH_SCOPE_DUMMY();
         }
         else {
            schema = SCHEMAcreate();
            LISTadd_last(PARSEnew_schemas, (Generic) schema);
            PUSH_SCOPE(schema, yypvt[-1].symbol, OBJ_SCHEMA);
         }
      } break;
   case 247:
# line 1565 "expparse.y"
      {
         exp_yyval.typebody = TYPEBODYcreate(select_);
         exp_yyval.typebody->list = yypvt[-1].list;
      } break;
   case 248:
# line 1570 "expparse.y"
      {
         yyerrok;
      } break;
   case 249:
# line 1574 "expparse.y"
      {
         exp_yyval.typebody = TYPEBODYcreate(set_);
         exp_yyval.typebody->base = yypvt[-0].type;
         exp_yyval.typebody->lower = yypvt[-2].upper_lower.lower_limit;
         exp_yyval.typebody->upper = yypvt[-2].upper_lower.upper_limit;
      } break;
   case 250:
# line 1579 "expparse.y"
      {
         exp_yyval.typebody = TYPEBODYcreate(set_);
         exp_yyval.typebody->base = yypvt[-0].type;
      } break;
   case 251:
# line 1584 "expparse.y"
      {
         exp_yyval.statement = STATEMENT_SKIP;
      } break;
   case 252:
# line 1588 "expparse.y"
      {
         exp_yyval.statement = yypvt[-0].statement;
      } break;
   case 253:
# line 1590 "expparse.y"
      {
         exp_yyval.statement = yypvt[-0].statement;
      } break;
   case 254:
# line 1592 "expparse.y"
      {
         exp_yyval.statement = yypvt[-0].statement;
      } break;
   case 255:
# line 1594 "expparse.y"
      {
         exp_yyval.statement = yypvt[-0].statement;
      } break;
   case 256:
# line 1596 "expparse.y"
      {
         exp_yyval.statement = yypvt[-0].statement;
      } break;
   case 257:
# line 1598 "expparse.y"
      {
         exp_yyval.statement = yypvt[-0].statement;
      } break;
   case 258:
# line 1600 "expparse.y"
      {
         exp_yyval.statement = yypvt[-0].statement;
      } break;
   case 259:
# line 1602 "expparse.y"
      {
         exp_yyval.statement = yypvt[-0].statement;
      } break;
   case 260:
# line 1604 "expparse.y"
      {
         exp_yyval.statement = yypvt[-0].statement;
      } break;
   case 261:
# line 1606 "expparse.y"
      {
         exp_yyval.statement = yypvt[-0].statement;
      } break;
   case 262:
# line 1612 "expparse.y"
      {
         exp_yyval.list = LISTcreate();
      } break;
   case 263:
# line 1615 "expparse.y"
      {
         exp_yyval.list = yypvt[-0].list;
      } break;
   case 264:
# line 1617 "expparse.y"
      {
         exp_yyval.list = yypvt[-0].list;
         LISTadd_first(exp_yyval.list, (Generic) yypvt[-1].statement);
      } break;
   case 265:
# line 1625 "expparse.y"
      {
         exp_yyval.subsuper_decl.subtypes = EXPRESSION_NULL;
         exp_yyval.subsuper_decl.abstract = false;
         exp_yyval.subsuper_decl.supertypes = LIST_NULL;
      } break;
   case 266:
# line 1629 "expparse.y"
      {
         exp_yyval.subsuper_decl.subtypes = yypvt[-0].subtypes.subtypes;
         exp_yyval.subsuper_decl.abstract = yypvt[-0].subtypes.abstract;
         exp_yyval.subsuper_decl.supertypes = LIST_NULL;
      } break;
   case 267:
# line 1633 "expparse.y"
      {
         exp_yyval.subsuper_decl.supertypes = yypvt[-0].list;
         exp_yyval.subsuper_decl.abstract = false;
         exp_yyval.subsuper_decl.subtypes = EXPRESSION_NULL;
      } break;
   case 268:
# line 1641 "expparse.y"
      {
         exp_yyval.subsuper_decl.subtypes = yypvt[-1].subtypes.subtypes;
         exp_yyval.subsuper_decl.abstract = yypvt[-1].subtypes.abstract;
         exp_yyval.subsuper_decl.supertypes = yypvt[-0].list;
      } break;
   case 269:
# line 1648 "expparse.y"
      {
         exp_yyval.list = yypvt[-1].list;
      } break;
   case 270:
# line 1652 "expparse.y"
      {
         exp_yyval.subtypes.subtypes = (Expression) 0;
         exp_yyval.subtypes.abstract = true;
      } break;
   case 271:
# line 1656 "expparse.y"
      {
         exp_yyval.subtypes.subtypes = yypvt[-1].expression;
         exp_yyval.subtypes.abstract = false;
      } break;
   case 272:
# line 1660 "expparse.y"
      {
         exp_yyval.subtypes.subtypes = yypvt[-1].expression;
         exp_yyval.subtypes.abstract = true;
      } break;
   case 273:
# line 1665 "expparse.y"
      {
         exp_yyval.expression = yypvt[-0].subtypes.subtypes;
      } break;
   case 274:
# line 1667 "expparse.y"
      {
         exp_yyval.expression = BIN_EXPcreate(OP_AND, yypvt[-2].expression, yypvt[-0].subtypes.subtypes);
      } break;
   case 275:
# line 1669 "expparse.y"
      {
         exp_yyval.expression = BIN_EXPcreate(OP_ANDOR, yypvt[-2].expression, yypvt[-0].subtypes.subtypes);
      } break;
   case 276:
# line 1673 "expparse.y"
      {
         exp_yyval.list = LISTcreate();
         LISTadd_last(exp_yyval.list, (Generic) yypvt[-0].expression);
      } break;
   case 277:
# line 1676 "expparse.y"
      {
         LISTadd_last(yypvt[-2].list, (Generic) yypvt[-0].expression);
         exp_yyval.list = yypvt[-2].list;
      } break;
   case 278:
# line 1681 "expparse.y"
      {
         exp_yyval.subtypes.subtypes = yypvt[-0].expression;
      } break;
   case 279:
# line 1684 "expparse.y"
      {
         exp_yyval.subtypes.subtypes = EXPcreate(Type_Oneof);
         exp_yyval.subtypes.subtypes->u.list = yypvt[-1].list;
      } break;
   case 280:
# line 1687 "expparse.y"
      {
         exp_yyval.subtypes.subtypes = yypvt[-1].expression;
      } break;
   case 281:
# line 1691 "expparse.y"
      {
         exp_yyval.type_either.type = 0;
         exp_yyval.type_either.body = yypvt[-0].typebody;
      } break;
   case 282:
# line 1694 "expparse.y"
      {
         exp_yyval.type_either.type = 0;
         exp_yyval.type_either.body = yypvt[-0].typebody;
      } break;
   case 283:
# line 1697 "expparse.y"
      {
         exp_yyval.type_either.type = yypvt[-0].type;
         exp_yyval.type_either.body = 0;
      } break;
   case 284:
# line 1700 "expparse.y"
      {
         exp_yyval.type_either.type = 0;
         exp_yyval.type_either.body = yypvt[-0].typebody;
      } break;
   case 286:
# line 1705 "expparse.y"
      {
         CURRENT_SCOPE->u.type->head = yypvt[-0].type_either.type;
         CURRENT_SCOPE->u.type->body = yypvt[-0].type_either.body;
      } break;
   case 287:
# line 1711 "expparse.y"
      {
         Type t = TYPEcreate_name(yypvt[-1].symbol);
         PUSH_SCOPE(t, yypvt[-1].symbol, OBJ_TYPE);
      } break;
   case 288:
# line 1714 "expparse.y"
      {
         SYMBOL_destroy(yypvt[-3].symbol);
      } break;
   case 290:
# line 1719 "expparse.y"
      {
         POP_SCOPE();
      } break;
   case 292:
# line 1722 "expparse.y"
      {
         CURRENT_SCOPE->where = yypvt[-0].list;
         POP_SCOPE();
      } break;
   case 294:
# line 1732 "expparse.y"
      {
         yypvt[-0].expression->e.op1 = yypvt[-1].expression;
         exp_yyval.expression = yypvt[-0].expression;
      } break;
   case 295:
# line 1735 "expparse.y"
      {
         exp_yyval.expression = yypvt[-0].expression;
      } break;
   case 296:
# line 1739 "expparse.y"
      {
         exp_yyval.expression = yypvt[-0].expression;
      } break;
   case 297:
# line 1741 "expparse.y"
      {
         yypvt[-0].expression->e.op1 = yypvt[-1].expression;
         exp_yyval.expression = yypvt[-0].expression;
      } break;
   case 298:
# line 1744 "expparse.y"
      {
         exp_yyval.expression = yypvt[-0].expression;
      } break;
   case 299:
# line 1746 "expparse.y"
      {
         exp_yyval.expression = yypvt[-0].expression;
      } break;
   case 300:
# line 1748 "expparse.y"
      {
         exp_yyval.expression = yypvt[-0].expression;
      } break;
   case 301:
# line 1750 "expparse.y"
      {
         exp_yyval.expression = yypvt[-1].expression;
      } break;
   case 302:
# line 1754 "expparse.y"
      {
         exp_yyval.expression = yypvt[-0].expression;
      } break;
   case 303:
# line 1759 "expparse.y"
      {
         exp_yyval.expression = yypvt[-0].expression;
      } break;
   case 304:
# line 1761 "expparse.y"
      {
         exp_yyval.expression = UN_EXPcreate(OP_NOT, yypvt[-0].expression);
      } break;
   case 305:
# line 1763 "expparse.y"
      {
         exp_yyval.expression = yypvt[-0].expression;
      } break;
   case 306:
# line 1765 "expparse.y"
      {
         exp_yyval.expression = UN_EXPcreate(OP_NEGATE, yypvt[-0].expression);
      } break;
   case 307:
# line 1772 "expparse.y"
      {
         exp_yyval.type_flags.unique = 0;
      } break;
   case 308:
# line 1774 "expparse.y"
      {
         exp_yyval.type_flags.unique = 1;
      } break;
   case 309:
# line 1778 "expparse.y"
      {
         exp_yyval.qualified_attr = QUAL_ATTR_new();
         exp_yyval.qualified_attr->attribute = yypvt[-0].symbol;
      } break;
   case 310:
# line 1782 "expparse.y"
      {
         exp_yyval.qualified_attr = QUAL_ATTR_new();
         exp_yyval.qualified_attr->entity = yypvt[-2].symbol;
         exp_yyval.qualified_attr->attribute = yypvt[-0].symbol;
      } break;
   case 311:
# line 1789 "expparse.y"
      {
         exp_yyval.list = LISTcreate();
         LISTadd_last(exp_yyval.list, (Generic) yypvt[-0].qualified_attr);
      } break;
   case 312:
# line 1792 "expparse.y"
      {
         exp_yyval.list = yypvt[-2].list;
         LISTadd_last(exp_yyval.list, (Generic) yypvt[-0].qualified_attr);
      } break;
   case 313:
# line 1797 "expparse.y"
      {
         LISTadd_first(yypvt[-1].list, (Generic) EXPRESSION_NULL);
         exp_yyval.list = yypvt[-1].list;
      } break;
   case 314:
# line 1800 "expparse.y"
      {
         LISTadd_first(yypvt[-1].list, (Generic) yypvt[-3].symbol);
         exp_yyval.list = yypvt[-1].list;
      } break;
   case 315:
# line 1819 "expparse.y"
      {
         exp_yyval.list = LISTcreate();
         LISTadd_last(exp_yyval.list, (Generic) yypvt[-0].list);
      } break;
   case 316:
# line 1822 "expparse.y"
      {
         LISTadd_last(yypvt[-1].list, (Generic) yypvt[-0].list);
         exp_yyval.list = yypvt[-1].list;
      } break;
   case 317:
# line 1828 "expparse.y"
      {
         exp_yyval.list = 0;
      } break;
   case 318:
# line 1830 "expparse.y"
      {
         exp_yyval.list = yypvt[-0].list;
      } break;
   case 319:
# line 1834 "expparse.y"
      {
         exp_yyval.expression = 0;
      } break;
   case 320:
# line 1836 "expparse.y"
      {
         exp_yyval.expression = yypvt[-0].expression;
      } break;
   case 321:
# line 1840 "expparse.y"
      {
         exp_yyval.where = WHERE_new();
         exp_yyval.where->label = 0;
         exp_yyval.where->expr = yypvt[-1].expression;
      } break;
   case 322:
# line 1845 "expparse.y"
      {
         exp_yyval.where = WHERE_new();
         exp_yyval.where->label = yypvt[-3].symbol;
         exp_yyval.where->expr = yypvt[-1].expression;
         if (!CURRENT_SCOPE->symbol_table) {
            CURRENT_SCOPE->symbol_table = DICTcreate(25);
         }
         DICTdefine(CURRENT_SCOPE->symbol_table, yypvt[-3].symbol->name,
                    (Generic) exp_yyval.where, yypvt[-3].symbol, OBJ_WHERE);
      } break;
   case 323:
# line 1857 "expparse.y"
      {
         exp_yyval.list = LISTcreate();
         LISTadd(exp_yyval.list, (Generic) yypvt[-0].where);
      } break;
   case 324:
# line 1860 "expparse.y"
      {
         exp_yyval.list = yypvt[-1].list;
         LISTadd_last(exp_yyval.list, (Generic) yypvt[-0].where);
      } break;
   case 325:
# line 1867 "expparse.y"
      {
         exp_yyval.list = LIST_NULL;
      } break;
   case 326:
# line 1869 "expparse.y"
      {
         exp_yyval.list = yypvt[-0].list;
      } break;
   case 327:
# line 1873 "expparse.y"
      {
         exp_yyval.expression = 0;
      } break;
   case 328:
# line 1875 "expparse.y"
      {
         exp_yyval.expression = yypvt[-0].expression;
      } break;
   }
   goto yystack;                /* reset registers in driver code */
}

# ifdef __RUNTIME_YYMAXDEPTH

static int allocate_stacks()
{
   /* allocate the yys and exp_yyv stacks */
   yys = (int *) malloc(yymaxdepth * sizeof(int));
   exp_yyv = (exp_YYSTYPE *) malloc(yymaxdepth * sizeof(exp_YYSTYPE));

   if (yys == 0 || exp_yyv == 0) {
      yyerror((nl_msg(30004, "unable to allocate space for yacc stacks")));
      return (1);
   }
   else
      return (0);

}


static void free_stacks()
{
   if (yys != 0)
      free((char *) yys);
   if (exp_yyv != 0)
      free((char *) exp_yyv);
}

# endif /* defined(__RUNTIME_YYMAXDEPTH) */
