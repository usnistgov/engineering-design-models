# include "stdio.h"
#ifdef __cplusplus
extern "C" {
   extern int yyreject();
   extern int yywrap();
   extern int exp_yylook();
   extern void main();
   extern int exp_yyback(int *, int);
   extern int yyinput();
   extern void exp_yyoutput(int);
   extern void yyunput(int);
   extern int exp_yylex();
}
#endif /* __cplusplus */
# define U(x) x
# define NLSTATE exp_yyprevious=YYNEWLINE
# define BEGIN exp_yybgin = exp_yysvec + 1 +
# define INITIAL 0
# define YYLERR exp_yysvec
# define YYSTATE (exp_yyestate-exp_yysvec-1)
# define YYOPTIM 1
# define YYLMAX 200
# define output(c) putc(c,yyout)
# define input() (((exp_yytchar=exp_yysptr>exp_yysbuf?U(*--exp_yysptr):getc(yyin))==10?(yylineno++,exp_yytchar):exp_yytchar)==EOF?0:exp_yytchar)
# define unput(c) {exp_yytchar= (c);if(exp_yytchar=='\n')yylineno--;*exp_yysptr++=exp_yytchar;}
# define yymore() (exp_yymorfg=1)
# define ECHO fprintf(yyout, "%s",exp_yytext)
# define REJECT { nstr = yyreject(); goto yyfussy;}
int exp_yyleng;
int exp_yylenguc;
extern unsigned char exp_yytextarr[];
extern unsigned char exp_yytext[];
int yyposix_point = 0;
int yynls16 = 0;
int yynls_wchar = 0;
char *yylocale = "/\001:C;\002:C;\003:C;\004:C;:C;:C;:C;/";
int exp_yymorfg;
extern unsigned char *exp_yysptr,
 exp_yysbuf[];
int exp_yytchar;
extern FILE *yyin,
*yyout;
extern int yylineno;
struct yysvf {
   int yystoff;
   struct yysvf *yyother;
   int *yystops;
};
struct yysvf *exp_yyestate;
extern struct yysvf exp_yysvec[],
*exp_yybgin;

static char rcsid[] = "$Id: expscan.l,v 1.10 1994/05/12 17:22:23 libes Exp $";

/*
 * Lex source for Fed-X lexical analyzer.
 *
 * This software was developed by U.S. Government employees as part of
 * their official duties and is not subject to copyright.
 *
 * $Log: expscan.l,v $
 * Revision 1.10  1994/05/12  17:22:23  libes
 * added #ifdefs for flex
 *
 * Revision 1.9  1994/05/12  17:18:10  libes
 * made flex understand multiple files
 *
 * Revision 1.8  1994/05/11  19:50:00  libes
 * numerous fixes
 *
 * Revision 1.7  1993/10/15  18:47:26  libes
 * CADDETC certified
 *
 * Revision 1.5  1993/02/22  21:46:33  libes
 * fixed unmatched_open_comment handler
 *
 * Revision 1.4  1992/08/18  17:11:36  libes
 * rm'd extraneous error messages
 *
 * Revision 1.3  1992/06/08  18:05:20  libes
 * prettied up interface to print_objects_when_running
 *
 * Revision 1.2  1992/05/31  08:30:54  libes
 * multiple files
 *
 * Revision 1.1  1992/05/28  03:52:25  libes
 * Initial revision
 *
 * Revision 1.4  1992/05/05  19:49:03  libes
 * final alpha
 *
 * Revision 1.3  1992/02/12  07:02:49  libes
 * do sub/supertypes
 *
 * Revision 1.2  1992/02/09  00:49:04  libes
 * does ref/use correctly
 *
 * Revision 1.1  1992/02/05  08:40:30  libes
 * Initial revision
 *
 * Revision 1.0.1.1  1992/01/22  02:47:57  libes
 * copied from ~pdes
 *
 * Revision 4.9  1991/06/14  20:49:12  libes
 * removed old infinity, added backslash
 *
 * Revision 4.8.1.1  1991/05/16  04:07:57  libes
 * made scanner (under lex) understand hooks for doing include directive
 *
 * Revision 4.8.1.0  1991/05/16  01:10:15  libes
 * branch for fixes to old code
 *
 * Revision 4.8  1991/05/03  21:09:02  libes
 * Added sanity check to make sure lex/flex match -DLEX/FLEX
 *
 * Revision 4.7  1991/05/02  05:49:18  libes
 * fixed bug in testing for exceeding open_comment[nesting_level]
 *
 * Revision 4.6  1991/04/29  19:44:40  libes
 * Print all open comments rather than just one.
 *
 * Revision 4.5  1991/04/29  15:39:02  libes
 * Changed commenting style (back) as per SNC who claims that N9 meant to
 * say that tail remarks cannot occur in an open comment, nor can nested
 * comments begin in a tail remark.
 *
 * Revision 4.4  1991/04/29  15:01:46  libes
 * Add bounds checking to nesting level history
 *
 * Revision 4.3  1991/04/26  20:12:50  libes
 * Made scanner work with lex
 * 	Simulated exclusive states with inclusive states
 * 	Fixed line counting
 * Speeded up whitespace matching
 * Convert unknown chars to whitespace
 * Disabled default rule matching (enabled "jamming")
 * Enabled detection/diagnostics of unterminated comments and strings literals
 * Enabled detection/diagnostics of unexpected close comments
 * Disabled detection/diagnostics of nested comments
 *
 * Revision 4.2  1990/12/18  14:00:04  clark
 * Cosmetic changes
 *
 * Revision 4.1  90/09/13  16:29:00  clark
 * BPR 2.1 alpha
 *
 */

#include "basic.h"
#include "error.h"
#include "lexact.h"
#include "exptoks.h"

extern void yyerror();
extern int yylineno;
extern Boolean yyeof;
static int nesting_level;

/* can't imagine this will ever be more than 2 or 3 - DEL */
#define MAX_NESTED_COMMENTS 20
static struct Symbol open_comment[MAX_NESTED_COMMENTS];

#undef yywrap
static int yywrap()
{
   int i;

   for (i = 0; i < nesting_level && i < MAX_NESTED_COMMENTS; i++) {
      ERRORreport_with_symbol(ERROR_unmatched_open_comment,
                              &open_comment[i]);
      /* maybe not all, but at least some will be reported - DEL */
   }
   return 1;
}

#ifdef FLEX_SCANNER

#ifdef LEX
))))
this line will generate an error during compilation intentionally - DEL
 You used flex(in make_rules)
but compiled with - DLEX(in Makefile) !
#endif

#define YY_USER_INIT	BEGIN code;/* DEL */

#undef YY_DECL
#define YY_DECL int exp_yylex(void)

/* here's the hook for the preprocessor */
#undef YY_INPUT
#define YY_INPUT(buf, result, max_size)					\
	(result) = SCANnextchar(buf)

/* I don't believe this is used anymore, but not sure */
/* in any case, experimental code above that attempts to skip over */
/* initial non-Express code explicitly refers to YY_INPUT */
#ifdef slow_yylineno
#undef YY_INPUT
#define YY_INPUT(buf,result,max_size)					\
 	result = (((buf[0] = getc(yyin)) == '\n')			\
		  ? (NEWLINE, 1)					\
		  : ((buf[0] == EOF) ? ((yyeof = true), YY_NULL) : 1))
#endif /* slow_yylineno */

#define NEWLINE	yylineno++
#define LINENO_FUDGE yylineno

#else /* !FLEX_SCANNER (i.e, LEX) */

#ifdef FLEX
))))
this line will generate an error during compilation intentionally - DEL
 You used lex(in make_rules)
but compiled with - DFLEX(in Makefile) !
#endif

#undef input
#undef unput

/* max page size 100 is guaranteed, but lex code uses BUFSIZ! - DEL */
static char unchar[BUFSIZ];     /* one char for lex unput storage */
static char *unchar_p = unchar; /* whether unchar is in use */

static int first_time = true;

static int input()
{
   char c;

   if (unchar_p == unchar) {
      /* no chars pushed back */
      if (!SCANnextchar(&c))
         return (0);
      if (c == '\n')
         yylineno++;
      return (c);
   }
   else {
      unchar_p--;
      if (*unchar_p == '\n')
         yylineno++;
      return (*unchar_p);
   }
}

/* if paranoid, should check that bounds are never exceeded, but maybe */
/* lex does this for us?   lex is not documented well enough to know */
#define unput(c) {exp_yytchar=(c);if(exp_yytchar=='\n')yylineno--;*unchar_p++=exp_yytchar;}
/* really shouldn't use exp_yytchar since it isn't part of the defined interface */


/* lex counts line for us, so turn this into a no-op - DEL */
#define NEWLINE
/* when lex looks ahead over a newline, error messages get thrown off */
/* Fortunately, we know when that occurs, so adjust for it by this hack */
#define LINENO_FUDGE (yylineno-1)

#endif

#ifdef FLEX_SCANNER
void exp_flex_init();
#endif

/* added for re-initializing parser -snc 22-Apr-1992 */
void SCAN_lex_init(char *filename, FILE *fp)
{
   int i;

   /* return to initial scan buffer */
   SCAN_current_buffer = 0;
   *(SCANcurrent = SCANbuffer.text) = '\0';
   SCANbuffer.readEof = false;
   SCANbuffer.file = fp;
   SCANbuffer.filename = (filename ? filename : "");
   current_filename = SCANbuffer.filename;

   /* empty all scan buffers */
/*      for (i = 0; i < SCAN_NESTING_DEPTH; ++i)*/
/*          SCAN_buffers[i].text[0] = '\0';*/

#ifdef FLEX_SCANNER
   exp_flex_init();
#endif

#ifndef FLEX_SCANNER
   /* initialize un-got character pointer to start of buffer */
   unchar_p = unchar;

   first_time = true;
#endif
}


# define comment 2
# define code 4
# define return_end_schema 6
# define YYNEWLINE 10
exp_yylex()
{
   int nstr;
   extern int exp_yyprevious;
#ifndef FLEX_SCANNER
   if (first_time) {
      BEGIN code;
      first_time = false;
   }
#endif
/* Added * at the end of next rule (to make lexer faster) - DEL */
   while ((nstr = exp_yylook()) >= 0)
yyfussy:switch (nstr) {
      case 0:
         if (yywrap())
            return (0);
         break;
      case 1:
         ;
         break;
      case 2:
         {
            NEWLINE;
         }
         break;
      case 3:
         {
            NEWLINE;
         }
         break;
      case 4:
         {
            /* nested comment errors will occur with most deeply nested - DEL */
            if (nesting_level < MAX_NESTED_COMMENTS) {
               open_comment[nesting_level].line = yylineno;
               open_comment[nesting_level].filename = current_filename;
            }
            nesting_level++;
            BEGIN comment;
         }
         break;
/* real literal (like, think it'll fly?!) */
      case 5:
         {
            return SCANprocess_real_literal();
         }
         break;
/* integer literal */
      case 6:
         {
            return SCANprocess_integer_literal();
         }
         break;
/* binary literal */
      case 7:
         {
            return SCANprocess_binary_literal();
         }
         break;
/* identifier/keyword */
      case 8:
         {
            return SCANprocess_identifier_or_keyword();
         }
         break;
/* bad identifier */
      case 9:
         {
            ERRORreport_with_line(ERROR_bad_identifier, yylineno, exp_yytext);
            return SCANprocess_identifier_or_keyword();
         }
         break;
/* string literal */
      case 10:
         {
            return SCANprocess_string();
         }
         break;
      case 11:
         {
            ERRORreport_with_line(ERROR_unterminated_string, LINENO_FUDGE);
            NEWLINE;
            return SCANprocess_string();
         }
         break;
      case 12:
         {
            return SCANprocess_encoded_string();
         }
         break;
      case 13:
         {
            ERRORreport_with_line(ERROR_unterminated_string, LINENO_FUDGE);
            NEWLINE;
            return SCANprocess_encoded_string();
         }
         break;
      case 14:
         {
            return TOK_ASSIGNMENT;
         }
         break;
      case 15:
         {
            return TOK_COLON;
         }
         break;
      case 16:
         {
            return TOK_COMMA;
         }
         break;
      case 17:
         {
            return TOK_CONCAT_OP;
         }
         break;
      case 18:
         {
            return TOK_DOT;
         }
         break;
      case 19:
         {
            return TOK_EQUAL;
         }
         break;
      case 20:
         {
            return TOK_EXP;
         }
         break;
      case 21:
         {
            return TOK_SUCH_THAT;
         }
         break;
      case 22:
         {
            return TOK_ALL_IN;
         }
         break;
      case 23:
         {
            return TOK_GREATER_EQUAL;
         }
         break;
      case 24:
         {
            return TOK_GREATER_THAN;
         }
         break;
      case 25:
         {
            return TOK_QUESTION_MARK;
         }
         break;
      case 26:
         {
            return TOK_INST_EQUAL;
         }
         break;
      case 27:
         {
            return TOK_INST_NOT_EQUAL;
         }
         break;
      case 28:
         {
            return TOK_LEFT_BRACKET;
         }
         break;
      case 29:
         {
            return TOK_LEFT_CURL;
         }
         break;
      case 30:
         {
            return TOK_LEFT_PAREN;
         }
         break;
      case 31:
         {
            return TOK_LESS_EQUAL;
         }
         break;
      case 32:
         {
            return TOK_LESS_THAN;
         }
         break;
      case 33:
         {
            return TOK_MINUS;
         }
         break;
      case 34:
         {
            return TOK_NOT_EQUAL;
         }
         break;
      case 35:
         {
            return TOK_PLUS;
         }
         break;
      case 36:
         {
            return TOK_REAL_DIV;
         }
         break;
      case 37:
         {
            return TOK_RIGHT_BRACKET;
         }
         break;
      case 38:
         {
            return TOK_RIGHT_CURL;
         }
         break;
      case 39:
         {
            return TOK_RIGHT_PAREN;
         }
         break;
      case 40:
         {
            return TOK_SEMICOLON;
         }
         break;
      case 41:
         {
            return TOK_TIMES;
         }
         break;
      case 42:
         {
            return TOK_BACKSLASH;
         }
         break;
      case 43:
         {
            BEGIN code;
            return TOK_END_SCHEMA;
         }
         break;
      case 44:
         {
            if (0 == --nesting_level)
               BEGIN code;
         }
         break;
      case 45:
         {
            ERRORreport_with_line(ERROR_unmatched_close_comment, yylineno);
         }
         break;
      case 46:
         {
            NEWLINE;
         }
         break;
      case 47:
         ;
         break;
      case 48:
         ;
         break;
/* As per N15, 7.1.5.3, all other recognized chars are incorrect - DEL */
      case 49:
         {
            ERRORreport_with_line(ERROR_unexpected_character, yylineno, exp_yytext[0]);
         }
         break;
/* ... and unrecognized characters are treated as whitespace - DEL */
      case 50:
         ;
         break;
      case -1:
         break;
      default:
         fprintf(yyout, "bad switch exp_yylook %d", nstr);
      } return (0);
}
/* end of exp_yylex */

static void __yy__unused() {
   main();
}
void SCANskip_to_end_schema()
{
   while (exp_yylex() != TOK_END_SCHEMA);

   unput('X');                  /* any old character */

   BEGIN return_end_schema;
}

#ifdef FLEX_SCANNER
/* required because yy_init isn't known when we need to re-init it */
void exp_flex_init()
{
   /* yy_init is what tells flex to reinitialize its buffers */

   yy_init = 1;
}
#endif
int exp_yyvstop[] = {
   0,

   1,
   47,
   0,

   1,
   47,
   0,

   1,
   47,
   0,

   1,
   47,
   0,

   1,
   47,
   0,

   1,
   47,
   0,

   1,
   47,
   0,

   1,
   47,
   0,

   50,
   0,

   1,
   50,
   0,

   2,
   0,

   50,
   0,

   47,
   50,
   0,

   1,
   47,
   50,
   0,

   2,
   46,
   0,

   48,
   50,
   0,

   48,
   50,
   0,

   48,
   50,
   0,

   50,
   0,

   49,
   50,
   0,

   49,
   50,
   0,

   50,
   0,

   30,
   50,
   0,

   39,
   50,
   0,

   41,
   50,
   0,

   35,
   50,
   0,

   16,
   50,
   0,

   33,
   50,
   0,

   18,
   50,
   0,

   36,
   50,
   0,

   6,
   50,
   0,

   15,
   50,
   0,

   40,
   50,
   0,

   32,
   50,
   0,

   19,
   50,
   0,

   24,
   50,
   0,

   25,
   50,
   0,

   8,
   9,
   50,
   0,

   28,
   50,
   0,

   42,
   50,
   0,

   37,
   50,
   0,

   9,
   50,
   0,

   29,
   49,
   50,
   0,

   21,
   50,
   0,

   38,
   49,
   50,
   0,

   43,
   50,
   0,

   1,
   0,

   4,
   0,

   47,
   0,

   1,
   47,
   0,

   44,
   0,

   13,
   0,

   12,
   0,

   7,
   0,

   11,
   0,

   10,
   0,

   45,
   0,

   20,
   0,

   5,
   0,

   6,
   0,

   14,
   0,

   22,
   0,

   31,
   0,

   34,
   0,

   23,
   0,

   8,
   9,
   0,

   9,
   0,

   17,
   0,

   3,
   0,

   26,
   0,

   5,
   0,

   27,
   0,
0};
# define YYTYPE unsigned char
struct yywork {
   YYTYPE verify,
    advance;
} exp_yycrank[] = {
   0, 0, 0, 0, 1, 9, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 1, 10, 1, 11,
   0, 0, 10, 47, 0, 0, 3, 13,
   0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 3, 14,
   3, 15, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 1, 9,
   10, 47, 1, 9, 0, 0, 0, 0,
   1, 9, 1, 12, 1, 9, 1, 9,
   1, 9, 2, 9, 2, 9, 12, 48,
   3, 13, 1, 9, 3, 13, 1, 9,
   18, 51, 3, 13, 3, 16, 3, 17,
   3, 18, 3, 13, 4, 17, 4, 18,
   14, 50, 14, 0, 3, 13, 28, 61,
   3, 13, 36, 69, 1, 9, 21, 55,
   21, 55, 34, 66, 1, 9, 49, 0,
   5, 9, 7, 9, 7, 9, 8, 9,
   8, 9, 25, 59, 25, 60, 3, 13,
   5, 10, 5, 11, 58, 56, 3, 13,
   32, 64, 32, 65, 64, 75, 65, 76,
   34, 67, 34, 68, 75, 79, 14, 0,
   14, 0, 14, 0, 0, 0, 0, 0,
   1, 9, 0, 0, 0, 0, 0, 0,
   0, 0, 49, 0, 49, 0, 49, 0,
   0, 0, 5, 19, 0, 0, 5, 20,
   5, 21, 3, 13, 5, 22, 5, 23,
   5, 24, 5, 25, 5, 26, 5, 27,
   5, 28, 5, 29, 5, 30, 5, 31,
   7, 46, 5, 31, 8, 46, 0, 0,
   0, 0, 0, 0, 44, 72, 50, 50,
   50, 0, 5, 32, 5, 33, 5, 34,
   5, 35, 5, 36, 5, 37, 0, 0,
   5, 38, 0, 0, 0, 0, 0, 0,
   5, 38, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 6, 21, 0, 0,
   0, 0, 0, 0, 6, 24, 6, 25,
   0, 0, 6, 27, 6, 28, 6, 29,
   6, 30, 0, 0, 50, 0, 50, 0,
   50, 0, 0, 0, 5, 39, 5, 40,
   5, 41, 0, 0, 5, 42, 6, 32,
   6, 33, 6, 34, 6, 35, 6, 36,
   6, 37, 13, 49, 0, 0, 0, 0,
   0, 0, 0, 0, 74, 77, 0, 0,
   74, 77, 13, 49, 13, 0, 74, 78,
   74, 78, 74, 78, 74, 78, 74, 78,
   74, 78, 74, 78, 74, 78, 74, 78,
   74, 78, 0, 0, 5, 43, 5, 44,
   5, 45, 0, 0, 0, 0, 0, 0,
   6, 39, 6, 40, 6, 41, 0, 0,
   0, 0, 0, 0, 13, 49, 0, 0,
   13, 49, 19, 52, 0, 0, 13, 49,
   13, 0, 13, 0, 13, 0, 13, 49,
   0, 0, 19, 52, 19, 53, 0, 0,
   13, 49, 0, 0, 13, 49, 0, 0,
   0, 0, 0, 0, 0, 0, 22, 56,
   0, 0, 0, 0, 0, 0, 0, 0,
   6, 43, 6, 44, 6, 45, 22, 56,
   22, 57, 13, 49, 0, 0, 0, 0,
   0, 0, 13, 49, 19, 54, 0, 0,
   19, 52, 0, 0, 0, 0, 19, 52,
   19, 52, 0, 0, 0, 0, 19, 52,
   0, 0, 0, 0, 0, 0, 0, 0,
   19, 52, 0, 0, 19, 52, 0, 0,
   22, 56, 0, 0, 22, 56, 0, 0,
   0, 0, 22, 58, 22, 56, 13, 49,
   0, 0, 22, 56, 0, 0, 0, 0,
   0, 0, 19, 52, 22, 56, 0, 0,
   22, 56, 19, 52, 31, 62, 0, 0,
   31, 63, 31, 63, 31, 63, 31, 63,
   31, 63, 31, 63, 31, 63, 31, 63,
   31, 63, 31, 63, 0, 0, 22, 56,
   0, 0, 0, 0, 0, 0, 22, 56,
   0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 19, 52,
   0, 0, 38, 70, 38, 70, 38, 70,
   38, 70, 38, 70, 38, 70, 38, 70,
   38, 70, 38, 70, 38, 70, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 22, 56, 38, 70, 38, 70,
   38, 70, 38, 70, 38, 70, 38, 70,
   38, 70, 38, 70, 38, 70, 38, 70,
   38, 70, 38, 70, 38, 70, 38, 70,
   38, 70, 38, 70, 38, 70, 38, 70,
   38, 70, 38, 70, 38, 70, 38, 70,
   38, 70, 38, 70, 38, 70, 38, 70,
   0, 0, 0, 0, 0, 0, 0, 0,
   38, 70, 0, 0, 38, 70, 38, 70,
   38, 70, 38, 70, 38, 70, 38, 70,
   38, 70, 38, 70, 38, 70, 38, 70,
   38, 70, 38, 70, 38, 70, 38, 70,
   38, 70, 38, 70, 38, 70, 38, 70,
   38, 70, 38, 70, 38, 70, 38, 70,
   38, 70, 38, 70, 38, 70, 38, 70,
   42, 71, 42, 71, 42, 71, 42, 71,
   42, 71, 42, 71, 42, 71, 42, 71,
   42, 71, 42, 71, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 42, 71, 42, 71, 42, 71,
   42, 71, 42, 71, 42, 71, 42, 71,
   42, 71, 42, 71, 42, 71, 42, 71,
   42, 71, 42, 71, 42, 71, 42, 71,
   42, 71, 42, 71, 42, 71, 42, 71,
   42, 71, 42, 71, 42, 71, 42, 71,
   42, 71, 42, 71, 42, 71, 0, 0,
   0, 0, 0, 0, 0, 0, 42, 71,
   0, 0, 42, 71, 42, 71, 42, 71,
   42, 71, 42, 71, 42, 71, 42, 71,
   42, 71, 42, 71, 42, 71, 42, 71,
   42, 71, 42, 71, 42, 71, 42, 71,
   42, 71, 42, 71, 42, 71, 42, 71,
   42, 71, 42, 71, 42, 71, 42, 71,
   42, 71, 42, 71, 42, 71, 61, 61,
   0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 61, 61,
   61, 73, 62, 62, 62, 62, 62, 62,
   62, 62, 62, 62, 62, 62, 62, 62,
   62, 62, 62, 62, 62, 62, 77, 78,
   77, 78, 77, 78, 77, 78, 77, 78,
   77, 78, 77, 78, 77, 78, 77, 78,
   77, 78, 0, 0, 62, 74, 0, 0,
   61, 61, 0, 0, 61, 61, 0, 0,
   0, 0, 61, 61, 61, 61, 0, 0,
   0, 0, 61, 61, 0, 0, 0, 0,
   0, 0, 0, 0, 61, 61, 0, 0,
   61, 61, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 62, 74, 61, 61,
   0, 0, 0, 0, 0, 0, 61, 61,
   0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 61, 61, 0, 0, 0, 0,
   0, 0
};
struct yysvf exp_yysvec[] = {
   0, 0, 0,
   -1, 0, exp_yyvstop + 1,
   -4, exp_yysvec + 1, exp_yyvstop + 4,
   -14, 0, exp_yyvstop + 7,
   -17, exp_yysvec + 3, exp_yyvstop + 10,
   -71, 0, exp_yyvstop + 13,
   -109, exp_yysvec + 5, exp_yyvstop + 16,
   -32, exp_yysvec + 1, exp_yyvstop + 19,
   -34, exp_yysvec + 1, exp_yyvstop + 22,
   0, 0, exp_yyvstop + 25,
   4, 0, exp_yyvstop + 27,
   0, 0, exp_yyvstop + 30,
   5, 0, exp_yyvstop + 32,
   -172, 0, exp_yyvstop + 34,
   -51, exp_yysvec + 13, exp_yyvstop + 37,
   0, 0, exp_yyvstop + 41,
   0, exp_yysvec + 12, exp_yyvstop + 44,
   0, 0, exp_yyvstop + 47,
   11, 0, exp_yyvstop + 50,
   -208, 0, exp_yyvstop + 53,
   0, 0, exp_yyvstop + 55,
   19, 0, exp_yyvstop + 58,
   -226, 0, exp_yyvstop + 61,
   0, exp_yysvec + 12, exp_yyvstop + 63,
   0, 0, exp_yyvstop + 66,
   36, 0, exp_yyvstop + 69,
   0, 0, exp_yyvstop + 72,
   0, 0, exp_yyvstop + 75,
   18, 0, exp_yyvstop + 78,
   0, 0, exp_yyvstop + 81,
   0, 0, exp_yyvstop + 84,
   232, 0, exp_yyvstop + 87,
   24, 0, exp_yyvstop + 90,
   0, 0, exp_yyvstop + 93,
   27, 0, exp_yyvstop + 96,
   0, 0, exp_yyvstop + 99,
   4, 0, exp_yyvstop + 102,
   0, 0, exp_yyvstop + 105,
   257, 0, exp_yyvstop + 108,
   0, 0, exp_yyvstop + 112,
   0, 0, exp_yyvstop + 115,
   0, 0, exp_yyvstop + 118,
   332, 0, exp_yyvstop + 121,
   0, 0, exp_yyvstop + 124,
   2, 0, exp_yyvstop + 128,
   0, 0, exp_yyvstop + 131,
   0, 0, exp_yyvstop + 135,
   0, exp_yysvec + 10, exp_yyvstop + 138,
   0, 0, exp_yyvstop + 140,
   -61, exp_yysvec + 13, exp_yyvstop + 142,
   -118, exp_yysvec + 13, exp_yyvstop + 144,
   0, 0, exp_yyvstop + 147,
   0, exp_yysvec + 19, 0,
   0, 0, exp_yyvstop + 149,
   0, 0, exp_yyvstop + 151,
   0, exp_yysvec + 21, exp_yyvstop + 153,
   0, exp_yysvec + 22, 0,
   0, 0, exp_yyvstop + 155,
   43, 0, exp_yyvstop + 157,
   0, 0, exp_yyvstop + 159,
   0, 0, exp_yyvstop + 161,
   -454, 0, 0,
   417, 0, exp_yyvstop + 163,
   0, exp_yysvec + 31, exp_yyvstop + 165,
   24, 0, 0,
   29, 0, exp_yyvstop + 167,
   0, 0, exp_yyvstop + 169,
   0, 0, exp_yyvstop + 171,
   0, 0, exp_yyvstop + 173,
   0, 0, exp_yyvstop + 175,
   0, exp_yysvec + 38, exp_yyvstop + 177,
   0, exp_yysvec + 42, exp_yyvstop + 180,
   0, 0, exp_yyvstop + 182,
   0, 0, exp_yyvstop + 184,
   135, 0, 0,
   32, 0, 0,
   0, 0, exp_yyvstop + 186,
   427, 0, 0,
   0, exp_yysvec + 77, exp_yyvstop + 188,
   0, 0, exp_yyvstop + 190,
0, 0, 0};
struct yywork *exp_yytop = exp_yycrank + 549;
struct yysvf *exp_yybgin = exp_yysvec + 1;
unsigned char exp_yymatch[] = {
   00, 01, 01, 01, 01, 01, 01, 01,
   01, 011, 012, 01, 01, 01, 01, 01,
   01, 01, 01, 01, 01, 01, 01, 01,
   01, 01, 01, 01, 01, 01, 01, 01,
   011, 01, '"', 01, '$', '$', '$', 047,
   '(', '(', '(', '+', 01, '+', 01, 01,
   '0', '0', '2', '2', '2', '2', '2', '2',
   '2', '2', 01, 01, 01, 01, 01, 01,
   '$', 'A', 'A', 'A', 'A', 'E', 'A', 'A',
   'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A',
   'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A',
   'A', 'A', 'A', 01, 01, 01, '$', '_',
   01, 'A', 'A', 'A', 'A', 'E', 'A', 'A',
   'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A',
   'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A',
   'A', 'A', 'A', '$', 01, '$', '$', 01,
   01, 01, 01, 01, 01, 01, 01, 01,
   01, 01, 01, 01, 01, 01, 01, 01,
   01, 01, 01, 01, 01, 01, 01, 01,
   01, 01, 01, 01, 01, 01, 01, 01,
   01, 01, 01, 01, 01, 01, 01, 01,
   01, 01, 01, 01, 01, 01, 01, 01,
   01, 01, 01, 01, 01, 01, 01, 01,
   01, 01, 01, 01, 01, 01, 01, 01,
   01, 01, 01, 01, 01, 01, 01, 01,
   01, 01, 01, 01, 01, 01, 01, 01,
   01, 01, 01, 01, 01, 01, 01, 01,
   01, 01, 01, 01, 01, 01, 01, 01,
   01, 01, 01, 01, 01, 01, 01, 01,
   01, 01, 01, 01, 01, 01, 01, 01,
   01, 01, 01, 01, 01, 01, 01, 01,
   01, 01, 01, 01, 01, 01, 01, 01,
0};
unsigned char exp_yyextra[] = {
   0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0,
0};
/* @(#) $Revision: 70.1 $      */
extern int yylineno;
# define YYU(x) x
# define NLSTATE exp_yyprevious=YYNEWLINE

#ifdef YYNLS16_WCHAR
unsigned char exp_yytextuc[YYLMAX * sizeof(wchar_t)];
# ifdef YY_PCT_POINT            /* for %pointer */
wchar_t exp_yytextarr[YYLMAX];
wchar_t *exp_yytext;
# else /* %array */
wchar_t exp_yytextarr[1];
wchar_t exp_yytext[YYLMAX];
# endif
#else
unsigned char exp_yytextuc;
# ifdef YY_PCT_POINT            /* for %pointer */
unsigned char exp_yytextarr[YYLMAX];
unsigned char *exp_yytext;
# else /* %array */
unsigned char exp_yytextarr[1];
unsigned char exp_yytext[YYLMAX];
# endif
#endif

struct yysvf *exp_yylstate[YYLMAX],
**exp_yylsp,
**exp_yyolsp;
unsigned char exp_yysbuf[YYLMAX];
unsigned char *exp_yysptr = exp_yysbuf;
int *exp_yyfnd;
extern struct yysvf *exp_yyestate;
int exp_yyprevious = YYNEWLINE;
exp_yylook()
{
   register struct yysvf *yystate,
   **lsp;
   register struct yywork *yyt;
   struct yysvf *yyz;
   int yych,
    yyfirst;
   struct yywork *yyr;
# ifdef LEXDEBUG
   int debug;
# endif
/*	char *yylastch;
 * ***** nls8 ***** */
   unsigned char *yylastch,
    sec;
   /* start off machines */
# ifdef LEXDEBUG
   debug = 0;
# endif
   yyfirst = 1;
   if (!exp_yymorfg)
#ifdef YYNLS16_WCHAR
      yylastch = exp_yytextuc;
#else
      yylastch = exp_yytext;
#endif
   else {
      exp_yymorfg = 0;
#ifdef YYNLS16_WCHAR
      yylastch = exp_yytextuc + exp_yylenguc;
#else
      yylastch = exp_yytext + exp_yyleng;
#endif
   }
   for (;;) {
      lsp = exp_yylstate;
      exp_yyestate = yystate = exp_yybgin;
      if (exp_yyprevious == YYNEWLINE)
         yystate++;
      for (;;) {
# ifdef LEXDEBUG
         if (debug)
            fprintf(yyout, "state %d\n", yystate - exp_yysvec - 1);
# endif
         yyt = &exp_yycrank[yystate->yystoff];
         if (yyt == exp_yycrank && !yyfirst) {  /* may not be any transitions */
            yyz = yystate->yyother;
            if (yyz == 0)
               break;
            if (yyz->yystoff == 0)
               break;
         }
         *yylastch++ = yych = input();
         yyfirst = 0;
   tryagain:
# ifdef LEXDEBUG
         if (debug) {
            fprintf(yyout, "char ");
            allprint(yych);
            putchar('\n');
         }
# endif
         yyr = yyt;
         if ((int) yyt > (int) exp_yycrank) {
            yyt = yyr + yych;
            if (yyt <= exp_yytop && yyt->verify + exp_yysvec == yystate) {
               if (yyt->advance + exp_yysvec == YYLERR) {   /* error transitions */
                  unput(*--yylastch);
                  break;
               }
               *lsp++ = yystate = yyt->advance + exp_yysvec;
               goto contin;
            }
         }
# ifdef YYOPTIM
         else if ((int) yyt < (int) exp_yycrank) { /* r < exp_yycrank */
            yyt = yyr = exp_yycrank + (exp_yycrank - yyt);
# ifdef LEXDEBUG
            if (debug)
               fprintf(yyout, "compressed state\n");
# endif
            yyt = yyt + yych;
            if (yyt <= exp_yytop && yyt->verify + exp_yysvec == yystate) {
               if (yyt->advance + exp_yysvec == YYLERR) {   /* error transitions */
                  unput(*--yylastch);
                  break;
               }
               *lsp++ = yystate = yyt->advance + exp_yysvec;
               goto contin;
            }
            yyt = yyr + YYU(exp_yymatch[yych]);
# ifdef LEXDEBUG
            if (debug) {
               fprintf(yyout, "try fall back character ");
               allprint(YYU(exp_yymatch[yych]));
               putchar('\n');
            }
# endif
            if (yyt <= exp_yytop && yyt->verify + exp_yysvec == yystate) {
               if (yyt->advance + exp_yysvec == YYLERR) {   /* error transition */
                  unput(*--yylastch);
                  break;
               }
               *lsp++ = yystate = yyt->advance + exp_yysvec;
               goto contin;
            }
         }
         if ((yystate = yystate->yyother) && (yyt = &exp_yycrank[yystate->yystoff]) != exp_yycrank) {
# ifdef LEXDEBUG
            if (debug)
               fprintf(yyout, "fall back to state %d\n", yystate - exp_yysvec - 1);
# endif
            goto tryagain;
         }
# endif
         else {
            unput(*--yylastch);
            break;
         }
   contin:
# ifdef LEXDEBUG
         if (debug) {
            fprintf(yyout, "state %d char ", yystate - exp_yysvec - 1);
            allprint(yych);
            putchar('\n');
         }
# endif
         ;
      }
# ifdef LEXDEBUG
      if (debug) {
         fprintf(yyout, "stopped at %d with ", *(lsp - 1) - exp_yysvec - 1);
         allprint(yych);
         putchar('\n');
      }
# endif
      while (lsp-- > exp_yylstate) {
         *yylastch-- = 0;
         if (*lsp != 0 && (exp_yyfnd = (*lsp)->yystops) && *exp_yyfnd > 0) {
            exp_yyolsp = lsp;
            if (exp_yyextra[*exp_yyfnd]) {   /* must backup */
               while (exp_yyback((*lsp)->yystops, -*exp_yyfnd) != 1 && lsp > exp_yylstate) {
                  lsp--;
                  unput(*yylastch--);
               }
            }
            exp_yyprevious = YYU(*yylastch);
            exp_yylsp = lsp;
#ifdef YYNLS16_WCHAR
            exp_yylenguc = yylastch - exp_yytextuc + 1;
            exp_yytextuc[exp_yylenguc] = 0;
#else
            exp_yyleng = yylastch - exp_yytext + 1;
            exp_yytext[exp_yyleng] = 0;
#endif
# ifdef LEXDEBUG
            if (debug) {
               fprintf(yyout, "\nmatch ");
#ifdef YYNLS16_WCHAR
               sprint(exp_yytextuc);
#else
               sprint(exp_yytext);
#endif
               fprintf(yyout, " action %d\n", *exp_yyfnd);
            }
# endif
            return (*exp_yyfnd++);
         }
         unput(*yylastch);
      }
#ifdef YYNLS16_WCHAR
      if (exp_yytextuc[0] == 0 /* && feof(yyin) */ )
#else
      if (exp_yytext[0] == 0 /* && feof(yyin) */ )
#endif
      {
         exp_yysptr = exp_yysbuf;
         return (0);
      }
#ifdef YYNLS16_WCHAR
      exp_yyprevious = exp_yytextuc[0] = input();
#else
      exp_yyprevious = exp_yytext[0] = input();
#endif
      if (exp_yyprevious > 0) {
         output(exp_yyprevious);
#ifdef YYNLS16
         if (yynls16)
#ifdef YYNLS16_WCHAR
            if (FIRSTof2(exp_yytextuc[0]))
#else
            if (FIRSTof2(exp_yytext[0]))
#endif
               if (SECof2(sec = input()))
#ifdef YYNLS16_WCHAR
                  output(exp_yyprevious = exp_yytextuc[0] = sec);
#else
                  output(exp_yyprevious = exp_yytext[0] = sec);
#endif
               else
                  unput(sec);
#endif
      }
#ifdef YYNLS16_WCHAR
      yylastch = exp_yytextuc;
#else
      yylastch = exp_yytext;
#endif
# ifdef LEXDEBUG
      if (debug)
         putchar('\n');
# endif
   }
}

# ifdef __cplusplus
exp_yyback(int *p, int m)
# else
exp_yyback(p, m)
int *p;
# endif
{
   if (p == 0)
      return (0);
   while (*p) {
      if (*p++ == m)
         return (1);
   }
   return (0);
}
 /* the following are only used in the lex library */
static yyinput()
{
   return (input());

}

#ifdef __cplusplus
void exp_yyoutput(int c)
#else
exp_yyoutput(c)
int c;
# endif
{
   output(c);
}

#ifdef __cplusplus
void yyunput(int c)
#else
static yyunput(c)
int c;
#endif
{
   unput(c);
}
