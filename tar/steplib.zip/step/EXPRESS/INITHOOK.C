/* dummy function, user can supply one allowing them to setup a backend */
/* or customize other parts of fedex application */

void EXPRESSinit_init()
{
}
