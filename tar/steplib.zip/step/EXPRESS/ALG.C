static char rcsid[] = "$Id: alg.c,v 1.2 1993/10/15 18:48:48 libes Exp $";

/************************************************************************
** Module:	Algorithm
** Description:	This module implements the Algorithm abstraction.  An
**	algorithm can be a procedure, a function, or a rule.  It consists
**	of a name, a return type (for functions and rules), a list of
**	formal parameters, and a list of statements (body).
** Constants:
**	ALGORITHM_NULL	- the null algorithm
**
************************************************************************/

/*
 * This code was developed with the support of the United States Government,
 * and is not subject to copyright.
 *
 * $Log: alg.c,v $
 * Revision 1.2  1993/10/15  18:48:48  libes
 * CADDETC certified
 *
 * Revision 1.5  1993/02/16  03:13:56  libes
 * add Where type
 *
 * Revision 1.4  1992/08/18  17:13:43  libes
 * rm'd extraneous error messages
 *
 * Revision 1.3  1992/06/08  18:06:57  libes
 * prettied up interface to print_objects_when_running
 */

#define ALGORITHM_C
#include "alg.h"
#include "object.h"
#include "schema.h"

Scope
ALGcreate(char type)
{
	Scope s = SCOPEcreate(type);

	switch(type) {
	case OBJ_PROCEDURE:
		s->u.proc = PROC_new();
		break;
	case OBJ_FUNCTION:
		s->u.func = FUNC_new();
		break;
	case OBJ_RULE:
		s->u.rule = RULE_new();
		break;
	}
	return s;
}

/*
** Procedure:	ALGinitialize
** Parameters:	-- none --
** Returns:	void
** Description:	Initialize the Algorithm module.
*/

Symbol *
WHERE_get_symbol(Generic w)
{
	return(((Where)w)->label);
}

void
ALGinitialize(void)
{
	MEMinitialize(&FUNC_fl,sizeof(struct Function),	100,50);
	MEMinitialize(&RULE_fl,sizeof(struct Rule),	100,50);
	MEMinitialize(&PROC_fl,sizeof(struct Procedure),100,50);
	MEMinitialize(&WHERE_fl,sizeof(struct Where),100,50);
	OBJcreate(OBJ_RULE,SCOPE_get_symbol,"rule",OBJ_UNUSED_BITS);
	OBJcreate(OBJ_PROCEDURE,SCOPE_get_symbol,"procedure",OBJ_PROCEDURE_BITS);
	OBJcreate(OBJ_FUNCTION,SCOPE_get_symbol,"function",OBJ_FUNCTION_BITS);
	OBJcreate(OBJ_WHERE,WHERE_get_symbol,"where",OBJ_UNFINDABLE_BITS);
}
