#define  CLASSES_MISC_C
#include "classes.h"
/*******************************************************************
** FedEx parser output module for generating C++  class definitions
** December  5, 1989
** release 2 17-Feb-1992
** release 3 March 1993
** release 4 December 1993
** K. C. Morris
**
** Development of FedEx was funded by the United States Government,
** and is not subject to copyright.

*******************************************************************
The conventions used in this binding follow the proposed specification
for the STEP Standard Data Access Interface as defined in document
N350 ( August 31, 1993 ) of ISO 10303 TC184/SC4/WG7.
*******************************************************************/



/******************************************************************
**    The following functions will be used      ***
***      through out the the program fedex_plus    ***/


/******************************************************************
 ** Procedure:  CheckWord
 ** Description: if word is a reserved word, it is capitalized
 ** Parameters:  word -- string to be checked
 ** Returns:  altered word if word is reserved;  otherwise the original word
 ** Side Effects:  the word is altered in memory
 ** Status:  started 12/1
 ******************************************************************/
const char *
 CheckWord(const char *word)
{
#ifdef NOT_USING_SDAI_BINDING
/*  obsolete with proposed c++ binding  */

   static char *reserved_words[] = {
      "application_marker", "asm", "attributes", "auto",
      "break", "case", "char", "class", "const", "continue",
      "default", "delete", "do", "double",
      "else", "enum", "extern",
      "float", "for", "friend", "goto", "handle",
      "if", "inline", "instance_id", "int", "long",
      "new", "nullable", "opcode", "operator", "overload",
      "private", "protected", "public", "register", "return",
      "shared", "short", "sizeof", "static", "struct", "switch",
      "this", "template", "type", "typedef", "type_name",
      "union", "unsigned",
      "val", "virtual", "void", "volatile"
   };
   int nwords = (sizeof reserved_words / sizeof reserved_words[0]);
   int cond,
    i,
    low = 0,
    high = nwords - 1;

   /* word is obviously not in list, if it is longer than any of the words in the list  */
   if (strlen(word) > 12)
      return (word);

   while (low <= high) {
      i = (low + high) / 2;
      if ((cond = strcmp(word, reserved_words[i])) < 0)
         high = i - 1;
      else if (cond > 0)
         low = i + 1;
      else {                    /* word is a reserved word, capitalize it   */
         printf("** warning: reserved word  %s  ", word);
         *(word + 0) = toupper(*(word + 0));
         printf("is changed to  %s **\n", word);

      }
   }
#endif
   return (word);

}

/******************************************************************
 ** Procedure:  string functions
 ** Description:  These functions take a character or a string and return
 **   a temporary copy of the string with the function applied to it.
 ** Parameters:
 ** Returns:  temporary copy of characters
 ** Side Effects:  character or string returned persists until the
 **   next invocation of the function
 ** Status:  complete
 ******************************************************************/

char ToLower(char c)
{
   if (isupper(c))
      return (tolower(c));
   else
      return (c);

}

char ToUpper(char c)
{
   if (islower(c))
      return (toupper(c));
   else
      return (c);
}

const char *
 StrToLower(const char *word)
{
   static char newword[MAX_LEN];
   int i = 0;
   if (!word)
      return 0;
   while (word[i] != '\0') {
      newword[i] = ToLower(word[i]);
      ++i;
   }
   newword[i] = '\0';
   return (newword);

}

const char *
 StrToUpper(const char *word)
{
   static char newword[MAX_LEN];
   int i = 0;
   char ToUpper(char c);

   while (word[i] != '\0') {
      newword[i] = ToUpper(word[i]);
      ++i;

   }
   newword[i] = '\0';
   return (newword);
}

const char *
 StrToConstant(const char *word)
{
   static char newword[MAX_LEN];
   int i = 0;

   while (word[i] != '\0') {
      if (word[i] == '/' || word[i] == '.')
         newword[i] = '_';
      else
         newword[i] = ToUpper(word[i]);
      ++i;

   }
   newword[i] = '\0';
   return (newword);
}

/******************************************************************
 ** Procedure:  FILEcreate
 ** Description:  creates a file for c++ with header definitions
 ** Parameters:  filename
 ** Returns:  FILE*  pointer to file created or NULL
 ** Side Effects:  creates a file with name filename
 ** Status:  complete
 ******************************************************************/

FILE *
 FILEcreate(const char *filename)
{
   FILE *file;
   const char *fn;

   if ((file = fopen(filename, "w")) == NULL) {
      printf("**Error in SCHEMAprint:  unable to create file %s ** \n", filename);
      return (NULL);
   }

   fprintf(file, "#ifndef  %s\n", fn = StrToConstant(filename));
   fprintf(file, "#define  %s\n", fn);

   fprintf(file, "// This file was generated by fedex_plus.  You probably don't want to edit\n");
   fprintf(file, "// it since your modifications will be lost if fedex_plus is used to\n");
   fprintf(file, "// regenerate it.\n");

   fprintf(file, "\n\n#include \"stdafx.h\"\n");

   return (file);

}

/******************************************************************
 ** Procedure:  FILEclose
 ** Description:  closes a file opened with FILEcreate
 ** Parameters:  FILE*  file  --  pointer to file to close
 ** Returns:
 ** Side Effects:
 ** Status:  complete
 ******************************************************************/

void FILEclose(FILE *file)
{
   fprintf(file, "#endif\n");
   fclose(file);
}


/******************************************************************
 ** Procedure:  isAggregate
 ** Parameters:  Attribute a
 ** Returns:  int    indicates whether the attribute is an aggregate
 ** Description:     indicates whether the attribute is an aggregate
 ** Side Effects:  none
 ** Status:  complete 1/15/91
 ******************************************************************/

int isAggregate(Variable a)
{
   return (TYPEinherits_from(VARget_type(a), aggregate_));
}

int isAggregateType(const Type t)
{
   return (TYPEinherits_from(t, aggregate_));
}


/******************************************************************
 ** Procedure:  TYPEget_ctype
 ** Parameters:  const Type t --  type for attribute
 ** Returns:  a string which is the type of the data member in the c++ class
 ** Description:  supplies the type of a data member for the c++ class
 ** Side Effects:
 ** Status:  complete 1/15/90
 ** Changes: Modified by CD to return the appropiate types as outlined in "SDAI
 **          C++ Binding for PDES, Inc. Prototyping" by Stephen Clark
 ** Change Date: 5/22/91 CD
 ** Change Date: 28-Sep-1993 made entities use their real type instead of base class STEPentityH
******************************************************************/

const char *
 TYPEget_ctype(const Type t)
{
   Class_Of_Type class;
   // class2;
   Type bt;
   static char retval[BUFSIZ];
   // char *n;


   /* aggregates are based on their base type  case TYPE_ARRAY: case TYPE_BAG: case TYPE_LIST: case TYPE_SET: */
   if (isAggregateType(t)) {
      bt = TYPEget_body(t)->base;

      if (isAggregateType(bt)) {
         return ("GenericAggregate");
      }

      class = TYPEget_type(bt);

      /* case TYPE_INTEGER:    */
      if (class == Class_Integer_Type)
         return ("IntAggregate");

      /* case TYPE_REAL: case TYPE_NUMBER:    */
      if ((class == Class_Number_Type) || (class == Class_Real_Type))
         return ("RealAggregate");

      /* case TYPE_ENTITY:  */
      if (class == Class_Entity_Type)
         return ("EntityAggregate");

      /* case TYPE_ENUM:       */
      /* case TYPE_SELECT:  */
      if ((class == Class_Enumeration_Type)
          || (class == Class_Select_Type)) {
         strcpy(retval, ClassName(TYPEget_name(bt)));
         strcat(retval, "s");
         return (retval);
      }

      /* case TYPE_LOGICAL:    */
      if ((class == Class_Boolean_Type) || (class == Class_Logical_Type))
         return ("  Logicals");

      /* case TYPE_STRING:  */
      if (class == Class_String_Type)
         return ("StringAggregate");

      /* case TYPE_BINARY:  */
      if (class == Class_Binary_Type)
         return ("BinaryAggregate");


   }

   /* the rest is for things that are not aggregates   */

   class = TYPEget_type(t);

   /* case TYPE_LOGICAL:    */
   if ((class == Class_Boolean_Type) || (class == Class_Logical_Type))
      return ("SdaiLogical");

   /* case TYPE_INTEGER:    */
   if (class == Class_Integer_Type)
      return ("SdaiInteger");

   /* case TYPE_REAL: case TYPE_NUMBER:    */
   if ((class == Class_Number_Type) || (class == Class_Real_Type))
      return ("SdaiReal");

   /* case TYPE_STRING:  */
   if (class == Class_String_Type)
      return ("SdaiString");

   /* case TYPE_BINARY:  */
   if (class == Class_Binary_Type)
      return ("SdaiBinary");

   /* case TYPE_ENTITY:  */
   if (class == Class_Entity_Type) {
      strncpy(retval, TypeName(t), BUFSIZ - 2);
      strcat(retval, "H");
      return retval;
/* return ("STEPentityH");    */
   }
   /* case TYPE_ENUM:    */
   /* case TYPE_SELECT:  */
   if ((class == Class_Enumeration_Type) || (class == Class_Select_Type)) {
      return (TypeName(t));
   }

   /* default returns undefined   */
   return ("SCLundefined");
}

/******************************************************************
 ** Procedure:  TypeName
 ** Parameters:  Type t
 ** Returns:  name of type as defined in SDAI C++ binding  4-Nov-1993
 ** Status:   4-Nov-1993
 ******************************************************************/
const char *
 TypeName(Type t)
{
   static char name[BUFSIZ];
   strcpy(name, TYPE_PREFIX);
   if (TYPEget_name(t))
      strncat(name, FirstToUpper(TYPEget_name(t)), BUFSIZ - strlen(TYPE_PREFIX) - 1);
   else
      return TYPEget_ctype(t);
   return name;
}

/******************************************************************
 ** Procedure:  AccessType
 ** Parameters:  const Type t --  type for attribute
 ** Returns:  a string which is the type used by the access functions to
              the data member in the c++ class
 ** Description:  supplies the type for access functions in a c++ class
 ** Side Effects:
 ** Status:    3-Nov-1993 -kcm
******************************************************************/

const char *
 AccessType(Type t)
{
   static char nm[BUFSIZ];
   strncpy(nm, TypeName(t), BUFSIZ - 2);
   if ((TYPEis_entity(t)) || (TYPEis_select(t)) || (TYPEis_aggregate(t)))
      strcat(nm, "H");
   return nm;
}

/******************************************************************
 ** Procedure:  ClassName
 ** Parameters:  const char * oldname
 ** Returns:  temporary copy of name suitable for use as a class name
 ** Side Effects:  erases the name created by a previous call to this function
 ** Status:  complete
 ******************************************************************/

const char *
 ClassName(const char *oldname)
{
   int i = 0,
    j = 0;
   static char newname[BUFSIZ];
   if (!oldname)
      return ("");


   strcpy(newname, ENTITYCLASS_PREFIX);
   j = strlen(ENTITYCLASS_PREFIX);
   newname[j] = ToUpper(oldname[i]);
   ++i;
   ++j;
   while (oldname[i] != '\0') {
      newname[j] = ToLower(oldname[i]);
/* if (oldname [i] == '_')  */
/*  character is '_' */
/*     newname [++j] = ToUpper (oldname [++i]);*/
      ++i;
      ++j;
   }
   newname[j] = '\0';
   return (newname);

/******  This procedure gets rid of '_' and is no longer being used
   if (oldname [i] != '_') newname [j] = ToLower (oldname [i]);
       * else {   *//* character is '_'    *//* newname [j] = ToUpper (oldname [++i]); if (oldname [i] == '\0') --i; }
    * ++i; ++j; ***** */
}

/******************************************************************
 ** Procedure:  ENTITYget_classname
 ** Parameters:  Entity ent
 ** Returns:  the name of the c++ class representing the entity
 ** Status:  complete
 ******************************************************************/

const char *
 ENTITYget_classname(Entity ent)
{
   const char *oldname = ENTITYget_name(ent);
   return (ClassName(oldname));
}

/******************************************************************
 ** Procedure:  PrettyTmpName (char * oldname)
 ** Procedure:  PrettyNewName (char * oldname)
 ** Parameters:  oldname
 ** Returns:  a new capitalized name
 ** Description:  creates a new name with first character's in caps
 ** Side Effects:  PrettyNewName allocates memory for the new name
 ** Status:   OK  7-Oct-1992 kcm
 ******************************************************************/
const char *
 PrettyTmpName(const char *oldname)
{
   int i = 0;
   static char newname[BUFSIZ];
   newname[0] = '\0';
   while ((oldname[i] != '\0') && (i < BUFSIZ)) {
      newname[i] = ToLower(oldname[i]);
      if (oldname[i] == '_') {  /* character is '_'   */
         ++i;
         newname[i] = ToUpper(oldname[i]);
      }
      if (oldname[i] != '\0')
         ++i;
   }

   newname[0] = ToUpper(oldname[0]);
   newname[i] = '\0';
   return newname;
}

const char *
 EnumName(const char *oldname)
{
   int i = 0,
    j = 0;
   static char newname[MAX_LEN];
   if (!oldname)
      return ("");

   strcpy(newname, ENUM_PREFIX);
   j = strlen(ENUM_PREFIX);
   newname[j] = ToUpper(oldname[0]);
   strncpy(newname + j + 1, StrToLower(oldname + 1), MAX_LEN - j - 1);
   j = strlen(newname);
   newname[j] = '\0';
   return (newname);
}

const char *
 SelectName(const char *oldname)
{
   int i = 0,
    j = 0;
   static char newname[MAX_LEN];
   if (!oldname)
      return ("");

   strcpy(newname, ENUM_PREFIX);
   newname[0] = ToUpper(newname[0]);
   j = strlen(ENUM_PREFIX);
   newname[j] = ToUpper(oldname[0]);
   strncpy(newname + j + 1, StrToLower(oldname + 1), MAX_LEN - j - 1);
   j = strlen(newname);
   newname[j] = '\0';
   return (newname);
}

const char *
 FirstToUpper(const char *word)
{
   static char newword[MAX_LEN];
   int i = 0;

   strncpy(newword, word, MAX_LEN);
   newword[0] = ToUpper(newword[0]);
   return (newword);
}

const char *
 TypeDescriptorName(Type t, Schema s)
{
   static char b[BUFSIZ];
   sprintf(b, "%s%s%s", SCHEMAget_name(s), TYPEprefix(t), TYPEget_name(t));
   return b;
}

int ENTITYhas_explicit_attributes(Entity e)
{
   Linked_List l = ENTITYget_attributes(e);
   int cnt = 0;
   LISTdo(l, a, Variable)
      if (VARget_initializer(a) == EXPRESSION_NULL)
      ++cnt;
   LISTod;
   return cnt;

}

Entity
ENTITYput_superclass(Entity entity)
{
#define ENTITYget_type(e)  ((e)->u.entity->type)

   Linked_List l = ENTITYget_supertypes(entity);
   Entity super = 0;
   Entity ignore = 0;
   int super_cnt = 0;
   EntityTag tag;

   if (!LISTempty(l)) {
      LISTdo(l, e, Entity)
      /* if there\'s no super class yet, or the super class doesn\'t have any attributes */
         if ((!super) || (!ENTITYhas_explicit_attributes(super))) {
         ignore = super;
         super = e;
         ++super_cnt;
      }
      else {
         ignore = e;
      }
      // if (ignore) {
      //   printf("WARNING:  multiple inheritance not implemented.\n");
      //   printf("\tin ENTITY %s\n\tSUPERTYPE %s IGNORED.\n\n",
      //          ENTITYget_name(entity), ENTITYget_name(e));
      // }
      LISTod;

      tag = (EntityTag) malloc(sizeof(struct EntityTag));
      tag->superclass = super;
      TYPEput_clientData(ENTITYget_type(entity), tag);
      return super;
   }
   return 0;
}

Entity
ENTITYget_superclass(Entity entity)
{
   EntityTag tag;
   tag = TYPEget_clientData(ENTITYget_type(entity));
   return (tag ? tag->superclass : 0);
}

/* Attributes are divided into four categories:
**
**      . simple explicit
** . type shifters
**      . simple derived
** . overriding
**
** All of them are added to the dictionary.
** Only overriding generate a new STEPattribute.
** Overriding generate access functions and data members, for now.
** Type shifters generate access functions and data members, for now.

** //  type shifting attributes
** //  ------------------------
** // before printing new STEPattribute
** // check to see if it\'s already printed in supertype
** // still add new access function
**
** //  overriding attributes
** //  ---------------------
** // go through derived attributes
** // if STEPattribute found with same name
** // tell it to be * for reading and writing
**/

Variable
VARis_type_shifter(Variable a)
{
   char *temp;

   if (VARis_derived(a) || VARget_inverse(a))
      return 0;

   temp = EXPRto_string(VARget_name(a));
   if (!strncmp(StrToLower(temp), "self\\", 5)) {
      /* a is a type shifter */
      free(temp);
      return a;
   }
   free(temp);
   return 0;
}

Variable
VARis_overrider(Entity e, Variable a)
{

   Variable other;
   char *tmp;

   tmp = VARget_simple_name(a);

   LISTdo(ENTITYget_supertypes(e), s, Entity)
      if ((other = ENTITYget_named_attribute(s, tmp))
          && other != a)
      return other;
   LISTod;
   return 0;
}

int isvowel(char c)
{
   switch (c) {
 case 'a':
 case 'A':
 case 'e':
 case 'E':
 case 'i':
 case 'I':
 case 'o':
 case 'O':
 case 'u':
 case 'U':
 case 'y':
 case 'Y':
      return 1;
   default:
      return 0;
   }
}

typedef struct stringname {
   char shortName[20];
   char name[1000];
} StringName;

int renameShortName(char *shortName, char *longName, Linked_List names)
{
   LISTdo (names, sname, StringName *)
      if ((strcmp(sname->shortName, shortName) == 0) &&
          (strcmp(sname->name, longName) != 0)) {
         // short name is equal to another shortName.
         if (isdigit(shortName[strlen(shortName) - 1])) {
            shortName[strlen(shortName) - 1]++;
            return 1;
         }
         else {
            shortName[strlen(shortName) - 1] = '0';
            return 1;
         }
      }
   LISTod;
   return 0;
}

int longNameInList(char *shortName, char *longName, Linked_List names)
{
   LISTdo (names, sname, StringName *)
      if (strcmp(sname->name, longName) == 0) {
         // long name is equal to another longName.
         strcpy(shortName, sname->shortName);
         return 1;
      }
   LISTod;
   return 0;
}



void eightCharName(char *longName, char *shortName)
{
   static Linked_List names = NULL;
   StringName *sname;

   if (strlen(longName) < 9) {
      strcpy(shortName, longName);
   }
   else {
      int len = strlen(longName);
      int i,
       j;
      for (i = 0, j = 0; ((i < 8) && (j < len)); j++) {
         if ((i == 0) && isalpha(longName[j])) {
            shortName[i++] = longName[j];
            shortName[i] = 0;
         }
         else if (isalpha(longName[j])) {
            if ((8 - i) < (len - j)) {
               if (isvowel(longName[j]))
                  continue;
               else if (shortName[i - 1] == longName[j])
                  continue;
               else {
                  shortName[i++] = longName[j];
                  shortName[i] = 0;
               }
            }
            else {
               strcat(shortName, &longName[j]);
               break;
            }
         }
      }
   }
   if (names) {
      if (!longNameInList(shortName, longName, names)) {
         while (renameShortName(shortName, longName, names));
         sname = (StringName *) malloc (sizeof(StringName));
         strcpy(sname->shortName,shortName);
         strcpy(sname->name,longName);
         LISTadd_last (names, sname);
      }
   }
   else {
      names = LISTcreate();
      sname = (StringName *) malloc (sizeof(StringName));
      strcpy(sname->shortName,shortName);
      strcpy(sname->name,longName);
      LISTadd_first (names, sname);
   }
}

