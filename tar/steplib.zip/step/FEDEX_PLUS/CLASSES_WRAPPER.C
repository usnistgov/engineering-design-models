#include "classes.h"
/*******************************************************************
** FedEx parser output module for generating C++  class definitions
** December  5, 1989
** release 2 17-Feb-1992
** release 3 March 1993
** release 4 December 1993
** K. C. Morris
**
** Development of FedEx was funded by the United States Government,
** and is not subject to copyright.

*******************************************************************
The conventions used in this binding follow the proposed specification
for the STEP Standard Data Access Interface as defined in document
N350 ( August 31, 1993 ) of ISO 10303 TC184/SC4/WG7.
*******************************************************************/

/******************************************************************
***   The functions in this file drive the processing of an     **
***   EXPRESS file.                                             **
 **                        **/


void use_ref(Schema, Express, FILES *);

void create_builtin_type_decl(FILES * files, char *name)
{
   fprintf(files->incall, "extern TypeDescriptor *%s%s_TYPE;\n",
           TD_PREFIX, name);
/* fprintf(files->initall,"TypeDescriptor *%s%s_TYPE;\n",*/
/*    TD_PREFIX,name);*/
}

void create_builtin_type_defn(FILES * files, char *name)
{
   fprintf(files->initall, "\t%s%s_TYPE = new TypeDescriptor (",
           TD_PREFIX, name);
   fprintf(files->initall, "\"%s\", %s_TYPE, \"%s\");\n",
           PrettyTmpName(name), StrToUpper(name), StrToLower(name));
}

/******************************************************************
 ** Procedure: print_file_header
 ** Parameters:   const Schema schema  - top-level schema being printed
 **      FILE*        file - file on which to print header
 ** Returns:
 ** Description:  handles file related tasks that need to be done once
 **   at the beginning of processing.
 **   In this case the files make_schema and schema.h are initiated
 ** Side Effects:  prints opening line of make_schema file
 ** Status:  ok 1/15/91
 ******************************************************************/

/*ARGSUSED*/
void print_file_header(Express express, FILES * files)
{
   /* open file to record schema source files in to be used in makefile  */
   if (((files->make) = fopen("make_schema", "w")) == NULL) {
      printf("**Error in print_file_header:  unable to open file make_schema ** \n");
      return;
   }
   fprintf(files->make, "OFILES =  schema.o ");


   /* open file which unifies all schema specific header files of input Express source */
   files->incall = FILEcreate("schema.h");

   /* prevent RCS from expanding this! */
   fprintf(files->incall, "/* %cId$ */\n", '$');
   fprintf(files->incall, "#ifdef __O3DB__\n");
   fprintf(files->incall, "#include <OpenOODB.h>\n");
   fprintf(files->incall, "#endif\n\n");
   fprintf(files->incall, "#include <sdai.h>\n\n");
   fprintf(files->incall, "\n#include <Registry.h>\n");
   fprintf(files->incall, "\n#include <STEPaggregate.h>\n");
   fprintf(files->incall, "\n#include <STEPentity.h>\n");
   fprintf(files->incall, "\n#include <STEPundefined.h>\n");
   fprintf(files->incall, "extern void SchemaInit (Registry &);\n");

   files->initall = FILEcreate("schema.cpp");
   fprintf(files->initall, "/* %cId$  */ \n", '\044');
/*    fprintf (files ->initall, "#include <schema.h>\n");*/
   fprintf(files->initall, "class Registry;\n");

   fprintf(files->initall, "\nvoid \nSchemaInit (Registry & reg)\n{\n");

   /* create built-in types */
/*  no need to generate
   create_builtin_type_decl(files,"INTEGER");
   create_builtin_type_decl(files,"REAL");
   create_builtin_type_decl(files,"STRING");
   create_builtin_type_decl(files,"BINARY");
   create_builtin_type_decl(files,"BOOLEAN");
   create_builtin_type_decl(files,"LOGICAL");
   create_builtin_type_decl(files,"NUMBER");
   create_builtin_type_decl(files,"GENERIC");
*/
   /* create built-in types */
/*  no need to generate
   create_builtin_type_defn(files,"INTEGER");
   create_builtin_type_defn(files,"REAL");
   create_builtin_type_defn(files,"STRING");
   create_builtin_type_defn(files,"BINARY");
   create_builtin_type_defn(files,"BOOLEAN");
   create_builtin_type_defn(files,"LOGICAL");
   create_builtin_type_defn(files,"NUMBER");
   create_builtin_type_defn(files,"GENERIC");
*/

}

/******************************************************************
 ** Procedure: print_file_trailer
 ** Parameters:   const Schema schema  - top-level schema printed
 **      FILE*        file - file on which to print trailer
 ** Returns:
 ** Description:  handles cleaning up things at end of processing
 ** Side Effects:  closes make_schema file
 ** Status:  ok 1/15/91
 ******************************************************************/

/*ARGSUSED*/
void print_file_trailer(Express express, FILES * files)
{
   fprintf(files->make, "\n");
   fclose(files->make);
   FILEclose(files->incall);

   fprintf(files->initall, "\n}\n");
   FILEclose(files->initall);
}

/******************************************************************
 **  SCHEMA SECTION                  **/

/******************************************************************
 ** Procedure: SCOPEPrint
 ** Parameters:   const Scope scope - scope to print
 **      FILE*       file  - file on which to print
 ** Returns:
 ** Description:  cycles through the scopes of the input Express schema
 ** Side Effects:  calls functions for processing entities and types
 ** Status:  working 1/15/91
 **   --  it's still not clear how include files should be organized
 **   and what the relationship is between this organization and the
 **   organization of the schemas in the input Express
 ******************************************************************/

void SCOPEPrint(Scope scope, FILES * files, Schema schema, Express model)
{
   Linked_List list;
   int nument,ncurent = 0;
   char nm[BUFSIZ];
   void ENTITYprint_new(Entity entity, FILES * files, Schema schema);
   char fnm[MAX_LEN];
   char longSchnm[MAX_LEN];
   char schnm[MAX_LEN];
   char orgschnm[MAX_LEN];

   DictionaryEntry de;

   fprintf(files->inc, "\n/*\t**************  TYPES  \t*/\n");
   fprintf(files->lib, "\n/*\t**************  TYPES  \t*/\n");
   fprintf(files->init, "\n/*\t**************  TYPES  \t*/\n");

   /* do \'new\'s for types descriptors  */
   SCOPEdo_types(scope, t, de)
      TYPEprint_new(t, files, schema);
   SCOPEod;

   /* do \'new\'s for entity descriptors  */
   list = SCOPEget_entities_superclass_order(scope);
   fprintf(files->init, "\n\t//\t*****  Describe the Entities  \t*/\n");
   fprintf(files->inc, "\n//\t***** Describe the Entities  \t\n");
   LISTdo(list, e, Entity);
     ENTITYput_superclass(e);     /* find supertype to use for single inheritance */
     ENTITYprint_new(e, files, schema);
   LISTod;

   /* fill in the values for the type descriptors */
   /* and print the enumerations  */
   fprintf(files->inc, "\n//\t***** Describe the Other Types  \t\n");
   SCOPEdo_types(scope, t, de)
      TYPEprint_descriptions(t, files, schema);
   if (TYPEis_select(t)) {
      /* do the select aggregates here  */
      strncpy(nm, SelectName(TYPEget_name(t)), BUFSIZ);
      fprintf(files->inc, "class %s;\n"
              "typedef %s * %sH;\n\n",
              nm, nm, nm);
      fprintf(files->inc, "class %ss;\n"
              "typedef %ss * %ssH;\n",
              nm, nm, nm);
   }
   SCOPEod;

   /* build the typedefs  */
   SCOPEdo_types(scope, t, de)
      if (!(TYPEis_select(t)))
      TYPEprint_typedefs(t, files->inc);
   SCOPEod;

   sprintf(longSchnm, "%s%s", SCHEMA_FILE_PREFIX, StrToUpper(SCHEMAget_name(schema)));
   eightCharName ( longSchnm, orgschnm);

   /* do the select definitions next, since they depend on the others  */
   fprintf(files->inc, "\n//\t***** Build the SELECT Types  \t\n");
   fprintf(files->init, "\n//\t***** Add the TypeDescriptor's to the SELECT Types  \t\n");
   SCOPEdo_types(scope, t, de)
      if (TYPEis_select(t))
      TYPEselect_print(t, files, schema);
      ncurent++;
      if ((ncurent % 50) == 0) {
         sprintf(longSchnm, "%s%s%d", SCHEMA_FILE_PREFIX, StrToUpper(SCHEMAget_name(schema)),ncurent);
         eightCharName ( longSchnm, schnm);
         sprintf(fnm, "%s.cpp", schnm);
         FILEclose (files->lib);
         if (!((files->lib) = FILEcreate(fnm))) return;
         fprintf(files->lib, "/* %cId$ */\n", '$');
         fprintf(files->lib, "#include \"%s.h\"\n", orgschnm);
      }
   SCOPEod;

   fprintf(files->inc, "\n/*\t**************  ENTITIES  \t*/\n");
   fprintf(files->lib, "\n/*\t**************  ENTITIES  \t*/\n");

   fprintf(files->inc, "\n//\t***** Print Entity Classes  \t\n");


   nument = LISTget_length(list);
   LISTdo(list, e, Entity);
      ENTITYPrint(e, files, schema);
      ncurent++;
      if ((ncurent % 50) == 0) {
         sprintf(longSchnm, "%s%s%d", SCHEMA_FILE_PREFIX, StrToUpper(SCHEMAget_name(schema)),ncurent);
         eightCharName ( longSchnm, schnm);
         sprintf(fnm, "%s.cpp", schnm);
         FILEclose (files->lib);
         if (!((files->lib) = FILEcreate(fnm))) return;
         fprintf(files->lib, "/* %cId$ */\n", '$');
         fprintf(files->lib, "#include \"%s.h\"\n", orgschnm);
      }
   LISTod;
   LISTfree(list);

#if following_should_be_done_in_caller
   list = SCOPEget_schemata(scope);
   fprintf(files->inc, "\n/*\t**************  SCOPE  \t*/\n");
   fprintf(files->lib, "\n/*\t**************  SCOPE  \t*/\n");

   LISTdo(list, s, Schema)
      sprintf(nm, "%s%s", SCHEMA_PREFIX, SCHEMAget_name(s));
   fprintf(files->inc, "// \t include definitions for %s \n", nm);
   fprintf(files->inc, "#include <%s.h> \n", nm);
#if 0
   l = SCOPEget_imports(s);
   fprintf(files->inc, "/*  the following are *assumed* in the express schema  */\n");
   LISTdo(l, s, Schema)
      fprintf(files->inc, "/*  include definitions for %s  */\n",
              nm = ClassName(SCHEMAget_name(s)));
/*            fprintf (files -> inc, "#include <%s.h> \n", nm);*/
   LISTod;
#endif

   LISTod;
#endif

#if 0
   use_ref(schema, model, files);
#endif
}

#if 0
/* simulate USE/REFERENCE by creating links */
/* assignments have to be done after all initializations above */
void use_ref(Schema schema, Express model, FILES * files)
{
   DictionaryEntry de;
   Rename *r;

   DICTdo_init(schema->u.schema->usedict, &de);
   while (0 != (r = (Rename *) DICTdo(&de))) {

   }

   DICTdo_init(schema->u.schema->refdict, &de);
   while (0 != (r = (Rename *) DICTdo(&de))) {

   }

   LISTdo(schema->u.schema->uselist, r, Rename *)
      LISTod

      LISTdo(schema->u.schema->reflist, r, Rename *)
      LISTod
}
#endif

/******************************************************************
 ** Procedure: SCHEMAprint
 ** Parameters:   const Schema schema  - schema to print
 **      FILE*        file - file on which to print
 ** Returns:
 ** Description:  handles initialization of files specific to schemas
 ** Side Effects:
 ** Status:
 ******************************************************************/

void SCHEMAPrint(Schema schema, FILES * files, Express model)
{
   char fnm[MAX_LEN];
   char longSchnm[MAX_LEN],
   *np;
   char schnm[MAX_LEN];
   FILE *libfile;
   FILE *incfile;
   FILE *schemafile = files->incall;
   FILE *schemainit = files->initall;
   FILE *makefile = files->make;
   FILE *initfile;

   /**********  create files based on name of schema  ***********/
   /* return if failure        */
   /* 1.  header file             */
   sprintf(longSchnm, "%s%s", SCHEMA_FILE_PREFIX, StrToUpper(SCHEMAget_name(schema)));
   eightCharName ( longSchnm, schnm);
   sprintf(fnm, "%s.h", schnm);

   if (!(incfile = (files->inc) = FILEcreate(fnm)))
      return;
   fprintf(incfile, "/* %cId$  */ \n", '\044');
   fprintf(incfile, "#ifdef __O3DB__\n");
   fprintf(incfile, "#include <OpenOODB.h>\n");
   fprintf(incfile, "#endif\n\n");
   fprintf(incfile,
           "#ifndef  SCHEMA_H \n"
           "#include <schema.h> \n"
           "#endif \n");

/*    Generate local to SCHEMA.init.cc file  */
/*    fprintf(incfile,"SchemaDescriptor *%s%s;\n",*/
/*    SCHEMA_PREFIX,SCHEMAget_name(schema));*/

/*    fprintf (incfile, "extern void %sInit (Registry & r);\n", schnm);*/
/*    fprintf (incfile, "extern void SchemaInit (Registry & r);\n");*/

   np = fnm + strlen(fnm) - 2;  /* point to end of constant part of string  */

   /* 2.  class source file          */
   sprintf(np, ".cpp");
   if (!(libfile = (files->lib) = FILEcreate(fnm)))
      return;
   fprintf(libfile, "/* %cId$  */ \n", '$');
#ifdef SCHEMA_HANDLING
   sprintf(np, "h");
   fprintf(libfile, "#ifndef  %s\n", StrToConstant(fnm));
   fprintf(libfile, "#include <%s.h> \n", schnm);
   fprintf(libfile, "#endif");
#else
   fprintf(libfile,
           "#ifndef  SCHEMA_H \n"
           "#include <schema.h> \n"
           "#endif \n");
#endif

   /* 3.  source code to initialize entity registry    */
   /* prints header of file for input function   */

   sprintf(np, "_init.cpp");
   if (!(initfile = (files->init) = FILEcreate(fnm)))
      return;
   /* prevent RCS from expanding this! */
   fprintf(initfile, "/* $Id%c */\n", '$');
#ifdef SCHEMA_HANDLING
   fprintf(initfile, "#include <%s.h> \n", schnm);
#else
   fprintf(initfile,
           "#ifndef  SCHEMA_H \n"
           "#include <schema.h> \n"
           "#endif \n");
#endif
   fprintf(initfile, "#include <Registry.h>\n");

   fprintf(initfile, "void \n%sInit (Registry& reg)\n{\n", longSchnm);
   fprintf(initfile, "\tSchemaDescriptor *  %s%s = new SchemaDescriptor(\"%s\");\n",
           SCHEMA_PREFIX, SCHEMAget_name(schema),
           PrettyTmpName(SCHEMAget_name(schema)));

   fprintf(initfile, "\treg.AddSchema (*%s%s);\n",
           SCHEMA_PREFIX, SCHEMAget_name(schema));

   /**********  record in files relating to entire input    ***********/

   /* add soruce files to list for makefile   */
   fprintf(makefile, "\\\n\t%s.o ", schnm);
   fprintf(makefile, "\\\n\t%s.init.o ", schnm);

   /* add to schema's include and initialization file  */
   fprintf(schemafile, "#include <%s.h> \n", schnm);
   fprintf(schemafile, "extern void %sInit (Registry & r);\n", longSchnm);
   fprintf(schemainit, "\t extern void %sInit (Registry & r);\n", longSchnm);
   fprintf(schemainit, "\t %sInit (reg); \n", longSchnm);

   /**********  make an explicit makefile rule for the schema  ***********/
   /* replaced by list of source files (above) used with a general rule in the makefile.  the code is here in case it
    * is needed later    */

/*    fprintf (makefile, " \n%s.o:  %s.cc\n", schnm);
//    fprintf (makefile, "\techo  \"compiling %s.cc\" \n", schnm);
//    fprintf (makefile, "\tCC -I$(INCLUDE) -c %s.cc -L$(LIBS)\n", schnm);
//    fclose (makefile);
//    if ((makefile = fopen ("makefull", "a")) == NULL) {
// printf ("**Error in SCHEMAprint:  unable to open file sources ** \n");
// return;
//    }
*/

   /**********  do the schemas   ***********/

   /* really, create calls for entity constructors */
   SCOPEPrint(schema, files, schema, model);

#if 0
   /* create calls for connecting sub/supertypes */
   STypePrint(schema, files, schema);
#endif

   /**********  close the files  ***********/
   FILEclose(libfile);
   FILEclose(incfile);
   fprintf(initfile, "\n}\n");
   FILEclose(initfile);

}


/******************************************************************
 ** Procedure:  EXPRESSPrint
 ** Parameters:
       Express express -- in memory representation of an express model
       FIELS* files  -- set of output files to print to
 ** Returns:
 ** Description:  drives functions to generate code for all the schemas
 **   in an Express model into one set of files  -- works with
 **     print_schemas_combined
 ** Side Effects:  generates code
 ** Status:  24-Feb-1992 new -kcm
 ******************************************************************/
void EXPRESSPrint(Express express, FILES * files)
{
   char fnm[MAX_LEN],
   *np;
   const char *schnm;           /* schnm is really "express name" */
   FILE *libfile;
   FILE *incfile;
   FILE *schemafile = files->incall;
   FILE *schemainit = files->initall;
   FILE *makefile = files->make;
   FILE *initfile;
   /* new */
   Schema schema;
   DictionaryEntry de;


   /**********  create files based on name of schema  ***********/
   /* return if failure        */
   /* 1.  header file             */
   sprintf(fnm, "%s.h", schnm = ClassName(EXPRESSget_basename(express)));
   if (!(incfile = (files->inc) = FILEcreate(fnm)))
      return;
   fprintf(incfile, "/* %cId$ */\n", '$');
   fprintf(incfile, "#ifdef __O3DB__\n");
   fprintf(incfile, "#include <OpenOODB.h>\n");
   fprintf(incfile, "#endif\n\n");
   fprintf(incfile, "#include <sdai.h> \n");
/*    fprintf (incfile, "#include <schema.h> \n");*/
/*    fprintf (incfile, "extern void %sInit (Registry & r);\n", schnm);*/

   np = fnm + strlen(fnm) - 1;  /* point to end of constant part of string  */

   /* 2.  class source file          */
   sprintf(np, "cpp");
   if (!(libfile = (files->lib) = FILEcreate(fnm)))
      return;
   fprintf(libfile, "/* %cId$ */\n", '$');
   fprintf(libfile, "#include <%s.h> n", schnm);

   /* 3.  source code to initialize entity registry    */
   /* prints header of file for input function   */

   sprintf(np, "init.cpp");
   if (!(initfile = (files->init) = FILEcreate(fnm)))
      return;
   fprintf(initfile, "/* $Id%d */\n", '$');
   fprintf(initfile, "#include <%s.h>\n\n", schnm);
   fprintf(initfile, "void \n%sInit (Registry& reg)\n{\n", schnm);

   /**********  record in files relating to entire input    ***********/

   /* add soruce files to list for makefile   */
   fprintf(makefile, "\\\n %s.o   ", schnm);
   fprintf(makefile, "\\\n %s.init.o   ", schnm);

   /* add to schema's include and initialization file  */
   fprintf(schemafile, "#include <%s.h>\n\n", schnm);
   fprintf(schemafile, "extern void %sInit (Registry & r);\n", schnm);
   fprintf(schemainit, "\t extern void %sInit (Registry & r);\n", schnm);
   fprintf(schemainit, "\t %sInit (reg);\n", schnm);

   /**********  make an explicit makefile rule for the schema  ***********/
   /* replaced by list of source files (above) used with a general rule in the makefile.  the code is here in case it
    * is needed later    */

/*    fprintf (makefile, " \n%s.o:  %s.cc\n", schnm, schnm);
//    fprintf (makefile, "\techo  \"compiling %s.cc\" \n", schnm);
//    fprintf (makefile, "\tCC -I$(INCLUDE) -c %s.cc -L$(LIBS)\n", schnm);
//    fclose (makefile);
//    if ((makefile = fopen ("makefull", "a")) == NULL) {
// printf ("**Error in SCHEMAprint:  unable to open file sources ** \n");
// return;
//    }
*/

   /**********  do all schemas   ***********/
   DICTdo_init(express->symbol_table, &de);
   while (0 != (schema = (Scope) DICTdo(&de))) {
      SCOPEPrint(schema, files, schema, express);
   }


   /**********  close the files  ***********/
   FILEclose(libfile);
   FILEclose(incfile);
   fprintf(initfile, "\n}\n");
   FILEclose(initfile);

}

/******************************************************************
 ** Procedure:  print_schemas_separate
 ** Parameters:
       Express express -- in memory representation of an express model
       FIELS* files  -- set of output files to print to
 ** Returns:
 ** Description:  drives functions to generate code for all the schemas
 **   in an Express model into separate sets of files - works with
 **   SCHEMAPrint
 ** Side Effects:  generates code
 ** Status:  24-Feb-1992 new -kcm
 ******************************************************************/
void print_schemas_separate(Express express, FILES * files)
{

   DictionaryEntry de;
   Schema schema;

   /**********  do all schemas   ***********/
   DICTdo_init(express->symbol_table, &de);
   while (0 != (schema = (Scope) DICTdo(&de))) {
      SCHEMAPrint(schema, files, express);
   }
}

/******************************************************************
 ** Procedure:  print_schemas_combined
 ** Parameters:
       Express express -- in memory representation of an express model
       FIELS* files  -- set of output files to print to
 ** Returns:
 ** Description:  drives functions to generate code for all the schemas
 **   in an Express model into one set of files  -- works with EXPRESSPrint
 ** Side Effects:  generates code
 ** Status:  24-Feb-1992 new -kcm
 ******************************************************************/

void print_schemas_combined(Express express, FILES * files)
{

   EXPRESSPrint(express, files);
}

/*
** Procedure:  print_file
** Parameters: const Schema schema  - top-level schema to print
**    FILE*        file - file on which to print
** Returns: void
** Description:  this function calls one of two different functions
** depending on whether the output should be combined into a single
** set of files or a set separate set for each schema
**
*/

void print_file(Express express)
{
   extern void RESOLUTIONsucceed(void);
   int separate_schemas = 1;

   File_holder files;

   resolution_success();

   print_file_header(express, &files);
   if (separate_schemas) {
      print_schemas_separate(express, &files);
   }
   else {
      print_schemas_combined(express, &files);
   }
   print_file_trailer(express, &files);
}
