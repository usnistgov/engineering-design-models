/*******************************************************************
** FedEx parser output module for generating C++  class definitions
** December  5, 1989
** release 2 17-Feb-1992
** release 3 March 1993
** release 4 December 1993
** K. C. Morris
**
** Development of FedEx was funded by the United States Government,
** and is not subject to copyright.

*******************************************************************
The conventions used in this binding follow the proposed specification
for the STEP Standard Data Access Interface as defined in document
N350 ( August 31, 1993 ) of ISO 10303 TC184/SC4/WG7.
*******************************************************************/


/**************************************************************************
********    The functions in this file generate C++ code for representing
********    EXPRESS SELECT types.
**************************************************************************/
#include "classes.h"
#define BASE_SELECT "SdaiSelect"



#define TYPEis_primitive(t)   ( !(TYPEis_entity(t) || TYPEis_select (t) || TYPEis_aggregate(t)) )

#define TYPEis_numeric(t)   (((t)->u.type->body->type == real_) || \
               ((t)->u.type->body->type == integer_) || \
               ((t)->u.type->body->type == number_) )
#define PRINT_BUG_REPORT  \
     fprintf( f, "   cerr << __FILE__ << \":\" << __LINE__ <<  \":  ERROR in schema library:  \\n\" \n\t<< _POC_ << \"\\n\\n\";\n");

#define PRINT_SELECTBUG_WARNING(f) \
     fprintf( (f), "\n  severity( SEVERITY_WARNING );\n" ); \
     fprintf( (f), "   cerr << __FILE__ << \":\" << __LINE__ <<  \":  WARNING:  possible misuse of SELECT TYPE from schema library.\\n\";\n"); \
     fprintf( (f), "  Error( \"Mismatch in underlying type.\" );\n" );

#define print_error_msg() \
      fprintf( f, "\n  severity( SEVERITY_BUG );\n" ); \
      PRINT_BUG_REPORT  \
      fprintf( f, "  Error( \"This 'argument' is of the incorrect type\" );\n" );

#define TRUE      1
#define FALSE     0

const char *
 SEL_ITEMget_enumtype(Type t)
{
   return StrToUpper(TYPEget_name(t));
}


/******************************************************************
 ** Procedure:  TYPEget_utype
 ** Parameters:  Type t
 ** Returns:  type used to represent the underlying type in a select class
 ** Description:
 ** Side Effects:
 ** Status:
 ******************************************************************/

const char *
 TYPEget_utype(Type t)
{
/*
  static char b [BUFSIZ];
  strncpy (b, TYPEget_ctype (t), BUFSIZ-2);
  if (TYPEis_select (t)) strcat (b, "H");
  */
   return (TYPEis_entity(t) ? "STEPentityH" : TYPEget_ctype(t));
}

/*******************
LISTmember

determines if the given entity is a member of the list.
RETURNS the member if it is a member; otherwise 0 is returned.
*******************/
Generic
LISTmember(const Linked_List list, Generic e)
{
   Link node;
   for (node = list->mark->next; node != list->mark; node = node->next)
      if (e == node->data)
         return e;
   return (0);
}

/*******************
utype_member

determines if the given "link's" underlying type is a member of the list.
        RETURNS the underlying type if it is a member; otherwise 0 is returned.
*******************/
const char *
 utype_member(const Linked_List list, const Type check)
{
   char r[BUFSIZ];
   // *p;
   LISTdo(list, t, Type)
      strncpy(r, TYPEget_utype(t), BUFSIZ);
   if (strcmp(r, TYPEget_utype(check)) == 0)
      return r;
   LISTod;
   return 0;
}

/**
***  SELgetnew_dmlist (const Type type)
***  Returns a list of types which have unique underlying types
***  The returned list includes all the types which have a data members
***  in the select type.
***
***  The list that is returned needs to be freed by the caller.
***/


Linked_List
SELgetnew_dmlist(const Type type)
{
   Linked_List complete = SEL_TYPEget_items(type);
   Linked_List newlist = LISTcreate();

   LISTdo(complete, t, Type)
   /* if t\'s underlying type is not already in newlist, */
      if (!utype_member(newlist, t))
      LISTadd_first(newlist, t);

   LISTod;

   return newlist;

}

const char *
 SEL_ITEMget_dmtype(Type t, const Linked_List l)
{
   const char *r = utype_member(l, t);
   return StrToLower(r ? r : TYPEget_utype(t));

}


/**
***  SEL_ITEMget_dmname (Type t)
***  Returns the name of the data member in the select class for
***  the item of the select having the type t.
***
***  Note the return value is in a static buffer.
***/

#define SEL_ITEMget_dmname(t)   StrToLower (TYPEget_utype (t))

/*******************
duplicate_utype_member

determines if the given "link's" underlying type is a multiple member
of the list.
   RETURNS 1 if true, else 0.
*******************/
int duplicate_utype_member(const Linked_List list, const Type check)
{
   char b[BUFSIZ];

   if (TYPEis_entity(check))
      return FALSE;
   /* entities are never the same  */

   LISTdo(list, t, Type)
      if (t == check);
   /* don\'t compare check to itself  */
   else {                       /* continue looking  */
      strncpy(b, TYPEget_utype(t), BUFSIZ);
      if (!strcmp(b, TYPEget_utype(check)))
         /* if the underlying types are the same  */
         return TRUE;
      if (!strcmp(b, "SdaiInteger") &&
          (!strcmp(TYPEget_utype(check), "SdaiReal")))
         /* integer\'s and real\'s are not unique  */
         return TRUE;
   }
   LISTod;
   return FALSE;
}

/*******************
any_duplicates_in_select

determines if any of the types in a select type resolve to the same
underlying Express type.
RETURNS 1 if true, else 0.
*******************/
int any_duplicates_in_select(const Linked_List list)
{
   LISTdo(list, t, Type)
   if (duplicate_utype_member(list, t))
      return TRUE;
   LISTod;
   return FALSE;
}

/*******************
find_duplicate_list

finds a instance of each kind of duplicate type found in the given list.
This list is returned as dup_list.  If a duplicate exists, the function
returns TRUE, else FALSE.
list should be unbound before calling, and freed afterwards.
*******************/
int find_duplicate_list(const Type type, Linked_List * duplicate_list)
{
   Linked_List temp;            /** temporary list for comparison **/

   *duplicate_list = LISTcreate();
   if (any_duplicates_in_select(SEL_TYPEget_items(type))) { /**  if there is a dup somewhere  **/
      temp = LISTcreate();
      LISTdo(SEL_TYPEget_items(type), u, Type)
         if (!utype_member(*duplicate_list, u)) {  /**  if not already a duplicate  **/
         if (utype_member(temp, u))
            LISTadd_first(*duplicate_list, u);
         else
            LISTadd_first(temp, u);
      }
      LISTod;
      LISTfree(temp);
      return TRUE;
   }
   return FALSE;
}

/******************************************************************
 ** Procedure:  ATTR_LISTmember
 ** Parameters:  Linked_List l, Variable check
 ** Returns:  the attribute if an attribute with the same name as "check"
 **  is on the list, 0 otherwise
 ** Description:  checks to see if an attribute is a member of the list
 ** Side Effects:
 ** Status:  26-Oct-1993 done
 ******************************************************************/

Variable
ATTR_LISTmember(Linked_List l, Variable check)
{
   char nm[BUFSIZ];
   char cur[BUFSIZ];

   generate_attribute_name(check, nm);
   LISTdo(l, a, Variable)
      generate_attribute_name(a, cur);
   if (!strcmp(nm, cur))
      return check;
   LISTod;
   return (0);
}


/******************************************************************
 ** Procedure:  SEL_TYPEgetnew_attribute_list
 ** Parameters:  const Type type
 ** Returns:  Returns a list of all the attributes for a select type.
 **   The list is the union of all the attributes of the underlying types.
 ** Description:
 ** Side Effects:
***  The list that is returned needs to be freed by the caller.
 ** Status:
 ******************************************************************/

Linked_List
SEL_TYPEgetnew_attribute_list(const Type type)
{
   Linked_List complete = SEL_TYPEget_items(type);
   Linked_List newlist = LISTcreate();
   Linked_List attrs;
   Entity cur;

   LISTdo(complete, t, Type)
      if (TYPEis_entity(t)) {
      cur = ENT_TYPEget_entity(t);
      attrs = ENTITYget_all_attributes(cur);
      LISTdo(attrs, a, Variable)
         if (!ATTR_LISTmember(newlist, a))
         LISTadd_first(newlist, a);
      LISTod;
   }
   LISTod;
   return newlist;
}

/*******************
TYPEselect_inc_print_vars prints the class 'definition', that is, the objects
   and the constructor(s)/destructor for a select class.
*******************/
void TYPEselect_inc_print_vars(const Type type, FILE *f, Linked_List dups)
{
   char buffer[BUFSIZ],
   *buf = buffer;
   char sbuf[2048];
   // int result;
   Linked_List data_members = SELgetnew_dmlist(type);
   char dmname[BUFSIZ];
   char classnm[BUFSIZ];
   buffer[0] = '\0';

   strncpy(classnm, SelectName(TYPEget_name(type)), BUFSIZ);
   fprintf(f, "\n//////////  SELECT TYPE %s\n", TYPEget_name(type));
/*  fprintf( f, "class %s;\n"*/
/*    "typedef %s * %sH;\n\n",*/
/*    classnm, classnm, classnm);*/
   fprintf(f, "class %s  :  public " BASE_SELECT " {\n", classnm);
   fprintf(f, "  protected:\n");
/*   fprintf( f, "  \tunion {  \n" );  */
   fprintf(f, "/*  \tunion {  */\n");
   fprintf(f, "\t//  types in SELECT \n");
   LISTdo(SEL_TYPEget_items(type), t, Type)
      fprintf(f, "\t//   %s\t--  %s\n",
              SEL_ITEMget_enumtype(t), FundamentalType(t, 0));
   LISTod;

   LISTdo(data_members, t, Type)
      strncpy(dmname, SEL_ITEMget_dmname(t), BUFSIZ);
   fprintf(f, "\t   %s _%s;\n",
           TYPEget_utype(t), dmname
      );
   LISTod;

/*   fprintf( f, "  \t}  ;" );*/
   fprintf(f, "/*  \t} ;  */");
   fprintf(f, "  /* unnamed union of select items */\n");

   fprintf(f, "\n  public:\n"
           "\tvirtual const TypeDescriptor * AssignEntity (STEPentity * se);\n"
           "\tvirtual SdaiSelect * NewSelect ();\n"
      );

   fprintf(f, "\n\n// STEP Part 21\n");
   fprintf(f, "\tvirtual void STEPwrite_content (ostream& out =cout) const;\n");
   fprintf(f, "\tvirtual Severity STEPread_content "
           "(istream& in =cin, InstMgr * instances =0, int addFileId =0);\n");

   /* read StrToVal_content   */
   fprintf(f, "\n\tvirtual Severity StrToVal_content "
           "(const char *, InstMgr * instances =0);\n");

   /* constructor(s)  */
   fprintf(f, "\n// STEP Part 22:  SDAI\n");
   fprintf(f, "\n// structors\n\t%s();\n", classnm);

   fprintf(f, "\t//  part 1\n");

   LISTdo(SEL_TYPEget_items(type), t, Type)
      if ((TYPEis_entity(t)) ||
          (!utype_member(dups, t))) {
      /**  if an entity or not in the dup list  **/
      sprintf(sbuf, "\t%s( const %s& );\n", SelectName(TYPEget_name(type)), AccessType(t));
      fprintf(f, "%s", sbuf);
      }
   LISTod;
   LISTdo(dups, t, Type)
   if (!TYPEis_entity(t)) {  /* entity\'s were done already */
      if (isAggregateType(t)) {
         sprintf(sbuf, "\t%s( const %sH& );\n", SelectName(TYPEget_name(type)), TYPEget_utype(t));
         fprintf(f, "%s", sbuf);
      }
      else {
         sprintf(sbuf, "\t%s( const %s& );\n", SelectName(TYPEget_name(type)), TYPEget_utype(t));
         fprintf(f, "%s", sbuf);
      }
   }
   LISTod;

   /* destructor   */
   fprintf(f, "\tvirtual ~%s();\n", classnm);

}

/*******************
TYPEselect_inc_print prints the class member function declarations of a select class.
*******************/
void TYPEselect_inc_print(const Type type, FILE *f)
{
   char n[BUFSIZ];              /* class name  */
   // char tdnm[BUFSIZ];           /* TypeDescriptor name  */
   // String attrnm;
   Linked_List dups;
   int dup_result;
   Linked_List attrs;

   dup_result = find_duplicate_list(type, &dups);
   strncpy(n, SelectName(TYPEget_name(type)), BUFSIZ);
   TYPEselect_inc_print_vars(type, f, dups);

   fprintf(f, "\n\t//  part 2\n");

   LISTdo(SEL_TYPEget_items(type), t, Type)
      if ((TYPEis_entity(t)) ||
          (!utype_member(dups, t)))
      /**  if an entity or not in the dup list  **/
      fprintf(f, "\toperator %s();\n", AccessType(t));
   LISTod;
   LISTdo(dups, t, Type)
      if (!TYPEis_entity(t))    /* entity\'s were done already */
      fprintf(f, "\toperator %s ();\n",
              TYPEis_aggregate(t) ?
              AccessType(t) : TYPEget_utype(t));
   LISTod;

   fprintf(f, "\n\t//  part 3\n");
   attrs = SEL_TYPEgetnew_attribute_list(type);
   /* get the list of unique attributes from the entity items */
   LISTdo(attrs, a, Variable)
      if (VARget_initializer(a) == EXPRESSION_NULL)
      ATTRsign_access_methods(a, f);
   LISTod;

   fprintf(f, "\n\t//  part 4\n");
   LISTdo(SEL_TYPEget_items(type), t, Type)
      if ((TYPEis_entity(t)) ||
          (!utype_member(dups, t)))
      /**  if an entity or not in the dup list  **/
      fprintf(f, "\t%s& operator =( const %s& );\n",
              SelectName(TYPEget_name(type)), AccessType(t));
   LISTod;
   LISTdo(dups, t, Type)
      if (!TYPEis_entity(t)) {  /* entity\'s were done already */
      if (isAggregateType(t))
         fprintf(f, "\t%s& operator =( const %sH& );\n",
                 SelectName(TYPEget_name(type)), TYPEget_utype(t));
      else
         fprintf(f, "\t%s& operator =( const %s& );\n",
                 SelectName(TYPEget_name(type)), TYPEget_utype(t));
   }
   LISTod;

   fprintf(f, "\n#ifdef COMPILER_DEFINES_OPERATOR_EQ\n#else\n"
           "\t// not in SDAI\n");
   fprintf(f, "\t%s& operator =( const %sH& );\n", n, n);
   fprintf(f, "\t%s& operator =( const %s& );\n", n, n);
   fprintf(f, "#endif\n");

   fprintf(f, "\n\t//  part 5\n");
   LISTdo(SEL_TYPEget_items(type), t, Type)
      fprintf(f, "\t%sLogical Is%s() const;\n", ENTITYCLASS_PREFIX,
              FirstToUpper(TYPEget_name(t)));
   LISTod;

   fprintf(f, "\n\t//  part 6 ... UnderlyingTypeName () implemented in SdaiSelect class ...\n");
/*   fprintf( f, "\tSdaiString UnderlyingTypeName() const;\n" );*/
/*   fprintf( f, "\tconst EntityDescriptor * CurrentUnderlyingType();\n" );*/

   if (dup_result) {            /**  if there are duplicate underlying types  **/
      fprintf(f, "\n\t//  part 7\n");
      fprintf(f, "\tconst TypeDescriptor *"
              "SetUnderlyingType ( const TypeDescriptor * td );\n", n);
   }
   else
      fprintf(f, "\n\t//  part 7 ... NONE\tonly for complex selects...\n");

#ifdef PART8
   fprintf(f, "\n\t//  part 8\n");
   fprintf(f, "\t%s* operator->();\n", n);
#endif

   fprintf(f, "};\n");

/* DAS brandnew below */

   /* DAS creation function select class */
   fprintf(f, "\ninline %s * create_%s () { return new %s ; }\n\n",
           SelectName(TYPEget_name(type)),
           SelectName(TYPEget_name(type)),
           SelectName(TYPEget_name(type)));

/* DAS brandnew above */

   /* print things for aggregate class  */
   fprintf(f, "\nclass %ss  :  public  SelectAggregate  {\n", n);
   fprintf(f, "  public:\n\tvirtual SingleLinkNode * NewNode ()  {\n");
   fprintf(f, "\t  return new SelectNode (new %s);\t}\n};\n", n);

/* DAS brandnew below */

   /* DAS creation function for select aggregate class */
   fprintf(f, "\ninline %ss * create_%ss () { return new %ss ; }\n",
           SelectName(TYPEget_name(type)),
           SelectName(TYPEget_name(type)),
           SelectName(TYPEget_name(type)));

/* DAS brandnew above */


   fprintf(f, "\n/////  END SELECT TYPE %s \n\n",
           TYPEget_name(type));

   LISTfree(dups);
}


/*******************
TYPEselect_lib_print_part_one prints constructor(s)/destructor of a select class.
*******************/
void TYPEselect_lib_print_part_one(const Type type, FILE *f, Schema schema, Linked_List dups, char *n)
{
#define schema_name  SCHEMAget_name(schema)
   // char var,
   // attrnm[BUFSIZ],
   char tdnm[BUFSIZ];

   strncpy(tdnm, TYPEtd_name(type, schema), BUFSIZ);

   /* constructor(s)  */
   /* null constructor  */
   fprintf(f, "\n// STEP Part 22:  SDAI\n");
   fprintf(f, "\n\t//  part 0\n");
   fprintf(f, "%s::%s()\n", n, n);
   fprintf(f, "  : " BASE_SELECT " (%s)\n{\n", tdnm);

/*  fprintf( f, "#ifdef  WE_WANT_TO_HAVE_THIS_CONSTRUCTOR\n" );*/
   fprintf(f, "   nullify();\n");
/*  fprintf( f, "#endif\n" );*/
   fprintf(f, "}\n");

   /* constructors with underlying types  */
   fprintf(f, "\n\t//  part 1\n");
   LISTdo(SEL_TYPEget_items(type), t, Type)
      if ((TYPEis_entity(t)) ||
          (!utype_member(dups, t)))
      /* if there is not more than one underlying type that map to the same base type print out the constructor using
       * the type from the TYPE statement as the underlying type. */

   {                            /**  if not an entity or in the dups list  **/
      fprintf(f, "%s::%s( const %s& o )\n",
              n, n, AccessType(t));

      fprintf(f, "  : " BASE_SELECT " (%s, %s )\n{\n",
              tdnm, TYPEtd_name(t, schema));

      if (isAggregateType(t))
         fprintf(f, "   _%s.ShallowCopy (*o);\n", SEL_ITEMget_dmname(t));
      else
         fprintf(f, "   _%s = o;\n", SEL_ITEMget_dmname(t));

      fprintf(f, "}\n\n");
   }
   LISTod;
   LISTdo(dups, t, Type)
   /* if there is more than one underlying type that maps to the same base type, print a constructor using the base
    * type. */
      if (!TYPEis_entity(t)) {  /* entity\'s were done already */
      if (isAggregateType(t)) {
         fprintf(f, "%s::%s( const %sH& o )\n", n, n, TYPEget_utype(t));
         fprintf(f, "  : " BASE_SELECT " (%s, %s )\n{\n",
                 tdnm, TYPEtd_name(t, schema));
         fprintf(f, "   _%s.ShallowCopy (*o);\n", SEL_ITEMget_dmname(t));
      }
      else {
         fprintf(f, "%s::%s( const %s& o )\n", n, n, TYPEget_utype(t));
         fprintf(f, "  : " BASE_SELECT " (%s, %s )\n{\n",
                 tdnm, TYPEtd_name(t, schema));
         fprintf(f, "   _%s = o;\n", SEL_ITEMget_dmname(t));
      }
      fprintf(f,
              "//  NOTE:  Underlying type defaults to %s instead of NULL\n",
              TYPEtd_name(t, schema));
      fprintf(f, "}\n\n");
   }
   LISTod;

   fprintf(f, "%s::~%s()\n{\n", n, n);
   fprintf(f, "}\n\n");
#undef schema_name
}

Linked_List
ENTITYget_expanded_entities(Entity e, Linked_List l)
{
   Linked_List supers;
   int super_cnt = 0;
   // Entity super;

   if (!LISTmember(l, e))
      LISTadd_first(l, e);


#ifdef MULTIPLE_INHERITANCE
   supers = ENTITYget_supertypes(e);
   LISTdo(supers, s, Entity)
   /* ignore the more than one supertypes since multiple inheritance isn\'t implemented  */
      if (super_cnt == 0)
      ENTITYget_expanded_entities(s, l);
   ++super_cnt;
   LISTod;
#else
   /* ignore the more than one supertypes since multiple inheritance isn\'t implemented  */
   super = ENTITYget_superclass(e);
   ENTITYget_expanded_entities(super, l);
#endif
   return l;

}

Linked_List
SELget_entity_itemlist(const Type type)
{
   Linked_List complete = SEL_TYPEget_items(type);
   Linked_List newlist = LISTcreate();
   Entity cur;

   LISTdo(complete, t, Type)
      if (TYPEis_entity(t)) {
      cur = ENT_TYPEget_entity(t);
      ENTITYget_expanded_entities(cur, newlist);
   }
   LISTod;
   return newlist;

}

/*******************
TYPEselect_lib_print_part_three prints part 3) of the SDAI C++ binding for
a select class -- access functions for the data members of underlying entity
types.
*******************/
void TYPEselect_lib_print_part_three(const Type type, FILE *f, Schema schema, char *classnm)
{
#define ENTITYget_type(e)  ((e)->u.entity->type)

   char uent[BUFSIZ],           /* name of underlying entity type  */
    utype[BUFSIZ],              /* underlying type name  */
    attrnm[BUFSIZ],             /* attribute name ->  data member = _attrnm  */
    funcnm[BUFSIZ];             /* access function name = Attrnm  */
   Class_Of_Type class;
   Linked_List items = SEL_TYPEget_items(type);
   /* all the items in the select type  */
   Linked_List attrs = SEL_TYPEgetnew_attribute_list(type);
   /* list of attributes with unique names */
   Linked_List supers;
   Entity super;                /* super type used for super class with single inheritance  */

   Variable uattr;              /* attribute in underlying type  */

   fprintf(f, "\n\t//  part 3\n");

   LISTdo(attrs, a, Variable)
   /* go through all the unique attributes  */
      if (VARget_initializer(a) == EXPRESSION_NULL) { /* only do for explicit attributes  */
      generate_attribute_name(a, attrnm);
      strncpy(funcnm, attrnm, BUFSIZ);
      funcnm[0] = toupper(funcnm[0]);
      strncpy(utype, TYPEget_ctype(VARget_type(a)), BUFSIZ);
      /* use the ctype since utype will be the same for all entities  */
      class = TYPEget_type(VARget_type(a));

      /* get method  */
      ATTRprint_access_methods_get_head(classnm, a, f);
      fprintf(f, "{\n");

      LISTdo(items, t, Type)
         if (TYPEis_entity(t) &&
             (uattr = ENTITYget_named_attribute(ENT_TYPEget_entity(t), (char *) StrToLower(attrnm)))) {
         /* for the select items which have the current attribute  */
         /* hack around multiple inheritance only do for first supertype   */
#ifdef MULTIPLE_INHERITANCE
         supers = ENTITYget_supertypes(ENT_TYPEget_entity(t));
         if (!supers
             || (supers
                 && LISTmember(ENTITYget_all_attributes((Entity) LISTget_first(supers)), uattr)))
#else
         super = ENTITYget_superclass(ENT_TYPEget_entity(t));
         if (LISTmember(ENTITYget_attributes(ENT_TYPEget_entity(t)), uattr)
         /* attribute is in this entity - not parent  */
             || (super && LISTmember(ENTITYget_all_attributes(super), uattr)))
            /* or the attribute is from the parent that\'s being used  */
#endif
         {

            if (!VARis_derived(uattr)) {

               if (!strcmp(utype, TYPEget_ctype(VARget_type(uattr)))) {
                  /* check to make sure the underlying attribute\'s type is the same as the current attribute.  */

                  strncpy(uent, TYPEget_ctype(t), BUFSIZ);

                  /* if the underlying type is that item\'s type call the underlying_item\'s member function  */
                  fprintf(f, "  if( CurrentUnderlyingType () == %s ) \n\t//  %s\n",
                          TYPEtd_name(t, schema), StrToUpper(TYPEget_name(t)));
                  fprintf(f, "\treturn ((%s) %s::castdown (_%s)) ->%s();\n",
                          uent,  ClassName(TYPEget_name(t)), SEL_ITEMget_dmname(t), funcnm);

               }
               else {
                  /* types are not the same issue a warning  */
                  fprintf(stderr,
                          "WARNING: in SELECT TYPE %s: \n\t"
                          "ambiguous attribute \"%s\" from underlying type \"%s\".\n\n",
                          TYPEget_name(type), attrnm, TYPEget_name(t));
                  fprintf(f, "  //  %s\n\t//  attribute access function"
                          " has a different return type\n",
                          StrToUpper(TYPEget_name(t)));
               }
            }
            else                /* derived attributes  */
               fprintf(f, "  //  for %s  attribute is derived\n",
                       StrToUpper(TYPEget_name(t)));
         }
      }
      LISTod;
      PRINT_BUG_REPORT(f);
      fprintf(f, "   return (%s)NULL;\n}\n\n", AccessType(VARget_type(a)));
      
      /* put method  */
      ATTRprint_access_methods_put_head(classnm, a, f);
      fprintf(f, "{\n");
      LISTdo(items, t, Type)
         if (TYPEis_entity(t) &&
             (uattr = ENTITYget_named_attribute(ENT_TYPEget_entity(t), (char *) StrToLower(attrnm)))) {  /* for the select items
                                                                                                          * which have the
                                                                                                          * current attribute  */

         /* hack around multiple inheritance only do for first supertype   */

#ifdef MULTIPLE_INHERITANCE
         supers = ENTITYget_supertypes(ENT_TYPEget_entity(t));
         if (supers
             && LISTmember(ENTITYget_all_attributes((Entity) LISTget_first(supers)), uattr))
#else
         super = ENTITYget_superclass(ENT_TYPEget_entity(t));
         if (LISTmember(ENTITYget_attributes(ENT_TYPEget_entity(t)), uattr)
         /* attribute is in this entity - not parent  */
             || (super && LISTmember(ENTITYget_all_attributes(super), uattr)))
            /* or the attribute is from the parent that\'s being used  */
#endif
         {

            if (!VARis_derived(uattr)) {

               if (!strcmp(utype, TYPEget_ctype(VARget_type(uattr)))) {
                  /* check to make sure the underlying attribute\'s type is the same as the current attribute.  */

                  /* if the underlying type is that item\'s type call the underlying_item\'s member function  */
                  strncpy(uent, TYPEget_ctype(t), BUFSIZ);
                  fprintf(f, "  if( CurrentUnderlyingType () == %s ) \n\t//  %s\n",
                          TYPEtd_name(t, schema), StrToUpper(TYPEget_name(t)));
                  fprintf(f, "\t{  ((%s) %s::castdown(_%s)) ->%s( x );\n\t  return;\n\t}\n",
                          uent,  ClassName(TYPEget_name(t)), SEL_ITEMget_dmname(t), funcnm);
               }
               else             /* warning printed above  */
                  fprintf(f, "  //  for %s  attribute access function"
                          " has a different argument type\n",
                          SEL_ITEMget_enumtype(t));
            }
            else                /* derived attributes  */
               fprintf(f, "  //  for %s  attribute is derived\n",
                       SEL_ITEMget_enumtype(t));
         }
      }
      LISTod;
      PRINT_SELECTBUG_WARNING(f);
      fprintf(f, "\n}\n");
   }
   LISTod;

#ifdef NO_OVERLAPS
   Linked_List l = SELget_entity_itemlist(type);
   /* this part only applies to entities  */
   Type t;

   fprintf(f, "\n\t//  part 3\n");

   LISTdo(l, e, Entity)
      strncpy(uent, ClassName(ENTITYget_name(e)), BUFSIZ);
   LISTdo(ENTITYget_attributes(e), a, Variable)
      t = ENTITYget_type(e);
   if (VARget_initializer(a) == EXPRESSION_NULL) {
      generate_attribute_name(a, attrnm);
      attrnm[0] = toupper(attrnm[0]);
      strncpy(utype, TYPEget_ctype(VARget_type(a)), BUFSIZ);
   }
   class = TYPEget_type(VARget_type(a));

   /* get method  */

   ATTRprint_access_methods_get_head
      (n, a, VARget_type(a), f, class, attrnm, utype);
   fprintf(f, "{\n  //  %s\n"
           "  if( CurrentUnderlyingType () == %s )\n",
           p StrToUpper(TYPEget_name(t)),
           TYPEtd_name(t, schema));
   fprintf(f, "\treturn ((%sH) %s::castdown (_%s)) ->%s();\n\n",
           uent,  ClassName(TYPEget_name(t)), SEL_ITEMget_dmname(t), attrnm);
   PRINT_SELECTBUG_WARNING(f);
   fprintf(f, "   return NULL;\n}\n\n");

   /* put method  */

   ATTRprint_access_methods_put_head(n, a, t, f, class, attrnm, utype);
   fprintf(f, "{\n   if( CurrentUnderlyingType () == %s )  //  %s\n",
           TYPEtd_name(t, schema), SEL_ITEMget_enumtype(t));
   fprintf(f, "\t((%sH) %s::castdown (_%s)) ->%s( x );\n   else  {\n",
           uent,  ClassName(TYPEget_name(t)), SEL_ITEMget_dmname(t), attrnm);
/*       print_error_msg();*/
   PRINT_SELECTBUG_WARNING(f);
   fprintf(f, "  }\n}\n");
   LISTod;
   LISTod;

#endif
}

/*******************
TYPEselect_lib_print_part_four prints part 4) of the SDAI document of a select class.
*******************/
void TYPEselect_lib_print_part_four(const Type type, FILE *f, Schema schema, Linked_List dups, char *n)
{
   char nvar = tolower(n[4]),
    x[BUFSIZ];

   fprintf(f, "\n\t//  part 4\n");

   LISTdo(SEL_TYPEget_items(type), t, Type)
      if ((TYPEis_entity(t)) ||
          (!utype_member(dups, t))) {  /**  if an entity or not in dups list  **/
      fprintf(f, "%s& %s::operator =( const %s& o )\n{\n"
              "  nullify ();\n",
              n, n, AccessType(t));

      if (isAggregateType(t))
         fprintf(f, "   _%s.ShallowCopy (*o);\n", SEL_ITEMget_dmname(t));
      else
         fprintf(f, "   _%s = o;\n", SEL_ITEMget_dmname(t));

      fprintf(f, "   SetUnderlyingType (%s);\n", TYPEtd_name(t, schema));
      fprintf(f, "   return *this;\n}\n\n");
   }
   LISTod;
   LISTdo(dups, t, Type)
      if (!TYPEis_entity(t)) {  /* entity\'s were done already */
      if (isAggregateType(t)) {
         fprintf(f, "%s& %s::operator =( const %sH& o )\n{\n", n, n,
                 TYPEget_utype(t));
         fprintf(f, "   _%s.ShallowCopy (*o);\n",
                 SEL_ITEMget_dmname(t));
      }
      else {
         fprintf(f, "%s& %s::operator =( const %s& o )\n{\n", n, n,
                 TYPEget_utype(t));
         fprintf(f, "   _%s = o;\n", SEL_ITEMget_dmname(t));
      }
      fprintf(f, "  underlying_type = 0; // MUST BE SET BY USER \n");
      fprintf(f, "// discriminator = UNSET\n");
      fprintf(f, "   return *this;\n}\n\n");
   }
   LISTod;

   fprintf(f, "%s& %s::operator =( const %sH& o )\n{\n", n, n, n);


   LISTdo(SEL_TYPEget_items(type), t, Type)
      strncpy(x, TYPEget_name(t), BUFSIZ);
   fprintf(f, "   if( o -> CurrentUnderlyingType () == %s )\n", TYPEtd_name(t, schema));
   if (utype_member(dups, t))
      /**  if in the dup list  **/
      fprintf(f, "      _%s = o -> _%s;\n",
              SEL_ITEMget_dmname(t),
              StrToLower(TYPEget_utype(t)));
   else
      fprintf(f, "\t_%s =  o -> _%s;\n",
              SEL_ITEMget_dmname(t),
              SEL_ITEMget_dmname(t));
   LISTod;
   fprintf(f, "   underlying_type = o -> CurrentUnderlyingType ();\n");
   fprintf(f, "   return *this;\n}\n");

   fprintf(f, "%s& %s::operator =( const %s& o )\n{\n", n, n, n);

   LISTdo(SEL_TYPEget_items(type), t, Type)
      strncpy(x, TYPEget_name(t), BUFSIZ);
   fprintf(f, "   if( o.CurrentUnderlyingType () == %s )\n", TYPEtd_name(t, schema));
   if (utype_member(dups, t))
      /**  if in the dup list  **/
      fprintf(f, "      _%s = o._%s;\n",
              SEL_ITEMget_dmname(t),
              StrToLower(TYPEget_utype(t)));
   else
      fprintf(f, "\t_%s =  o._%s;\n",
              SEL_ITEMget_dmname(t),
              SEL_ITEMget_dmname(t));
   LISTod;
   fprintf(f, "   underlying_type = o.CurrentUnderlyingType ();\n");
   fprintf(f, "   return *this;\n}\n");

}


/*******************
TYPEselect_init_print prints the types that belong to the select type
*******************/

void TYPEselect_init_print(const Type type, FILE *f, Schema schema)
{
#define schema_name  SCHEMAget_name(schema)
   LISTdo(SEL_TYPEget_items(type), t, Type)
   fprintf(f, "\t%s -> Elements ().AddNode",
           TYPEtd_name(type, schema));
   fprintf(f, " (%s);\n",
           TYPEtd_name(t, schema));
   LISTod;
#undef schema_name

}


void TYPEselect_lib_part21(const Type type, FILE *f, Schema schema)
{
   char n[BUFSIZ];
   // *z;                          /* pointers to class name(s)  */
   const char *dm;              /* data member name */
   Linked_List dups;
   Linked_List data_members = SELgetnew_dmlist(type);
   int dup_result;

   dup_result = find_duplicate_list(type, &dups);
   strncpy(n, SelectName(TYPEget_name(type)), BUFSIZ);

   fprintf(f, "// STEP Part 21\n");
   /* write part 21   */
   fprintf(f, "\nvoid\n%s::STEPwrite_content (ostream& out) const\n{\n", n);

/*  go through the items  */
   LISTdo(SEL_TYPEget_items(type), t, Type)
      dm = SEL_ITEMget_dmname(t);

   fprintf(f, "  if (CurrentUnderlyingType () == %s)\n",
           TYPEtd_name(t, schema));

   switch (TYPEget_body(t)->type) {

      /* if it\'s a number, just print it  */
   case integer_:
   case real_:
   case number_:
      fprintf(f, "\tout <<  _%s;\n  else  ", dm);
      break;

   case entity_:
      fprintf(f,
              "\t_%s -> STEPwrite_reference (out);\n  else  ", dm);
      break;
   case string_:
   case enumeration_:
   case aggregate_:
   case array_:
   case bag_:
   case set_:
   case list_:
   case select_:
      /* for string\'s, enum\'s, select\'s and aggregate\'s it\'ll be embedded; */
      fprintf(f,
              "\t_%s.STEPwrite (out);\n  else  ", dm);
      break;

   default:
      /* otherwise it\'s a pointer  */
      fprintf(f,
              "\t_%s -> STEPwrite (out);\n  else  ", dm);
      break;
   }
   LISTod;

   fprintf(f, "  {\n");
   PRINT_BUG_REPORT
      fprintf(f, "  }\n");
   fprintf(f, "  return;\n}\n");

   /* read part 21   */
   fprintf(f, "\nSeverity\n%s::STEPread_content "
           "(istream& in, InstMgr * instances, int addFileId)"
           "\n{\n", n);

/*  go through the items  */
   LISTdo(SEL_TYPEget_items(type), t, Type)
      fprintf(f, "\n  if (CurrentUnderlyingType () == %s) ",
              TYPEtd_name(t, schema));

   dm = SEL_ITEMget_dmname(t);

   switch (TYPEget_body(t)->type) {
      /* if it\'s a number, just read it  */
   case real_:
   case number_:
      /* since REAL and NUMBER are handled the same they both need to be included in the case stmt  */
      fprintf(f, "  {\n\tReadReal (_%s, in, &_error, \"),\");\n"
              "\treturn severity ();\n  }\n",
              dm);
      break;

   case integer_:
      fprintf(f, "  {\n\tReadInteger (_%s, in, &_error, \"),\");\n"
              "\treturn severity ();\n  }\n",
              dm);
      break;

   case entity_:
      /* if it\'s an entity, use Assign - done in Select class  */
      fprintf(f,
              "  {\n\t// set Underlying Type in Select class\n"
              "\t_%s = ReadEntityRef "
              "(in, &_error, \",)\", instances, addFileId);\n", dm);
      fprintf(f, "\tif (_%s && (_%s != S_ENTITY_NULL)\n "
              "\t  && (CurrentUnderlyingType () -> CanBe (_%s -> EntityDescriptor )) )\n"
              "\t  return severity ();\n",
              dm, dm, dm);
      fprintf(f, "\telse {\n "
              "\t  Error (\"Reference to instance that is not indicated type\\n\");\n"
              "\t  _%s = 0;\n"
              "\t  nullify ();\n"
              "\t  return severity (SEVERITY_USERMSG);\n\t}\n  }\n",
              dm
         );
      break;

   case string_:
   case enumeration_:
      fprintf(f,
              "  {\n\t_%s.STEPread (in, &_error);\n"
              "\treturn severity ();\n  }",
              dm);
      break;
   case select_:
      fprintf(f,
              "  {\n\t_%s.STEPread (in, &_error, instances, addFileId);\n"
              "\treturn severity ();\n  }",
              dm);
      break;
   case aggregate_:
   case array_:
   case bag_:
   case set_:
   case list_:
      fprintf(f,
              "  {\n\t_%s.STEPread (in, &_error, "
              "%s -> AggrElemTypeDescriptor (), "
              "instances, addFileId);\n"
              "\treturn severity ();\n  }",
              dm,
              TYPEtd_name(t, schema));
      break;

   default:
      fprintf(f,
              "  {\n\t_%s -> STEPread (in, &_error, instances, addFileId);\n"
              "\treturn severity ();\n  }",
              dm);
      break;
   }

   LISTod;

   PRINT_SELECTBUG_WARNING(f);
   fprintf(f, "#ifdef __SUNCPLUSPLUS__\n"
           "cerr << instances << \"  \" << addFileId << endl;\n"
           "#endif\n");

   LISTfree(data_members);
   fprintf(f,
/*    "#ifdef __GNUG__\n"*/
/*    "\n  return SEVERITY_NULL;\n"*/
/*    "#endif"*/
           "\n  return severity ();"
           "\n}\n");
}


void TYPEselect_lib_StrToVal(const Type type, FILE *f, Schema schema)
{
   char n[BUFSIZ];
   // *z;                          /* pointers to class name  */
   Linked_List dups;
   Linked_List data_members = SELgetnew_dmlist(type);
   int dup_result;
   int enum_cnt = 0;
   int enum_item_cnt = 0;

   dup_result = find_duplicate_list(type, &dups);
   strncpy(n, SelectName(TYPEget_name(type)), BUFSIZ);

   /* read StrToVal_content   */
   fprintf(f, "\nSeverity\n%s::StrToVal_content "
           "(const char * val, InstMgr * instances)"
           "\n{\n", n);

   LISTdo(data_members, t, Type)

   switch (TYPEget_body(t)->type) {

      case real_:
      case integer_:
      case number_:
      case select_:
         /* if it\'s a number, use STEPread_content - done in Select class  */
         /* if it\'s a select, use STEPread_content - done in Select class  */
         break;

      case entity_:
         /* if it\'s an entity, use AssignEntity - done in Select class  */
         break;
      case enumeration_:
         enum_item_cnt++;
         break;

      case string_:
         enum_item_cnt++;
         break;

      case aggregate_:
      case array_:
      case bag_:
      case set_:
      case list_:
         enum_item_cnt++;
         break;

      default:
         enum_item_cnt++;
         break;
   }
   LISTod;

   if (enum_item_cnt) {
      fprintf(f, "  switch (base_type)  {\n");
      LISTdo(data_members, t, Type)
   /* fprintf (f, "  case %s :  \n",   FundamentalType (t, 0));*/

         switch (TYPEget_body(t)->type) {

      case real_:
      case integer_:
      case number_:
      case select_:
         /* if it\'s a number, use STEPread_content - done in Select class  */
         /* if it\'s a select, use STEPread_content - done in Select class  */
   /*   fprintf (f, "\t// done in Select class\n\treturn SEVERITY_NULL;\n");*/
         break;

      case entity_:
         /* if it\'s an entity, use AssignEntity - done in Select class  */
   /*   fprintf (f, "\t// done in Select class\n\treturn SEVERITY_NULL;\n");*/

         break;
      case enumeration_:
        if (!enum_cnt) {
            /* if there\'s more than one enumeration they are done in Select class  */
            fprintf(f, "  case %s :  \n", FundamentalType(t, 0));
            fprintf(f,
                    "\treturn _%s.StrToVal (val, &_error);\n",
                    SEL_ITEMget_dmname(t));
         }
         else {
            fprintf(f, "  //  case %s :  done in Select class\n",
                    FundamentalType(t, 0));
         }
         ++enum_cnt;
         break;

      case string_:
         fprintf(f, "  case %s :  \n", FundamentalType(t, 0));
         fprintf(f,
                 "\treturn _%s.StrToVal (val);\n",
                 SEL_ITEMget_dmname(t));
         break;

      case aggregate_:
      case array_:
      case bag_:
      case set_:
      case list_:
         fprintf(f, "  case %s :  \n", FundamentalType(t, 0));
         fprintf(f,
                 "\treturn _%s.StrToVal (val, &_error, "
                 "%s -> AggrElemTypeDescriptor ());\n",
   /*       "instances, addFileId);  "*/
                 SEL_ITEMget_dmname(t),
                 TYPEtd_name(t, schema));
         break;

      default:
         /* otherwise use StrToVal on the contents to check the format  */
         fprintf(f, "  case %s :  \n", FundamentalType(t, 0));
         fprintf(f,
                 "\treturn _%s -> StrToVal (val, instances);\n",
                 SEL_ITEMget_dmname(t));
      }
      LISTod;

      fprintf(f, "  default:  // should never be here - done in Select class\n");
      PRINT_SELECTBUG_WARNING(f);
      fprintf(f, "#ifdef __SUNCPLUSPLUS__\n"
              "cerr << val << \"  \" << instances << endl;\n"
              "#endif\n");
      fprintf(f, "\treturn SEVERITY_WARNING;\n  }\n");
   }
   else {
      PRINT_SELECTBUG_WARNING(f);
      fprintf(f, "#ifdef __SUNCPLUSPLUS__\n"
              "cerr << val << \"  \" << instances << endl;\n"
              "#endif\n");
      fprintf(f, "   return SEVERITY_WARNING;\n");
   }
   LISTfree(data_members);
   fprintf(f,
           "#ifdef __GNUG__\n"
           "\n  return SEVERITY_NULL;\n"
           "#endif"
           "\n}\n");
}

void TYPEselect_lib_virtual(const Type type, FILE *f, Schema schema)
{
   TYPEselect_lib_part21(type, f, schema);
   TYPEselect_lib_StrToVal(type, f, schema);
}

void SELlib_print_protected(const Type type, FILE *f, const Schema schema)
{
   const char *snm;

   /* SELECT::AssignEntity  */
   fprintf(f, "\nconst TypeDescriptor * \n%s::AssignEntity (STEPentity * se)\n"
           "{\n",
           SelectName(TYPEget_name(type))
      );


/* loop through the items in the SELECT */
   LISTdo(SEL_TYPEget_items(type), t, Type)
      if (TYPEis_entity(t)) {
      fprintf(f,
              "  //  %s\n"      /* item name  */
              "  if (se -> EntityDescriptor -> IsA (%s))\n" /* td */
              "  {  \n"
              "\t_%s = (%sH) %s::castdown(se);\n" /* underlying data member */
                                                  /* underlying data member type */
              "\treturn SetUnderlyingType (%s);\n" /* td */
              "  }\n",
              StrToUpper(TYPEget_name(t)),
              TYPEtd_name(t, schema),
              SEL_ITEMget_dmname(t),
              ClassName(TYPEget_name(t)),
              ClassName(TYPEget_name(t)),
              TYPEtd_name(t, schema)
         );
   }
   if (TYPEis_select(t)) {
      fprintf(f,
              "  //  %s\n"      /* item name  */
              "  if (%s -> CanBe (se -> EntityDescriptor))\n"
              "  {  \n"
              "\t_%s.AssignEntity (se);\n"   /* underlying data member */
              "\treturn SetUnderlyingType (%s);\n" /* td */
              "  }\n",
              StrToUpper(TYPEget_name(t)),
              TYPEtd_name(t, schema),
              SEL_ITEMget_dmname(t),
              TYPEtd_name(t, schema)
         );
   }

   LISTod;
   fprintf(f, "  // should never be here - done in Select class\n");
   PRINT_SELECTBUG_WARNING(f);
   fprintf(f,
           "#ifdef __SUNCPLUSPLUS__\n"
           "  cerr << se -> EntityName () << endl;\n"
           "#endif\n"
           "  return 0;\n}\n");

   /* SELECT::NewSelect  */
   snm = SelectName(TYPEget_name(type));
   fprintf(f, "\nSdaiSelect * \n%s::NewSelect ()\n"
           "{\n"
           "  %s * tmp = new %s ();\n"
           "  return tmp;\n}\n",
           snm, snm, snm
      );


}


/*******************
TYPEselect_lib_print prints the member functions (definitions) of a select class.
*******************/
void TYPEselect_lib_print(const Type type, FILE *f, Schema schema)
{
   char n[BUFSIZ];
   const char *z;               /* pointers to class name(s)  */
   Linked_List dups;
   int dup_result;

   dup_result = find_duplicate_list(type, &dups);
   strncpy(n, SelectName(TYPEget_name(type)), BUFSIZ);
   fprintf(f, "\n//////////  SELECT TYPE %s\n", TYPEget_name(type));

   SELlib_print_protected(type, f, schema);
   TYPEselect_lib_virtual(type, f, schema);
   TYPEselect_lib_print_part_one(type, f, schema, dups, n);

   fprintf(f, "\n\t//  part 2\n");

   LISTdo(SEL_TYPEget_items(type), t, Type)
      if (TYPEis_entity(t)) {   /* if an entity  */
      fprintf(f, "%s::operator %sH()\n{\n", n, ClassName(TYPEget_name(t)));
      fprintf(f, "   if( CurrentUnderlyingType () == %s )\n", TYPEtd_name(t, schema));
      fprintf(f, "      return ((%sH) %s::castdown(_%s));\n",
              ClassName(TYPEget_name(t)),
              ClassName(TYPEget_name(t)),
              SEL_ITEMget_dmname(t));
      PRINT_SELECTBUG_WARNING(f);
      fprintf(f, "   return NULL;\n}\n\n");
   }
   else if (!utype_member(dups, t)) {  /**  if not in the dup list  **/
      fprintf(f, "%s::operator %s()\n{\n", n, AccessType(t));
      fprintf(f, "   if( CurrentUnderlyingType () == %s )\n", TYPEtd_name(t, schema));
      fprintf(f, "      return %s _%s;\n",
              ((TYPEis_aggregate(t) || TYPEis_select(t)) ? "&" : ""),
              SEL_ITEMget_dmname(t)
         );
      fprintf(f, "\n  severity( SEVERITY_WARNING );\n");
      fprintf(f, "  Error( \"Underlying type is not %s\" );\n", AccessType(t));
      PRINT_SELECTBUG_WARNING(f);
      fprintf(f, "   return NULL;\n}\n\n");
   }
   LISTod;
   LISTdo(dups, t, Type)
      if (!TYPEis_entity(t)) {  /* entity\'s were done already */
      fprintf(f, "%s::operator %s()\n{\n", n,
              TYPEis_aggregate(t) ?
              AccessType(t) : TYPEget_utype(t));

      /**** MUST CHANGE FOR multiple big types ****/
      LISTdo(SEL_TYPEget_items(type), x, Type)
         if (strcmp(TYPEget_utype(t), TYPEget_utype(x)) == 0) {   /** if this is one of the dups  **/
         fprintf(f, "   if( CurrentUnderlyingType () == %s )\n", TYPEtd_name(x, schema));
         fprintf(f, "      return %s _%s;\n",
                 ((TYPEis_aggregate(t)) ? "&" : ""),
                 SEL_ITEMget_dmname(t)
            );
      }
      LISTod;
      fprintf(f, "\n  severity( SEVERITY_WARNING );\n");
      fprintf(f, "  Error( \"Underlying type is not %s\" );\n",
              TYPEis_aggregate(t) ?
              AccessType(t) : TYPEget_utype(t));
      PRINT_SELECTBUG_WARNING(f);
      fprintf(f, "   return NULL;\n}\n\n");
   }
   LISTod;

   TYPEselect_lib_print_part_three(type, f, schema, n);
   TYPEselect_lib_print_part_four(type, f, schema, dups, n);

   fprintf(f, "\n\t//  part 5\n");
   LISTdo(SEL_TYPEget_items(type), t, Type)
      z = FirstToUpper(TYPEget_name(t));
   fprintf(f, "%sLogical %s::Is%s() const\n{\n", ENTITYCLASS_PREFIX, n, z);
   fprintf(f, "   if( !exists() )\n", n);
   fprintf(f, "      return sdaiUNKNOWN;\n");
   fprintf(f, "   if( CurrentUnderlyingType () == %s )\n", TYPEtd_name(t, schema));
   fprintf(f, "      return sdaiTRUE;\n");
   fprintf(f, "   return sdaiFALSE;\n}\n\n");
   LISTod;

#ifdef UNDERLYINGTYPE
   fprintf(f, "\n\t//  part 6\n");
   fprintf(f, "SdaiString %s::UnderlyingTypeName() const\n{\n", n);
   fprintf(f, "   if( exists() )\n");
   fprintf(f, "   {\n");
   LISTdo(SEL_TYPEget_items(type), t, Type)
      fprintf(f, "   if( CurrentUnderlyingType () == %s )\n", TYPEtd_name(t, schema));
   if (TYPEis_entity(t))
      fprintf(f, "         return( _%s->Name() );\n", StrToLower(TYPEget_name(t)));
   else
      fprintf(f, "         return( \"%s\" );\n", TYPEget_utype(t));
   LISTod;
   fprintf(f, "   }\n   return NULL;\n}\n\n");

   fprintf(f, "const EntityDescriptor * %s::CurrentUnderlyingType()\n{\n", n);
   fprintf(f, "   if( exists() )\n");
   fprintf(f, "   {\n");
   LISTdo(SEL_TYPEget_items(type), t, Type)
      if (TYPEis_entity(t)) {
      fprintf(f, "   if( discriminator == %s )\n", SEL_ITEMget_enumtype(t));
      fprintf(f, "         return( _%s->EntityDescriptor );\n",
              SEL_ITEMget_dmname(t));
   }
   LISTod;
   fprintf(f, "   }\n   return NULL;\n}\n\n");

#endif
   if (dup_result) {
      fprintf(f, "\n\t//  part 7\n");
      fprintf(f,
              "const TypeDescriptor * \n"
              "%s::SetUnderlyingType (const TypeDescriptor * td)\n{\n"
              "  return " BASE_SELECT "::SetUnderlyingType (td);\n}\n",
              n);
   }

#ifdef PART8
   fprintf(f, "\n\t//  part 8\n");
   fprintf(f, "%s* %s::operator->()\n", n, n);
   fprintf(f, "{\n   return this;\n}\n");
#endif
   LISTfree(dups);

   fprintf(f, "//////////  END SELECT TYPE %s\n\n", n);

}

void TYPEselect_print(Type t, FILES * files, Schema schema)
{

   SelectTag tag,
    tmp;
   Type bt;                     /* type of elements in an aggregate  */

   /* if type is already marked, return  */
   if ((SelectTag) (tmp = TYPEget_clientData(t))) {
      if ((tmp->started) && (!tmp->complete))
         fprintf(stderr, "WARNING:  SELECT type %s causes circular references\n",
                 TYPEget_name(t));
      return;
   }
   /* mark the type as being processed  */
   tag = (SelectTag) malloc(sizeof(struct SelectTag));
   tag->started = 1;
   tag->complete = 0;
   TYPEput_clientData(t, tag);

   LISTdo(SEL_TYPEget_items(t), i, Type)
   /* check the items for select types  */
   /* and do the referenced select types first  */

   /* check aggregates too  */
   /* set i to the bt and  catch in next ifs  */
      if (isAggregateType(i)) {
      bt = TYPEget_nonaggregate_base_type(i);
      if (TYPEis_select(bt))
         i = bt;
      else if (TYPEis_entity(bt))
         i = bt;
   }

   if (TYPEis_select(i) && !TYPEget_clientData(i))
      TYPEselect_print(i, files, schema);

   /* check the attributes to see if a select is referenced  */
   if (TYPEis_entity(i)) {
      LISTdo(ENTITYget_all_attributes(ENT_TYPEget_entity(i)), a, Variable)
         if (TYPEis_select(VARget_type(a)))
         TYPEselect_print(VARget_type(a), files, schema);
      LISTod
   }

   LISTod

      TYPEselect_inc_print(t, files->inc);
   TYPEselect_lib_print(t, files->lib, schema);
   TYPEselect_init_print(t, files->init, schema);
   tag->complete = 1;
}
#undef BASE_SELECT


/**************************************************************************
********    END  of SELECT TYPE
**************************************************************************/
