static char rcsid[] = "$Id: fedex_main.c,v 1.6 1992/09/29 15:46:55 libes Exp $";

/************************************************************************
** Driver for Fed-X Express parser.
************************************************************************/

/*
 * This software was developed by U.S. Government employees as part of
 * their official duties and is not subject to copyright.
 *
 * $Log: fedex_main.c,v $
 * Revision 1.6  1992/09/29  15:46:55  libes
 * added messages for KC
 *
 * Revision 1.5  1992/08/27  23:28:52  libes
 * moved Descriptor "new"s to precede assignments
 * punted SELECT type
 *
 * Revision 1.4  1992/08/19  18:49:59  libes
 * registry support
 *
 * Revision 1.3  1992/06/05  19:55:28  libes
 * Added * to typedefs.  Replaced warning kludges with ERRORoption.
 */

#include <stdio.h>
#include "express.h"
#include "resolve.h"

void print_file(Express);

void resolution_success(void)
{
   printf("Resolution successful.  Writing C++ output...\n");
}

int success(Express model)
{
   printf("Finished writing files.\n");
   return (0);
}

void EXPRESSinit_init()
{
   EXPRESSbackend = print_file;
   EXPRESSsucceed = success;
}
