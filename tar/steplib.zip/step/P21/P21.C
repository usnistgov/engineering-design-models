static char _rcsid[] = "$Id: p21.c,v 1.1 1992/03/06 09:19:33 libes Exp libes $";

/*
 * P21 package manager -- common components
 *
 * This software was developed by U.S. Government employees as part of
 * their official duties and is not subject to copyright.
 *
 * $Log: p21.c,v $
 * Revision 1.1  1992/03/06  09:19:33  libes
 * Initial revision
 */

#define	P21_C

#include "p21.h"

/*
** Procedure:	P21initialize
** Parameters:	Error*	errc	- buffer for error code
** Returns:	void
** Description:	Initialize the P21 package.
*/

void
P21initialize(void)
{
    INSTinitialize();
    PRODinitialize();
}

/* gross, but this is how the result comes back from yacc */
Product	product_model;
Schema header_schema;

Product
P21parse(char *filename, Express model,int estimated_size)
{
	extern FILE *yyin;

	header_schema = (Schema)DICTlookup(model->symbol_table,
				P21_HEADER_SCHEMA_NAME);
	if (!header_schema) {
		fprintf(stderr,"The header schema (%s) is not found\n",
				P21_HEADER_SCHEMA_NAME);
		exit(2);
	}

	current_filename = filename;

	/* I can't figure out how Steve's version ever read from the file */
	/* The code did an fopen but then ignored the result!?!?!?! */
	if (!(yyin = fopen(filename,"r"))) {
		perror(filename);
		exit(2);
	}

	product_model = PRODcreate(filename, estimated_size);
	yynewparse();	/* all this does is to set yylineno = 1; */
	p21_yyparse();

	P21resolve(model,product_model);

	return product_model;
}

void
P21resolve(Express model,Product product)
{
	Instance i;
	DictionaryEntry de;

	DICTdo_init(product->dict,&de);
	while (i = (Instance)DICTdo(&de)) {
		INSTresolve(product,i);
	}
}
