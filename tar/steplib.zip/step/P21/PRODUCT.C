static char rcsid[] = "$Id: product.c,v 1.1 1992/03/06 09:19:33 libes Exp libes $";

/************************************************************************
** Module:	Product
** Description:	This module implements the Product abstraction.  A
**	product is composed of a collection of Entity Instances, which
**	are defined in the context of a conceptual schema.  For example,
**	the AMRF pipeclamp part can be represented as a Product within
**	the STEP conceptual schema.
** Constants:
**	PRODUCT_NULL	- the null product
**
************************************************************************/

/*
 * This software was developed by U.S. Government employees as part of
 * their official duties and is not subject to copyright.
 *
 * $Log: product.c,v $
 * Revision 1.1  1992/03/06  09:19:33  libes
 * Initial revision
 */

#define	PRODUCT_C
#include "product.h"
#include "lexact.h"

struct Symbol *
PROD_get_symbol(Generic p)
{
	return(&((struct Product *)p)->symbol);
}

/*
** Procedure:	PRODinitialize
** Parameters:	-- none --
** Returns:	void
** Description:	Initialize the Product module.
*/

void
PRODinitialize(void)
{
	MEMinitialize(&PROD_fl,sizeof(struct Product),1000,500);
	OBJcreate(OBJ_PRODUCT,PROD_get_symbol,"instance",OBJ_UNFINDABLE_BITS);
}

/*
** Procedure:	PRODcreate
** Parameters:	String  name	- name of new product
**		Express model	- conceptual schema in which to create product
** Returns:	Product		- the newly created product
** Description:	Create an empty product within a particular conceptual schema.
*/

Product
PRODcreate(String name, int estimated_size)
{
	Product new = PROD_new();

    new->symbol.name = SCANstrdup(name);
    new->dict = DICTcreate(estimated_size);
/*    new->list = LISTcreate();*/
    return new;
}

#if 0
/*
** Procedure:	PRODadd_instance
** Parameters:	Product  product	- product to modify
**		Instance instance	- entity instance to add
** Returns:	void
** Requires:	OBJget_class(INSTget_type(instance)) == Class_Entity_Type
** Description:	Add an entity instance to a product model.  The instance 
**		is assumed already to have been added to the instance
**		list of its class, since INSTcreate_entity() does this.
*/

void
PRODadd_instance(Product product, Instance instance)
{
/*	LISTadd_last(product->list, (Generic)instance);*/

	/* DICTdefine reports problem if name already in use */

	/* use INSTget_name(instance) as key */
	DICTdefine(product->dict,INSTget_name(instance),(Generic)instance,
					&instance->symbol,OBJ_INSTANCE);
}
#endif

/*
** Procedure:	PRODget_name
** Parameters:	Product product	- product to examine
** Returns:	String		- name of product
** Description:	Retrieve the name of a particular product.
*/

/* this function is inlined in product.h */

/*
** Procedure:	PRODget_conceptual_schema
** Parameters:	Product product	- product to examine
** Returns:	Express		- conceptual schema in which the product exists
** Description:	Retrieve the conceptual schema in which a product exists.
*/

/* this function is inlined in product.h */

/*
** Procedure:	PRODget_contents
** Parameters:	Product product	- product to examine
** Returns:	Linked_List	- list of Instances
** Description:	Retrieve a list of the Entity Instances which make up a product.
**
** Notes:	The order of creation of the instances in the product model
**	is preserved in the list returned.
*/

/* this function is inlined in product.h */

/*
** Procedure:	PRODget_named_instance
** Parameters:	Product product	- product to examine
**		String  name	- name of instance to retrieve
** Returns:	Instance	- the named instance
** Description:	Retrieve a particular instance by name from a product model.
*/

/* this function is inlined in product.h */
