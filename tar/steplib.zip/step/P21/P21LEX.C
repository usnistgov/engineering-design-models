# include "stdio.h"
#ifdef __cplusplus
   extern "C" {
     extern int yyreject();
     extern int yywrap();
     extern int p21_yylook();
     extern void main();
     extern int p21_yyback(int *, int);
     extern int yyinput();
     extern void p21_yyoutput(int);
     extern void yyunput(int);
     extern int p21_yylex();
   }
#endif	/* __cplusplus */
# define U(x) x
# define NLSTATE p21_yyprevious=YYNEWLINE
# define BEGIN p21_yybgin = p21_yysvec + 1 +
# define INITIAL 0
# define YYLERR p21_yysvec
# define YYSTATE (p21_yyestate-p21_yysvec-1)
# define YYOPTIM 1
# define YYLMAX 200
# define output(c) putc(c,yyout)
# define input() (((p21_yytchar=p21_yysptr>p21_yysbuf?U(*--p21_yysptr):getc(yyin))==10?(yylineno++,p21_yytchar):p21_yytchar)==EOF?0:p21_yytchar)
# define unput(c) {p21_yytchar= (c);if(p21_yytchar=='\n')yylineno--;*p21_yysptr++=p21_yytchar;}
# define yymore() (p21_yymorfg=1)
# define ECHO fprintf(yyout, "%s",p21_yytext)
# define REJECT { nstr = yyreject(); goto yyfussy;}
int p21_yyleng;
int p21_yylenguc;
extern unsigned char p21_yytextarr[];
extern unsigned char p21_yytext[];
int yyposix_point=0;
int yynls16=0;
int yynls_wchar=0;
char *yylocale = "/\001:C;\002:C;\003:C;\004:C;:C;:C;:C;/";
int p21_yymorfg;
extern unsigned char *p21_yysptr, p21_yysbuf[];
int p21_yytchar;
extern FILE *yyin, *yyout;
extern int yylineno;
struct yysvf { 
	int yystoff;
	struct yysvf *yyother;
	int *yystops;};
struct yysvf *p21_yyestate;
extern struct yysvf p21_yysvec[], *p21_yybgin;

static char rcsid[] = "$Id: p21lex.l,v 1.1 1992/03/06 09:20:16 libes Exp libes $";

/*
 * Lex source for P21parse lexical analyzer.
 *
 * This software was developed by U.S. Government employees as part of
 * their official duties and is not subject to copyright.
 *
 * $Log: p21lex.l,v $
 * Revision 1.1  1992/03/06  09:20:16  libes
 * Initial revision
 *
 * Revision 2.4  1991/05/03  21:38:54  libes
 * added test for illegal characters
 *
 * Revision 2.3  1991/05/03  21:04:59  libes
 * Made scanner work with lex
 * 	Simulated exclusive states with inclusive states
 * 	Fixed line counting
 * Speeded up whitespace matching
 * Disabled default rule matching (enabled "jamming")
 * Enabled detection/diagnostics of unterminated comments and string literals
 * Enabled detection/diagnostics of unexpected close comments
 * Added support for print control characters
 * Change '' to ' in string literals
 *
 * Revision 2.1  1990/09/14  13:05:23  clark
 * BPR 2.1 alpha
 *
 * Revision 2.0  90/09/12  15:15:53  clark
 * Initial revision
 * 
 */

#include "linklist.h"
#include "p21.h"
#include "p21yacc.h"
#include "lexact.h"

extern int	yylineno;

static int open_comment = 0;	/* positive number is the line where the */
				/* comment began */

#undef yywrap
int yywrap()
{
	if (open_comment) {
		ERRORreport_with_line(ERROR_unmatched_open_comment,
			open_comment);
	}
	return 1;
}

#ifdef FLEX_SCANNER

#define YY_USER_INIT	BEGIN code;	/* DEL */

#undef YY_DECL
#define YY_DECL int p21_p21_yylex(void)

#define NEWLINE yylineno++
#define LINENO_FUDGE yylineno

#else /* !FLEX_SCANNER (i.e., LEX) */

/* lex counts line for us, so turn this into a no-op - DEL */
#define NEWLINE
/* when lex looks ahead over a newline, error messages get thrown off */
/* Fortunately, we know when that occurs, so adjust for it by this hack */
#define LINENO_FUDGE (yylineno-1)

#endif

/* Keyword Table Entry */
typedef struct KeyWordType {
   char *Key;
   int   KeyToken;
} Keyword;

static Keyword Keys[] = {
	"DATA",				DATA,
	"ENDSCOPE",			ENDSCOPE,
	"ENDSEC",			ENDSEC,
/*	"END_ISO_10303_21",		END_ISO_10303_21,*/
	"HEADER",			HEADER,
/*	"ISO_10303_21",			ISO_10303_21,*/
};

#define NKeys	(sizeof(Keys) / sizeof(Keyword))

static
int
FindIdent(Keyword Table[], int TableSize, char *s)
{
   int cmp;
   int l = 0, u = TableSize-1;
   register int m;

   do {
      m = (l + u) >> 1;
      if((cmp = strcmp(s,Table[m].Key)) == 0)
	 return(Table[m].KeyToken);
      else if(cmp < 0)
	 u = m - 1;
      else
	 l = m + 1;
   } while(l <= u);

   SCANlowerize(s);
   return(KEYWORD);
}

# define comment 2
# define code 4
# define YYNEWLINE 10
p21_yylex(){
   int nstr; extern int p21_yyprevious;
#ifndef FLEX_SCANNER
BEGIN code;
#endif
/* Added * at the end of next rule (to make lexer faster) - DEL */
   while((nstr = p21_yylook()) >= 0)
yyfussy: switch(nstr){
case 0:
   if(yywrap()) return(0); break;
case 1:
	;
break;
case 2:
	{ NEWLINE; }
break;
/* "!*""!"*([^*!]|[^*]"!"|"*"[^!])*"*"+"!"	; */
case 3:
	{	/* new-style comments */
		open_comment = yylineno;
		BEGIN comment;
}
break;
case 4:
	{	/* old-style comments */
		fprintf(stderr, "WARNING <line %4d>: Old-style comment\n", yylineno);
		open_comment = yylineno;
		BEGIN comment;
}
break;
case 5:
	{
		p21_yylval.lVal = Lfalse;
		return LOGICAL;
}
break;
case 6:
	{
		p21_yylval.lVal = Lunknown;
		return LOGICAL;
}
break;
case 7:
	{
		p21_yylval.lVal = Ltrue;
		return LOGICAL;
}
break;
case 8:
{
		p21_yylval.string = SCANstrdup(p21_yytext+1);	/* remove 1st dot */
		*strrchr(p21_yylval.string,'.') = 0;	/* remove 2nd */
		SCANlowerize(p21_yylval.string);
		return ENUM;
}
break;
case 9:
{	/* user-defined keyword */
		p21_yylval.string = SCANstrdup(p21_yytext + 1);
		SCANlowerize(p21_yylval.string);
		return(USER_DEFINED_KEYWORD);
}
break;
/*
<code>"#"({digit}{1,9})	{
                p21_yylval.string = SCANstrdup(p21_yytext + 1);
                return(ENTITY_REFERENCE);
}
*/
case 10:
{
                p21_yylval.string = SCANstrdup(p21_yytext + 1);
                return(ENTITY_NAME);
}
break;
case 11:
{
		sscanf(p21_yytext, "%lf", &(p21_yylval.rVal));
                return(REAL);
}
break;
case 12:
{
		sscanf(p21_yytext, "%d", &(p21_yylval.iVal));
		return(INTEGER);
}
break;
case 13:
{
	char *s, *d;	/* source, destination */

	p21_yylval.string = SCANstrdup(p21_yytext+1);	/* remove 1st quote */
	*strrchr(p21_yylval.string,'\'') = 0;	/* remove 2nd quote which is */
				/* is guaranteed to exist by pattern above */

	/* do it by hand rather than say strstr because we don't want to */
	/* rescan and pick up new \X\s than were created when olds ones */
	/* were removed - i.e., \\X\Y\ - DEL */
	for (s = d = p21_yylval.string;*s;) {
		if (*s != '\'' && *s != '\\') {
			*d++ = *s++;
		} else if (0 == strncmp(s,"\\\\N\\\\",2) ||
			   0 == strncmp(s,"\\\\F\\\\",2)) {
			s += 5;
		} else if (0 == strncmp(s,"''",2) ||
			   0 == strncmp(s,"\\\\",2)) {
			*d++ = *s;
			s += 2;
		}
	}
	*d = '\0';

	return(STRING);
}
break;
case 14:
{
	
	ERRORreport_with_line(ERROR_unterminated_string,LINENO_FUDGE);
	NEWLINE;
	p21_yylval.string = SCANstrdup(p21_yytext+1);	/* remove 1st quote */

	return(STRING);
}
break;
case 15:
{
	p21_yylval.string = SCANstrdup(p21_yytext+1);	/* remove 1st quote */
	*strrchr(p21_yylval.string,'"') = 0;	/* remove 2nd quote which is */
				/* is guaranteed to exist by pattern above */
	return(BINARY);
}
break;
case 16:
		{return(SCOPE);}
break;
case 17:
	{return(ISO_10303_21);}
break;
case 18:
{return(END_ISO_10303_21);}
break;
case 19:
	{ 			/* keyword */
                p21_yylval.string = SCANstrdup(p21_yytext);
		return(FindIdent(Keys, NKeys, p21_yylval.string));
}
break;
case 20:
	return(EQUALS);
break;
case 21:
	return(SEMICOLON);
break;
case 22:
	return(COMMA);
break;
case 23:
	return(LEFT_PAREN);
break;
case 24:
	return(RIGHT_PAREN);
break;
case 25:
	return(SLASH);
break;
case 26:
	return(MISSING);
break;
case 27:
	return(REDEFINE);
break;
/* print control directives - DEL */
case 28:
	;
break;
case 29:
	;
break;
case 30:
	{
	open_comment = 0;
	BEGIN code;
}
break;
case 31:
	{
	ERRORreport_with_line(ERROR_unmatched_close_comment,yylineno);
}
break;
case 32:
	{ NEWLINE; }
break;
case 33:
;
break;
case 34:
	;
break;
case 35:
		ERRORreport_with_line(ERROR_illegal_lowercase,
						yylineno,p21_yytext[0]);
break;
case 36:
		ERRORreport_with_line(ERROR_illegal_character,
						yylineno,(int)p21_yytext[0]);
break;
case -1:
break;
default:
   fprintf(yyout,"bad switch p21_yylook %d",nstr);
} return(0); }
/* end of p21_yylex */

static void __yy__unused() { main(); }
int p21_yyvstop[] = {
0,

1,
33,
0,

1,
33,
0,

1,
33,
0,

1,
33,
0,

1,
33,
0,

1,
33,
0,

36,
0,

1,
36,
0,

2,
0,

35,
36,
0,

33,
36,
0,

1,
33,
36,
0,

2,
32,
0,

34,
36,
0,

33,
35,
36,
0,

36,
0,

36,
0,

36,
0,

26,
36,
0,

36,
0,

36,
0,

23,
36,
0,

24,
36,
0,

27,
36,
0,

36,
0,

22,
36,
0,

36,
0,

25,
36,
0,

12,
36,
0,

21,
36,
0,

20,
36,
0,

19,
36,
0,

19,
36,
0,

19,
36,
0,

36,
0,

1,
0,

33,
0,

1,
33,
0,

30,
0,

4,
0,

9,
0,

10,
0,

14,
0,

13,
0,

31,
0,

12,
0,

3,
0,

11,
0,

19,
0,

19,
0,

19,
0,

15,
0,

10,
0,

8,
0,

5,
8,
0,

7,
8,
0,

6,
8,
0,

19,
0,

19,
0,

29,
0,

28,
0,

10,
0,

11,
0,

10,
0,

10,
0,

16,
0,

10,
0,

10,
0,

10,
0,

10,
0,

17,
0,

18,
0,
0};
# define YYTYPE unsigned char
struct yywork { YYTYPE verify, advance; } p21_yycrank[] = {
0,0,	0,0,	1,7,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	3,11,	1,8,	1,9,	
8,36,	12,38,	12,0,	0,0,	
0,0,	3,12,	3,13,	0,0,	
15,0,	0,0,	0,0,	0,0,	
0,0,	37,0,	38,38,	38,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	8,36,	
0,0,	0,0,	0,0,	0,0,	
1,7,	47,45,	0,0,	1,7,	
1,7,	28,54,	12,0,	3,11,	
14,39,	1,7,	3,14,	3,11,	
15,0,	1,7,	24,48,	29,55,	
3,11,	37,0,	49,55,	38,0,	
3,11,	17,42,	17,42,	17,42,	
17,42,	69,77,	1,7,	70,78,	
44,63,	57,69,	78,82,	80,84,	
1,7,	3,11,	5,7,	77,81,	
82,86,	86,89,	88,91,	3,11,	
33,57,	58,70,	5,8,	5,9,	
18,43,	18,43,	18,43,	18,43,	
18,43,	18,43,	18,43,	18,43,	
18,43,	18,43,	20,44,	34,58,	
1,7,	59,71,	1,10,	60,72,	
63,74,	74,80,	35,59,	3,11,	
81,85,	3,15,	5,16,	5,17,	
5,18,	5,19,	35,60,	5,20,	
5,21,	5,22,	5,23,	5,24,	
5,25,	5,26,	85,88,	5,27,	
5,28,	5,29,	89,92,	91,94,	
92,95,	5,29,	94,97,	95,98,	
97,99,	98,100,	99,101,	100,102,	
5,30,	101,103,	5,31,	103,104,	
104,105,	105,106,	5,32,	0,0,	
0,0,	0,0,	5,33,	0,0,	
5,32,	0,0,	5,34,	6,16,	
6,17,	6,18,	6,19,	0,0,	
6,20,	0,0,	6,22,	6,23,	
0,0,	0,0,	6,26,	0,0,	
6,27,	6,28,	0,0,	11,37,	
0,0,	5,35,	0,0,	0,0,	
5,7,	0,0,	5,10,	11,37,	
11,0,	6,30,	0,0,	6,31,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	6,33,	
0,0,	0,0,	0,0,	6,34,	
25,49,	25,49,	25,49,	25,49,	
25,49,	25,49,	25,49,	25,49,	
25,49,	25,49,	0,0,	0,0,	
0,0,	11,37,	0,0,	0,0,	
11,0,	11,37,	6,35,	0,0,	
0,0,	0,0,	11,37,	0,0,	
0,0,	0,0,	11,37,	43,62,	
43,62,	43,62,	43,62,	43,62,	
43,62,	43,62,	43,62,	43,62,	
43,62,	0,0,	0,0,	11,37,	
0,0,	0,0,	0,0,	0,0,	
0,0,	11,37,	0,0,	0,0,	
0,0,	16,40,	62,73,	62,73,	
62,73,	62,73,	62,73,	62,73,	
62,73,	62,73,	62,73,	62,73,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	11,37,	0,0,	11,37,	
16,41,	16,41,	16,41,	16,41,	
16,41,	16,41,	16,41,	16,41,	
16,41,	16,41,	16,41,	16,41,	
16,41,	16,41,	16,41,	16,41,	
16,41,	16,41,	16,41,	16,41,	
16,41,	16,41,	16,41,	16,41,	
16,41,	16,41,	21,45,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	21,45,	21,46,	
27,50,	27,50,	27,50,	27,50,	
27,50,	27,51,	27,50,	27,50,	
27,50,	27,50,	27,50,	27,50,	
27,50,	27,50,	27,50,	27,50,	
27,50,	27,50,	27,50,	27,52,	
27,53,	27,50,	27,50,	27,50,	
27,50,	27,50,	0,0,	0,0,	
21,47,	0,0,	42,61,	21,45,	
21,45,	0,0,	0,0,	0,0,	
0,0,	21,45,	0,0,	0,0,	
0,0,	21,45,	0,0,	0,0,	
42,42,	42,42,	42,42,	42,42,	
42,42,	42,42,	42,42,	42,42,	
42,42,	42,42,	21,45,	0,0,	
0,0,	0,0,	0,0,	0,0,	
21,45,	42,42,	42,42,	42,42,	
42,42,	42,42,	42,42,	0,0,	
0,0,	0,0,	32,56,	32,56,	
32,56,	32,56,	32,56,	32,56,	
32,56,	32,56,	32,56,	32,56,	
0,0,	0,0,	0,0,	0,0,	
21,45,	0,0,	21,45,	32,56,	
32,56,	32,56,	32,56,	32,56,	
32,56,	32,56,	32,56,	32,56,	
32,56,	32,56,	32,56,	32,56,	
32,56,	32,56,	32,56,	32,56,	
32,56,	32,56,	32,56,	32,56,	
32,56,	32,56,	32,56,	32,56,	
32,56,	0,0,	0,0,	0,0,	
0,0,	32,56,	41,41,	41,41,	
41,41,	41,41,	41,41,	41,41,	
41,41,	41,41,	41,41,	41,41,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	41,41,	
41,41,	41,41,	41,41,	41,41,	
41,41,	41,41,	41,41,	41,41,	
41,41,	41,41,	41,41,	41,41,	
41,41,	41,41,	41,41,	41,41,	
41,41,	41,41,	41,41,	41,41,	
41,41,	41,41,	41,41,	41,41,	
41,41,	0,0,	0,0,	0,0,	
50,64,	41,41,	50,50,	50,50,	
50,50,	50,50,	50,50,	50,50,	
50,50,	50,50,	50,50,	50,50,	
51,65,	0,0,	51,50,	51,50,	
51,50,	51,50,	51,50,	51,50,	
51,50,	51,50,	51,50,	51,50,	
50,50,	55,55,	55,55,	55,55,	
55,55,	55,55,	55,55,	55,55,	
55,55,	55,55,	55,55,	0,0,	
51,50,	0,0,	50,50,	50,50,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	55,68,	0,0,	
0,0,	50,50,	51,50,	51,50,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
52,66,	51,50,	52,50,	52,50,	
52,50,	52,50,	52,50,	52,50,	
52,50,	52,50,	52,50,	52,50,	
53,67,	0,0,	53,50,	53,50,	
53,50,	53,50,	53,50,	53,50,	
53,50,	53,50,	53,50,	53,50,	
52,50,	73,79,	73,79,	73,79,	
73,79,	73,79,	73,79,	73,79,	
73,79,	73,79,	73,79,	0,0,	
53,50,	0,0,	52,50,	52,50,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	52,50,	53,50,	53,50,	
0,0,	0,0,	0,0,	0,0,	
0,0,	68,75,	0,0,	68,75,	
0,0,	53,50,	68,76,	68,76,	
68,76,	68,76,	68,76,	68,76,	
68,76,	68,76,	68,76,	68,76,	
75,76,	75,76,	75,76,	75,76,	
75,76,	75,76,	75,76,	75,76,	
75,76,	75,76,	79,83,	79,83,	
79,83,	79,83,	79,83,	79,83,	
79,83,	79,83,	79,83,	79,83,	
83,87,	83,87,	83,87,	83,87,	
83,87,	83,87,	83,87,	83,87,	
83,87,	83,87,	87,90,	87,90,	
87,90,	87,90,	87,90,	87,90,	
87,90,	87,90,	87,90,	87,90,	
90,93,	90,93,	90,93,	90,93,	
90,93,	90,93,	90,93,	90,93,	
90,93,	90,93,	93,96,	93,96,	
93,96,	93,96,	93,96,	93,96,	
93,96,	93,96,	93,96,	93,96,	
0,0};
struct yysvf p21_yysvec[] = {
0,	0,	0,
-1,	0,		p21_yyvstop+1,
0,	p21_yysvec+1,	p21_yyvstop+4,
-8,	0,		p21_yyvstop+7,
0,	p21_yysvec+3,	p21_yyvstop+10,
-73,	0,		p21_yyvstop+13,
-114,	p21_yysvec+5,	p21_yyvstop+16,
0,	0,		p21_yyvstop+19,
3,	0,		p21_yyvstop+21,
0,	0,		p21_yyvstop+24,
0,	0,		p21_yyvstop+26,
-162,	0,		p21_yyvstop+29,
-4,	p21_yysvec+11,	p21_yyvstop+32,
0,	0,		p21_yyvstop+36,
1,	0,		p21_yyvstop+39,
-10,	p21_yysvec+11,	p21_yyvstop+42,
195,	0,		p21_yyvstop+46,
13,	0,		p21_yyvstop+48,
36,	0,		p21_yyvstop+50,
0,	0,		p21_yyvstop+52,
11,	0,		p21_yyvstop+55,
-285,	0,		p21_yyvstop+57,
0,	0,		p21_yyvstop+59,
0,	0,		p21_yyvstop+62,
7,	0,		p21_yyvstop+65,
140,	0,		p21_yyvstop+68,
0,	0,		p21_yyvstop+70,
231,	0,		p21_yyvstop+73,
3,	0,		p21_yyvstop+75,
9,	p21_yysvec+25,	p21_yyvstop+78,
0,	0,		p21_yyvstop+81,
0,	0,		p21_yyvstop+84,
318,	0,		p21_yyvstop+87,
2,	p21_yysvec+32,	p21_yyvstop+90,
12,	p21_yysvec+32,	p21_yyvstop+93,
32,	0,		p21_yyvstop+96,
0,	p21_yysvec+8,	p21_yyvstop+98,
-15,	p21_yysvec+11,	p21_yyvstop+100,
-17,	p21_yysvec+11,	p21_yyvstop+102,
0,	0,		p21_yyvstop+105,
0,	0,		p21_yyvstop+107,
366,	0,		p21_yyvstop+109,
292,	0,		0,	
167,	0,		p21_yyvstop+111,
1,	0,		0,	
0,	p21_yysvec+21,	0,	
0,	0,		p21_yyvstop+113,
2,	0,		p21_yyvstop+115,
0,	0,		p21_yyvstop+117,
12,	p21_yysvec+25,	p21_yyvstop+119,
414,	p21_yysvec+27,	0,	
426,	p21_yysvec+27,	0,	
474,	p21_yysvec+27,	0,	
486,	p21_yysvec+27,	0,	
0,	0,		p21_yyvstop+121,
437,	0,		p21_yyvstop+123,
0,	p21_yysvec+32,	p21_yyvstop+125,
1,	p21_yysvec+32,	p21_yyvstop+127,
2,	p21_yysvec+32,	p21_yyvstop+129,
5,	0,		0,	
7,	0,		0,	
0,	0,		p21_yyvstop+131,
190,	0,		p21_yyvstop+133,
21,	0,		0,	
0,	0,		p21_yyvstop+135,
0,	0,		p21_yyvstop+137,
0,	0,		p21_yyvstop+140,
0,	0,		p21_yyvstop+143,
534,	0,		0,	
20,	p21_yysvec+32,	p21_yyvstop+146,
22,	p21_yysvec+32,	p21_yyvstop+148,
0,	0,		p21_yyvstop+150,
0,	0,		p21_yyvstop+152,
497,	0,		p21_yyvstop+154,
21,	0,		0,	
544,	0,		0,	
0,	p21_yysvec+75,	p21_yyvstop+156,
2,	0,		0,	
21,	0,		0,	
554,	0,		p21_yyvstop+158,
2,	0,		0,	
21,	0,		0,	
28,	0,		0,	
564,	0,		p21_yyvstop+160,
0,	0,		p21_yyvstop+162,
39,	0,		0,	
26,	0,		0,	
574,	0,		p21_yyvstop+164,
33,	0,		0,	
74,	0,		0,	
584,	0,		p21_yyvstop+166,
74,	0,		0,	
73,	0,		0,	
594,	0,		p21_yyvstop+168,
78,	0,		0,	
82,	0,		0,	
0,	0,		p21_yyvstop+170,
77,	0,		0,	
79,	0,		0,	
82,	0,		0,	
82,	0,		0,	
82,	0,		0,	
0,	0,		p21_yyvstop+172,
90,	0,		0,	
86,	0,		0,	
88,	0,		0,	
0,	0,		p21_yyvstop+174,
0,	0,	0};
struct yywork *p21_yytop = p21_yycrank+651;
struct yysvf *p21_yybgin = p21_yysvec+1;
unsigned char p21_yymatch[] = {
00  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,011 ,012 ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
011 ,01  ,01  ,01  ,01  ,01  ,01  ,047 ,
01  ,01  ,'*' ,'+' ,01  ,'+' ,01  ,01  ,
'0' ,'0' ,'0' ,'0' ,'4' ,'4' ,'4' ,'4' ,
'4' ,'4' ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'G' ,
'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,
'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,
'G' ,'G' ,'G' ,01  ,01  ,01  ,01  ,'_' ,
01  ,'a' ,'a' ,'a' ,'a' ,'a' ,'a' ,'a' ,
'a' ,'a' ,'a' ,'a' ,'a' ,'a' ,'a' ,'a' ,
'a' ,'a' ,'a' ,'a' ,'a' ,'a' ,'a' ,'a' ,
'a' ,'a' ,'a' ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
0};
unsigned char p21_yyextra[] = {
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0};
/* @(#) $Revision: 70.1 $      */
extern int yylineno;
# define YYU(x) x
# define NLSTATE p21_yyprevious=YYNEWLINE
 
#ifdef YYNLS16_WCHAR
unsigned char p21_yytextuc[YYLMAX * sizeof(wchar_t)];
# ifdef YY_PCT_POINT /* for %pointer */
wchar_t p21_yytextarr[YYLMAX];
wchar_t *p21_yytext;
# else               /* %array */
wchar_t p21_yytextarr[1];
wchar_t p21_yytext[YYLMAX];
# endif
#else
unsigned char p21_yytextuc;
# ifdef YY_PCT_POINT /* for %pointer */
unsigned char p21_yytextarr[YYLMAX];
unsigned char *p21_yytext;
# else               /* %array */
unsigned char p21_yytextarr[1];
unsigned char p21_yytext[YYLMAX];
# endif
#endif

struct yysvf *p21_yylstate [YYLMAX], **p21_yylsp, **p21_yyolsp;
unsigned char p21_yysbuf[YYLMAX];
unsigned char *p21_yysptr = p21_yysbuf;
int *p21_yyfnd;
extern struct yysvf *p21_yyestate;
int p21_yyprevious = YYNEWLINE;
p21_yylook(){
	register struct yysvf *yystate, **lsp;
	register struct yywork *yyt;
	struct yysvf *yyz;
	int yych, yyfirst;
	struct yywork *yyr;
# ifdef LEXDEBUG
	int debug;
# endif
/*	char *yylastch;
 * ***** nls8 ***** */
	unsigned char *yylastch, sec;
	/* start off machines */
# ifdef LEXDEBUG
	debug = 0;
# endif
	yyfirst=1;
	if (!p21_yymorfg)
#ifdef YYNLS16_WCHAR
		yylastch = p21_yytextuc;
#else
		yylastch = p21_yytext;
#endif
	else {
		p21_yymorfg=0;
#ifdef YYNLS16_WCHAR
		yylastch = p21_yytextuc+p21_yylenguc;
#else
		yylastch = p21_yytext+p21_yyleng;
#endif
		}
	for(;;){
		lsp = p21_yylstate;
		p21_yyestate = yystate = p21_yybgin;
		if (p21_yyprevious==YYNEWLINE) yystate++;
		for (;;){
# ifdef LEXDEBUG
			if(debug)fprintf(yyout,"state %d\n",yystate-p21_yysvec-1);
# endif
			yyt = &p21_yycrank[yystate->yystoff];
			if(yyt == p21_yycrank && !yyfirst){  /* may not be any transitions */
				yyz = yystate->yyother;
				if(yyz == 0)break;
				if(yyz->yystoff == 0)break;
				}
			*yylastch++ = yych = input();
			yyfirst=0;
		tryagain:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"char ");
				allprint(yych);
				putchar('\n');
				}
# endif
			yyr = yyt;
			if ( (int)yyt > (int)p21_yycrank){
				yyt = yyr + yych;
				if (yyt <= p21_yytop && yyt->verify+p21_yysvec == yystate){
					if(yyt->advance+p21_yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+p21_yysvec;
					goto contin;
					}
				}
# ifdef YYOPTIM
			else if((int)yyt < (int)p21_yycrank) {		/* r < p21_yycrank */
				yyt = yyr = p21_yycrank+(p21_yycrank-yyt);
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"compressed state\n");
# endif
				yyt = yyt + yych;
				if(yyt <= p21_yytop && yyt->verify+p21_yysvec == yystate){
					if(yyt->advance+p21_yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+p21_yysvec;
					goto contin;
					}
				yyt = yyr + YYU(p21_yymatch[yych]);
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"try fall back character ");
					allprint(YYU(p21_yymatch[yych]));
					putchar('\n');
					}
# endif
				if(yyt <= p21_yytop && yyt->verify+p21_yysvec == yystate){
					if(yyt->advance+p21_yysvec == YYLERR)	/* error transition */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+p21_yysvec;
					goto contin;
					}
				}
			if ((yystate = yystate->yyother) && (yyt = &p21_yycrank[yystate->yystoff]) != p21_yycrank){
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"fall back to state %d\n",yystate-p21_yysvec-1);
# endif
				goto tryagain;
				}
# endif
			else
				{unput(*--yylastch);break;}
		contin:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"state %d char ",yystate-p21_yysvec-1);
				allprint(yych);
				putchar('\n');
				}
# endif
			;
			}
# ifdef LEXDEBUG
		if(debug){
			fprintf(yyout,"stopped at %d with ",*(lsp-1)-p21_yysvec-1);
			allprint(yych);
			putchar('\n');
			}
# endif
		while (lsp-- > p21_yylstate){
			*yylastch-- = 0;
			if (*lsp != 0 && (p21_yyfnd= (*lsp)->yystops) && *p21_yyfnd > 0){
				p21_yyolsp = lsp;
				if(p21_yyextra[*p21_yyfnd]){		/* must backup */
					while(p21_yyback((*lsp)->yystops,-*p21_yyfnd) != 1 && lsp > p21_yylstate){
						lsp--;
						unput(*yylastch--);
						}
					}
				p21_yyprevious = YYU(*yylastch);
				p21_yylsp = lsp;
#ifdef YYNLS16_WCHAR
				p21_yylenguc = yylastch-p21_yytextuc+1;
				p21_yytextuc[p21_yylenguc] = 0;
#else
				p21_yyleng = yylastch-p21_yytext+1;
				p21_yytext[p21_yyleng] = 0;
#endif
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"\nmatch ");
#ifdef YYNLS16_WCHAR
					sprint(p21_yytextuc);
#else
					sprint(p21_yytext);
#endif
					fprintf(yyout," action %d\n",*p21_yyfnd);
					}
# endif
				return(*p21_yyfnd++);
				}
			unput(*yylastch);
			}
#ifdef YYNLS16_WCHAR
		if (p21_yytextuc[0] == 0  /* && feof(yyin) */)
#else
		if (p21_yytext[0] == 0  /* && feof(yyin) */)
#endif
			{
			p21_yysptr=p21_yysbuf;
			return(0);
			}
#ifdef YYNLS16_WCHAR
		p21_yyprevious = p21_yytextuc[0] = input();
#else
		p21_yyprevious = p21_yytext[0] = input();
#endif
		if (p21_yyprevious>0) {
			output(p21_yyprevious);
#ifdef YYNLS16
                        if (yynls16)
#ifdef YYNLS16_WCHAR
                        	if (FIRSTof2(p21_yytextuc[0]))
#else
                        	if (FIRSTof2(p21_yytext[0]))
#endif
     					if (SECof2(sec = input()))
#ifdef YYNLS16_WCHAR
 						output(p21_yyprevious=p21_yytextuc[0]=sec);
#else
 						output(p21_yyprevious=p21_yytext[0]=sec);
#endif
					else 
						unput(sec);
#endif
                }
#ifdef YYNLS16_WCHAR
		yylastch=p21_yytextuc;
#else
		yylastch=p21_yytext;
#endif
# ifdef LEXDEBUG
		if(debug)putchar('\n');
# endif
		}
	}

# ifdef __cplusplus
p21_yyback(int *p, int m)
# else
p21_yyback(p, m)
	int *p;
# endif
{
if (p==0) return(0);
while (*p)
	{
	if (*p++ == m)
		return(1);
	}
return(0);
}
	/* the following are only used in the lex library */
static yyinput(){
	return(input());
	
	}

#ifdef __cplusplus
void p21_yyoutput(int c)
#else
p21_yyoutput(c)
  int c;
# endif
{
	output(c);
}

#ifdef __cplusplus
void yyunput(int c)
#else
static yyunput(c)
   int c;
#endif
{
	unput(c);
}
