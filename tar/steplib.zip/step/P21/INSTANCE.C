static char rcsid[] = "$Id: instance.c,v 1.1 1992/03/06 09:19:33 libes Exp $";

/************************************************************************
** Module:	Instance
** Description:	This module implements the Instance abstraction.  An
**	Instance represents a piece of information in a P21 product
**	model.  Thus, there are integer instances, array instances, and
**	entity instances.  Each instance contains a type, which dictates
**	the interpretation of the contents of the instance.  In addition,
**	a user data field is provided to allow instances to be connected
**	with external data structures.
** Constants:
**	INSTANCE_NULL	- the null instance
**
************************************************************************/

/*
 * This software was developed by U.S. Government employees as part of
 * their official duties and is not subject to copyright.
 *
 * $Log: instance.c,v $
 * Revision 1.1  1992/03/06  09:19:33  libes
 * Initial revision
 *
 *
 * Revision 2.6  1992/01/16  12:55:29  libes
 * added print function
 *
 * Revision 2.5  1991/08/29  17:25:30  libes
 * added check for putting too many values into an aggregate
 *
 * Revision 2.4  1991/01/25  23:33:30  silver
 * merge of SCRA changes into NIST.  Changes caused by DEC ansi C
 *
 * Revision 2.3  91/01/14  15:06:18  laurila
 * Modified to work with DEC ANSI C compiler and yacc andlex instead of
 * bison and flex
 * 
 * Revision 2.2  90/09/17  11:18:19  clark
 * Initial - Beta checkin at SCRA
 * 
 * Revision 2.2  90/09/17  11:18:19  clark
 * Fix off-by-one in INST_aggr_grow_by()
 * With help from Tom Kramer
 * 
 * Revision 2.1  90/09/14  13:05:14  clark
 * BPR 2.1 alpha
 * 
 * Revision 2.0  90/09/12  14:47:41  clark
 * Initial revision
 * 
 */

#define INSTANCE_C
#include "instance.h"
#include "product.h"

static Error ERROR_not_implemented;
static Error ERROR_nonoptional;

static Symbol *
INST_get_symbol(Generic i)
{
	return(&((Instance)i)->symbol);
}

/*
** Procedure:	INSTinitialize
** Parameters:	Error* errc	- buffer for error code
** Returns:	void
** Description:	Initialize the Instance module.
**
** Notes:	Various error messages are set up.
*/

void
INSTinitialize()
{
	MEMinitialize(&INST_fl,sizeof(struct Instance),1000,500);
	MEMinitialize(&AGGR_fl,sizeof(struct Aggregate),500,500);
	OBJcreate(OBJ_INSTANCE,INST_get_symbol,"instance",OBJ_UNFINDABLE_BITS);
	Type_User_Defined = TYPEcreate(special_);
	Type_Forward_Ref = TYPEcreate(special_);
	Type_Redefine = TYPEcreate(special_);
	INSTANCE_REDEFINE = INSTcreate(Type_Redefine);

    ERROR_aggregate_expected =
	ERRORcreate("Aggregate instance expected for attribute %s",
		    SEVERITY_ERROR);
    ERROR_array_expected =
	ERRORcreate("Array expected for attribute %s", SEVERITY_ERROR);
    ERROR_bag_expected =
	ERRORcreate("Bag expected for attribute %s", SEVERITY_ERROR);
    ERROR_bag_full =
	ERRORcreate("Attempt to insert into full bag", SEVERITY_WARNING);
    ERROR_boolean_expected =
	ERRORcreate("Boolean expected for attribute %s", SEVERITY_ERROR);
    ERROR_entity_expected =
	ERRORcreate("Entity expected for attribute %s", SEVERITY_ERROR);
    ERROR_external_expected =
	ERRORcreate("External reference expected for attribute %s",
		    SEVERITY_WARNING);
    ERROR_inappropriate_entity =
	ERRORcreate("Inappropriate entity class for attribute %s",
		    SEVERITY_ERROR);
    ERROR_incompatible_types =
	ERRORcreate("Incompatible types in %s", SEVERITY_ERROR);
    ERROR_undefined_enum_value = ERRORcreate(
"Undefined enumeration value for type %s", SEVERITY_ERROR);

    ERROR_index_out_of_range =
	ERRORcreate("Aggregate index out of range: %d", SEVERITY_WARNING);
    ERROR_insufficient_attributes =
	ERRORcreate("Not enough attributes given for '@%s'", SEVERITY_WARNING);
    ERROR_integer_expected =
	ERRORcreate("Integer expected for attribute %s", SEVERITY_ERROR);
    ERROR_internal_expected =
	ERRORcreate("Internal instance expected for attribute %s",
		    SEVERITY_WARNING);
    ERROR_list_expected =
	ERRORcreate("List expected for attribute %s", SEVERITY_ERROR);
    ERROR_logical_expected =
	ERRORcreate("Logical expected for attribute %s", SEVERITY_ERROR);
    ERROR_number_expected =
	ERRORcreate("Number expected for attribute %s", SEVERITY_ERROR);
    ERROR_set_duplicate_entry =
	ERRORcreate("Duplicate entry in set", SEVERITY_ERROR);
    ERROR_set_expected =
	ERRORcreate("Set expected for attribute %s", SEVERITY_ERROR);
    ERROR_set_full =
	ERRORcreate("Attempt to insert into full set", SEVERITY_WARNING);
    ERROR_string_expected =
	ERRORcreate("String expected for attribute %s", SEVERITY_ERROR);
    ERROR_too_many_attributes =
	ERRORcreate("Too many attributes given for @%s", SEVERITY_WARNING);
    ERROR_undefined_reference =
	ERRORcreate("Reference to undefined entity instance %s", SEVERITY_ERROR);
    ERROR_unknown_entity =
	ERRORcreate("Reference to unknown entity type %s", SEVERITY_ERROR);
	ERROR_illegal_character = ERRORcreate(
"Illegal character encountered while reading file (hex value %x)",SEVERITY_ERROR);
	ERROR_illegal_lowercase = ERRORcreate(
"Lowercase character (\"%c\") not allowed in keyword or enumeration name",SEVERITY_ERROR);
	ERROR_not_implemented = ERRORcreate(
"%s is not implemented",SEVERITY_ERROR);
	ERROR_unexpected_header_entity = ERRORcreate(
"Expected header entity %s but found %s",SEVERITY_ERROR);
	ERROR_instance_not_created = ERRORcreate(
"Instance %s not created",SEVERITY_ERROR);
	ERROR_nonoptional = ERRORcreate(
"Missing attribute ($) for non-optional attribute %s",SEVERITY_ERROR);
}

Instance
INSTcreate_entity_forward_ref(int line,char *name)
{
	Instance i = INSTcreate(Type_Forward_Ref);
	INSTput_name(i,name);
	INSTput_line_number(i,line);
	return i;
}

/*
** Procedure:	INSTcreate
** Parameters:	Type   type	- type to instantiate
**		Error* errc	- buffer for error code
** Returns:	Instance	- the new instance
** Description:	Create and return an empty instance of a particular type.
*/

Instance
INSTcreate(Type type)
{
	int j, k, size;
	Instance i = INST_new();
	i->type = type;

	if (TYPEis_entity(type)) {
		size = TYPEget_size(type);
		i->u.entity = (Instance *)calloc(size,sizeof(Instance));
		if (!i->u.entity) {
			fprintf(stderr,"failed to alloc Entity instance data in INSTcreate\n");
			exit(1);
		}
		for (j = size; j--; )
		    i->u.entity[j] = INSTANCE_NULL;
		ENTITYadd_instance(ENT_TYPEget_entity(type),(Generic)i);
	} else if (TYPEinherits_from(type,Class_Aggregate_Type)) {
		i->u.aggregate = AGGR_new();
 		if (TYPEis_aggregate(type) || TYPEis_array(type)) {
			i->u.aggregate->low = EXPget_integer_value(AGGR_TYPEget_lower_limit(type));
		} else i->u.aggregate->low = 1;
		size = TYPEget_size(type);
		i->u.aggregate->high = i->u.aggregate->low + size - 1;
		i->u.aggregate->contents = (Instance *)calloc(size,sizeof(Instance));
		if (i->u.aggregate->contents == 0) {
			fprintf(stderr,"failed to alloc aggregate contents buffer in INSTcreate");
			exit(1);
		}
/*		base = AGGR_TYPEget_base_type(type);*/
/*		if (OBJis_kind_of(base, Class_Aggregate_Type)) {*/

		/* if reading a list of unknown type (so far) out of p21 */
		/* file then we can't really do any of this init. yet */
 		if (TYPEis_aggregate(type) && TYPEis_aggregate(TYPEget_base_type(type))) {
		    for (j = size; j--; ) {
			errc = ERROR_none;
 			i->u.aggregate->contents[j] = INSTcreate(TYPEget_base_type(type));
			if (errc != ERROR_none) {
			    for (k = size; --k > j; )
				OBJfree(i->u.aggregate->contents[j]);
			    free((Generic)i->u.aggregate->contents);
			    AGGR_destroy(i->u.aggregate);
			    INST_destroy(i);
			    errc = ERROR_subordinate_failed;
			    return INSTANCE_NULL;
			}
		    }
		} else {
		    for (j = size; j--; )
			i->u.aggregate->contents[j] = INSTANCE_NULL;
		}
		i->u.aggregate->max = OBJreference(AGGR_TYPEget_upper_limit(type));
	}
	/* Note that things like Type_User_Defined fall thru here */
	return(i);
}

#if 0
Instance
INSTcreate(Type type, Error* errc)
{
    Instance		instance;
    struct Instance*	data;
    Class		type_class;
    int			i, j, size;
    Type		base;

    instance = OBJcreate(Class_Instance, errc);
    data = (struct Instance*)OBJget_data(instance, Class_Instance, errc);
    data->type = OBJreference(type);
    type_class = OBJget_class(type);
    if (type_class == Class_Enumeration_Type) {
	data->value.enumeration = SYMBOL_NULL;
    } else if (type_class == Class_Integer_Type) {
	data->value.integer = 0;
    } else if (type_class == Class_Logical_Type) {
	data->value.logical = Lunknown;
    } else if (type_class == Class_Boolean_Type) {
	data->value.logical = Lfalse;
    } else if (type_class == Class_Real_Type) {
	data->value.real = 0.0;
    } else if (type_class == Class_String_Type) {
	data->value.string = STRING_NULL;
    } else if (type_class == Class_Entity_Type) {
	size = TYPEget_size(type);
	BALLOC(data->value.entity, size, Instance,
	       "Entity instance data in INSTcreate");
	for (i = size; i--; )
	    data->value.entity[i] = INSTANCE_NULL;
	ENTITYadd_instance(ENT_TYPEget_entity(type), instance);
    } else if (CLASSinherits_from(type_class, Class_Aggregate_Type)) {
	HMALLOC(data->value.aggregate, Aggregate,
		"aggregate value in INSTcreate");
	if ((type_class == Class_Aggregate_Type) || (type_class == Class_Array_Type))
	    data->value.aggregate->low =
		EXPget_integer_value(AGGR_TYPEget_lower_limit(type), errc);
	else
	    data->value.aggregate->low = 1;
	size = TYPEget_size(type);
	data->value.aggregate->high = data->value.aggregate->low + size - 1;
	BALLOC(data->value.aggregate->contents, size, Instance,
	       "aggregate contents buffer in INSTcreate");
	base = AGGR_TYPEget_base_type(type);
	if (OBJis_kind_of(base, Class_Aggregate_Type)) {
	    for (i = size; i--; ) {
		data->value.aggregate->contents[i] = INSTcreate(base, errc);
		if (*errc != ERROR_none) {
		    for (j = size; --j > i; )
			OBJfree(data->value.aggregate->contents[i]);
		    FREE(data->value.aggregate->contents,
			 "failed aggregate contents in INSTcreate");
		    FREE(data, "failed instance in INSTcreate");
		    *errc = ERROR_subordinate_failed;
		    return INSTANCE_NULL;
		}
	    }
	} else {
	    for (i = size; i--; )
		data->value.aggregate->contents[i] = INSTANCE_NULL;
	}
	data->value.aggregate->max = OBJreference(AGGR_TYPEget_upper_limit(type));
    } else {
	ERRORreport(ERROR_corrupted_type, "INSTcreate");
	return INSTANCE_NULL;
    }
    return instance;
}
#endif

/* Similar to INSTcreate and INSTcreate_entity, but this creates an
** external mapping
*/ 

Instance
INSTcreate_external(Linked_List attributes)
{
	Instance i = INST_new();
	INSTput_line_number(i, yylineno);
	errc = ERROR_none;

	i->type = TYPEcreate(entity_list_);
	i->u.list = attributes;

	return i;
}

/*
** Procedure:	INSTcreate_entity
** Parameters:	Entity      entity	- entity class to instantiate
**		Linked_List attributes	- list of attribute values
**		int         line	- line number of this construct
**		Error*      errc	- buffer for error code
** Returns:	Instance		- the new entity instance
** Description:	Creates an entity instance as described by the arguments.
**
** Notes:	A type corresponding to the entity class is created, and
**	a new instance of this type is created.  The list of attribute values
**	is then traversed in parallel with the list of expected attribute
**	definitions for the type, and the values are stuffed in.  Errors
**	such as inappropriate types and too many/not enough attribute
**	values are reported to the caller.
*/

Instance
INSTcreate_entity(Entity entity, Linked_List attributes, 
	Boolean complex_constituent)
{
    Type	type;
    Instance	instance, attrVal;
    Linked_List	duplicate;
    Linked_List	attr_recs;

    /* Create the type */
	type = TYPEcreate(entity_);
    ENT_TYPEput_entity(type, entity);

    /* Get a new, empty instance of the type */
    errc = ERROR_none;
    instance = INSTcreate(type);
    if (errc != ERROR_none)
	return INSTANCE_NULL;
    INSTput_line_number(instance, yylineno);

    /* Make a copy of the attribute value list so we can muck around with it */
    duplicate = LISTcopy(attributes);

	/* Get the list of expected attributes */
	if (complex_constituent) {
		attr_recs = ENTITYget_attributes(ENT_TYPEget_entity(type));
		instance->internal_mapping = true;
	} else {
		attr_recs = ENTITYget_all_attributes(ENT_TYPEget_entity(type));
		instance->internal_mapping = false;
	}

    /* Iterate over expected attributes */
    LISTdo(attr_recs, var, Variable)
	/* If this is an explicit attribute */
	if (!VARis_derived(var) && !VARget_inverse(var)) {
	    /* If we're out of values */
	    if (LISTempty(duplicate)) {
		/* Report an error */
		errc = ERROR_insufficient_attributes;

		/* Clean up and exit, returning the partially-filled instance */
		OBJfree(attr_recs);
		LISTfree(duplicate);
		return instance;
	    }
	    /* Otherwise, stuff in the next value */
	    attrVal = (Instance)LISTremove_first(duplicate);
	    INSTfast_put_attribute(instance, var, attrVal);
	    /* some trickiness going on with errc in original code */
	    if (errc) {
		ERRORreport_with_line(errc, yylineno, VARget_simple_name(var));
		errc = ERROR_subordinate_failed;
		break;
	    }
	}
    LISTod;

    /* If there are still more values left, report this */
    if ((errc == 0) && !LISTempty(duplicate))
	errc = ERROR_too_many_attributes;

    /* Clean up workspace and return */
    OBJfree(attr_recs);
    LISTfree(duplicate);
    return instance;
}


/*
** Procedure:	INSTcreate_ud_entity
** Parameters:	Entity      entity	- entity class to instantiate
**		Linked_List attributes	- list of attribute values
**		int         line	- line number of this construct
**		Error*      errc	- buffer for error code
** Returns:	Instance		- the new entity instance
** Description:	Create a user-defined entity instance.
**
** Notes:	This procedure is not yet implemented.
*/

/*ARGSUSED*/
Instance
INSTcreate_ud_entity(Entity entity, Linked_List attributes,int line)
{
/*    Instance instance;*/

    errc = ERROR_none;	/* why? */
/*    instance = INSTcreate();*/
/*    return instance;*/
    ERRORreport(ERROR_not_implemented, "INSTcreate_ud_entity");
    return INSTANCE_NULL;
}

/*
** Procedure:	INSTget_type
** Parameters:	Instance instance	- instance to examine
** Returns:	Type			- instance's type
** Description:	Retrieve the type of an instance.
*/

/* this function is inlined in instance.h */

/*
** Procedure:	INSTput_user_data
** Parameters:	Instance instance	- instance to modify
**		Generic  value		- user data for instance
**		Error*   errc		- buffer for error code
** Returns:	Generic			- old value of user data field
** Modifies:	instance
** Description:	Put a value in the user data field of an instance.
*/

/* now a macro in instance.h */

/*
** Procedure:	INSTget_user_data
** Parameters:	Instance instance	- instance to examine
**		Error*   errc		- buffer for error code
** Returns:	Generic			- user data field from instance
** Description:	Retrieve the user data field of an instance.
*/

/* now a macro in instance.h */

/*
** Procedure:	INSTput_value
** Parameters:	Instance instance	- instance to modify
**		Generic  value		- value for instance
**		Error*   errc		- buffer for error code
** Returns:	void
** Requires:	!OBJis_kind_of(INSTget_type(instance), Class_Entity_Type)
**		!OBJis_kind_of(INSTget_type(instance), Class_Aggregate_Type)
** Modifies:	instance
** Description:	Set the value of a simple instance.
**
** Notes:	See Notes: for INSTget_value for appropriate types for
**	the 'value' parameter.  See INSTput_attribute to store a value
**	in an attribute of an entity instance.  See INSTarray_at_put(),
**	INSTlist_insert(), INSTbag_add(), and INSTset_add() to store a
**	value into an aggregate instance.
*/

void
INSTput_value(Instance instance, Generic value)
{
#if 0
    struct Instance*	data;
    Type		type;
    Class		class;

    assert(!OBJis_kind_of(INSTget_type(instance), Class_Entity_Type));
    assert(!OBJis_kind_of(INSTget_type(instance), Class_Aggregate_Type));

    data = (struct Instance*)OBJget_data(instance, Class_Instance, errc);
    type = INSTget_type(instance);
    class = OBJget_class(type);
#endif
 	switch (TYPEis(instance->type)) {
	case Class_Enumeration_Type:
		instance->u.enumeration = (Expression)value; break;
	case Class_Integer_Type:
		instance->u.integer = *(Integer*)value; break;
	case Class_Real_Type:
		instance->u.real = *(Real*)value;	break;
	case Class_String_Type:
		if (instance->u.string) free(instance->u.string);
		instance->u.string = SCANstrdup((char *)value);
	default:
		if (TYPEinherits_from(instance->type, Class_Logical_Type))
			instance->u.logical = *(Logical*)value;
		else ERRORreport(ERROR_corrupted_type, "INSTput_value");
	}
}

/*
** Procedure:	INSTget_value
** Parameters:	Instance instance	- instance to examine
**		Error*   errc		- buffer for error code
** Returns:	Generic			- instance's value
** Requires:	!OBJis_kind_of(INSTget_type(instance), Class_Entity_Type)
**		!OBJis_kind_of(INSTget_type(instance), Class_Aggregate_Type)
** Description:	Retrieve the value of an unstructured instance.
**
** Notes:	The value returned is:	    if INSTget_type(instance) is:
**		    int*			TY_Integer
**		    double*			TY_Real
**		    String (char*)		TY_String
**		    Boolean* (enum)		TY_Logical
**		    Constant			TY_Enumeration_xxx
**		    Instance*			TY_Select_xxx
**	See INSTget_attribute() to retrieve the value of an attribute from
**	an entity instance instance.  See INSTarray_at(), INSTlist_at(), and
**	INSTincludes() to retrieve values from an aggregate instance.
*/

Generic
INSTget_value(Instance instance)
{
#if 0
    assert(!OBJis_kind_of(INSTget_type(instance), Class_Entity_Type));
    assert(!OBJis_kind_of(INSTget_type(instance), Class_Aggregate_Type));

    data = (struct Instance*)OBJget_data(instance, Class_Instance, errc);
    type = INSTget_type(instance);
#endif

	switch (TYPEis(instance->type)) {
	case Class_Enumeration_Type:
		return (Generic)instance->u.enumeration;
	case Class_Integer_Type:
		return (Generic)&instance->u.integer;
	case Class_Real_Type:
		return (Generic)&instance->u.real;
	case Class_String_Type:
		return (Generic)instance->u.string;
	}

	if (TYPEinherits_from(instance->type, Class_Logical_Type))
		return (Generic)&instance->u.logical;

	fprintf(stderr, "ERROR: Bad instance in INSTget_value\n");
	return NULL;
}

/*
** Procedure:	INSTput_attribute
** Parameters:	Instance instance	- instance to modify
**		String attributeName	- name of attribute to store into
**		Instance value		- value to store into attribute
**		Error* errc		- buffer for error code
** Returns:	void
** Requires:	OBJget_class(INSTget_type(instance)) == Class_Entity_Type
** Modifies:	instance
** Description:	Store a value into a named attribute of an entity instance.
**
** Notes:	This call is the slower method for storing into an
**	attribute.  If the actual attribute record is already available,
**	use INSTfast_put_attribute() instead.
*/

void
INSTput_attribute(Instance instance, char *attributeName, Instance value)
{
    Instance		*pos;
    Entity		entity;
    Variable		attribute;
/*    Reference_Class	rc;*/

	if (!value && !attribute->flags.optional) {
		errc = ERROR_nonoptional;
		return;
	}


    entity = ENT_TYPEget_entity(INSTget_type(instance));
    attribute = ENTITYget_named_attribute(entity, attributeName);
    pos = instance->u.entity + ENTITYget_attribute_offset(entity, attribute);
    if (*pos != INSTANCE_NULL)
	OBJfree(*pos);
    *pos = INSTtype_cast(value, VARget_type(attribute));
/* old N496 - DEL
    if (*errc == ERROR_none) {
	rc = VARget_reference_class(attribute);
	if ((rc == REF_INTERNAL) && (INSTis_external(value)))
	    *errc = ERROR_internal_expected;
	if ((rc == REF_EXTERNAL) && (INSTis_internal(value)))
	    *errc = ERROR_external_expected;
    }
*/
}

/*
** Procedure:	INSTfast_put_attribute
** Parameters:	Instance instance	- instance to modify
**		Variable attribute	- attribute to store into
**		Instance value		- value to store into attribute
**		Error*   errc		- buffer for error code
** Returns:	void
** Requires:	OBJget_class(INSTget_type(instance)) == Class_Entity_Type
** Modifies:	instance
** Description:	Store a value into an attribute of an entity instance.
**
** Notes:	This call is faster than INSTput_attribute() when the
**	caller already has the actual attribute record for the desired
**	attribute, rather than simply having its name (as expected by
**	INSTput_attribute()).
*/

void
INSTfast_put_attribute(Instance i, Variable attribute, Instance value)
{
    Instance		*pos;
/*    Reference_Class	rc;*/

/*    assert(OBJget_class(INSTget_type(i)) == Class_Entity_Type);*/

	if (!value && !attribute->flags.optional) {
		errc = ERROR_nonoptional;
		return;
	}

    pos = i->u.entity + ENTITYget_attribute_offset(ENT_TYPEget_entity(INSTget_type(i)), attribute);
    if (*pos != INSTANCE_NULL)
	OBJfree(*pos);
    *pos = INSTtype_cast(value, VARget_type(attribute));
/* N496 - DEL
    if (*errc == ERROR_none) {
	rc = VARget_reference_class(attribute);
	if ((rc == REF_INTERNAL) && (INSTis_external(value)))
	    *errc = ERROR_internal_expected;
	if ((rc == REF_EXTERNAL) && (INSTis_internal(value)))
	    *errc = ERROR_external_expected;
    }
*/
}

/*
** Procedure:	INSTget_attribute
** Parameters:	Instance instance	- instance to examine
**		String   attributeName	- name of attribute to retrieve
**		Error*   errc		- buffer for error code
** Returns:	Instance		- value of attribute
** Requires:	OBJget_class(INSTget_type(instance)) == Class_Entity_Type
** Description:	Retrieve the value of a named attribute from an entity instance.
**
** Notes:	This call is the slower method for retrieving an
**	attribute value.  If the actual attribute record is already
**	available, use INSTfast_get_attribute() instead.
*/

Instance
INSTget_attribute(Instance i, String attributeName)
{
    Instance *pos;

/*    assert(OBJget_class(INSTget_type(instance)) == Class_Entity_Type);*/

    pos = i->u.entity + ENTITYget_named_attribute_offset(ENT_TYPEget_entity(INSTget_type(i)), attributeName);
    return *pos;
}

/*
** Procedure:	INSTfast_get_attribute
** Parameters:	Instance instance	- instance to examine
**		Variable attribute	- attribute to retrieve
**		Error*   errc		- buffer for error code
** Returns:	Instance		- value of attribute
** Requires:	OBJget_class(INSTget_type(instance)) == Class_Entity_Type
** Description:	Retrieve the value of an attribute from an entity instance.
**
** Notes:	This call is the faster method for retrieving an
**	attribute value, and should be used whenver the actual attribute
**	record is already available.
*/

Instance
INSTfast_get_attribute(Instance i, Variable attribute)
{
    Instance *pos;

/*    assert(OBJget_class(INSTget_type(instance)) == Class_Entity_Type);*/

/*    data = (struct Instance*)OBJget_data(instance, Class_Instance, errc);*/
    pos = i->u.entity + ENTITYget_attribute_offset(ENT_TYPEget_entity(INSTget_type(i)), attribute);
    return *pos;
}

/*
** Procedure:	INST_aggregate_grow_by
** Parameters:	Instance instance	- instance to grow
**		int      amount 	- number of slots to grow by
** Returns:	void
** Modifies:	instance
** Description:	Increase the storage space for an aggregate
**
** Notes:	This function is not externally callable.
*/

static
void
INST_aggregate_grow_by(Instance instance, int amount)
{
    Aggregate	data;
    int		newsize, low;
    Instance 	*tmp;
    Type	base;

	data = instance->u.aggregate;

    low = INSTaggr_lower_bound(instance);
    newsize = INSTaggr_upper_bound(instance) - low + amount + 1;
    tmp = (Instance *)realloc(data->contents, newsize * sizeof(Instance));
    if (tmp == NULL) {
	fprintf(stderr, "realloc failed allocating %d in INST_aggregate_grow_by().\n",
		newsize * sizeof(Instance));
	exit(1);
    }

    base = TYPEget_base_type(INSTget_type(instance));
    if (TYPEis_aggregate(base)) {
	while (++data->high < low + newsize)
	    tmp[data->high - low] = INSTcreate(base);
    } else {
	while (++data->high < low + newsize)
	    tmp[data->high - low] = INSTANCE_NULL;
    }
    data->high--;
    data->contents = tmp;
}

/*
** Procedure:	INSTaggr_at_put
** Parameters:	Instance instance	- instance to modify
**		int      index		- index at which to put element
**		Instance value		- value to insert
**		Error*   errc		- buffer for error code
** Returns:	void
** Requires:	OBJis_kind_of(INSTget_type(instance), Class_Aggregate_Type)
** Modifies:	instance
** Description:	Store a value at some position in an aggregate instance.
*/

void
INSTaggr_at_put(Instance instance, int index, Instance value)
{
    Aggregate	data;
/*    Class	class;*/
    int		low, high;

/*    assert(OBJis_kind_of(INSTget_type(instance), Class_Aggregate_Type));*/

/*    data = ((struct Instance*)OBJget_data(instance,Class_Instance, errc))->value.aggregate;*/
	data = instance->u.aggregate;

/*
    class = OBJget_class(INSTget_type(instance));
    if ((class == Class_Aggregate_Type) || (class == Class_Array_Type)) {
*/
    if (TYPEis_aggregate(instance->type)) {
	low = data->low;
	high = data->high;
    } else {
	low = 1;
	high = data->high;
    }
    if (index < low) {
	errc = ERROR_index_out_of_range;
	return;
    }
    if (index > high) {
	/* really have to evaluate data->max to tell what it is */
	/* for now, just assume it is infinite for everything, sigh */
	/*
	if (data->max != LITERAL_INFINITY) {
	    *errc = ERROR_index_out_of_range;
	    return;
	}
	*/
	INST_aggregate_grow_by(instance, INSTANCE_GROW_BY);
    }

    if (data->contents[index - low] != INSTANCE_NULL)
	OBJfree(data->contents[index - low]);
    data->contents[index - low] = OBJreference(value);
}


/*
** Procedure:	INSTaggr_at
** Parameters:	Instance instance	- instance to examine
**		int      index		- index of requested element
**		Error*   errc		- buffer for error code
** Returns:	Instance		- value at requested position
** Requires:	OBJis_kind_of(INSTget_type(instance), Class_Aggregate_Type)
** Description:	Retrieve the value at some position in an aggregate.
*/

Instance
INSTaggr_at(Instance instance, int index)
{
    Aggregate	data;
/*    Class	class;*/
    int		low, high;

/*    assert(OBJis_kind_of(INSTget_type(instance), Class_Aggregate_Type));*/

/*    data = ((struct Instance*)OBJget_data(instance, Class_Instance, errc))->value.aggregate;*/
	data = instance->u.aggregate;

/*    class = OBJget_class(INSTget_type(instance));
    if ((class == Class_Aggregate_Type) || (class == Class_Array_Type)) {*/
    if (TYPEis_aggregate(instance->type)) {
	low = data->low;
	high = data->high;
    } else {
	low = 1;
	high = data->high;
    }
    if (index < low) {
	errc = ERROR_index_out_of_range;
	return INSTANCE_NULL;
    }
    if (index > high) {
	if (data->max != LITERAL_INFINITY)
	    errc = ERROR_index_out_of_range;
	return INSTANCE_NULL;
    }
    return data->contents[index - low];
}

/*
** Procedure:	INSTlist_add_first
** Parameters:	Instance list	- list to modify
**		Instance item	- item to insert
**		Error*   errc	- buffer for error code
** Returns:	void
** Modifies:	list
** Description:	Add an item to the beginning of a list
*/

/*ARGSUSED*/
void
INSTlist_add_first(Instance list, Instance item)
{
    ERRORreport(ERROR_not_implemented, "INSTlist_add_first");
}

/*
** Procedure:	INSTlist_add_last
** Parameters:	Instance list	- list to modify
**		Instance item	- item to insert
**		Error*   errc	- buffer for error code
** Returns:	void
** Modifies:	list
** Description:	Add an item to the end of a list
*/

/*ARGSUSED*/
void
INSTlist_add_last(Instance list, Instance item)
{
    ERRORreport(ERROR_not_implemented, "INSTlist_last");
}

/*
** Procedure:	INSTlist_concat
** Parameters:	Instance list	- list to concatenate onto
**		Instance tail	- list to concatenate
**		Error*   errc	- buffer for error code
** Returns:	void
** Modifies:	list
** Description:	Concatenate a list onto the end of another list
**
** Notes:	A copy of 'tail' is concatenated directly onto 'list'
**	so that subsequent changes to 'tail' do not affect 'list.'
*/

/*ARGSUSED*/
void
INSTlist_concat(Instance list, Instance tail)
{
    ERRORreport(ERROR_not_implemented, "INSTlist_concat");
}

/*
** Procedure:	INSTbag_add
** Parameters:	Instance bag	- bag to modify
**		Instance item	- item to add
**		Error*   errc	- buffer for error code
** Returns:	void
** Modifies:	bag
** Description:	Add an instance to a bag
*/

void
INSTbag_add(Instance bag, Instance item)
{
    int		i;
    Aggregate	data;

/*    data = ((struct Instance*)OBJget_data(bag, Class_Instance, errc))->value.aggregate;*/
	data = bag->u.aggregate;

    for (i = 0; i < data->high; ++i) {
	if (data->contents[i] == INSTANCE_NULL) {
	    data->contents[i] = OBJreference(item);
	    return;
	}
    }
    if (data->max == LITERAL_INFINITY) {
	INST_aggregate_grow_by(bag, INSTANCE_GROW_BY);
/*
	data = ((struct Instance*)OBJget_data(bag,
					      Class_Instance,
					      errc))->value.aggregate;*/
	data = bag->u.aggregate;
	data->contents[i] = OBJreference(item);
    } else
	errc = ERROR_bag_full;
}

/*
** Procedure:	INSTbag_unite
** Parameters:	Instance bag	- bag to unite onto
**		Instance with	- the other bag to unite
**		Error*   errc	- buffer for error code
** Returns:	void
** Modifies:	bag
** Description:	Add the contents of a bag to another bag
**
** Notes:	This operation is destructive: 'bag' holds the
**	resulting bag on return.
*/

void
INSTbag_unite(Instance bag, Instance with)
{
    int		i, j;
    Aggregate	data, into;

/*    data = ((struct Instance*)OBJget_data(with, Class_Instance, errc))->value.aggregate;
    into = ((struct Instance*)OBJget_data(bag, Class_Instance, errc))->value.aggregate;*/
	data = with->u.aggregate;
	into = bag->u.aggregate;

    for (i = j = 0; i < data->high; ++i) {
	if (data->contents[i] != INSTANCE_NULL) {
	    /*SUPPRESS 530*/
	    for ( ; (j < into->high) && (into->contents[j] != INSTANCE_NULL); ++j)
		;
	    if (j == into->high) {
		if (data->max == LITERAL_INFINITY) {
		    INST_aggregate_grow_by(bag, INSTANCE_GROW_BY);
/*
		    into = ((struct Instance*)OBJget_data(bag,
							  Class_Instance,
							  errc))->value.aggregate;
*/
		    into = bag->u.aggregate;
		    into->contents[i] = OBJreference(data->contents[i]);
		} else {
		    errc = ERROR_bag_full;
		    return;
		}
	    }
	}
    }
}

/*
** Procedure:	INSTbag_intersect
** Parameters:	Instance bag	- bag to intersect into
**		Instance with	- bag to intersect with
**		Error*   errc	- buffer for error code
** Returns:	void
** Modifies:	bag
** Description:	intersect two bags
**
** Notes:	This operation is destructive: 'bag' holds the
**	resulting bag on return.
*/

void
INSTbag_intersect(Instance bag, Instance with)
{
    int		i;
    Aggregate	data;

    if (bag == with)
	return;
/*    data = ((struct Instance*)OBJget_data(with, Class_Instance, errc))->value.aggregate;*/
	data = with->u.aggregate;

    for (i = 0; i < data->high; ++i) {
	if ((data->contents[i] != INSTANCE_NULL) &&
	    (!INSTbag_includes(bag, data->contents[i]))) {
		OBJfree(data->contents[i]);
		data->contents[i] = INSTANCE_NULL;
	    }
    }
}

/*
** Procedure:	INSTbag_remove
** Parameters:	Instance bag	- bag to remove from
**		Instance item	- item to remove
**		Error*   errc	- buffer for error code
** Returns:	void
** Modifies:	bag
** Description:	Remove an item from a bag, if it occurs in the bag
*/

void
INSTbag_remove(Instance bag, Instance item)
{
    int		i;
    Aggregate	data;

    errc = ERROR_none;
/*    data = ((struct Instance*)OBJget_data(bag, Class_Instance, errc))->value.aggregate;*/
	data = bag->u.aggregate;

    for (i = 0; i < data->high; ++i) {
	if (data->contents[i] == item) {
	    OBJfree(data->contents[i]);
	    data->contents[i] = INSTANCE_NULL;
	}
    }
}

/*
** Procedure:	INSTbag_remove_all
** Parameters:	Instance bag	- bag to remove from
**		Instance remove	- bag of items to remove
**		Error*   errc	- buffer for error code
** Returns:	void
** Modifies:	bag
** Description:	Remove all items in a bag from some other bag
*/

void
INSTbag_remove_all(Instance bag, Instance remove)
{
    int		i, j;
    Aggregate	data, from;

/*
    data = ((struct Instance*)OBJget_data(remove,
					  Class_Instance, errc))->value.aggregate;
    from = ((struct Instance*)OBJget_data(bag,
					  Class_Instance, errc))->value.aggregate;
*/
	data = remove->u.aggregate;
	from = bag->u.aggregate;

    for (i = 0; i < data->high; ++i) {
	if (data->contents[i] != INSTANCE_NULL) {
	    for (j = 0; j < from->high; ++j)
		if (data->contents[i] == from->contents[j]) {
		    OBJfree(from->contents[j]);
		    from->contents[j] = INSTANCE_NULL;
		}
	}
    }
}

/*
** Procedure:	INSTbag_includes
** Parameters:	Instance bag	- bag to test
**		Instance item	- item to test for
**		Error*   errc	- buffer for error code
** Returns:	Boolean		- does the bag contain the item?
** Description:	Look for a particular item in a bag
*/

Boolean
INSTbag_includes(Instance bag, Instance item)
{
    int		i;
    Aggregate	data;

/*    data = ((struct Instance*)OBJget_data(bag, Class_Instance, errc))->value.aggregate;*/
	data = bag->u.aggregate;

    for (i = 0; i < data->high; ++i) {
	if (data->contents[i] == item)
	    return true;
    }
    return false;
}

/*
** Procedure:	INSTbag_subset
** Parameters:	Instance bag	- bag to test as superset
**		Instance subset	- bag to test as subset
**		Error*   errc	- buffer for error code
** Returns:	Boolean		- Does the bag contain the subset?
** Description:	Test whether some bag is wholly contained in another
**
** Notes:	This implementation is not correct.  In particular, it
**	returns 'true' in the following case:
**		INSTbag_subset({A, B, C}, {A, A})
*/

Boolean
INSTbag_subset(Instance bag, Instance subset)
{
    int		i;
    Aggregate	data;

/*    errc = ERROR_none;*/
    if (bag == subset)
	return true;
/*
    data = ((struct Instance*)OBJget_data(subset,
					  Class_Instance, errc))->value.aggregate;*/
	data = subset->u.aggregate;

    for (i = 0; i < data->high; ++i) {
	if (!INSTbag_includes(bag, data->contents[i]))
	    return false;
    }
    return true;
}

/*
** Procedure:	INSTset_add
** Parameters:	Instance set	- set to modify
**		Instance item	- item to add
**		Error*   errc	- buffer for error code
** Returns:	void
** Modifies:	set
** Description:	Add an item to a set, if it is not already present
*/

void
INSTset_add(Instance set, Instance item)
{
    int		i;
    Aggregate	data;

    errc = ERROR_none;
    if (INSTset_includes(set, item)) {
	errc = ERROR_set_duplicate_entry;
	return;
    }
/*    data = ((struct Instance*)OBJget_data(set,
					  Class_Instance,
					  errc))->value.aggregate;*/
	data = set->u.aggregate;

    for (i = 0; i < data->high; ++i) {
	if (data->contents[i] == INSTANCE_NULL) {
	    data->contents[i] = OBJreference(item);
	    return;
	}
    }
    if (data->max == LITERAL_INFINITY) {
	INST_aggregate_grow_by(set, INSTANCE_GROW_BY);
/*	data = ((struct Instance*)OBJget_data(set,
					      Class_Instance,
					      errc))->value.aggregate;*/
	data = set->u.aggregate;
	data->contents[i] = OBJreference(item);
    } else
	errc = ERROR_set_full;
}

/*
** Procedure:	INSTset_unite
** Parameters:	Instance set	- set to unite onto
**		Instance with	- the other set to unite
**		Error*   errc	- buffer for error code
** Returns:	void
** Modifies:	set
** Description:	Form the union of two sets
**
** Notes:	This operation is destructive: 'set' holds the
**	union on return.
*/

void
INSTset_unite(Instance set, Instance with)
{
    int		i, j;
    Aggregate	data, into;

    errc = ERROR_none;
    if (set == with)
	return;
/*    data = ((struct Instance*)OBJget_data(with, Class_Instance, errc))->value.aggregate;
    into = ((struct Instance*)OBJget_data(set, Class_Instance, errc))->value.aggregate;*/
	data = with->u.aggregate;
	into = set->u.aggregate;

    for (i = j = 0; i < data->high; ++i) {
	if ((data->contents[i] != INSTANCE_NULL) &&
	    (!INSTset_includes(set, data->contents[i]))) {
	    /*SUPPRESS 530*/
	    for ( ; (j < into->high) && (into->contents[j] != INSTANCE_NULL); ++j)
		;
	    if (j == into->high) {
		if (into->max == LITERAL_INFINITY) {
		    INST_aggregate_grow_by(set, INSTANCE_GROW_BY);
/*		    into = ((struct Instance*)OBJget_data(set,
							  Class_Instance,
							  errc))->value.aggregate;*/
		    into = set->u.aggregate;
		    into->contents[i] = OBJreference(data->contents[i]);
		} else {
		    errc = ERROR_set_full;
		    return;
		}
	    }
	}
    }
}

/*
** Procedure:	INSTset_intersect
** Parameters:	Instance set	- set to intersect into
**		Instance with	- set to intersect with
**		Error*   errc	- buffer for error code
** Returns:	void
** Modifies:	set
** Description:	Form the intersection of two sets
**
** Notes:	This operation is destructive: 'set' holds the
**	intersection on return.
*/

void
INSTset_intersect(Instance set, Instance with)
{
    int		i;
    Aggregate	data;

/*    errc = ERROR_none;*/
    if (set == with)
	return;
/*    data = ((struct Instance*)OBJget_data(with, Class_Instance, errc))->value.aggregate;*/
	data = with->u.aggregate;

    for (i = 0; i < data->high; ++i) {
	if ((data->contents[i] != INSTANCE_NULL) &&
	    (!INSTset_includes(set, data->contents[i]))) {
		OBJfree(data->contents[i]);
		data->contents[i] = INSTANCE_NULL;
	    }
    }
}

/*
** Procedure:	INSTset_remove
** Parameters:	Instance set	- set to remove from
**		Instance item	- item to remove from set
**		Error*   errc	- buffer for error code
** Returns:	void
** Modifies:	set
** Description:	Remove an item from a set, if it occurs in the set
*/

void
INSTset_remove(Instance set, Instance item)
{
    int		i;
    Aggregate	data;

/*    errc = ERROR_none;*/
/*    data = ((struct Instance*)OBJget_data(set, Class_Instance, errc))->value.aggregate;*/
	data = set->u.aggregate;

    for (i = 0; i < data->high; ++i) {
	if (data->contents[i] == item) {
	    OBJfree(data->contents[i]);
	    data->contents[i] = INSTANCE_NULL;
	}
    }
}

#if 0
/*
** Procedure:	INSTset_remove_all
** Parameters:	Instance set	- set to remove from
**		Instance remove	- set of items to remove
**		Error*   errc	- buffer for error code
** Returns:	void
** Modifies:	set
** Description:	From the difference of two sets
**
** Notes:	This operation is destructive: as the name suggests,
**	the contents of the second set are removed directly from the
**	first set.
*/

void
INSTset_remove_all(Instance set, Instance remove, Error* errc)
{
    int		i, j;
    Aggregate	data, from;

    *errc = ERROR_none;
    data = ((struct Instance*)OBJget_data(remove,
					  Class_Instance,
					  errc))->value.aggregate;
    from = ((struct Instance*)OBJget_data(set,
					  Class_Instance,
					  errc))->value.aggregate;
    for (i = 0; i < data->high; ++i) {
	if (data->contents[i] != INSTANCE_NULL) {
	    for (j = 0; j < from->high; ++j)
		if (data->contents[i] == from->contents[j]) {
		    OBJfree(from->contents[j]);
		    from->contents[j] = INSTANCE_NULL;
		}
	}
    }
}

#endif

/*
** Procedure:	INSTset_includes
** Parameters:	Instance set	- set to test
**		Instance item	- item to test for
**		Error*   errc	- buffer for error code
** Returns:	Boolean		- does the set contain the item?
** Description:	Look for a particular item in a set
*/

Boolean
INSTset_includes(Instance set, Instance item)
{
    int		i;
    Aggregate	data = set->u.aggregate;

    for (i = 0; i < data->high; ++i) {
	if (data->contents[i] == item)
	    return true;
    }
    return false;
}

#if 0

/*
** Procedure:	INSTset_subset
** Parameters:	Instance set	- set to test
**		Instance subset	- set to test as subset
**		Error*   errc	- buffer for error code
** Returns:	Boolean		- does the set contain the subset?
** Description:	Test whether some set is wholly contained in another
*/

Boolean
INSTset_subset(Instance set, Instance subset, Error* errc)
{
    int		i;
    Aggregate	data;

    *errc = ERROR_none;
    if (set == subset)
	return true;
    data = ((struct Instance*)OBJget_data(subset,
					  Class_Instance,
					  errc))->value.aggregate;
    for (i = 0; i < data->high; ++i) {
	if (!INSTset_includes(set, data->contents[i], errc))
	    return false;
    }
    return true;
}

#endif

/*
** Procedure:	INSTtype_cast
** Parameters:	Instance instance	- instance to cast
**		Type     type		- type to cast to
**		Error*   errc		- buffer for error code
** Returns:	Instance - the instance, cast to the requested type
** Modifies:	instance
** Description:	Convert an instance to a new type, if possible
**
** Notes:	If the cast is successful (*errc == ERROR_none), the
**	original instance should no longer be used.  It is guaranteed
**	to be valid only when an error is reported.  This call does
**	not report errors to stderr; it is the callers responsibility
**	to check *errc and to call ERRORreport(*errc, (String)context)
**	if it is not ERROR_none.
*/

Instance
INSTtype_cast(Instance instance, Type type)
{
    Type		obj_type;
    enum type_enum	from_class, to_class;
    Instance		new = INSTANCE_NULL;
    Instance	INST_convert_aggregate(Instance, Type);
    Boolean	INST_verify_base_types(Instance, Type);
 /*   static Boolean	INST_verify_base_types(Instance, Type); */

    errc = ERROR_none;

    if (instance == INSTANCE_NULL)
	return instance;
    if (instance == INSTANCE_REDEFINE)
	return instance;

    obj_type = INSTget_type(instance);

    if (obj_type == Type_Forward_Ref) return instance;

    from_class = TYPEis(obj_type);
    to_class = TYPEis(type);


    if (TYPEis_aggregate(type)) {
	if (TYPEinherits_from(obj_type, Class_Aggregate_Type)) {
	    if (INST_verify_base_types(instance,TYPEget_base_type(type)))
		new = instance;
	    else
		errc = ERROR_subordinate_failed;
	} else
	    errc = ERROR_aggregate_expected;
    } else if (TYPEinherits_from(type, Class_Aggregate_Type)) {
	if (from_class == to_class) {
	    if (INST_verify_base_types(instance,TYPEget_base_type(type)))
		new = instance;
	    else
		errc = ERROR_subordinate_failed;
	} else if (from_class == Class_Aggregate_Type) {
	    new = INST_convert_aggregate(instance, type);
	    if (errc != ERROR_none)
		new = instance;
	} else if (to_class == Class_Array_Type) {
	    errc = ERROR_array_expected;
	} else if (to_class == Class_Bag_Type) {
	    errc = ERROR_bag_expected;
	} else if (to_class == Class_List_Type) {
	    errc = ERROR_list_expected;
	} else if (to_class == Class_Set_Type) {
	    errc = ERROR_set_expected;
	}
    } else if (to_class == Class_Entity_Type) {
	if (from_class == Class_Entity_Type) {
	    Entity	child, parent;

	    parent = ENT_TYPEget_entity(type);
	    child = ENT_TYPEget_entity(obj_type);
	    if (OBJequal(child, parent) ||
		ENTITYhas_supertype(child, parent))
		new = instance;
	    else
		errc = ERROR_inappropriate_entity;
	} else if (from_class == entity_list_) {
		/* external mapping */
		/* for now, just imagine that there is a good fit */
		new = instance;		
        } else {
	    errc = ERROR_entity_expected;
        }
    } else if (to_class == Class_Enumeration_Type) {
	Expression x = (Expression)DICTlookup(TYPEget_enum_tags(type),
		instance->u.enumeration->symbol.name);
	if (x) {
		/* note that old instance->type was one of the predefined */
		/* types, so we needn't free it, just the expression itself */
		instance->type = x->type;	/* use new type */
		EXP_destroy(instance->u.enumeration);
		instance->u.enumeration = x;	/* use new expr */
		new = instance;		/* new, for Connie */
	} else {
		errc = ERROR_undefined_enum_value;
	}
#if originally
	if (OBJequal(type, obj_type))
	    new = instance;
	else
	    errc = ERROR_incompatible_types;
#endif
    } else if (to_class == Class_Generic_Type) {
	new = instance;
    } else if (to_class == Class_Integer_Type) {
	if (from_class == Class_Integer_Type)
	    new = instance;
	else if (from_class == Class_Real_Type) {
	    int ival;
/*	    new = INSTcreate(TYPE_INTEGER, errc);*/
	    new = INSTcreate(Type_Integer);
	    if (errc != ERROR_none) {
		errc = ERROR_subordinate_failed;
		return INSTANCE_NULL;
	    }
	    ival = (int)(*(Real*)INSTget_value(instance));
	    if (errc != ERROR_none) {
		OBJfree(new);
		errc = ERROR_subordinate_failed;
		return INSTANCE_NULL;
	    }
	    INSTput_value(new, (Generic)&ival);
	    if (errc != ERROR_none) {
		OBJfree(new);
		errc = ERROR_subordinate_failed;
		return INSTANCE_NULL;
	    }
	    OBJfree(instance);
	} else
	    errc = ERROR_integer_expected;
    } else if (to_class == Class_Logical_Type) {
	if (TYPEinherits_from(/*from_class*/obj_type,Class_Logical_Type))
	    new = instance;
	else
	    errc = ERROR_logical_expected;
    } else if (to_class == Class_Boolean_Type) {
	if (TYPEinherits_from(/*from_class*/obj_type,Class_Logical_Type) &&
	    *(Logical*)INSTget_value(instance) != Lunknown)
	    new = instance;
	else
	    errc = ERROR_boolean_expected;
    } else if ((to_class == Class_Number_Type) || (to_class == Class_Real_Type)) {
	if (from_class == Class_Real_Type)
	    new = instance;
	else if (from_class == Class_Integer_Type) {
	    double rval;
/*	    new = INSTcreate(TYPE_REAL);*/
	    new = INSTcreate(Type_Real);
	    if (errc != ERROR_none) {
		errc = ERROR_subordinate_failed;
		return INSTANCE_NULL;
	    }
	    rval = (double)(*(int*)INSTget_value(instance));
	    if (errc != ERROR_none) {
		OBJfree(new);
		errc = ERROR_subordinate_failed;
		return INSTANCE_NULL;
	    }
	    INSTput_value(new, (Generic)&rval);
	    if (errc != ERROR_none) {
		OBJfree(new);
		errc = ERROR_subordinate_failed;
		return INSTANCE_NULL;
	    }
	    OBJfree(instance);
	} else
	    errc = ERROR_number_expected;
    } else if (to_class == Class_Select_Type) {
	if (from_class == Class_Entity_Type) {
	    Entity	child, parent;
	    Linked_List	selections;

	    child = ENT_TYPEget_entity(obj_type);
	    selections = COMP_TYPEget_items(type);
	    LISTdo(selections, item, Type)
 		if (TYPEis_entity(item)) {
		    parent = ENT_TYPEget_entity(item);
		    if (OBJequal(child, parent) ||
			ENTITYhas_supertype(child, parent))
			new = instance;
 	        } else if (TYPEis_select(item)) {
		    if (INSTtype_cast(instance, item) != INSTANCE_NULL) {
			new = instance;
		    }
		} else {
/*		    assert(false);*/
			fprintf(stderr,"unknown assertion failed\n");
			ERRORabort(0);
		}
	    LISTod;
	    if (new == INSTANCE_NULL)
		errc = ERROR_incompatible_types;
	}
    } else if (to_class == Class_String_Type) {
	if (from_class == Class_String_Type)
	    new = instance;
	else
	    errc = ERROR_string_expected;
    }
return new;
}

/*static*/
Instance
INST_convert_aggregate(Instance instance, Type type)
{
    Instance	new = INSTANCE_NULL;

    Class_Of_Type	class;
    Aggregate	data;
    int 	i, j;
    Type	base;
    Instance	cast;

    class = TYPEis(type);
    if (class == Class_Aggregate_Type) {
	new = instance;
    } else if (class == Class_Array_Type) {
	new = INSTcreate(type);
	base = TYPEget_base_type(type);
	j = INSTaggr_lower_bound(new);
	data = instance->u.aggregate;
	for (i = 0; i < data->high; ++i) {
	    if (data->contents[i] != INSTANCE_NULL) {
		errc = ERROR_none;
		cast = INSTtype_cast(data->contents[i], base);
		if (errc != ERROR_none) {
		    ERRORreport(errc, "INST_convert_aggregate");
		    errc = ERROR_subordinate_failed;
		} else {
		    INSTaggr_at_put(new, j++, cast);
		    if (errc != ERROR_none) {
#if 0
			ERRORreport_with_line(errc,
				/* dunno about this for a line number */
				/* but I'm desparate - DEL */
				INSTget_line_number(data->contents[i]),j-1);
#endif
			/* Eh?  Are there line numbers?  Where? */
			ERRORreport(errc);
			errc = ERROR_subordinate_failed;
		    }
		}
	    }
	}
    } else if (class == Class_Bag_Type) {
	new = INSTcreate(type);
	base = TYPEget_base_type(type);
	data = instance->u.aggregate;
	for (i = 0; i < data->high; ++i) {
	    if (data->contents[i] != INSTANCE_NULL) {
		errc = ERROR_none;
		cast = INSTtype_cast(data->contents[i], base);
		if (errc != ERROR_none) {
		    ERRORreport(errc, "INST_convert_aggregate");
		    errc = ERROR_subordinate_failed;
		} else {
		    INSTbag_add(new, cast);
		}
	    }
	}
    } else if (class == Class_List_Type) {
	new = INSTcreate(type);
	base = TYPEget_base_type(type);
	j = 1;
	data = instance->u.aggregate;
	for (i = 0; i < data->high; ++i) {
	    if (data->contents[i] != INSTANCE_NULL) {
		errc = ERROR_none;
		cast = INSTtype_cast(data->contents[i], base);
		if (errc != ERROR_none) {
		    ERRORreport(errc, "INST_convert_aggregate");
		    errc = ERROR_subordinate_failed;
		} else {
		    INSTaggr_at_put(new, j++, cast);
		}
	    }
	}
    } else if (class == Class_Set_Type) {
	new = INSTcreate(type);
	base = TYPEget_base_type(type);
	data = instance->u.aggregate;
	for (i = 0; i < data->high; ++i) {
	    if (data->contents[i] != INSTANCE_NULL) {
		errc = ERROR_none;
		cast = INSTtype_cast(data->contents[i], base);
		if (errc != ERROR_none) {
		    ERRORreport(errc, "INST_convert_aggregate");
		    errc = ERROR_subordinate_failed;
		} else {
		    INSTset_add(new, cast);
		}
	    }
	}
    }
    return new;
}

/*static*/
/*ARGSUSED*/
Boolean
INST_verify_base_types(Instance instance, Type type)
{
    return true;
}

/*
** Procedure:	INSTaggr_lower_bound
** Parameters:	Instance instance	- instance to examine
**		Error*   errc		- buffer for error code
** Returns:	int			- the lower bound of the instance
** Description:	Retrieves the lower bound of an aggregate instance
**
** Notes:	For an array, this is the index of the first element
**	of the arrry.  For other aggregates, it is 1.
*/

int
INSTaggr_lower_bound(Instance instance)
{
	return(instance->u.aggregate->low);
}

/*
** Procedure:	INSTaggr_upper_bound
** Parameters:	Instance instance	- instance to examine
**		Error*   errc		- buffer for error code
** Returns:	int			- the upper bound of the instance
** Description:	Retrieves the upper bound of an aggregate instance
**
** Notes:	For an aggregate with a constrained size, this is the
**	value of the upper limit or index.  For an aggregate with an
**	infinite upper bound, the value returned is guaranteed to be
**	larger than the highest index of a filled slot in the aggregate.
*/

int
INSTaggr_upper_bound(Instance instance)
{
	return(instance->u.aggregate->high);
}

/* returns true instance */
Instance
INST_resolve(Product p,Instance i)
{
	Generic x;

	if (!i) return i;	/* can be null if instance was originally */
				/* omitted, i.e., "$" */

	if (i->type == Type_Forward_Ref) {
		x = DICTlookup(p->dict,i->symbol.name);
		if (x) return x;
		ERRORreport_with_line(ERROR_undefined_reference,i->symbol.line,i->symbol.name);
	}
	return i;
}

void
INSTresolve(Product p, Instance i)
{
	Linked_List attr_recs;
	Instance isub, inew;
	Entity e;

	switch (i->type->u.type->body->type) {
	case entity_list_:
		/* handle external mapping */
		LISTdo_links(i->u.list,link)
			isub = (Instance)link->data;
			errc = 0;
			inew = INST_resolve(p,isub);
			if (inew != isub) {
				INST_destroy(isub);
				link->data = (Generic)isub;
			}
		LISTod
		break;
	case entity_:
		/* handle internal mapping */

		/* Get the list of expected attributes */
		e = ENT_TYPEget_entity(i->type);
		if (i->internal_mapping) {
			attr_recs = ENTITYget_attributes(e);
		} else {
			attr_recs = ENTITYget_all_attributes(e);
		}

		/* Iterate over expected attributes */
		LISTdo(attr_recs, var, Variable)
			/* If this is an explicit attribute */
			if (!VARis_derived(var) && !VARget_inverse(var)) {
				isub = INSTfast_get_attribute(i, var);
				inew = INST_resolve(p,isub);
				if (inew != isub) {
					errc = 0;
					INSTfast_put_attribute(i, var, inew);
					if (errc) {
						ERRORreport_with_line(errc, yylineno, VARget_simple_name(var));
					}
					INST_destroy(isub);

				}
			}
		LISTod
	}
}
