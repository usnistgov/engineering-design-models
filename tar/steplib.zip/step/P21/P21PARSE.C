static char rcsid[] = "$Id: p21parse.c,v 1.1 1992/03/06 09:19:33 libes Exp libes $";

/*
 * Driver for Part 21 parser
 *
 * This software was developed by U.S. Government employees as part of
 * their official duties and is not subject to copyright.
 *
 * $Log: p21parse.c,v $
 * Revision 1.1  1992/03/06  09:19:33  libes
 * Initial revision
 *
 */

#include <stdio.h>
#include <string.h>
#include "express.h"
#include "p21.h"

int DebugLevel;

#ifdef YYDEBUG
extern int	p21_yydebug;
#endif /*YYDEBUG*/

char P21getopt_options[256] = "d:e:i:h:m:v";

Express model;
Dictionary entity_dict;

static void
usage()
{
	fprintf(stderr, "usage: %s [-v][-m <max instances>][-h <header_schema>][-d <n>] -e <EXPRESS file> -i <Part 21 file>\n",P21program_name);
	exit(2);
}

/* eventually, this function should be moved to libexpress.a */
Dictionary
ENTITYdictionary(Express model)
{
	Schema s;
	Entity e;
	DictionaryEntry de, fg;
	Dictionary d = DICTcreate(1000);

	errc = 0;

	DICTdo_type_init(model->symbol_table,&de,OBJ_SCHEMA);
	while (0 != (s = (Schema)DICTdo(&de))) {
		DICTdo_type_init(s->symbol_table,&fg,OBJ_ENTITY);
		while (0 != (e = (Entity)DICTdo(&fg))) {
			DICTdefine(d,e->symbol.name,(Generic)e,&e->symbol,OBJ_ENTITY);
			if (errc) {
				return 0;
			}
		}
	}
	return d;
}

int
P21_fail(Express m,Product p)
{
	ERRORflush_messages();

	if (P21fail) (*P21fail)(m,p);
	else fprintf(stderr,"Errors in input\n");

	return 1;
}

int
P21_succeed(Express m,Product p)
{
	if (P21succeed) return((*P21succeed)(m,p));

	fprintf(stderr,"No errors in instances\n");
	return 0;
}

/*ARGSUSED*/
static int
EXPRESS__succeed(Express model)
{
	fprintf(stderr,"No errors in schemas\n");
	return 0;
}

int
main(int argc, char* argv[])
{
    extern char *optarg;
    extern int	optind;
    /* extern int	getopt(int, char**, char*); */

	int rc;

    int		c;
    char	*schema_filename = 0;
	char	*p21_filename = 0;
    char        *p21_header_schema_filename = P21_HEADER_SCHEMA_FILENAME;
    Product	product;
	int max_instances = 10000;
	int no_need_to_work = 0;

	EXPRESSsucceed = EXPRESS__succeed;

	P21program_name = argv[0];
	ERRORusage_function = usage;

	P21init_init();

    EXPRESSinitialize();
    P21initialize();

#if 0
	/* i don't see the need for this - DEL */
    if (errc != ERROR_none)
	ERRORreport(errc);
#endif

	if (P21init_args) (*P21init_args)(argc,argv);

    optind = 1;
    while ((c = getopt(argc, argv, P21getopt_options)) != -1)
	switch (c) {
	  case 'd':
	    debug = atoi(optarg);
#ifdef YYDEBUG
	    if (debug > 3)
		p21_yydebug = 1;
#endif /*YYDEBUG*/
	    break;
	  case 'e':	schema_filename = optarg;		break;
	  case 'i':	p21_filename = optarg;			break;
	  case 'h':	p21_header_schema_filename = optarg;	break;
    case 'm':		max_instances = atoi(optarg);		break;
    case 'v':		printf("%s %s\n%s\n%s\n%s\n",
				P21program_name, P21version,
				"Part 21, DIS (E), October, 15, 1992",
				EXPRESSversion(),
				"Warning: Not all external/internal mappings work correctly");			
			no_need_to_work = 1;
			break;
	  default:
		rc = 1;
		if (P21getopt) {
			rc = (*P21getopt)(c,optarg);
		}
		if (rc == 1) (*ERRORusage_function)();
		break;
	}

	/* if no args, just print usage if necessary */
	if (!schema_filename && !p21_filename) {
		if (no_need_to_work) {
			return(0);
		} else {
			(*ERRORusage_function)();
		}
	}

	/* if at least one arg, user screwed up */
	if (!schema_filename || !p21_filename) {
		if (no_need_to_work) return(0);
		fprintf(stderr, "ERROR: Must specify schema AND product files\n");
		(*ERRORusage_function)();
	}

	if (EXPRESSinit_parse) (*EXPRESSinit_parse)();
	else fprintf(stderr,"Reading EXPRESS file %s\n",schema_filename);

	model = EXPRESScreate();
	if (!streq(p21_header_schema_filename,"")) {
		EXPRESSparse(model, (FILE *)0,p21_header_schema_filename);
	}
	EXPRESSparse(model, (FILE *)0,schema_filename);
	if (ERRORoccurred) return(EXPRESS_fail(model));
	EXPRESSresolve(model);
	if (ERRORoccurred) return(EXPRESS_fail(model));

	entity_dict = ENTITYdictionary(model);

#ifdef DEBUG
	p21_yydebug = 1;
	fflush(stdout);
	fflush(stderr);
#endif /*DEBUG*/

	if (ERRORoccurred) return(EXPRESS_fail(model));

	if (EXPRESSbackend) (*EXPRESSbackend)(model);
	if (ERRORoccurred) return(EXPRESS_fail(model));
	(void) EXPRESS_succeed(model);

	if (P21init_parse) (*P21init_parse)();
	else fprintf(stderr, "Reading Part 21 file %s\n", p21_filename);

	product = P21parse(p21_filename, model, max_instances);
	if (ERRORoccurred) return(P21_fail(model,product));
	else if (P21backend) {
		(*P21backend)(model,product);
	}

	if (ERRORoccurred) return(P21_fail(model,product));
	return(P21_succeed(model,product));
}
