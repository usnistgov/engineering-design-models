
# line 2 "p21yacc.y"

static char rcsid[] = "$Id: p21yacc.y,v 1.1 1992/11/09 17:53:54 libes Exp libes $";

/* 
 * NIST STEP Part 21 File Parser
 *
 * This software was developed by U.S. Government employees as part of
 * their official duties and is not subject to copyright.
 *
 * $Log: p21yacc.y,v $
 * Revision 1.1  1992/11/09  17:53:54  libes
 * Initial revision
 *
 * Revision 1.2  1992/03/06  10:07:43  libes
 * Figure out top-level schema
 *
 * Revision 2.3  1992/01/16  13:38:39  libes
 * pass in schema name rather than intuiting it from nesting`
 *
 * Revision 2.2  1990/09/17  11:49:03  clark
 * Add suppression of multiple identical warnings
 * Apply suppression to "Old style empty attribute" warning
 *
 * Revision 2.1  90/09/14  13:05:24  clark
 * BPR 2.1 alpha
 * 
 * Revision 2.0  90/09/12  15:14:23  clark
 * Initial revision
 * 
 * Based on early versions by:
 *   Bruce Thomas		5/89
 *   Sandy Ressler, Tina Lee	5/88
 */

#include "linklist.h"
#include "stack.h"
#include "express.h"
#include "p21.h"

extern Product product_model;
extern Schema header_schema;
Schema data_schema;
extern Dictionary entity_dict;

extern FILE	*yyin;
extern int	yylineno;

static void	yyerror(char*);
static void	yyerror2(char CONST *);
static char	*section = "header";	/* or "data" */

#ifdef FLEX
extern char     *p21_yytext;
#else /* LEX */
extern char     p21_yytext[];
#endif /*FLEX*/

static void	store_instance(char *,Instance);
static Instance	create_enum(char *);

static char	*expect_entity;	/* used to force order in Header section */

static Stack	listCounters;

#define MAX_SCOPE_DEPTH	100	/* man number of scopes that can be nested */

static struct scope {
	Dictionary dict;
} scopes[MAX_SCOPE_DEPTH], *scope;

#define CURRENT_SCOPE	scope->dict
#define PREVIOUS_SCOPE	(scope-1)->dict

#define PUSH_SCOPE	{	\
	scope++;		\
	scope->dict = DICTcreate(100); \
}
#define POP_SCOPE	{ \
	HASHdestroy(scope->dict); \
	scope--; \
}


# line 88 "p21yacc.y"
typedef union  {
	char *string;
	int iVal;
	double rVal;
	Logical lVal;
	Linked_List list;
	Instance instance;
	struct {
		Instance i;
		Symbol *sym;
	} entref;
} p21_YYSTYPE;
#ifdef __cplusplus
#  include <stdio.h>
   extern "C" {
     extern void yyerror(char *);
     extern int p21_yylex();
   }
#endif	/* __cplusplus */ 
# define ENTITY_NAME 257
# define ENUM 258
# define KEYWORD 259
# define STRING 260
# define BINARY 261
# define USER_DEFINED_KEYWORD 262
# define INTEGER 263
# define LOGICAL 264
# define REAL 265
# define COMMA 266
# define DATA 267
# define ENDSCOPE 268
# define ENDSEC 269
# define EQUALS 270
# define END_ISO_10303_21 271
# define HEADER 272
# define LEFT_PAREN 273
# define MISSING 274
# define REDEFINE 275
# define RIGHT_PAREN 276
# define SCOPE 277
# define SEMICOLON 278
# define SLASH 279
# define ISO_10303_21 280
#define yyclearin p21_yychar = -1
#define yyerrok p21_yyerrflag = 0
extern int p21_yychar;
#ifndef YYMAXDEPTH
#define YYMAXDEPTH 150
#endif

/* __YYSCLASS defines the scoping/storage class for global objects
 * that are NOT renamed by the -p option.  By default these names
 * are going to be 'static' so that multi-definition errors
 * will not occur with multiple parsers.
 * If you want (unsupported) access to internal names you need
 * to define this to be null so it implies 'extern' scope.
 * This should not be used in conjunction with -p.
 */
#ifndef __YYSCLASS
# define __YYSCLASS static
#endif
p21_YYSTYPE p21_yylval;
__YYSCLASS p21_YYSTYPE p21_yyval;
typedef int yytabelem;
# define YYERRCODE 256

# line 390 "p21yacc.y"

static void
yyerror(char* string)
{
	char buf[200];

	strcpy (buf, string);

	if (feof(yyin)) /*yyeof*/ strcat(buf, " at end of input");
	else if (p21_yytext[0] == 0) strcat(buf, " at null character");
	else if (p21_yytext[0] < 040 || p21_yytext[0] >= 0177)
		sprintf(buf + strlen(buf), " before character 0%o", p21_yytext[0]);
	else	sprintf(buf + strlen(buf), " before `%s'", p21_yytext);

#if 0
	ERRORreport_with_line(ERROR_syntax,yylineno, buf, CURRENT_SCOPE_TYPE_PRINTABLE,CURRENT_SCOPE_NAME);
#endif

	/* for now, punt */
	ERRORreport_with_line(ERROR_syntax,yylineno, buf, section, "section");
  }

static void
yyerror2(char const *t)	/* token or 0 to indicate no more tokens */
{
	char buf[200];
	static int first = 1;	/* true if first suggested replacement */
	static char tokens[4000] = "";/* error message, saying */
					/* "expecting <token types>" */

	if (t) {	/* subsequent token? */
		if (first) first = 0;
		else strcat (tokens," or ");
		strcat(tokens,t);
	} else {
	  strcpy(buf,"syntax error");
	  if (feof(yyin)) /*yyeof*/
	    strcat(buf, " at end of input");
	  else if (p21_yytext[0] == 0)
	    strcat(buf, " at null character");
	  else if (p21_yytext[0] < 040 || p21_yytext[0] >= 0177)
	    sprintf(buf + strlen(buf), " near character 0%o", p21_yytext[0]);
	  else
	    sprintf(buf + strlen(buf), " near `%s'", p21_yytext);

	  if (0 == strlen(tokens)) yyerror("syntax error");
	  ERRORreport_with_line(ERROR_syntax_expecting,
		yylineno - (p21_yytext[0] == '\n'),
		buf,tokens,section,"section");
#if 0
			,CURRENT_SCOPE_TYPE_PRINTABLE,CURRENT_SCOPE_NAME);
#endif
	}
}

#if 0
/* called to store an internal instance mapping */
static
void
store_instance(char * name, Instance i)
{
	INSTput_name(i,name);
	if (!i->dict)
		i->dict = DICTcreate(100);
	DICTdefine(CURRENT_SCOPE,INSTget_name(i),(Generic)i,
		&i->symbol,OBJ_INSTANCE);

/*	INSTadd_instance(CURRENT_SCOPE,i);*/
/*	PRODadd_instance(product_model,i);*/
}
#endif

static
void
store_instance(char *name, Instance i)
{
	Generic x;

	if (!i) {
		ERRORreport_with_line(ERROR_instance_not_created,yylineno,name);
		return;
	}

	i->symbol.name = name;
	i->symbol.line = yylineno;
	i->symbol.filename = current_filename;

	/* make it into a proper instance here and store it */

#if 0
	/* if we found a defn for what was formally a forward ref */
	/* replace the forward ref with the defn */
	x = DICTlookup(CURRENT_SCOPE,name);
	if (x == INSTANCE_FORWARD_REF) {
		DICTundefine(CURRENT_SCOPE,name);
	}
#endif
	DICTdefine(CURRENT_SCOPE,name,(Generic)i,&i->symbol,OBJ_INSTANCE);

/*    INSTput_name(i, name);*/
/*    PRODadd_instance(product_model, i);*/
}

#if 0
static
void
store_ud_entity_list(char * name, Linked_List i)
{
	Symbol *sym = SYMBOL_new();
	sym->name = name;
	sym->line = yylineno;
	sym->filename = current_filename;

/*	if (i == 0) return;*/
/*	INSTput_name(i, name);*/

	DICTdefine(CURRENT_SCOPE,name,(Generic)i,sym,OBJ_INSTANCE);

/*    PRODadd_instance(product_model, entity);*/
    fprintf(stderr, "ud entity %s defined\n", name);
}
#endif

/*ARGSUSED*/
static Instance
create_enum(char * value)
{
#if 0
    Constant *constant;
    /*Object*/ Generic *result;

    constant = SCOPElookup(data_schema, value, true, &errc);
    if (errc != ERROR_none) {
	ERRORreport_with_line(errc, yylineno, value);
	return 0;
    } else {
	result = INSTcreate(CSTget_type(constant), &errc);
	INSTput_value(result, constant, &errc);
	return result;
    }
#endif
	Expression e;
	Instance i;

	/* borrow Type_Enumeration temporarily until we find out the real */
	/* enumeration type */

	e = EXPcreate(Type_Enumeration);
	e->symbol.name = value;

	i = INSTcreate(Type_Enumeration);
	INSTput_value(i,(Generic)e);
	return i;
}

#if 0
void
ERROR_unknown_entity(int lineno,char *name)
{
	char *p = name;

	/* if user accidentally used lowercase, point this out */
	while (;*p;p++) {
		if (islower(*p)) {
			ERRORreport_with_line(ERROR_lowercased_entity,lineno,name);
			return;
		}
	}
	ERRORreport_with_line(ERROR_unknown_entity,yylineno,$1);
}
#endif

__YYSCLASS yytabelem p21_yyexca[] ={
-1, 1,
	0, -1,
	-2, 0,
	};
# define YYNPROD 57
# define YYLAST 159
__YYSCLASS yytabelem p21_yyact[]={

    51,    43,    49,    44,    45,    50,    40,    42,    41,     3,
   100,    93,   101,    77,    69,    54,    52,    38,    39,    35,
    29,    58,    80,    99,    27,    16,    15,     9,     4,    56,
    85,    94,    58,    58,    58,    62,    11,     6,    49,    86,
    84,    50,    83,    82,    57,    88,    60,    59,    30,    10,
    34,    26,    67,    26,    17,    47,    80,    21,    51,    26,
    37,    46,    64,    32,    89,    36,    74,    23,    24,    79,
    20,    19,    61,    96,    95,    92,    68,    55,     8,    63,
    31,    14,    18,    13,    12,    22,     7,     5,     2,    78,
    28,    66,    33,    73,    48,    25,     1,     0,     0,     0,
     0,     0,    53,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,    65,     0,    70,
     0,     0,    75,     0,     0,    71,    72,     0,     0,     0,
     0,     0,     0,     0,    76,     0,    81,     0,     0,     0,
     0,     0,     0,     0,     0,     0,    75,     0,    87,    97,
    33,     0,    90,     0,    91,     0,   102,    65,    98 };
__YYSCLASS yytabelem p21_yypact[]={

 -3000, -3000,  -271,  -250,  -235, -3000,  -251,  -222,  -231, -3000,
  -252,  -253,  -215,  -202,  -202, -3000,  -198,  -254,  -202,  -258,
 -3000,  -225, -3000,  -206, -3000,  -220, -3000, -3000,  -259, -3000,
  -257,  -202,  -263, -3000,  -248, -3000,  -232, -3000, -3000, -3000,
 -3000, -3000, -3000, -3000, -3000, -3000, -3000, -3000, -3000,  -226,
  -227, -3000,  -241, -3000, -3000,  -221, -3000,  -264,  -257,  -257,
  -257,  -257, -3000,  -202,  -265, -3000, -3000,  -203,  -198, -3000,
 -3000,  -233,  -234,  -236, -3000, -3000, -3000, -3000,  -237, -3000,
  -228,  -204, -3000, -3000, -3000,  -257, -3000, -3000,  -257,  -268,
 -3000,  -245, -3000,  -199, -3000,  -221,  -256, -3000,  -266, -3000,
  -199, -3000, -3000 };
__YYSCLASS yytabelem p21_yypgo[]={

     0,    96,    95,    55,    61,    66,    60,    94,    93,    69,
    91,    62,    65,    89,    88,    87,    86,    84,    83,    82,
    81,    70,    80,    79,    71,    78,    67,    68,    77,    76,
    75,    74,    73,    72 };
__YYSCLASS yytabelem p21_yyr1[]={

     0,    14,     1,    15,    17,    17,    20,    22,    23,    18,
    19,    19,    24,    25,    16,    26,    26,    28,    27,    29,
    31,    27,     2,     3,    21,    11,    11,    10,    13,    13,
     9,     4,     4,    12,    12,    12,     6,     6,     6,     6,
     6,     6,     6,     6,     6,     6,     6,    30,    30,    32,
    32,    33,     7,     7,     8,     8,     5 };
__YYSCLASS yytabelem p21_yyr2[]={

     0,     1,    14,    10,     2,     4,     1,     1,     1,    13,
     4,     6,     2,     1,    12,     2,     4,     1,    11,     1,
     1,    21,     3,     3,    11,     2,     2,     7,     3,     5,
     9,     9,     9,     1,     3,     7,     3,     3,     3,     3,
     3,     3,     3,     3,     3,     3,     3,     0,     6,     3,
     7,     1,     9,     5,     3,     7,     3 };
__YYSCLASS yytabelem p21_yychk[]={

 -3000,    -1,   -14,   280,   278,   -15,   272,   -16,   -25,   278,
   271,   267,   -17,   -18,   -20,   278,   278,   269,   -19,   -24,
   -21,   259,   -21,   -26,   -27,    -2,   257,   278,   -24,   278,
   273,   -22,   269,   -27,   270,   278,   -12,    -6,   274,   275,
   263,   265,   264,   258,   260,   261,    -4,    -3,    -7,   259,
   262,   257,   273,   -21,   278,   -28,   277,   276,   266,   273,
   273,   -33,   276,   -23,   -11,    -4,   -10,   273,   -29,   278,
    -6,   -12,   -12,    -8,    -5,    -6,   -21,   278,   -13,    -9,
   259,   -26,   276,   276,   276,   266,   276,    -9,   273,   268,
    -5,   -12,   -30,   279,   276,   -31,   -32,    -3,   -11,   279,
   266,   278,    -3 };
__YYSCLASS yytabelem p21_yydef[]={

     1,    -2,     0,     0,     0,    13,     0,     0,     0,     6,
     0,     0,     0,     4,     0,     2,     0,     0,     5,     0,
    12,     0,     7,     0,    15,     0,    22,     3,     0,    10,
    33,     0,     0,    16,    17,    11,     0,    34,    36,    37,
    38,    39,    40,    41,    42,    43,    44,    45,    46,     0,
     0,    23,    51,     8,    14,     0,    19,     0,     0,    33,
    33,     0,    53,     0,     0,    25,    26,     0,     0,    24,
    35,     0,     0,     0,    54,    56,     9,    18,     0,    28,
     0,     0,    31,    32,    52,     0,    27,    29,    33,    47,
    55,     0,    20,     0,    30,     0,     0,    49,     0,    48,
     0,    21,    50 };
typedef struct { char *t_name; int t_val; } yytoktype;
#ifndef YYDEBUG
#	define YYDEBUG	0	/* don't allow debugging */
#endif

#if YYDEBUG

__YYSCLASS yytoktype yytoks[] =
{
	"ENTITY_NAME",	257,
	"ENUM",	258,
	"KEYWORD",	259,
	"STRING",	260,
	"BINARY",	261,
	"USER_DEFINED_KEYWORD",	262,
	"INTEGER",	263,
	"LOGICAL",	264,
	"REAL",	265,
	"COMMA",	266,
	"DATA",	267,
	"ENDSCOPE",	268,
	"ENDSEC",	269,
	"EQUALS",	270,
	"END_ISO_10303_21",	271,
	"HEADER",	272,
	"LEFT_PAREN",	273,
	"MISSING",	274,
	"REDEFINE",	275,
	"RIGHT_PAREN",	276,
	"SCOPE",	277,
	"SEMICOLON",	278,
	"SLASH",	279,
	"ISO_10303_21",	280,
	"-unknown-",	-1	/* ends search */
};

__YYSCLASS char * yyreds[] =
{
	"-no such reduction-",
	"ExchangeFile : /* empty */",
	"ExchangeFile : ISO_10303_21 SEMICOLON HeaderSection DataSection END_ISO_10303_21 SEMICOLON",
	"HeaderSection : HEADER SEMICOLON HeaderEntities ENDSEC SEMICOLON",
	"HeaderEntities : ReqHdrEntities",
	"HeaderEntities : ReqHdrEntities OptHdrEntities",
	"ReqHdrEntities : /* empty */",
	"ReqHdrEntities : HeaderEntity",
	"ReqHdrEntities : HeaderEntity HeaderEntity",
	"ReqHdrEntities : HeaderEntity HeaderEntity HeaderEntity",
	"OptHdrEntities : OptHdrEntity SEMICOLON",
	"OptHdrEntities : OptHdrEntities OptHdrEntity SEMICOLON",
	"OptHdrEntity : HeaderEntity",
	"DataSection : /* empty */",
	"DataSection : DATA SEMICOLON DataEntities ENDSEC SEMICOLON",
	"DataEntities : DataEntity",
	"DataEntities : DataEntities DataEntity",
	"DataEntity : EntityName EQUALS",
	"DataEntity : EntityName EQUALS Entity_Instance_RHS SEMICOLON",
	"DataEntity : EntityName EQUALS SCOPE",
	"DataEntity : EntityName EQUALS SCOPE DataEntities ENDSCOPE Entity_export",
	"DataEntity : EntityName EQUALS SCOPE DataEntities ENDSCOPE Entity_export Entity_Instance_RHS SEMICOLON",
	"EntityName : ENTITY_NAME",
	"EntityReference : ENTITY_NAME",
	"HeaderEntity : KEYWORD LEFT_PAREN Parameters RIGHT_PAREN SEMICOLON",
	"Entity_Instance_RHS : Simple_Record",
	"Entity_Instance_RHS : Subsuper_Record",
	"Subsuper_Record : LEFT_PAREN Subsuper_Record_List RIGHT_PAREN",
	"Subsuper_Record_List : Subsuper_Record_List_Element",
	"Subsuper_Record_List : Subsuper_Record_List Subsuper_Record_List_Element",
	"Subsuper_Record_List_Element : KEYWORD LEFT_PAREN Parameters RIGHT_PAREN",
	"Simple_Record : KEYWORD LEFT_PAREN Parameters RIGHT_PAREN",
	"Simple_Record : USER_DEFINED_KEYWORD LEFT_PAREN Parameters RIGHT_PAREN",
	"Parameters : /* empty */",
	"Parameters : Parameter",
	"Parameters : Parameters COMMA Parameter",
	"Parameter : MISSING",
	"Parameter : REDEFINE",
	"Parameter : INTEGER",
	"Parameter : REAL",
	"Parameter : LOGICAL",
	"Parameter : ENUM",
	"Parameter : STRING",
	"Parameter : BINARY",
	"Parameter : Simple_Record",
	"Parameter : EntityReference",
	"Parameter : EmbeddedList",
	"Entity_export : /* empty */",
	"Entity_export : SLASH EntityReferences SLASH",
	"EntityReferences : EntityReference",
	"EntityReferences : EntityReferences COMMA EntityReference",
	"EmbeddedList : LEFT_PAREN",
	"EmbeddedList : LEFT_PAREN List RIGHT_PAREN",
	"EmbeddedList : LEFT_PAREN RIGHT_PAREN",
	"List : ListEntry",
	"List : List COMMA ListEntry",
	"ListEntry : Parameter",
};
#endif /* YYDEBUG */
#define YYFLAG  (-3000)
/* @(#) $Revision: 70.7 $ */    

/*
** Skeleton parser driver for yacc output
*/

#if defined(NLS) && !defined(NL_SETN)
#include <msgbuf.h>
#endif

#ifndef nl_msg
#define nl_msg(i,s) (s)
#endif

/*
** yacc user known macros and defines
*/
#define YYERROR		goto yyerrlab

#ifndef __RUNTIME_YYMAXDEPTH
#define YYACCEPT	return(0)
#define YYABORT		return(1)
#else
#define YYACCEPT	{free_stacks(); return(0);}
#define YYABORT		{free_stacks(); return(1);}
#endif

#define YYBACKUP( newtoken, newvalue )\
{\
	if ( p21_yychar >= 0 || ( p21_yyr2[ yytmp ] >> 1 ) != 1 )\
	{\
		yyerror( (nl_msg(30001,"syntax error - cannot backup")) );\
		goto yyerrlab;\
	}\
	p21_yychar = newtoken;\
	yystate = *yyps;\
	p21_yylval = newvalue;\
	goto yynewstate;\
}
#define YYRECOVERING()	(!!p21_yyerrflag)
#ifndef YYDEBUG
#	define YYDEBUG	1	/* make debugging available */
#endif

/*
** user known globals
*/
int p21_yydebug;			/* set to 1 to get debugging */

/*
** driver internal defines
*/
/* define for YYFLAG now generated by yacc program. */
/*#define YYFLAG		(FLAGVAL)*/

/*
** global variables used by the parser
*/
# ifndef __RUNTIME_YYMAXDEPTH
__YYSCLASS p21_YYSTYPE p21_yyv[ YYMAXDEPTH ];	/* value stack */
__YYSCLASS int yys[ YYMAXDEPTH ];		/* state stack */
# else
__YYSCLASS p21_YYSTYPE *p21_yyv;			/* pointer to malloc'ed value stack */
__YYSCLASS int *yys;			/* pointer to malloc'ed stack stack */

#if defined(__STDC__) || defined (__cplusplus)
#include <stdlib.h>
#else
	extern char *malloc();
	extern char *realloc();
	extern void free();
#endif /* __STDC__ or __cplusplus */


static int allocate_stacks(); 
static void free_stacks();
# ifndef YYINCREMENT
# define YYINCREMENT (YYMAXDEPTH/2) + 10
# endif
# endif	/* __RUNTIME_YYMAXDEPTH */
long  yymaxdepth = YYMAXDEPTH;

__YYSCLASS p21_YYSTYPE *yypv;			/* top of value stack */
__YYSCLASS int *yyps;			/* top of state stack */

__YYSCLASS int yystate;			/* current state */
__YYSCLASS int yytmp;			/* extra var (lasts between blocks) */

int p21_yynerrs;			/* number of errors */
__YYSCLASS int p21_yyerrflag;			/* error recovery flag */
int p21_yychar;			/* current input token number */



/*
** p21_yyparse - return 0 if worked, 1 if syntax error not recovered from
*/
int
p21_yyparse()
{
	register p21_YYSTYPE *yypvt;	/* top of value stack for $vars */

	/*
	** Initialize externals - p21_yyparse may be called more than once
	*/
# ifdef __RUNTIME_YYMAXDEPTH
	if (allocate_stacks()) YYABORT;
# endif
	yypv = &p21_yyv[-1];
	yyps = &yys[-1];
	yystate = 0;
	yytmp = 0;
	p21_yynerrs = 0;
	p21_yyerrflag = 0;
	p21_yychar = -1;

	goto yystack;
	{
		register p21_YYSTYPE *yy_pv;	/* top of value stack */
		register int *yy_ps;		/* top of state stack */
		register int yy_state;		/* current state */
		register int  yy_n;		/* internal state number info */

		/*
		** get globals into registers.
		** branch to here only if YYBACKUP was called.
		*/
	yynewstate:
		yy_pv = yypv;
		yy_ps = yyps;
		yy_state = yystate;
		goto yy_newstate;

		/*
		** get globals into registers.
		** either we just started, or we just finished a reduction
		*/
	yystack:
		yy_pv = yypv;
		yy_ps = yyps;
		yy_state = yystate;

		/*
		** top of for (;;) loop while no reductions done
		*/
	yy_stack:
		/*
		** put a state and value onto the stacks
		*/
#if YYDEBUG
		/*
		** if debugging, look up token value in list of value vs.
		** name pairs.  0 and negative (-1) are special values.
		** Note: linear search is used since time is not a real
		** consideration while debugging.
		*/
		if ( p21_yydebug )
		{
			register int yy_i;

			printf( "State %d, token ", yy_state );
			if ( p21_yychar == 0 )
				printf( "end-of-file\n" );
			else if ( p21_yychar < 0 )
				printf( "-none-\n" );
			else
			{
				for ( yy_i = 0; yytoks[yy_i].t_val >= 0;
					yy_i++ )
				{
					if ( yytoks[yy_i].t_val == p21_yychar )
						break;
				}
				printf( "%s\n", yytoks[yy_i].t_name );
			}
		}
#endif /* YYDEBUG */
		if ( ++yy_ps >= &yys[ yymaxdepth ] )	/* room on stack? */
		{
# ifndef __RUNTIME_YYMAXDEPTH
			yyerror( (nl_msg(30002,"yacc stack overflow")) );
			YYABORT;
# else
			/* save old stack bases to recalculate pointers */
			p21_YYSTYPE * p21_yyv_old = p21_yyv;
			int * yys_old = yys;
			yymaxdepth += YYINCREMENT;
			yys = (int *) realloc(yys, yymaxdepth * sizeof(int));
			p21_yyv = (p21_YYSTYPE *) realloc(p21_yyv, yymaxdepth * sizeof(p21_YYSTYPE));
			if (yys==0 || p21_yyv==0) {
			    yyerror( (nl_msg(30002,"yacc stack overflow")) );
			    YYABORT;
			    }
			/* Reset pointers into stack */
			yy_ps = (yy_ps - yys_old) + yys;
			yyps = (yyps - yys_old) + yys;
			yy_pv = (yy_pv - p21_yyv_old) + p21_yyv;
			yypv = (yypv - p21_yyv_old) + p21_yyv;
# endif

		}
		*yy_ps = yy_state;
		*++yy_pv = p21_yyval;

		/*
		** we have a new state - find out what to do
		*/
	yy_newstate:
		if ( ( yy_n = p21_yypact[ yy_state ] ) <= YYFLAG )
			goto p21_yydefault;		/* simple state */
#if YYDEBUG
		/*
		** if debugging, need to mark whether new token grabbed
		*/
		yytmp = p21_yychar < 0;
#endif
		if ( ( p21_yychar < 0 ) && ( ( p21_yychar = p21_yylex() ) < 0 ) )
			p21_yychar = 0;		/* reached EOF */
#if YYDEBUG
		if ( p21_yydebug && yytmp )
		{
			register int yy_i;

			printf( "Received token " );
			if ( p21_yychar == 0 )
				printf( "end-of-file\n" );
			else if ( p21_yychar < 0 )
				printf( "-none-\n" );
			else
			{
				for ( yy_i = 0; yytoks[yy_i].t_val >= 0;
					yy_i++ )
				{
					if ( yytoks[yy_i].t_val == p21_yychar )
						break;
				}
				printf( "%s\n", yytoks[yy_i].t_name );
			}
		}
#endif /* YYDEBUG */
		if ( ( ( yy_n += p21_yychar ) < 0 ) || ( yy_n >= YYLAST ) )
			goto p21_yydefault;
		if ( p21_yychk[ yy_n = p21_yyact[ yy_n ] ] == p21_yychar )	/*valid shift*/
		{
			p21_yychar = -1;
			p21_yyval = p21_yylval;
			yy_state = yy_n;
			if ( p21_yyerrflag > 0 )
				p21_yyerrflag--;
			goto yy_stack;
		}

	p21_yydefault:
		if ( ( yy_n = p21_yydef[ yy_state ] ) == -2 )
		{
#if YYDEBUG
			yytmp = p21_yychar < 0;
#endif
			if ( ( p21_yychar < 0 ) && ( ( p21_yychar = p21_yylex() ) < 0 ) )
				p21_yychar = 0;		/* reached EOF */
#if YYDEBUG
			if ( p21_yydebug && yytmp )
			{
				register int yy_i;

				printf( "Received token " );
				if ( p21_yychar == 0 )
					printf( "end-of-file\n" );
				else if ( p21_yychar < 0 )
					printf( "-none-\n" );
				else
				{
					for ( yy_i = 0;
						yytoks[yy_i].t_val >= 0;
						yy_i++ )
					{
						if ( yytoks[yy_i].t_val
							== p21_yychar )
						{
							break;
						}
					}
					printf( "%s\n", yytoks[yy_i].t_name );
				}
			}
#endif /* YYDEBUG */
			/*
			** look through exception table
			*/
			{
				register int *yyxi = p21_yyexca;

				while ( ( *yyxi != -1 ) ||
					( yyxi[1] != yy_state ) )
				{
					yyxi += 2;
				}
				while ( ( *(yyxi += 2) >= 0 ) &&
					( *yyxi != p21_yychar ) )
					;
				if ( ( yy_n = yyxi[1] ) < 0 )
					YYACCEPT;
			}
		}

		/*
		** check for syntax error
		*/
		if ( yy_n == 0 )	/* have an error */
		{
			/* no worry about speed here! */
			switch ( p21_yyerrflag )
			{
			case 0:		/* new error */
				yyerror( (nl_msg(30003,"syntax error")) );
				p21_yynerrs++;
				goto skip_init;
			yyerrlab:
				/*
				** get globals into registers.
				** we have a user generated syntax type error
				*/
				yy_pv = yypv;
				yy_ps = yyps;
				yy_state = yystate;
				p21_yynerrs++;
			skip_init:
			case 1:
			case 2:		/* incompletely recovered error */
					/* try again... */
				p21_yyerrflag = 3;
				/*
				** find state where "error" is a legal
				** shift action
				*/
				while ( yy_ps >= yys )
				{
					yy_n = p21_yypact[ *yy_ps ] + YYERRCODE;
					if ( yy_n >= 0 && yy_n < YYLAST &&
						p21_yychk[p21_yyact[yy_n]] == YYERRCODE)					{
						/*
						** simulate shift of "error"
						*/
						yy_state = p21_yyact[ yy_n ];
						goto yy_stack;
					}
					/*
					** current state has no shift on
					** "error", pop stack
					*/
#if YYDEBUG
#	define _POP_ "Error recovery pops state %d, uncovers state %d\n"
					if ( p21_yydebug )
						printf( _POP_, *yy_ps,
							yy_ps[-1] );
#	undef _POP_
#endif
					yy_ps--;
					yy_pv--;
				}
				/*
				** there is no state on stack with "error" as
				** a valid shift.  give up.
				*/
				YYABORT;
			case 3:		/* no shift yet; eat a token */
#if YYDEBUG
				/*
				** if debugging, look up token in list of
				** pairs.  0 and negative shouldn't occur,
				** but since timing doesn't matter when
				** debugging, it doesn't hurt to leave the
				** tests here.
				*/
				if ( p21_yydebug )
				{
					register int yy_i;

					printf( "Error recovery discards " );
					if ( p21_yychar == 0 )
						printf( "token end-of-file\n" );
					else if ( p21_yychar < 0 )
						printf( "token -none-\n" );
					else
					{
						for ( yy_i = 0;
							yytoks[yy_i].t_val >= 0;
							yy_i++ )
						{
							if ( yytoks[yy_i].t_val
								== p21_yychar )
							{
								break;
							}
						}
						printf( "token %s\n",
							yytoks[yy_i].t_name );
					}
				}
#endif /* YYDEBUG */
				if ( p21_yychar == 0 )	/* reached EOF. quit */
					YYABORT;
				p21_yychar = -1;
				goto yy_newstate;
			}
		}/* end if ( yy_n == 0 ) */
		/*
		** reduction by production yy_n
		** put stack tops, etc. so things right after switch
		*/
#if YYDEBUG
		/*
		** if debugging, print the string that is the user's
		** specification of the reduction which is just about
		** to be done.
		*/
		if ( p21_yydebug )
			printf( "Reduce by (%d) \"%s\"\n",
				yy_n, yyreds[ yy_n ] );
#endif
		yytmp = yy_n;			/* value to switch over */
		yypvt = yy_pv;			/* $vars top of value stack */
		/*
		** Look in goto table for next state
		** Sorry about using yy_state here as temporary
		** register variable, but why not, if it works...
		** If p21_yyr2[ yy_n ] doesn't have the low order bit
		** set, then there is no action to be done for
		** this reduction.  So, no saving & unsaving of
		** registers done.  The only difference between the
		** code just after the if and the body of the if is
		** the goto yy_stack in the body.  This way the test
		** can be made before the choice of what to do is needed.
		*/
		{
			/* length of production doubled with extra bit */
			register int yy_len = p21_yyr2[ yy_n ];

			if ( !( yy_len & 01 ) )
			{
				yy_len >>= 1;
				p21_yyval = ( yy_pv -= yy_len )[1];	/* $$ = $1 */
				yy_state = p21_yypgo[ yy_n = p21_yyr1[ yy_n ] ] +
					*( yy_ps -= yy_len ) + 1;
				if ( yy_state >= YYLAST ||
					p21_yychk[ yy_state =
					p21_yyact[ yy_state ] ] != -yy_n )
				{
					yy_state = p21_yyact[ p21_yypgo[ yy_n ] ];
				}
				goto yy_stack;
			}
			yy_len >>= 1;
			p21_yyval = ( yy_pv -= yy_len )[1];	/* $$ = $1 */
			yy_state = p21_yypgo[ yy_n = p21_yyr1[ yy_n ] ] +
				*( yy_ps -= yy_len ) + 1;
			if ( yy_state >= YYLAST ||
				p21_yychk[ yy_state = p21_yyact[ yy_state ] ] != -yy_n )
			{
				yy_state = p21_yyact[ p21_yypgo[ yy_n ] ];
			}
		}
					/* save until reenter driver code */
		yystate = yy_state;
		yyps = yy_ps;
		yypv = yy_pv;
	}
	/*
	** code supplied by user is placed in this switch
	*/
	switch( yytmp )
	{
		
case 1:
# line 138 "p21yacc.y"
{ listCounters = STACKcreate();
			scope = scopes;
			scope->dict = product_model->dict;
		  } break;
case 6:
# line 156 "p21yacc.y"
{expect_entity = "file_description";} break;
case 7:
# line 157 "p21yacc.y"
{expect_entity = "file_name";} break;
case 8:
# line 158 "p21yacc.y"
{expect_entity = "file_schema";} break;
case 9:
# line 159 "p21yacc.y"
{expect_entity = 0;} break;
case 13:
# line 170 "p21yacc.y"
{section = "data";} break;
case 17:
# line 178 "p21yacc.y"
{ /*sprintf(current_entity, $1);*/ } break;
case 18:
# line 180 "p21yacc.y"
{ store_instance(yypvt[-4].string, yypvt[-1].instance); } break;
case 19:
# line 182 "p21yacc.y"
{ PUSH_SCOPE} break;
case 20:
# line 184 "p21yacc.y"
{ /*sprintf(current_entity, $1); */} break;
case 21:
# line 186 "p21yacc.y"
{ POP_SCOPE
			store_instance(yypvt[-9].string, yypvt[-1].instance);} break;
case 22:
# line 191 "p21yacc.y"
{ p21_yyval.string = yypvt[-0].string; } break;
case 23:
# line 195 "p21yacc.y"
{ struct scope *s = scope;
		    p21_yyval.entref.i = 0;
		    for (;s >= scopes;s--) {
			if (0 != (p21_yyval.entref.i = (Instance)DICTlookup_symbol(s->dict,yypvt[-0].string,&p21_yyval.entref.sym))) break;
		    }
		    if (p21_yyval.entref.i == 0) {
			    p21_yyval.entref.i = INSTcreate_entity_forward_ref(yylineno,yypvt[-0].string);
		    }
		  } break;
case 24:
# line 207 "p21yacc.y"
{ Entity entity;
		    if (expect_entity && !streq(expect_entity,yypvt[-4].string)) {
			ERRORreport_with_line(ERROR_unexpected_header_entity,
				yylineno,expect_entity,yypvt[-4].string);
		    }
		    entity = (Entity)SCOPEfind(header_schema,yypvt[-4].string,SCOPE_FIND_ENTITY);
		    if (entity == 0) {
			ERRORreport_with_line(ERROR_unknown_entity,yylineno,yypvt[-4].string);
		    } else {
			Instance i;
			errc = 0;
			i = INSTcreate_entity(entity, yypvt[-2].list, false);
			if (errc) {
				ERRORreport_with_line(errc,yylineno,yypvt[-4].string);
			} else {
				/* we have to store this somewhere, but */
				/* these are not named.  To avoid stepping */
				/* on user's namespace (which is just */
				/* numbers), use the entity name. */
				store_instance(ENTITYget_name(entity),i);
			}
		    } } break;
case 27:
# line 237 "p21yacc.y"
{ 
			   p21_yyval.instance = INSTcreate_external(yypvt[-1].list);
			  } break;
case 28:
# line 243 "p21yacc.y"
{ p21_yyval.list = LISTcreate();
			    if (errc) ERRORreport_with_line(errc,yylineno,"INSTcreate");
			    else {
				LISTadd(p21_yyval.list,(Generic)yypvt[-0].instance);
			    }
		          } break;
case 29:
# line 249 "p21yacc.y"
{
			  if (!errc) {
				LISTadd(yypvt[-1].list,(Generic)yypvt[-0].instance);
			  }
			} break;
case 30:
# line 260 "p21yacc.y"
{ Entity entity;
		    if (0 == (entity = (Entity)DICTlookup(entity_dict,yypvt[-3].string))) {
			ERRORreport_with_line(ERROR_unknown_entity,yylineno,yypvt[-3].string);
			p21_yyval.instance = 0;
		    } else {
			Instance i;
			errc = 0;
			i = INSTcreate_entity(entity, yypvt[-1].list, true);
			i->symbol.line = yylineno;
			p21_yyval.instance = i;	/* eh? */
			if (errc) ERRORreport_with_line(errc,yylineno,yypvt[-3].string);
		    } } break;
case 31:
# line 275 "p21yacc.y"
{ Entity entity;
		    if (0 == (entity = (Entity)DICTlookup(entity_dict,yypvt[-3].string))) {
			ERRORreport_with_line(ERROR_unknown_entity,yylineno,yypvt[-3].string);
			p21_yyval.instance = 0;
		    } else {
			Instance i;
			errc = 0;
			i = INSTcreate_entity(entity, yypvt[-1].list, false);
			i->symbol.line = yylineno;
			p21_yyval.instance = i;	/* eh? */
			if (errc) ERRORreport_with_line(errc,yylineno,yypvt[-3].string);
		    } } break;
case 32:
# line 288 "p21yacc.y"
{ Instance i = INSTcreate(Type_User_Defined);
		    i->user_data = (Generic)yypvt[-1].list;
		    p21_yyval.instance = i;
	          } break;
case 33:
# line 295 "p21yacc.y"
{ p21_yyval.list = LISTcreate(); } break;
case 34:
# line 297 "p21yacc.y"
{ p21_yyval.list = LISTcreate();
		    LISTadd_last(p21_yyval.list, (Generic)yypvt[-0].instance); } break;
case 35:
# line 300 "p21yacc.y"
{ p21_yyval.list = yypvt[-2].list;
		    LISTadd_last(p21_yyval.list, (Generic)yypvt[-0].instance); } break;
case 36:
# line 305 "p21yacc.y"
{ p21_yyval.instance = INSTANCE_NULL; } break;
case 37:
# line 307 "p21yacc.y"
{ p21_yyval.instance = INSTANCE_REDEFINE; } break;
case 38:
# line 309 "p21yacc.y"
{ Instance i = INSTcreate(Type_Integer); p21_yyval.instance = i;
		    i->u.integer = yypvt[-0].iVal;
		    i->symbol.line = yylineno; } break;
case 39:
# line 313 "p21yacc.y"
{ Instance i = INSTcreate(Type_Real); p21_yyval.instance = i;
		    i->u.real = yypvt[-0].rVal;
		    i->symbol.line = yylineno; } break;
case 40:
# line 317 "p21yacc.y"
{ Instance i = INSTcreate(Type_Logical); p21_yyval.instance = i;
		    i->u.logical = yypvt[-0].lVal;
		    i->symbol.line = yylineno; } break;
case 41:
# line 321 "p21yacc.y"
{ p21_yyval.instance = create_enum(yypvt[-0].string); } break;
case 42:
# line 323 "p21yacc.y"
{ Instance i = INSTcreate(Type_String); p21_yyval.instance = i;
		    i->u.string = yypvt[-0].string;
		    i->symbol.line = yylineno; } break;
case 43:
# line 327 "p21yacc.y"
{ Instance i = INSTcreate(Type_Binary); p21_yyval.instance = i;
		    i->u.binary = yypvt[-0].string;
		    i->symbol.line = yylineno; } break;
case 44:
# line 331 "p21yacc.y"
{ p21_yyval.instance = yypvt[-0].instance; } break;
case 45:
# line 333 "p21yacc.y"
{ p21_yyval.instance = yypvt[-0].entref.i; } break;
case 46:
# line 335 "p21yacc.y"
{ p21_yyval.instance = yypvt[-0].instance;
		    /*int pos = 0;
		    $$ = INSTcreate(TYPE_AGGREGATE, &errc);
		    if (errc) ERRORreport_with_line(errc,yylineno,"INSTcreate");
		    INSTput_line_number($$, yylineno);
		    LISTdo($1, obj, Object)
			INSTaggr_at_put($$, ++pos, obj, &errc);
			if (errc != ERROR_none)
				ERRORreport_with_line(errc,
						      (obj != INSTANCE_NULL)
							? INSTget_line_number(obj)
							: yylineno,
						      pos);
		    LISTod;*/ } break;
case 49:
# line 356 "p21yacc.y"
{ DICTdefine(PREVIOUS_SCOPE,	yypvt[-0].entref.sym->name,(Generic)yypvt[-0].entref.i,
						yypvt[-0].entref.sym,OBJ_INSTANCE); } break;
case 50:
# line 359 "p21yacc.y"
{ DICTdefine(PREVIOUS_SCOPE,	yypvt[-0].entref.sym->name,(Generic)yypvt[-0].entref.i,
						yypvt[-0].entref.sym,OBJ_INSTANCE); } break;
case 51:
# line 364 "p21yacc.y"
{ STACKpush(listCounters, (Generic)1); } break;
case 52:
# line 366 "p21yacc.y"
{ (void)STACKpop(listCounters);
		    p21_yyval.instance = yypvt[-1].instance; } break;
case 53:
# line 369 "p21yacc.y"
{ p21_yyval.instance = INSTcreate(Type_Aggregate); } break;
case 54:
# line 373 "p21yacc.y"
{ p21_yyval.instance = INSTcreate(Type_Aggregate);
		    if (errc) ERRORreport_with_line(errc,yylineno,"INSTcreate");
		    INSTaggr_at_put(p21_yyval.instance, 1, yypvt[-0].instance); } break;
case 55:
# line 377 "p21yacc.y"
{ int pos;
		    pos = (int)STACKpop(listCounters);
		    STACKpush(listCounters, (Generic)++pos);
		    p21_yyval.instance = yypvt[-2].instance;
		    INSTaggr_at_put(p21_yyval.instance, pos, yypvt[-0].instance);
		    if (errc) ERRORreport_with_line(errc,yylineno,"INSTaggr_at_put"); } break;
case 56:
# line 386 "p21yacc.y"
{ p21_yyval.instance = yypvt[-0].instance; } break;
	}
	goto yystack;		/* reset registers in driver code */
}

# ifdef __RUNTIME_YYMAXDEPTH

static int allocate_stacks() {
	/* allocate the yys and p21_yyv stacks */
	yys = (int *) malloc(yymaxdepth * sizeof(int));
	p21_yyv = (p21_YYSTYPE *) malloc(yymaxdepth * sizeof(p21_YYSTYPE));

	if (yys==0 || p21_yyv==0) {
	   yyerror( (nl_msg(30004,"unable to allocate space for yacc stacks")) );
	   return(1);
	   }
	else return(0);

}


static void free_stacks() {
	if (yys!=0) free((char *) yys);
	if (p21_yyv!=0) free((char *) p21_yyv);
}

# endif  /* defined(__RUNTIME_YYMAXDEPTH) */

