/* Stub file for windows I/O routines.  Used to link windows object files
 * in DOS (no windows) environment.  This is sometimes useful for debugging.
 */
#include <stdio.h>
#include <math.h>
#include <stdarg.h>

int    NoEcho=0;        /* Flag indicating not to print to stdio win */

int windows_printf(char *format, ...)
{
    int n;
    va_list ap;

    // Start the variable argument list processing
    va_start(ap, format);

    n = vprintf(format, ap);

    // End the variable argument list processing
    va_end(format);
    return n;
}

int windows_fprintf(FILE *fp, char *format, ...)
{
    int n;
    va_list ap;

    // Start the variable argument list processing
    va_start(ap, format);

    n = vfprintf(fp, format, ap);

    // End the variable argument list processing
    va_end(format);

    return n;
}

int windows_fflush(FILE *fp)
{
    return fflush(fp);
}


int windows_putchar(int c)
{
    return putchar(c);
}


int windows_putc(int c, FILE *fp)
{
    return putc(c, fp);
}

void windows_exit(int status)
{
    // exit(status);
}

void WstdioOutput(FILE *fp)
{
}

void LiXYLocation( int *x, int *y )
{
}

int set_draw_mode ( int draw_flag )
{
   return 0;
}

