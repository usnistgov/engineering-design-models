//=============================================================================//
//                                                                             //
//                                STEP_ACIS.cpp                                //
//                                                                             //
//          =========================================================          //
//         |                IRIM Development Team                    |         //
//         |          Allied-Signal, Kansas City Division            |         //
//          =========================================================          //
//                                                                             //
//                       C++ program to read a STEP file and                   //
//                         generate an ACIS body from it.                      //
//                                                                             //
//                                                                             //
//          Notice:                                                            //
//          The originally developed software has been modified using          //
//          U.S. Department of Energy funding and is not subject               //
//          to copyright.                                                      //
//                                                                             //
//                                                                             //
//          The modifications were made at the U.S. Department of              //
//          Energy's Kansas City Plant (managed and operated by                //
//          AlliedSignal Inc.), January 1995.                                  //
//                                                                             //
//=============================================================================//

#ifdef NT
//
// A KLUDGE!  POINT is defined in windows and in ACIS.  To fix this,
// we define POINT to be WINDOWS_POINT just during inclusion of the
// windows system include files.
//
#define POINT WINDOWS_POINT
#include <afxwin.h>			// MFC core and standard components
#include <afxext.h> 		// MFC extensions
#include <iostream.h>
#include <strstrea.h>

#include <math.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#include <instmgr.h>
#include <Registry.h>
#include <STEPfile.h>

#include <SdCNFGCN.h> 
#include <needFunc.h>

#include <SEarritr.h>

#undef POINT
#endif

int acismain (int argc,char *argv[]);
int main (int argc,char *argv[])
{
  return acismain (argc,argv);
}

extern void SchemaInit (Registry &);

#include "HSHtable.h"
#include "acis.hxx"

#include "kernapi/api/api.hxx"
#include "kernapi/api/routines.hxx"

#include "kernapi/api/misc.hxx"
#include "kerndata/data/debug.hxx"
#include "kerndata/data/entity.hxx"

#include "kerndata/top/alltop.hxx"
#include "kerndata/geom/point.hxx"
#include "kerndata/geom/allcurve.hxx"
#include "kerndata/geom/allsurf.hxx"
#include "kerndata/geom/transfrm.hxx"

#include "kernutil/vector/vector.hxx"
#include "kernutil/vector/position.hxx"
#include "kernutil/vector/unitvec.hxx"
#include "kernutil/vector/transf.hxx"
#include "kernutil/vector/param.hxx"
#include "kernutil/option/option.hxx"

#include "kernutil/poly/poly.hxx"
#include "kerngeom/curve/alldef.hxx"
#include "kerngeom/curve/intdef.hxx"
#include "kerngeom/curve/strdef.hxx"
#include "kerngeom/surface/alldef.hxx"
#include "kerngeom/surface/spldef.hxx"
#include "kerngeom/surface/tordef.hxx"
#include "geomhusk/acistype.hxx"
#include "geomhusk/routines.hxx"
#include "geomhusk/geom_utl.hxx"

#include "sg_husk/vis/x_surf.hxx"
#include "sg_husk/vis/trim.hxx"
#include "sg_husk/api/routines.hxx"

#include "spline/sg_bs3s/routines.hxx"
#include "spline/sg_bs2c/routines.hxx"
#include "spline/sg_bs3c/routines.hxx"


#include "spline/bs2_crv/crv_def.hxx"
#include "spline/bs2_crv/routines.hxx"
#include "spline/bs2_crv/curve.hxx"
#include "spline/bs2_crv/crv_def.hxx"  
#include "spline/bs2_crv/routines.hxx" 
#include "spline/bs2_crv/curve.hxx"    
#include "spline/bs3_crv/crv_def.hxx"  
#include "spline/bs3_crv/bs_2_3.hxx"   
#include "spline/bs3_crv/routines.hxx" 
#include "spline/bs3_crv/curve.hxx"    
#include "spline/bs3_srf/surface.hxx"  
#include "spline/bs3_srf/routines.hxx"

#include "geomhusk/acistol.hxx"

#include "kernint/intsfsf/intsfsf.hxx"

#include "attstpid.h"

#define PRINT_LEVEL_EDGE

int DEBUG = 0;
int PRINT = 0;
int CHECK = 0;
int MERGE_FACES = 0;
int ANGLE_RADIANS = 1;  // angles in step file are in radians

Registry *registry;
InstMgr   instance_list;
STEPfile *sfile;

#ifndef MAX
#define MAX(X,Y)     ((X)>(Y) ? (X) : (Y))
#define MIN(X,Y)     ((X)>(Y) ? (Y) : (X))
#endif


#define  STEPattributeID(ent,id) \
    if (find_leaf_attrib (ent, ATTRIB_STEP_ID_KCP_TYPE) == NULL) \
      new ATTRIB_STEP_ID_KCP (ent, id);

int getSTEPattributeID(ENTITY *ent)
{  
   ATTRIB_STEP_ID_KCP *att = (ATTRIB_STEP_ID_KCP *) find_leaf_attrib (ent, ATTRIB_STEP_ID_KCP_TYPE);
   if (att) return att->step_id();
   else return 0;
}

#define PntCoords(point,X,Y,Z) \
   RealNode *next = (RealNode *)point->Coordinates()->GetHead(); \
   double X = next->value; \
   next = (RealNode *)next->NextNode(); \
   double Y = 0; \
   if (next) { \
      Y = next->value; \
      next = (RealNode *)next->NextNode(); \
   } \
   double Z = 0; \
   if (next) Z = next->value; \

#define DirRatios(direction,DX, DY, DZ) \
   RealNode *nextd = (RealNode *)direction->Direction_ratios()->GetHead(); \
   double DX = nextd->value; \
   nextd = (RealNode *)nextd->NextNode(); \
   double DY = 0; \
   if (nextd) { \
      DY = nextd->value; \
      nextd = (RealNode *)nextd->NextNode(); \
   } \
   double DZ = 0; \
   if (nextd) DZ = nextd->value; \


void check(outcome result);
int main (int argc,char *argv[]);
void print_acis_body (BODY* body);
BODY    *create_acis_body_from_brep (SdaiManifold_solid_brep *brep);
SHELL   *create_acis_shell   (HASHtable *hashtable,SdaiClosed_shell *shell);
FACE    *create_acis_face    (HASHtable *hashtable,SdaiFace_surface *face, int flag);
LOOP    *create_acis_vertex_loop (HASHtable *hashtable, SdaiVertex_loop *vertex_loop);
LOOP    *create_acis_edge_loop   (HASHtable *hashtable,SdaiEdge_loop *loop, int flag);
EDGE    *create_acis_edge    (HASHtable *hashtable,SdaiEdge_curve *edge);
VERTEX  *create_acis_vertex  (HASHtable *hashtable,SdaiVertex_point *vertex);
CURVE   *create_acis_curve   (HASHtable *hashtable,SdaiCurve *curve);
SURFACE *create_acis_surface (HASHtable *hashtable,SdaiSurface *surface);
void fill_in_intersection_curves (BODY* body);
void print_step_body (SdaiManifold_solid_brep *brep);
void print_step_edge (SdaiEdge_curve *edge);
void insert_intersection_curves (InstMgr &instance_list);
void fixDrillPoints (InstMgr &instance_list);
void print_acis_curve (CURVE *curve);
void print_acis_surface (SURFACE *surface);
void print_acis_edge (EDGE *edge);
void print_acis_vertex (VERTEX *vertex);
void print_acis_face (FACE *face);

void check(outcome result)
{ if (!result.ok())
   {printf("*** ERROR number %d from ACIS:\n",result.error_number());
   }
}

position v2p(const vector &vec) 
{
   position pos (vec.x(), vec.y(), vec.z());
   return pos;
}

vector p2v(const position &pos) 
{
   vector vec (pos.x(), pos.y(), pos.z());
   return vec;
}

double distance_plane_to_point (position p1, vector dir1, position p2)
/*==================================================================*/
/*  Calculate the shortest distance from a planar face that passes  */
/*  an arbitrary point p1 with normal direction dir1 to the point   */
/*  at coordinates p2.                                              */
/*==================================================================*/
{ 
   return ((dir1 % (p2 - p1)) / dir1.len() );
}

double distance_line_to_point (position p1, vector dir1, position p2)
/*==================================================================*/
/*  Calculate the shortest distance from a straight line passing    */
/*  through point p1 with direction dir1 to another point at p2.    */
/*==================================================================*/
{ 
   position pos = v2p(p2 - p1);
   double t = normalise (dir1) % pos;
   vector vec (pos.x(), pos.y(), pos.z());
   double r = vec.len();
   return sqrt (r*r - t*t);
}

 
int point_lies_on_plane (position p2,position p1,vector dir1)
/*==================================================================*/
/*  See if P2 lies on plane defined by point P1 and direction DIR1. */
/*==================================================================*/
{ 
   if (is_zero (distance_plane_to_point (p1,dir1,p2))) return 1;
   else return 0;
}


 
int point_lies_on_line (position p2, position p1, vector dir1)
/*==================================================================*/
/*  See if P2 lies on line defined by point P1 and direction DIR1.  */
/*==================================================================*/
{ 
   if (is_zero (distance_line_to_point (p1,dir1,p2))) return 1;
   else return 0;
}

double my_fmod (double a,double b)
//-------------------------------------------------------------------------
//  Floating point modulus function
//-------------------------------------------------------------------------
{ return (a - b*floor(a/b));}

double arctan(double x,double y)
//-------------------------------------------------------------------------
//  Computes the arctangent of x/y and checks for the following    
//  conditions:                                                    
//   if  x==0 && y==0  return 0.0                                  
//   if  x!=0 && y==0  return Pi/2 or -Pi/2,  depends on sign of x 
//   otherwise return atan2(x,y) in range from 0 to 2*Pi           */
//-------------------------------------------------------------------------
{
  double Pi2  = 6.283185307179586;
  double PiD2 = 1.570796326794897;
  if (y == 0.0) 
   {if (x == 0.0) return (0.0);
    else return( x>0  ? PiD2 : 3*PiD2 );
   }
  else return ( my_fmod( Pi2+atan2(x,y) , Pi2) );
}


transf zaxis_to_vector_transf (vector vec)
//-------------------------------------------------------------------------
//  Create a transformation to bring the z axis to direction vector vec.
//-------------------------------------------------------------------------
{
   double zangle = arctan(vec.y(), vec.x());
   double yangle = arctan(sqrt(vec.x()*vec.x() + vec.y()*vec.y()), vec.z());
   return rotate_transf(-zangle, vector(0.0, 0.0, 1.0)) *
          rotate_transf(-yangle, vector(0.0, 1.0, 0.0));
}

transf vector_to_xaxis_transf (vector vec)
//-------------------------------------------------------------------------
//  Create a transformation to bring the direction vector vec to x axis.
//-------------------------------------------------------------------------
{
   double zangle = arctan(vec.y(), vec.x());
   transf t1 = rotate_transf(-zangle, vector(0.0, 0.0, 1.0));
   vector u = vec * t1;
   double yangle = arctan(u.x(), u.z());
   transf t2 = rotate_transf(yangle, vector(0.0, 1.0, 0.0));

   return t2 * t1;
}

vector xaxis_from_zaxis (vector z_axis, vector *arg)
{
   vector x_axis = vector (1.0, 0.0, 0.0);
   vector v;
   z_axis = normalise(z_axis);
    
   if (arg == NULL) {
      if (.999 > fabs(z_axis % vector (1.0, 0.0, 0.0)))
         v = vector (1.0, 0.0, 0.0);
      else 
         v = vector (0.0, 1.0, 0.0);
   }
   else
      v = *arg;
    
   x_axis = (v % z_axis) * z_axis;
   x_axis = v - x_axis;
   x_axis = normalise(x_axis);
   return x_axis;
}

double seconds()
/*=================================================================*/
/*  Return the time in seconds since something or other.           */
/*=================================================================*/
{ return ((double) clock()) / CLOCKS_PER_SEC;}

int acismain (int argc,char *argv[])
{
   int i;
   char acis_file[100], step_file[100];
   double sec0, sec1;
   SdaiManifold_solid_brep *new_brep;
   FILE *FOUT;

//---Set ACIS resolution---
   resabs = 1e-8;
   resnor = 1e-10;
   resfit = 1e-6;
   resmch = 1e-14;

   printf("\n");
   printf("   ========================================================= \n");
   printf("  |                     STEP_ACIS                           |\n");
   printf("  |                IRIM Development Team                    |\n");
   printf("  |          Allied-Signal, Kansas City Division            |\n");
   printf("   ========================================================= \n");

//--Read command line arguments
   step_file[0] = 0;
   acis_file[0] = 0;
   for (i=1; i<argc; i++)
   {
            if (_stricmp(argv[i],"-DEBUG")==0) DEBUG = 1;
       else if (_stricmp(argv[i],"-PRINT")==0) PRINT = 1;
       else if (_stricmp(argv[i],"-CHECK")==0) CHECK = 1;
       else if (_stricmp(argv[i],"-RADIANS")==0) ANGLE_RADIANS = 1;
       else if (_stricmp(argv[i],"-DEGREES")==0) ANGLE_RADIANS = 0;
       else if (_stricmp(argv[i],"-MERGE")==0) MERGE_FACES = 1;
       else if (!step_file[0]) strcpy(step_file, argv[i]);
       else if (!acis_file[0]) strcpy(acis_file, argv[i]);
       else
      {
         printf("***ERROR*** '%s' is an invalid command line argument\n",argv[i]);
         exit(1);
      }
   }
   if (!step_file[0])
   {
      printf("\nUsage:  step_acis stepfile acisfile [-DEBUG] [-PRINT] [-CHECK]\n");
      printf("  stepfile = Name of STEP input file\n");
      printf("  acisfile = Name of ACIS part file\n");
      exit(0);
   }

//--Start ACIS modeler
   printf(" Starting ACIS ...\n");
   check (api_start_modeller (FALSE, NULL, 0));

   registry = new Registry(SchemaInit);
   sfile = new STEPfile(*registry, instance_list);

//--Import Brep from STEP file
   sfile->ReadExchangeFile (step_file);

   sec0 = seconds();
   HASHtable *hashtable = new HASHtable(997);

//--Insert Intersection curves for B-Spline curves that aren't already intersection curves.
   insert_intersection_curves (instance_list);

   fixDrillPoints (instance_list);

//--See if a SdaiManifold_solid_brep is in the hashtable
   new_brep = SdaiManifold_solid_brep::castdown(instance_list.GetSTEPentity ("Manifold_Solid_Brep"));
   if (!new_brep) 
      new_brep = SdaiManifold_solid_brep::castdown(instance_list.GetSTEPentity ("Brep_With_Voids"));
   delete hashtable;
   if (!new_brep)
   {
      printf(" ***ERROR*** No SdaiManifold_solid_brep in STEP import file\n");
      exit(1);
   }

//--Successfully imported BREP
   printf ("\n Imported BREP %ld from STEP file %s in %.3f seconds\n",
   new_brep->FileId(), step_file, seconds()-sec0);
   if (PRINT) print_step_body (new_brep);

//--Create a new Parasolid body from the brep--*/
   sec1 = seconds();
   BODY *new_body = create_acis_body_from_brep (new_brep);

   printf("\n Created new ACIS body from STEP data structures in %.3f seconds\n",seconds()-sec1);

   printf("\n Total time for importing ACIS body from STEP was %.3f seconds\n",seconds()-sec0);

   if (PRINT) {
      STEPattributeID (new_body, new_brep->FileId());
      print_acis_body (new_body);
   }

   if (MERGE_FACES)
      api_merge_faces (new_body, CONE_TYPE);


   if (DEBUG) debug_entity(new_body, stdout);

//--Check the body for errors
   if (CHECK)
   {
      ENTITY_LIST problem_ents;
      printf("\nChecking body for errors:\n");
      check(api_check_entity(new_body,&problem_ents));

      for (int i = 0; i < problem_ents.count(); i++) {
         if (is_FACE (problem_ents[i]))
            print_acis_face ((FACE *)problem_ents[i]);
         else if (is_EDGE(problem_ents[i]))
            print_acis_edge ((EDGE *)problem_ents[i]);
         else if (is_VERTEX(problem_ents[i]))
            print_acis_vertex ((VERTEX *)problem_ents[i]);
         else if (is_SURFACE (problem_ents[i]))
            print_acis_surface ((SURFACE *)problem_ents[i]);
         else if (is_CURVE (problem_ents[i]))
            print_acis_curve ((CURVE *)problem_ents[i]);
         else
            problem_ents[i]->debug_ent(stdout);
      }
      printf("\n");
   }

//--Write the body to a file--*/
   if (NULL != (FOUT = fopen(acis_file,"w")))
   {
      option_header *sequence_opt = find_option ( "seq" );
      if (sequence_opt != NULL)
         sequence_opt->set (TRUE);

      ENTITY_LIST bodies;
      bodies.add(new_body);
      printf("\n Saving body to file '%s' ...\n",acis_file);
      check (api_save_entity_list (FOUT, TRUE, bodies));
      fclose (FOUT);
   }
   else printf("*** Unable to open file '%s' for output\n",acis_file);

   return 0;
}

#define SENSE(x)((x == FORWARD) ? "Forward" : "Reversed")
void print_acis_body (BODY* body)
{
  for (LUMP* lump=body->lump(); lump; lump=lump->next())
   {printf(" body %d contains lump %d\n",getSTEPattributeID(body) ,getSTEPattributeID(lump) );

    for (SHELL* shell=lump->shell(); shell; shell=shell->next())
     {printf("  lump %d contains shell %d\n",getSTEPattributeID(lump) ,getSTEPattributeID(shell) );
    
      for (FACE* face=shell->face_list(); face; face=face->next_in_list())
       {printf("   shell %d contains face %d\n",getSTEPattributeID(shell) ,getSTEPattributeID(face) );
        printf("    face %d has sense = %s, surface %d of type '%s' (%d)\n",getSTEPattributeID(face),SENSE (face->sense()) ,getSTEPattributeID(face->geometry()),face->geometry()->type_name(),face->geometry()->equation().type());
    
        for (LOOP* loop=face->loop(); loop; loop=loop->next())
         {printf("    face %d contains loop %d\n",getSTEPattributeID(face) ,getSTEPattributeID(loop) );

          COEDGE* costart = loop->start();
          for (COEDGE* coedge=loop->start(); coedge; coedge=coedge->next())
           {
            EDGE* edge = coedge->edge();

            if (coedge == coedge->next() && !edge->geometry() &&
                edge->start() == edge->end()) 
             {printf("     loop %d is a vertex loop containing vertex %ld\n",getSTEPattributeID(loop),getSTEPattributeID(edge->start()));
             }
            else
             {printf("     loop %d contains coedge %ld \n",getSTEPattributeID(loop) ,getSTEPattributeID(coedge));
              printf("      coedge %d has sense = %s, contains edge %d\n",getSTEPattributeID(coedge), SENSE (coedge->sense()) ,getSTEPattributeID(edge) );
              if (edge->geometry()) printf("       edge %d has  sense = %s, curve %d of type '%s' (%d)\n",getSTEPattributeID(edge), SENSE (edge->sense()),
                 getSTEPattributeID(edge->geometry()),
                 edge->geometry()->type_name(),
                 edge->geometry()->equation().type());
              else printf("       edge %d has NO curve\n",getSTEPattributeID(edge));
#ifndef PRINT_LEVEL_EDGE
              printf("       edge %d contains vertex %ld\n",getSTEPattributeID(edge) ,getSTEPattributeID(edge->start()));
              printf("       edge %d contains vertex %ld\n",getSTEPattributeID(edge) ,getSTEPattributeID(edge->end()));
#endif
             } 
            if (costart == coedge->next()) break;
           } 
         }
       }
     }
   }
}

int partOf_intersectionCurve (SdaiB_spline_curve_with_knots *bscurve, InstMgr &instance_list)
{
   int instCount = instance_list.InstanceCount();

   for (int i = 0; i < instCount; i++) {
      MgrNode *mn = instance_list[i];
      STEPentity *se = mn->GetSTEPentity();
      if (se->isSpecies("Intersection_Curve")) {
         SdaiIntersection_curve *icurve =  SdaiIntersection_curve::castdown(se);

         if (icurve->Curve_3d()->FileId() == bscurve->FileId()) return TRUE;
      }
   }
   return FALSE;
}

SdaiEdge_curve *edgeCurveOfCurve  (SdaiCurve *curve, InstMgr &instance_list)
{
   int instCount = instance_list.InstanceCount();

   for (int i = 0; i < instCount; i++) {
      MgrNode *mn = instance_list[i];
      STEPentity *se = mn->GetSTEPentity();
      if (se->isSpecies("Edge_Curve")) {

         SdaiEdge_curve *edcurve = SdaiEdge_curve::castdown(se);

         if (edcurve->Edge_geometry()->FileId() == curve->FileId()) return edcurve;

         else if (edcurve->Edge_geometry()->isSpecies("Surface_Curve"))
         {
            SdaiSurface_curve *surfacecurve = SdaiSurface_curve::castdown(edcurve->Edge_geometry());
            if(surfacecurve->Curve_3d()->FileId()== curve->FileId()) return edcurve;
         }
      }
   }
   return NULL;
}

SdaiFace_surface *faceSurfaceOfSurface  (SdaiSurface *surface, InstMgr &instance_list)
{
   int instCount = instance_list.InstanceCount();

   for (int i = 0; i < instCount; i++) {
      MgrNode *mn = instance_list[i];
      STEPentity *se = mn->GetSTEPentity();
      if (se->isSpecies("Face_Surface")) {

         SdaiFace_surface *face = SdaiFace_surface::castdown(se);

         if (face->Face_geometry()->FileId() == surface->FileId()) return face;
      }
   }
   return NULL;
}

int strangeConicalSurfaceLoop (SdaiLoop *loop)
{
   if (loop->isSpecies ("Edge_Loop")) {
      SdaiEdge_loop *edge_loop = SdaiEdge_loop::castdown(loop);

      if (edge_loop->Edge_list()->EntryCount() == 3) {

         EntityNode *next = (EntityNode *)edge_loop->Edge_list()->GetHead();
         SdaiOriented_edge *oedge1 = SdaiOriented_edge::castdown(next->node);
         SdaiEdge *edge1 = oedge1->Edge_element();
         next = (EntityNode *)(next->NextNode());
         SdaiOriented_edge *oedge2 = SdaiOriented_edge::castdown(next->node);
         SdaiEdge *edge2 = oedge2->Edge_element();
         SdaiOriented_edge *oedge3 = SdaiOriented_edge::castdown(next->node);
         SdaiEdge *edge3 = oedge3->Edge_element();
         if (edge1->FileId() == edge2->FileId()) return TRUE;
         if (edge1->FileId() == edge3->FileId()) return TRUE;
         if (edge2->FileId() == edge3->FileId()) return TRUE;
      }
   }
   return FALSE;
}

SdaiOriented_edge *NonStraightEdgeCurveFromFaceLoop (SdaiLoop *loop)
{
   if (loop->isSpecies ("Edge_Loop")) {
      SdaiEdge_loop *edge_loop = SdaiEdge_loop::castdown(loop);

      EntityNode *nnext = (EntityNode *)edge_loop->Edge_list()->GetHead();
      while (nnext) 
      {
         SdaiOriented_edge *oedge = SdaiOriented_edge::castdown(nnext->node);
         SdaiEdge_curve *edge = SdaiEdge_curve::castdown(oedge->Edge_element());
         SdaiCurve *curve = edge->Edge_geometry();
         if (!curve->isSpecies("Line")) {
            return oedge;
         }
         nnext = (EntityNode *)(nnext->NextNode());
      }
   }
   return NULL;
}

SdaiOriented_edge *StraightEdgeCurveFromFaceLoop (SdaiLoop *loop)
{
   if (loop->isSpecies ("Edge_Loop")) {
      SdaiEdge_loop *edge_loop = SdaiEdge_loop::castdown(loop);

      EntityNode *nnext = (EntityNode *)edge_loop->Edge_list()->GetHead();
      while (nnext) 
      {
         SdaiOriented_edge *oedge = SdaiOriented_edge::castdown(nnext->node);
         SdaiEdge_curve *edge = SdaiEdge_curve::castdown(oedge->Edge_element());
         SdaiCurve *curve = edge->Edge_geometry();
         if (curve->isSpecies("Line")) {
            return oedge;
         }
         nnext = (EntityNode *)(nnext->NextNode());
      }
   }
   return NULL;
}

void fixDrillPoints (InstMgr &instance_list)
{
   int instCount = instance_list.InstanceCount();

   for (int i = 0; i < instCount; i++) {
      MgrNode *mn = instance_list[i];
      STEPentity *se = mn->GetSTEPentity();
      if (se->isSpecies("Conical_Surface")) {
         SdaiConical_surface *surface = SdaiConical_surface::castdown(se);

         SdaiFace_surface *faceSurface = faceSurfaceOfSurface (surface, instance_list);

         if (faceSurface) {
            if (faceSurface->Bounds()->EntryCount() == 1) {
               EntityNode *next = (EntityNode *)faceSurface->Bounds()->GetHead();
               if (next) {
                  SdaiFace_bound *boundary = SdaiFace_bound::castdown(next->node);

                  SdaiLoop *loop = boundary->Bound();
                  if (strangeConicalSurfaceLoop(loop)) {
                     SdaiOriented_edge *oedge = NonStraightEdgeCurveFromFaceLoop (loop);
                     SdaiOriented_edge *soedge = StraightEdgeCurveFromFaceLoop (loop);
                     if (oedge && soedge) {
                        SdaiEdge_loop *edge_loop = SdaiEdge_loop::castdown(loop);

                        edge_loop->Edge_list()->Empty();

                        vector axis;
                        {
                           SdaiConical_surface *cone = SdaiConical_surface::castdown(surface);
                           SdaiDirection *dir = cone->Position()->Axis();
                           DirRatios (dir, dx, dy, dz);

                           axis = vector(dx, dy, dz);
                        }
                        {
                           SdaiEdge_curve *edge = SdaiEdge_curve::castdown(oedge->Edge_element());
                           SdaiCurve *curve = edge->Edge_geometry();
                           if (curve->isKindOf("Conic")) {
                              SdaiConic *conic = SdaiConic::castdown(curve);
                              if (conic->Position()->IsAxis2_placement_3d() == sdaiTRUE)
                              {
                                 SdaiAxis2_placement_3d *place = SdaiAxis2_placement_3d::castdown((conic->Position())->SdaiAxis2_placement::operator SdaiAxis2_placement_3dH());
                                 SdaiDirection *dir = place->Axis();
                                 DirRatios (dir, dx, dy, dz);

                                 vector edgeAxis (dx, dy, dz);

                                 if ((edgeAxis % axis) < 0) {
                                    if (edge->Same_sense() == sdaiTRUE)
                                       oedge->Orientation (sdaiFALSE);
                                    else
                                       oedge->Orientation (sdaiTRUE);
                                 }
                                 else {
                                    if (edge->Same_sense() == sdaiTRUE)
                                       oedge->Orientation (sdaiTRUE);
                                    else
                                       oedge->Orientation (sdaiFALSE);
                                 }
                              }
                           }
                        }
                        edge_loop->Edge_list()->AddNode(new EntityNode (oedge));

                        SdaiEdge *edge = soedge->Edge_element();
                        SdaiVertex_point *start = SdaiVertex_point::castdown(edge->Edge_start());
                        SdaiVertex_point *end = SdaiVertex_point::castdown(edge->Edge_end());

                        position p1,origin;
                        {
                           SdaiCartesian_point *startpnt = SdaiCartesian_point::castdown(start->Vertex_geometry());
                           PntCoords(startpnt,x1,y1,z1)
                           p1 = position (x1, y1, z1);
                        }

                        {
                           SdaiVertex_point *vorigin = SdaiVertex_point::castdown(oedge->Edge_element()->Edge_start());
                           SdaiCartesian_point *voriginpnt = SdaiCartesian_point::castdown(vorigin->Vertex_geometry());
                           PntCoords(voriginpnt,x3,y3,z3)
                           origin = position (x3, y3, z3);
                        }

                        
                        if (point_lies_on_plane (p1,origin,axis)) {
                           // end point is the vertex loop;
                           SdaiVertex_loop *vertex_loop  = SdaiVertex_loop::castdown(registry->ObjCreate("Vertex_loop"));
                           instance_list.Append (STEPentity::castdown(vertex_loop), completeSE);
                           vertex_loop->Loop_vertex (end);

                           SdaiFace_bound *facebnd  = SdaiFace_bound::castdown(registry->ObjCreate("Face_bound"));
                           instance_list.Append (STEPentity::castdown(facebnd), completeSE);

                           facebnd->Bound(vertex_loop);
                           facebnd->Orientation (sdaiTRUE);

                           faceSurface->Bounds()->AddNode(new EntityNode (facebnd));
                        }
                        else {
                           // start point is the vertex loop;
                           SdaiVertex_loop *vertex_loop  = SdaiVertex_loop::castdown(registry->ObjCreate("Vertex_loop"));
                           instance_list.Append (STEPentity::castdown(vertex_loop), completeSE);
                           vertex_loop->Loop_vertex (start);

                           SdaiFace_bound *facebnd  = SdaiFace_bound::castdown(registry->ObjCreate("Face_bound"));
                           instance_list.Append (STEPentity::castdown(facebnd), completeSE);

                           facebnd->Bound(vertex_loop);
                           facebnd->Orientation (sdaiTRUE);

                           faceSurface->Bounds()->AddNode(new EntityNode (facebnd));
                        }
                     }
                  }
               }
            }
         }
      }
   }
}

int angleSIunitExist  (InstMgr &instance_list)
{
   int instCount = instance_list.InstanceCount();

   for (int i = 0; i < instCount; i++) {
      MgrNode *mn = instance_list[i];
      STEPentity *se = mn->GetSTEPentity();
      if (se->isSpecies("Si_Unit")) {

         SdaiSi_unit *unit = SdaiSi_unit::castdown(se);

         if (unit->Name().asInt() == si_unit_name_RADIAN) return TRUE;
      }
   }
   return FALSE;
}

int edgeCurveInFaceLoop (SdaiEdge_curve *edcurve, SdaiFace_surface *face)
{
   EntityNode *next = (EntityNode *)face->Bounds()->GetHead();
   while (next) 
   {
      SdaiFace_bound *boundary = SdaiFace_bound::castdown(next->node);
      SdaiLoop *loop = boundary->Bound();

      if (loop->isSpecies ("Edge_Loop")) {
         SdaiEdge_loop *edge_loop = SdaiEdge_loop::castdown(loop);

         EntityNode *nnext = (EntityNode *)edge_loop->Edge_list()->GetHead();
         while (nnext) 
         {
            SdaiOriented_edge *oedge = SdaiOriented_edge::castdown(nnext->node);
            SdaiEdge *edge = oedge->Edge_element();
            if (edcurve->FileId() == edge->FileId()) return TRUE;
            nnext = (EntityNode *)(nnext->NextNode());
         }
      }
      next = (EntityNode *)(next->NextNode());
   }
   return FALSE;
}

void facePairsOfEdgeCurve (SdaiEdge_curve *edcurve, SdaiFace_surface *&face1, SdaiFace_surface *&face2, InstMgr &instance_list)
{
   face1 = face2 = NULL;

   int instCount = instance_list.InstanceCount();

   for (int i = 0; i < instCount; i++) {
      MgrNode *mn = instance_list[i];
      STEPentity *se = mn->GetSTEPentity();
      if (se->isSpecies("Face_Surface")) {
         SdaiFace_surface *face = SdaiFace_surface::castdown(se);
         if (edgeCurveInFaceLoop (edcurve, face)) {
            if (face1 == NULL) face1 = face;
            else {
               face2 = face;
               return;
            }
         }
      }
   }
}


void addIntersectionCurve (SdaiB_spline_curve_with_knots *bscurve, InstMgr &instance_list)
{
   
   SdaiEdge_curve *edcurve = edgeCurveOfCurve(bscurve, instance_list);
   if (edcurve) {

      SdaiFace_surface *face1, *face2;

      facePairsOfEdgeCurve (edcurve, face1, face2, instance_list);
      
      if (face1 && face2) { 

         SdaiIntersection_curve *curveobject  = SdaiIntersection_curve::castdown(registry->ObjCreate("Intersection_curve"));
         instance_list.Append (STEPentity::castdown(curveobject), completeSE);

         SdaiPcurve_or_surfaces *pc_or_srfs = new SdaiPcurve_or_surfaces;
         SdaiPcurve_or_surface *pc_or_srf  = new SdaiPcurve_or_surface (face1->Face_geometry());
         pc_or_srfs->AddNode(new SelectNode ( pc_or_srf ));
         pc_or_srf  = new SdaiPcurve_or_surface (face2->Face_geometry());
         pc_or_srfs->AddNode(new SelectNode ( pc_or_srf ));

         curveobject->Associated_geometry (pc_or_srfs);
         curveobject->Master_representation (preferred_surface_curve_representation_CURVE_3D);

         printf ("Inserting Intersection Curve %d for Edge Curve %d, Face 1 = %d, Face 2 = %d\n",
          curveobject->FileId(), edcurve->FileId(), face1->FileId(), face2->FileId());
         curveobject->Curve_3d(bscurve);
         edcurve->Edge_geometry(curveobject);
         // print_step_edge (edcurve);
      }
   }
}


void insert_intersection_curves (InstMgr &instance_list)
{
   int instCount = instance_list.InstanceCount();

   for (int i = 0; i < instCount; i++) {
      MgrNode *mn = instance_list[i];
      STEPentity *se = mn->GetSTEPentity();
      if (se->isSpecies("B_Spline_Curve_With_Knots")) {
         SdaiB_spline_curve_with_knots *bscurve = SdaiB_spline_curve_with_knots::castdown(se);

         if (partOf_intersectionCurve (bscurve, instance_list)) continue;
         else  addIntersectionCurve (bscurve, instance_list);
      }
   }
}

void print_step_bs3_curve (SdaiB_spline_curve_with_knots *bscurve)
{
   SCLstring buf;
   bscurve->STEPwrite(buf);
   printf ("%s\n",(const char *)buf);

   EntityNode *next = (EntityNode *)bscurve->Control_points_list()->GetHead();
   for (int i = 0; next; next = (EntityNode *)(next->NextNode()), i++) 
   {
      SdaiCartesian_point *pnt = SdaiCartesian_point::castdown(next->node);
      SCLstring buf;
      pnt->STEPwrite(buf);
      printf ("%s\n",(const char *)buf);
   }
}

void print_step_curve (SdaiCurve *curve)
{

   SdaiCartesian_point *pnt;
   SdaiDirection       *dir;
   SdaiDirection       *ref;
   if (curve->isSpecies("Surface_Curve"))
   {
      SdaiSurface_curve *scurve = SdaiSurface_curve::castdown(curve);
      SCLstring buf;
      scurve->STEPwrite(buf);
      printf ("%s\n",(const char *)buf);
      print_step_curve  (scurve->Curve_3d());
   }
   else if (curve->isSpecies("Line"))
   {
      SdaiLine *line = SdaiLine::castdown(curve);
      SCLstring buf;
      line->STEPwrite(buf);
      printf ("%s\n",(const char *)buf);
      pnt = line->Pnt();
      dir = line->Dir()->Orientation();
      if (pnt && dir) 
      {
         SCLstring buf;
         pnt->STEPwrite(buf);
         printf ("%s\n",(const char *)buf);
         SCLstring buf1;
         dir->STEPwrite(buf1);
         printf ("%s\n",(const char *)buf1);
      }
   }
   else if (curve->isSpecies("Circle"))
   {
      SdaiCircle *circle = SdaiCircle::castdown(curve);
      SCLstring buf;
      circle->STEPwrite(buf);
      printf ("%s\n",(const char *)buf);
      if (circle->Position()->IsAxis2_placement_3d() == sdaiTRUE)
      {
         SdaiAxis2_placement_3d *place = SdaiAxis2_placement_3d::castdown((circle->Position())->SdaiAxis2_placement::operator SdaiAxis2_placement_3dH());
         pnt = place->Location();
         dir = place->Axis();
         SCLstring buf;
         place->STEPwrite(buf);
         printf ("%s\n",(const char *)buf);
         SCLstring buf1;
         pnt->STEPwrite(buf1);
         printf ("%s\n",(const char *)buf1);
         SCLstring buf2;
         dir->STEPwrite(buf2);
         printf ("%s\n",(const char *)buf2);
      }
   }
   else if (curve->isSpecies("Ellipse"))
   {
      SdaiEllipse *ellipse = SdaiEllipse::castdown(curve);
      SCLstring buf;
      ellipse->STEPwrite(buf);
      printf ("%s\n",(const char *)buf);
      if (ellipse->Position()->IsAxis2_placement_3d() == sdaiTRUE)
      {
         SdaiAxis2_placement_3d *place = SdaiAxis2_placement_3d::castdown((ellipse->Position())->SdaiAxis2_placement::operator SdaiAxis2_placement_3dH());
         pnt = place->Location();
         dir = place->Axis();
         ref = place->Ref_direction();
         SCLstring buf;
         place->STEPwrite(buf);
         printf ("%s\n",(const char *)buf);
         SCLstring buf1;
         pnt->STEPwrite(buf1);
         printf ("%s\n",(const char *)buf1);
         SCLstring buf2;
         dir->STEPwrite(buf2);
         printf ("%s\n",(const char *)buf2);
         SCLstring buf3;
         ref->STEPwrite(buf3);
         printf ("%s\n",(const char *)buf3);
      }
   }
   else if (curve->isSpecies("B_Spline_Curve_With_Knots"))
   {
      SdaiB_spline_curve_with_knots *bscurve = SdaiB_spline_curve_with_knots::castdown(curve);

      print_step_bs3_curve(bscurve);
   }

   else if (curve->isSpecies("Intersection_Curve"))
   {

      SdaiIntersection_curve *icurve =  SdaiIntersection_curve::castdown(curve);
      SCLstring buf;
      icurve->STEPwrite(buf);
      printf ("%s\n",(const char *)buf);

      SelectNode *snext = (SelectNode *)icurve->Associated_geometry()->GetHead();
      ASSERT(snext); // check the first element in the Select Aggregrate
      SdaiPcurve_or_surface *pcsurface1 = (SdaiPcurve_or_surface*)snext->node;
      ASSERT(pcsurface1->IsSurface() == sdaiTRUE);
      snext = (SelectNode *)(snext->NextNode());
      ASSERT(snext); // check the second element in the Select Aggregrate
      SdaiPcurve_or_surface *pcsurface2 = (SdaiPcurve_or_surface*)snext->node;
      ASSERT(pcsurface2->IsSurface() == sdaiTRUE);
      SdaiSurface *surface1 = pcsurface1->SdaiPcurve_or_surface::operator SdaiSurfaceH();
      SdaiSurface *surface2 = pcsurface2->SdaiPcurve_or_surface::operator SdaiSurfaceH();
      SCLstring buf1;
      surface1->STEPwrite(buf1);
      printf ("%s\n",(const char *)buf1);
      SCLstring buf2;
      surface2->STEPwrite(buf2);
      printf ("%s\n",(const char *)buf2);
      if (icurve->Curve_3d()) {
         ASSERT (icurve->Curve_3d()->isSpecies("B_Spline_Curve_With_Knots")); 
         SdaiB_spline_curve_with_knots *bscurve = SdaiB_spline_curve_with_knots::castdown(icurve->Curve_3d());
 
         print_step_bs3_curve(bscurve);
      }
   }
}

void print_step_surface (SdaiSurface *surface)
{
   SCLstring buf;
   surface->STEPwrite(buf);
   printf ("%s\n",(const char *)buf);

   SdaiCartesian_point *pnt;
   SdaiDirection       *dir;
   if (surface->isSpecies("Plane"))
   {
      SdaiPlane *plane = SdaiPlane::castdown(surface);
      SCLstring buf;
      plane->STEPwrite(buf);
      printf ("%s\n",(const char *)buf);
      pnt = plane->Position()->Location();
      dir = plane->Position()->Axis();
      SCLstring buf1;
      pnt->STEPwrite(buf1);
      printf ("%s\n",(const char *)buf1);
      SCLstring buf2;
      dir->STEPwrite(buf2);
      printf ("%s\n",(const char *)buf2);
   }
   else if (surface->isSpecies("Conical_Surface"))
   {
      SdaiConical_surface *cone = SdaiConical_surface::castdown(surface);
      pnt = cone->Position()->Location();
      dir = cone->Position()->Axis();
      SCLstring buf;
      cone->STEPwrite(buf);
      printf ("%s\n",(const char *)buf);
      SCLstring buf1;
      pnt->STEPwrite(buf1);
      printf ("%s\n",(const char *)buf1);
      SCLstring buf2;
      dir->STEPwrite(buf2);
      printf ("%s\n",(const char *)buf2);
   }
   else if (surface->isSpecies("Cylindrical_Surface"))
   {
      SdaiCylindrical_surface *cylinder = SdaiCylindrical_surface::castdown(surface);
      pnt = cylinder->Position()->Location();
      dir = cylinder->Position()->Axis();
      SCLstring buf;
      cylinder->STEPwrite(buf);
      printf ("%s\n",(const char *)buf);
      SCLstring buf1;
      pnt->STEPwrite(buf1);
      printf ("%s\n",(const char *)buf1);
      SCLstring buf2;
      dir->STEPwrite(buf2);
      printf ("%s\n",(const char *)buf2);
   }
   else if (surface->isSpecies("Spherical_Surface"))
   {
      SdaiSpherical_surface *sphere = SdaiSpherical_surface::castdown(surface);
      pnt = sphere->Position()->Location();
      SCLstring buf;
      sphere->STEPwrite(buf);
      printf ("%s\n",(const char *)buf);
      SCLstring buf1;
      pnt->STEPwrite(buf1);
      printf ("%s\n",(const char *)buf1);
   }
   else if (surface->isSpecies("Toroidal_Surface"))
   {
      SdaiToroidal_surface *torus = SdaiToroidal_surface::castdown(surface);
      pnt = torus->Position()->Location();
      dir = torus->Position()->Axis();
      SCLstring buf;
      torus->STEPwrite(buf);
      printf ("%s\n",(const char *)buf);
      SCLstring buf1;
      pnt->STEPwrite(buf1);
      printf ("%s\n",(const char *)buf1);
      SCLstring buf2;
      dir->STEPwrite(buf2);
      printf ("%s\n",(const char *)buf2);
   }
}


void print_step_vertex (SdaiVertex_point *vertex)
{
   SCLstring buf;
   vertex->STEPwrite(buf);
   printf ("%s\n",(const char *)buf);
   SdaiCartesian_point *pnt = SdaiCartesian_point::castdown(vertex->Vertex_geometry());
   if (pnt)
   {
      SCLstring buf;
      pnt->STEPwrite(buf);
      printf ("%s\n",(const char *)buf);
   }
}

void print_step_edge (SdaiEdge_curve *edge)
{
   SCLstring buf;
   edge->STEPwrite(buf);
   printf ("%s\n",(const char *)buf);

#ifndef PRINT_LEVEL_EDGE
   print_step_vertex(SdaiVertex_point::castdown(edge->Edge_start()));
   print_step_vertex(SdaiVertex_point::castdown(edge->Edge_end()));

   SdaiCurve *curve = edge->Edge_geometry();
   print_step_curve  (curve);
#endif
}

void print_step_edge_loop (SdaiEdge_loop *edge_loop)
{
   SCLstring buf;
   edge_loop->STEPwrite(buf);
   printf ("%s\n",(const char *)buf);
   EntityNode *next = (EntityNode *)edge_loop->Edge_list()->GetHead();
   while (next) 
   {
      SdaiOriented_edge *oedge = SdaiOriented_edge::castdown(next->node);
      SCLstring buf1;
      oedge->STEPwrite(buf1);
      printf ("%s\n",(const char *)buf1);
      SdaiEdge *edge = oedge->Edge_element();
      print_step_edge(SdaiEdge_curve::castdown(edge));
      next = (EntityNode *)(next->NextNode());
   }
}


void print_step_vertex_loop (SdaiVertex_loop *vertex_loop)
{
   SCLstring buf;
   vertex_loop->STEPwrite(buf);
   printf ("%s\n",(const char *)buf);

   SCLstring buf1;
   SdaiVertex_point::castdown(vertex_loop->Loop_vertex())->STEPwrite(buf1);
   printf ("%s\n",(const char *)buf);
}

void print_step_face (SdaiFace_surface *face)
{

   SCLstring buf;
   face->STEPwrite(buf);
   printf ("%s\n",(const char *)buf);

#ifndef PRINT_LEVEL_EDGE
   //--print a surface for the face
   SdaiSurface *surface = face->Face_geometry();
   print_step_surface (surface);
#endif

   //--Print loops
   EntityNode *next = (EntityNode *)face->Bounds()->GetHead();
   while (next) 
   {
      SdaiFace_bound *boundary = SdaiFace_bound::castdown(next->node);
      SCLstring buf;
      boundary->STEPwrite(buf);
      printf ("%s\n",(const char *)buf);

      SdaiLoop *loop = boundary->Bound();

      if (loop->isSpecies ("Vertex_Loop"))
         print_step_vertex_loop (SdaiVertex_loop::castdown(loop));
      else
         print_step_edge_loop (SdaiEdge_loop::castdown(loop));

      next = (EntityNode *)(next->NextNode());
   }
}


void print_step_shell (SdaiClosed_shell *closed_shell)
{
   EntityNode *next = (EntityNode *)closed_shell->Cfs_faces()->GetHead();
   if (!next) printf("No faces in shell %d\n",closed_shell);
   while (next) 
   {
      SdaiFace *face = SdaiFace::castdown(next->node);
      int flag = 1;

      SdaiFace_surface *face_surf;
      if (face->isSpecies ("Oriented_Face")) {
         SdaiOriented_face *oface = SdaiOriented_face::castdown(face); 
         SCLstring buf;
         oface->STEPwrite(buf);
         printf ("%s\n",(const char *)buf);
         face_surf = SdaiFace_surface::castdown(oface->Face_element());
      }
      else 
         face_surf = SdaiFace_surface::castdown(face);

      print_step_face (face_surf);
      next = (EntityNode *)(next->NextNode());
   }
}


void print_step_body (SdaiManifold_solid_brep *brep)
{
   //--Keep a hashtable to avoid duplicating entities
 
   SCLstring buf;
   brep->STEPwrite(buf);
   printf ("%s\n",(const char *)buf);
   print_step_shell (brep->Outer());
 
   if (brep->isSpecies("SdaiBrep_with_voids"))
   {
      SdaiBrep_with_voids *brepv = SdaiBrep_with_voids::castdown(brep);
      SCLstring buf;
      brepv->STEPwrite(buf);
      printf ("%s\n",(const char *)buf);
      EntityNode *next = (EntityNode *)brepv->Voids()->GetHead();
      while (next) 
      {
         SdaiClosed_shell *shell = SdaiClosed_shell::castdown(next->node);
         SCLstring buf;
         shell->STEPwrite(buf);
         printf ("%s\n",(const char *)buf);
         print_step_shell (shell);
         next = (EntityNode *)(next->NextNode());
      }
   }
}



BODY *create_acis_body_from_brep (SdaiManifold_solid_brep *brep)
//--------------------------------------------------------------------------
//  Create an ACIS body from this STEP SdaiManifold_solid_brep
//--------------------------------------------------------------------------
{
   BODY  *body;
   SHELL *first, *last, *acis_shell;

   if (!brep)
   {
      printf ("***ERROR*** Cannot create ACIS body from null instance of SdaiManifold_solid_brep.\n");
      return NULL;
   }

   if (DEBUG) printf("Found %s %d\n",brep->EntityName(),brep->FileId());    

//--Keep a hashtable to avoid duplicating entities
   HASHtable *hashtable = new HASHtable(997);

//------------------------------------------------------------------------
   API_BEGIN			// ACIS macro to begin bulletin board.
   api_checking (TRUE);
    
//--Create the outer shell
   acis_shell = create_acis_shell (hashtable, brep->Outer());
   last = first = acis_shell;

//--Append void shells to list
   if (brep->isSpecies("SdaiBrep_with_voids"))
   {
      SdaiBrep_with_voids *brepv = SdaiBrep_with_voids::castdown(brep);

      EntityNode *next = (EntityNode *)brepv->Voids()->GetHead();
      while (next) 
      {
         SdaiClosed_shell *shell = SdaiClosed_shell::castdown(next->node);
         acis_shell = create_acis_shell (hashtable, shell);
         last->set_next (acis_shell);
         last = acis_shell;
         next = (EntityNode *)(next->NextNode());
      }
   }
   
   if (DEBUG) printf(" Creating new body\n");
   LUMP *lump = new LUMP (first, NULL);
   if (PRINT) STEPattributeID (lump, brep->FileId());
   body = new BODY (lump);
 
   // fill_in_intersection_curves (body);
    
/*-----------------------------------------------------------*/
   result = outcome(0);
   API_END			// ACIS routine to end bulletin board.

   delete hashtable;
   return body;
}


SHELL *create_acis_shell (HASHtable *hashtable, SdaiClosed_shell *closed_shell)
//--------------------------------------------------------------------------
//  Create an ACIS shell from this STEP SdaiClosed_shell
//--------------------------------------------------------------------------
{
   if (DEBUG) 
      printf(" Found %s %d\n", closed_shell->EntityName(),closed_shell->FileId());    

   FACE  *first=0, *last=0, *acis_face=0;

   EntityNode *next = (EntityNode *)closed_shell->Cfs_faces()->GetHead();
   if (!next) printf("No faces in shell %d\n",closed_shell);
   while (next) 
   {
      SdaiFace *face = SdaiFace::castdown(next->node);
      int flag = 1;

      SdaiFace_surface *face_surf;
      if (face->isSpecies ("Oriented_Face"))
      {
         SdaiOriented_face *oface = SdaiOriented_face::castdown(face); 
         face_surf = SdaiFace_surface::castdown(oface->Face_element());
         flag = (oface->Orientation() == sdaiTRUE);
      }
      else
         face_surf = SdaiFace_surface::castdown(face);

      acis_face = create_acis_face (hashtable, face_surf, flag);
      if (!first) 
         first = acis_face;
      else 
         last->set_next (acis_face);
      last = acis_face;
      if (CHECK)
      {
         SCLstring buf;
         face_surf->STEPwrite(buf);
         printf ("%s\n",(const char *)buf);
         printf("\nChecking ACIS Face %d with sense = %s of %s #%d same_sense = %d, for errors:\n",acis_face,SENSE(acis_face->sense()),face_surf->EntityName(), face_surf->FileId(),(face_surf->Same_sense() == sdaiTRUE));
         printf("\n");
      }
      next = (EntityNode *)(next->NextNode());
   }

   SHELL *shell = new SHELL (first, NULL, NULL);
   if (PRINT) STEPattributeID (shell, closed_shell->FileId());

   return shell;
}


FACE *create_acis_face (HASHtable *hashtable, SdaiFace_surface *face, int flag)
//--------------------------------------------------------------------------
//  Create an ACIS face from this STEP Face.  FLAG is normally 1, but
//  may be 0 if an Oriented_Face was used with orientation of .FALSE. 
//  When FLAG==0, reverse the orientation flag of all Face_Bounds.
//--------------------------------------------------------------------------
{
  LOOP  *first=0, *last=0, *acis_loop=0;

  if (DEBUG) printf("  Found %s %d with sense flag %d\n",
                     face->EntityName(), face->FileId(),flag);    

//--Construct a surface for the face
  SdaiSurface *surface = face->Face_geometry();
  SURFACE *acis_surface = create_acis_surface (hashtable, surface);

//--Construct loops
   EntityNode *next = (EntityNode *)face->Bounds()->GetHead();
   while (next) 
   {
      SdaiFace_bound *boundary = SdaiFace_bound::castdown(next->node);
      SdaiLoop *loop = boundary->Bound();
      int flag2 = !((boundary->Orientation() == sdaiTRUE) ^ flag);

      if (loop->isSpecies ("Vertex_Loop"))
         acis_loop = create_acis_vertex_loop (hashtable, SdaiVertex_loop::castdown(loop));
      else
         acis_loop = create_acis_edge_loop (hashtable, SdaiEdge_loop::castdown(loop), flag2);

      if (!first) 
         first = acis_loop;
      else 
         last->set_next (acis_loop);
      last = acis_loop;

      if (CHECK)
      {
         SCLstring buf1;
         boundary->STEPwrite(buf1);
         printf ("%s\n",(const char *)buf1);
         SCLstring buf2;
         loop->STEPwrite(buf2);
         printf ("%s\n",(const char *)buf2);
         printf("\nChecking ACIS Loop %d of %s #%d Orientation = %d, for errors:\n",acis_loop,boundary->EntityName(), boundary->FileId(),(boundary->Orientation() == sdaiTRUE));
         printf("\n");
      }

      next = (EntityNode *)(next->NextNode());
   }

//--NOTE: I assume sense of surface is not affected by flag from Oriented_Face
   int same_surface_sense = (face->Same_sense() == sdaiTRUE);
   if (DEBUG) 
      printf("     Attaching %s %d to %s %d with sense flag %d\n",
               surface->EntityName(), surface->FileId(),
               face->EntityName(),    face->FileId(), same_surface_sense);

   FACE *acisface = new FACE (first, NULL, acis_surface, !same_surface_sense);
   if (PRINT) STEPattributeID (acisface, face->FileId());
   if (DEBUG)
      printf("     Created FACE %d, LOOP %d, to %s %d, with sense flag %s\n",
               acisface, first, acis_surface->type_name(), acis_surface, SENSE(!same_surface_sense));
   return acisface;
}


LOOP *create_acis_vertex_loop (HASHtable *hashtable, SdaiVertex_loop *vertex_loop)
//--------------------------------------------------------------------------
//  Create an ACIS loop from this STEP SdaiVertex_loop
//--------------------------------------------------------------------------
{
   LOOP *acis_loop=0;

   if (!vertex_loop) return acis_loop;

   if (DEBUG) printf("   Found %s %d\n",
       vertex_loop->EntityName(), vertex_loop->FileId());    
    
//--If this loop is in the hashtable, return its object
   if (NULL != (acis_loop=(LOOP *)hashtable->get_hash (vertex_loop->FileId())))
      return acis_loop;

   VERTEX *vertex    = create_acis_vertex (hashtable, SdaiVertex_point::castdown(vertex_loop->Loop_vertex()));
   EDGE   *acis_edge = new EDGE (vertex, vertex, (CURVE*)0, FORWARD);
   COEDGE *coedge    = new COEDGE (acis_edge, FORWARD, (COEDGE*)0, NULL);

   coedge->set_previous (coedge);
   coedge->set_next (coedge);
  
   acis_loop = new LOOP (coedge, NULL);

   if (PRINT) {
      STEPattributeID (vertex, vertex_loop->Loop_vertex()->FileId());
      STEPattributeID (coedge, vertex_loop->FileId());
      STEPattributeID (acis_loop, vertex_loop->FileId());
      STEPattributeID (acis_edge, vertex_loop->FileId());
   }
   hashtable->put_hash (vertex_loop->FileId(), (int) acis_loop);
   return acis_loop;
}


LOOP *create_acis_edge_loop (HASHtable *hashtable, SdaiEdge_loop *edge_loop, int flag)
//--------------------------------------------------------------------------
//  Create an ACIS loop from this STEP SdaiEdge_loop
//--------------------------------------------------------------------------
{
   LOOP *acis_loop=0;
   COEDGE *first=0, *last=0, *coedge=0;
   int edge_sense;
  
   if (!edge_loop) return acis_loop;

   if (DEBUG) 
   printf("   Found %s %d with sense flag %d\n",
          edge_loop->EntityName(), edge_loop->FileId(),flag);    
    
//--If this loop is in the hashtable, return its object
   if (NULL != (acis_loop=(LOOP *)hashtable->get_hash (edge_loop->FileId())))
	   return acis_loop;
   
   if (!flag) 
      edge_loop->Edge_list()->Reverse();
   EntityNode *next = (EntityNode *)edge_loop->Edge_list()->GetHead();
   while (next) 
   {
      SdaiOriented_edge *oedge = SdaiOriented_edge::castdown(next->node);
      SdaiEdge *edge = oedge->Edge_element();
      edge_sense = !((oedge->Orientation() == sdaiTRUE) ^ flag);

      EDGE *acis_edge = create_acis_edge(hashtable, SdaiEdge_curve::castdown(edge));

      if (CHECK)
      {
         SCLstring buf1;
         oedge->STEPwrite(buf1);
         printf ("%s\n",(const char *)buf1);
         SCLstring buf2;
         edge->STEPwrite(buf2);
         printf ("%s\n",(const char *)buf2);
         printf("\nChecking ACIS Edge %d with sense = %s of %s #%d Orientation = %d, for errors:\n",acis_edge,SENSE(acis_edge->sense()),edge->EntityName(), edge->FileId(),( SdaiEdge_curve::castdown(edge)->Same_sense() == sdaiTRUE));
         printf("\n");
      }
//--Create COEDGE
      coedge = new COEDGE (acis_edge, !edge_sense, last, NULL);
      if (PRINT) STEPattributeID (coedge, oedge->FileId());
      if (DEBUG) 
         printf("  Created COEDGE %d for EDGE %d with sense_flag %s (reverse_flag %s) flag=%d\n", coedge,
                edge->FileId(),SENSE(edge_sense),SENSE(!edge_sense),flag);

      if (!first) 
         first = coedge;
      else
      {
         coedge->set_previous (last);
         last->set_next (coedge);
      }
      last = coedge;
      if (CHECK)
      {
         printf("\nChecking ACIS CoEdge %d with sense %s of %s #%d Orientation = %d, for errors:\n",coedge,SENSE(coedge->sense()),oedge->EntityName(), oedge->FileId(),(oedge->Orientation() == sdaiTRUE));
         printf("\n");
      }
      next = (EntityNode *)(next->NextNode());
   }

   first->set_previous (last);
   last->set_next (first);
  
   acis_loop = new LOOP (first, NULL);
   if (PRINT) STEPattributeID (acis_loop, edge_loop->FileId());
   if (DEBUG) 
      printf("  Created LOOP %d with starting COEDGE %d\n", acis_loop, coedge);
   hashtable->put_hash (edge_loop->FileId(), (int) acis_loop);
   return acis_loop;
}


EDGE *create_acis_edge (HASHtable *hashtable, SdaiEdge_curve *edge)
//--------------------------------------------------------------------------
//  Create an ACIS edge from this STEP SdaiEdge
//--------------------------------------------------------------------------
{
   EDGE *acis_edge=0;
   CURVE *acis_curve=0;
   VERTEX *start=0, *end=0;

   if (!edge) return acis_edge;

   if (DEBUG) 
      printf("    Found %s %d\n", edge->EntityName(), edge->FileId());    

//--If entity is in the hashtable, return its object
   if (NULL != (acis_edge=(EDGE *)hashtable->get_hash (edge->FileId()))) return acis_edge;

   SdaiCurve *curve = edge->Edge_geometry();
   acis_curve = create_acis_curve  (hashtable, curve);
   start      = create_acis_vertex (hashtable, SdaiVertex_point::castdown(edge->Edge_start()));
   end        = create_acis_vertex (hashtable, SdaiVertex_point::castdown(edge->Edge_end()));

   if (DEBUG && start==end) printf("Start == End vertex %ld\n",edge->Edge_end()->FileId());
   if (DEBUG && !start) printf("Start == 0\n");
   if (DEBUG && !end  ) printf("End == 0\n");

   int same_sense = (edge->Same_sense() == sdaiTRUE);
   if (DEBUG) 
      printf("     Attaching %s %d to %s %d with sense flag %s\n",
             curve->EntityName(),curve->FileId(),
             edge->EntityName(),edge->FileId(), SENSE(!same_sense));

   acis_edge  = new EDGE (start, end, acis_curve, !same_sense);
   if (PRINT) STEPattributeID (acis_edge, edge->FileId());

   hashtable->put_hash (edge->FileId(), (int) acis_edge);

   return acis_edge;
}


VERTEX *create_acis_vertex (HASHtable *hashtable, SdaiVertex_point *vertex)
//--------------------------------------------------------------------------
//  Create an ACIS vertex from this STEP Vertex
//--------------------------------------------------------------------------
{
   VERTEX *acis_vertex=0;
  
   if (!vertex) return acis_vertex;

   if (DEBUG)  
      printf("     Found %s %d\n",
             vertex->EntityName(), vertex->FileId());    
  
//--If entity is in the hashtable, return its object
   if (NULL != (acis_vertex=(VERTEX *)hashtable->get_hash (vertex->FileId())))
      return acis_vertex;
  
//--Create a new entity
   SdaiCartesian_point *pnt = SdaiCartesian_point::castdown(vertex->Vertex_geometry());
   if (pnt)
   {
      PntCoords(pnt,x,y,z)
      POINT *point = new POINT (x, y, z);
      if (PRINT) STEPattributeID (point, vertex->Vertex_geometry()->FileId());
      acis_vertex = new VERTEX (point);
      if (PRINT) STEPattributeID (acis_vertex, vertex->FileId());
      hashtable->put_hash (vertex->FileId(), (int) acis_vertex);
   }
  
   return acis_vertex;
}


SURFACE *create_acis_surface (HASHtable *hashtable, SdaiSurface *surface)
//-----------------------------------------------------------------------------
//  Create a new surface 
//-----------------------------------------------------------------------------
{
   double radius, r1, r2, half_angle;
   SdaiCartesian_point *pnt;
   SdaiDirection       *dir;
   SdaiDirection       *ref;
   SURFACE         *acis_surface = 0;
   vector           vec;
 
   if (!surface)
   {
      printf ("***ERROR*** Cannot create Acis surface from null instance of surface.\n");
      return acis_surface;
   }

   if (DEBUG) 
      printf("   Face has surface: %s %d\n",
             surface->EntityName(), surface->FileId());    

//--If entity is in the hashtable, return its object
   if (NULL != (acis_surface=(SURFACE *)hashtable->get_hash (surface->FileId())))
           return acis_surface;

//--Planar surface   
   if (surface->isSpecies("Plane"))
   {
      SdaiPlane *splane = SdaiPlane::castdown(surface);
      pnt = splane->Position()->Location();
      dir = splane->Position()->Axis();
      ref = splane->Position()->Ref_direction();
      if (pnt && dir)
      {
         PntCoords (pnt,x,y,z)
         DirRatios (dir,dx,dy,dz)
         acis_surface = new PLANE (position (x,y,z), normalise (vector(dx,dy,dz)));
      }
      if (ref) {
         plane &pln = (plane &)acis_surface->equation_for_update();

         DirRatios (ref,dx,dy,dz)

         vector udir = pln.u_axis();

         if ((vector(dx,dy,dz) % udir) < 0) {
            if (CHECK) printf ("Warning Plane #%d has reversed u,v parametrisation,\nACIS planes are not true parametric surfaces.\n",surface->FileId());
         }
      }
   }
//--Conical surface    
   else if (surface->isSpecies("Conical_Surface"))
   {
      SdaiConical_surface *cone = SdaiConical_surface::castdown(surface);
      pnt = cone->Position()->Location();
      dir = cone->Position()->Axis();
      ref = cone->Position()->Ref_direction();
      radius = cone->Radius();
      if (ANGLE_RADIANS) // angleSIunitExist (instance_list))
         half_angle = cone->Semi_angle();
      else 
         half_angle = cone->Semi_angle()*atan (1.0)/45.0;

      //--NOTE: STEP assumes the direction of the cone axis is away from the apex
      //--when the half-angle is positive. ACIS assumes the direction is toward
      //--the apex when the half-angle is negative.
      if (pnt && dir)
      {
         PntCoords (pnt,x,y,z)
         DirRatios (dir,dx,dy,dz)
  	 
         vec = xaxis_from_zaxis (vector (dx,dy,dz), NULL);


         if (is_zero(radius)) {
            unit_vector u = normalise(vec);
            if (ref) {
               DirRatios (ref,rx,ry,rz)
               u.x() = rx; u.y() = ry; u.z() = rz;
            }

            // root at apex
            // surface normal outward from axis
            // axis pointing in direction of increasing size
            // ACIS cone determines the above by sign conventions on the 
            // sin/cos angles
            // root arbitrary
            // axis arbitrary
            position  p_origin( x, y, z);

            // normalize p_cone axis/angle so p_axis points in direction of expansion
            unit_vector 	p_axial_norm( dx, dy, dz);
            double 		p_alpha_norm = half_angle;
            if ( p_alpha_norm < 0. ) {
               p_axial_norm = -p_axial_norm;
               p_alpha_norm = -p_alpha_norm;
            }

            if ( p_alpha_norm > atan(1.0)*2 ) {		// not an else-if; both can happen
               p_axial_norm = -p_axial_norm;
               p_alpha_norm = atan(1.0)*4 - p_alpha_norm;
            }

            // now we go up the cone and establish the "base" for the acis cone
            position 	a_origin = p_origin + p_axial_norm;
            double 		a_angle = fabs(p_alpha_norm);	// alpha can be negative
            vector   	a_radial = tan( a_angle ) * u;	// from a_origin
            double 		sin_angle = fabs( sin( a_angle ) );
            double 		cos_angle = fabs( cos( a_angle ) );

            // we leave cos_angle and sine_angle positive as this implies that 
            // 1) the surface normal points outward from the axis and
            // 2) the cone expands in the axis direction
            // and we have ensured these by normalizing
            acis_surface = new CONE( a_origin, p_axial_norm, a_radial, 1, 
               												sin_angle, cos_angle );
         }
         else
            acis_surface =
             new CONE (position (x,y,z),unit_vector (dx,dy,dz), normalise(vec) * radius,
                       1.0, sin(half_angle), cos(half_angle));
         if (DEBUG)
         {
            printf("Cone:  ");
            printf("  p=%7.3f%7.3f%7.3f",x,y,z);
            printf("  d=%7.3f%7.3f%7.3f",dx,dy,dz);
            printf("  r=%7.3f",radius);	 
            printf("  a=%7.3f\n",half_angle);
         }	 
      }	 

   }

   //--Cylindrical surface   
   else if (surface->isSpecies("Cylindrical_Surface"))
   {
      SdaiCylindrical_surface *cylinder = SdaiCylindrical_surface::castdown(surface);
      pnt = cylinder->Position()->Location();
      dir = cylinder->Position()->Axis();
      radius = cylinder->Radius();
      if (pnt && dir) 
      {
         PntCoords (pnt,x,y,z)
         DirRatios (dir,dx,dy,dz)
	
         vec = xaxis_from_zaxis (vector (dx,dy,dz), NULL);

         acis_surface =
         new CONE (position (x,y,z), unit_vector (dx,dy,dz), normalise(vec) * radius,
                   1.0, 0.0, 1.0);
      }
   }

   //--Spherical surface   
   else if (surface->isSpecies("Spherical_Surface"))
   {
      SdaiSpherical_surface *sphere = SdaiSpherical_surface::castdown(surface);
      pnt = sphere->Position()->Location();
	   radius = sphere->Radius();
      if (pnt) 
      {
         PntCoords (pnt,x,y,z)
	
	      acis_surface = new SPHERE (position (x,y,z), radius);
      }
   }

   //--Toriodal surface    
   else if (surface->isSpecies("Toroidal_Surface"))
   {
      SdaiToroidal_surface *torus = SdaiToroidal_surface::castdown(surface);
      pnt = torus->Position()->Location();
      dir = torus->Position()->Axis();
      r1  = torus->Major_radius();
      r2  = torus->Minor_radius();
      if (pnt && dir) 
      {
         PntCoords (pnt,x,y,z)
         DirRatios (dir,dx,dy,dz)
	
	      acis_surface =
   	      new TORUS (position (x,y,z), unit_vector (dx,dy,dz), r1, r2);
      }
   }

   //--Surface_Of_Revolution    
   else if (surface->isSpecies("Surface_Of_Revolution"))
   {
      SdaiSurface_of_revolution *sor = SdaiSurface_of_revolution::castdown(surface);
      CURVE *acis_curve = create_acis_curve (hashtable, sor->Swept_curve());
      pnt =  sor->Axis_position()->Location();
      dir =  sor->Axis_position()->Axis();
      if (pnt && dir) 
      {
         PntCoords (pnt,x,y,z)
         DirRatios (dir,dx,dy,dz)
         unit_vector axis (normalise (vector (dx,dy,dz)));

         if (is_STRAIGHT (acis_curve)) {
            vec = xaxis_from_zaxis (axis, NULL);
            position point (x,y,z);
            position root_point = ((STRAIGHT *)acis_curve)->root_point();
            unit_vector direction = ((STRAIGHT *)acis_curve)->direction();
            double angle = -1*angle_between (axis, direction, normalise(axis * direction)); 
      		position axis_start = point + ( root_point - point ) % axis * axis;
            double radius = (root_point-axis_start).len();
            if (are_parallel (axis, direction)) {
               // Surface of Revolution is a Cylinder.
               acis_surface =
               new CONE (axis_start, axis, normalise(vec) * radius,
                         1.0, 0.0, 1.0);
            }
            else {
               // Surface of Revolution is a Cone.
         		// If the start vertex is off the axis
         		if(radius > resabs )
         		{
                  // Line start point is not at the appex
                  acis_surface =
                   new CONE (axis_start,axis, normalise(vec) * radius,
                          1.0, sin(angle), cos(angle));
              }
               else {
                  // Line start point is at the appex
                  unit_vector u = normalise(vec);

                  // root at apex
                  // surface normal outward from axis
                  // axis pointing in direction of increasing size
                  // ACIS cone determines the above by sign conventions on the 
                  // sin/cos angles
                  // root arbitrary
                  // axis arbitrary
                  position  p_origin = axis_start;

                  // normalize p_cone axis/angle so p_axis points in direction of expansion
                  unit_vector 	p_axial_norm( dx, dy, dz);
                  double 		p_alpha_norm = angle;
                  if ( p_alpha_norm < 0. ) {
                     p_axial_norm = -p_axial_norm;
                     p_alpha_norm = -p_alpha_norm;
                  }

                  if ( p_alpha_norm > atan(1.0)*2 ) {		// not an else-if; both can happen
                     p_axial_norm = -p_axial_norm;
                     p_alpha_norm = atan(1.0)*4 - p_alpha_norm;
                  }

                  // now we go up the cone and establish the "base" for the acis cone
                  position 	a_origin = p_origin + p_axial_norm;
                  double 		a_angle = fabs(p_alpha_norm);	// alpha can be negative
                  vector   	a_radial = tan( a_angle ) * u;	// from a_origin
                  double 		sin_angle = fabs( sin( a_angle ) );
                  double 		cos_angle = fabs( cos( a_angle ) );

                  // we leave cos_angle and sine_angle positive as this implies that 
                  // 1) the surface normal points outward from the axis and
                  // 2) the cone expands in the axis direction
                  // and we have ensured these by normalizing
                  acis_surface = new CONE( a_origin, p_axial_norm, a_radial, 1, 
                     												sin_angle, cos_angle );
               }
            }
         }
      }
      api_delent (acis_curve);
   }
   if (PRINT) STEPattributeID (acis_surface, surface->FileId());
   hashtable->put_hash ((int)surface->FileId(), (int) acis_surface);
   return acis_surface;
}

bs3_curve create_bs3_curve (SdaiB_spline_curve_with_knots *bscurve, int periodic)
{
   int dim = 3;
   int degree = 3;
   int rational = FALSE;
   int closed = FALSE;
   double knot_tolerance = 1.0e-6;
   double control_point_tolerance = 1.0e-6;
   double *knots=NULL;
   int num_knots = 0;
   int num_control_points;
   double *weights=NULL;
   position *control_points=NULL;

   num_control_points = bscurve->Control_points_list()->EntryCount();
   control_points = new position [num_control_points];
   EntityNode *next = (EntityNode *)bscurve->Control_points_list()->GetHead();
   for (int i = 0; next; next = (EntityNode *)(next->NextNode()), i++) 
   {
      SdaiCartesian_point *pnt = SdaiCartesian_point::castdown(next->node);
      PntCoords (pnt,x,y,z)
      control_points[i].set_x(x);
      control_points[i].set_y(y);
      control_points[i].set_z(z);
   }


   degree = bscurve->Degree ();
   closed = (bscurve->Closed_curve () == sdaiTRUE);
   ASSERT (bscurve->Self_intersect () == sdaiFALSE);

   IntAggregateH intEa = bscurve->Knot_multiplicities ();
   RealAggregateH realEa = bscurve->Knots ();
   IntNode *in = (IntNode *)intEa->GetHead();
   while (in) {
      num_knots += in->value;
      in = (IntNode *)(in->NextNode());
   }
   knots = new double[num_knots];
   RealNode *rn = (RealNode *)realEa->GetHead();
   int count = 0;
   for (in = (IntNode *)intEa->GetHead(); in, rn; in = (IntNode *)(in->NextNode()), rn = (RealNode *)(rn->NextNode())) {
      for (int j = 0; j < in->value; j++,count++) 
         knots[count] = rn->value;
   }

   bs3_curve bs = bs3_curve_from_ctrlpts(	degree,
                                    	rational,
                                    	closed,
                                    	periodic,
                                    	num_control_points,
                                    	control_points,
                                    	weights,
                                    	control_point_tolerance,
                                    	num_knots,
                                    	knots,
                                    	knot_tolerance,
                                       dim);
   delete [] control_points;
   delete [] knots;
   return bs;
}


CURVE *create_acis_curve (HASHtable *hashtable, SdaiCurve *scurve)
{
   double radius, r1, r2;
   SdaiCartesian_point *pnt;
   SdaiDirection       *dir;
   SdaiDirection       *ref;
   CURVE           *acis_curve = 0;
   vector           vec;

   if (!scurve)
   {
      printf ("***ERROR*** Cannot create curve from null instance of SdaiCurve.\n");
      return acis_curve;
   }

   if (DEBUG) 
      printf("     SdaiEdge has curve: %s %d\n",
             scurve->EntityName(), scurve->FileId());    

   if (scurve && scurve->isSpecies("Trimmed_Curve"))
      scurve = SdaiTrimmed_curve::castdown(scurve)->Basis_curve();

   if (!scurve)
   {
      printf ("***ERROR*** Cannot create ACIS curve from null instance of SdaiCurve.\n");
      return (CURVE*)0;
   }

   if (scurve->isSpecies("Surface_Curve"))
   {
      SdaiSurface_curve *surfacecurve = SdaiSurface_curve::castdown(scurve);
      acis_curve = create_acis_curve  (hashtable, surfacecurve->Curve_3d());
   }
   else if (scurve->isSpecies("Line"))
   {
      SdaiLine *line = SdaiLine::castdown(scurve);
      pnt = line->Pnt();
      dir = line->Dir()->Orientation();
      if (pnt && dir) 
      {
         PntCoords (pnt,x,y,z)
         DirRatios (dir,dx,dy,dz)
         acis_curve =
           new STRAIGHT (position (x,y,z),unit_vector (dx,dy,dz));
      }
   }
    
   else if (scurve->isSpecies("Circle"))
   {
      SdaiCircle *circle = SdaiCircle::castdown(scurve);
      if (circle->Position()->IsAxis2_placement_3d() == sdaiTRUE)
      {
         SdaiAxis2_placement_3d *place = SdaiAxis2_placement_3d::castdown((circle->Position())->SdaiAxis2_placement::operator SdaiAxis2_placement_3dH());
         pnt = place->Location();
         dir = place->Axis();
      }
      else
      {
         printf("***ERROR*** Cannot get point and direction of circle axis from a Axis2_Placement");
         exit(1);
      }
      radius = circle->Radius();
      if (pnt && dir) 
      {
         PntCoords (pnt,x,y,z)
         DirRatios (dir,dx,dy,dz)
         if (DEBUG)
         {
            printf("Circle:");
            printf("  p=%7.3f%7.3f%7.3f",x,y,z);
            printf("  d=%7.3f%7.3f%7.3f",dx,dy,dz);
            printf("  r=%7.3f\n",radius);
         }

         vec = xaxis_from_zaxis (vector (dx,dy,dz), NULL);
         acis_curve =
            new ELLIPSE (position(x,y,z),unit_vector(dx,dy,dz),normalise(vec)*radius,1.0);
      }
   }    
   else if (scurve->isSpecies("Ellipse"))
   {
      SdaiEllipse *ellipse = SdaiEllipse::castdown(scurve);
      if (ellipse->Position()->IsAxis2_placement_3d() == sdaiTRUE)
      {
         SdaiAxis2_placement_3d *place = SdaiAxis2_placement_3d::castdown((ellipse->Position())->SdaiAxis2_placement::operator SdaiAxis2_placement_3dH());
         pnt = place->Location();
         dir = place->Axis();
         ref = place->Ref_direction();
      }
      else
      {
         printf("***ERROR*** Cannot get point and direction of ellipse axis from a SdaiAxis2_placement\n");
         exit(1);
      }
      r1  = ellipse->Semi_axis_1();
      r2  = ellipse->Semi_axis_2();

      if (pnt && dir) 
      {
         PntCoords (pnt,x,y,z)
         DirRatios (dir,dx,dy,dz)


         if (DEBUG)
         {
            printf("Ellipse:\n");
            printf("  p=%7.3f %.3f%7.3f",x,y,z);
            printf("  d=%7.3f%7.3f%7.3f",dx,dy,dz);
            printf("  r1=%7.3f",r1);	 
            printf("  r2=%7.3f\n",r2);
         }
         if (ref)
         {
            DirRatios (ref,rx,ry,rz)

            vec = vector (rx,ry,rz);

            vec = xaxis_from_zaxis (vector (dx,dy,dz), &vec);

            acis_curve =
               new ELLIPSE (position (x,y,z),
                        normalise (vector (dx,dy,dz)),
                        normalise(vec) * r1,
                        r2/r1);
         }
         else 
         {
            vec = xaxis_from_zaxis (vector (dx,dy,dz), NULL);

            acis_curve =
               new ELLIPSE (position (x,y,z),
                        normalise (vector (dx,dy,dz)),
                        normalise(vec) * r1,
                        r2/r1);
         }
      }
   }
   else if (scurve->isSpecies("B_Spline_Curve_With_Knots"))
   {
      SdaiB_spline_curve_with_knots *bscurve = SdaiB_spline_curve_with_knots::castdown(scurve);

      bs3_curve bs = create_bs3_curve(bscurve, 0);

   	intcurve icrv (bs, 0.0, *(surface *) NULL, *(surface *) NULL);
   	acis_curve = new INTCURVE( icrv );
      
   }
   else if (scurve->isSpecies("Intersection_Curve"))
   {

      SdaiIntersection_curve *icurve =  SdaiIntersection_curve::castdown(scurve);
      
      SelectNode *snext = (SelectNode *)icurve->Associated_geometry()->GetHead();
      ASSERT(snext); // check the first element in the Select Aggregrate
      SdaiPcurve_or_surface *pcsurface1 = (SdaiPcurve_or_surface*)snext->node;
      ASSERT(pcsurface1->IsSurface() == sdaiTRUE);
      snext = (SelectNode *)(snext->NextNode());
      ASSERT(snext); // check the second element in the Select Aggregrate
      SdaiPcurve_or_surface *pcsurface2 = (SdaiPcurve_or_surface*)snext->node;
      ASSERT(pcsurface2->IsSurface() == sdaiTRUE);
      SdaiSurface *surface1 = pcsurface1->SdaiPcurve_or_surface::operator SdaiSurfaceH();
      SdaiSurface *surface2 = pcsurface2->SdaiPcurve_or_surface::operator SdaiSurfaceH();

      if (icurve->Curve_3d() && icurve->Curve_3d()->isSpecies("B_Spline_Curve_With_Knots")) {

         SdaiB_spline_curve_with_knots *bscurve = SdaiB_spline_curve_with_knots::castdown(icurve->Curve_3d());
 
         position pos1(10,10,10);
         position pos2(-10,-10,-10);

         SdaiEdge_curve *edge = edgeCurveOfCurve  (scurve, instance_list);
         if (edge) {
            {
               SdaiCartesian_point *pnt1 = SdaiCartesian_point::castdown(SdaiVertex_point::castdown(edge->Edge_start())->Vertex_geometry());
               PntCoords(pnt1,x1,y1,z1)
               pos1.x()=x1; pos1.y()=y1; pos1.z()=z1;
            }
            {
               SdaiCartesian_point *pnt2 = SdaiCartesian_point::castdown(SdaiVertex_point::castdown(edge->Edge_end())->Vertex_geometry());
               PntCoords(pnt2,x2,y2,z2)
               pos2.x()=x2; pos2.y()=y2; pos2.z()=z2;
            }
         }

         bs3_curve bs = create_bs3_curve(bscurve, is_equal (pos1,pos2));

         SURFACE *acis_surface1 = create_acis_surface (hashtable, surface1);
         SURFACE *acis_surface2 = create_acis_surface (hashtable, surface2);

      	intcurve icrv (bs, 0.001, acis_surface1->equation(), acis_surface2->equation());

         if (acis_surface1 && acis_surface2 && !(acis_surface1->equation() ==  acis_surface2->equation())) {
            position bpos1 = bs3_curve_start (bs);
            position bpos2 = bs3_curve_end (bs);

         	box region_of_interset;
         	// if (is_equal (pos1,pos2))
         	   region_of_interset = icrv.bound( pos2, pos1 );
            // else
            //    region_of_interset = box (pos2, pos1);

            surf_surf_int *ssi = int_surf_surf( acis_surface2->equation(), (FACE *)NULL, *(transf *)NULL,
                                                acis_surface1->equation(), (FACE *)NULL, *(transf *)NULL,
                                                region_of_interset);

            if (is_intcurve ( ssi->cur )) {
               intcurve *crv = (intcurve *)ssi->cur;
               logical p1_on_cur = crv->test_point(pos1);
               logical p2_on_cur = crv->test_point(pos2);

               if (p1_on_cur && p2_on_cur)
               {
                  double par_0 = crv->param(pos1);
                  double par_1 = crv->param(pos2);

                  if (par_1 < par_0) {
                     crv->negate();
                     par_0 = crv->param(pos1);
                     par_1 = crv->param(pos2);
                  }
                  crv->reparam(par_0, par_1);
               }
               else {
         			for (surf_surf_int* nssi = ssi; nssi!=NULL; nssi = nssi->next) {
				         if (nssi->cur != NULL && nssi->cur->test_point(pos1) && nssi->cur->test_point(pos2))
                        break;
                  }
                  crv = (nssi) ? (intcurve *)nssi->cur : (intcurve *)ssi->cur;
                  double par_0 = crv->param(pos1);
                  double par_1 = crv->param(pos2);

                  if (par_1 < par_0) {
                     crv->negate();
                     par_0 = crv->param(pos1);
                     par_1 = crv->param(pos2);
                  }
                  crv->reparam(par_0, par_1);
               }
            	acis_curve = new INTCURVE( *crv );
            }
            else
              	acis_curve = new INTCURVE( *((intcurve *)ssi->cur) );

            delete ssi;
         }
         else
            acis_curve = new INTCURVE( icrv );
      }
      else if (icurve->Curve_3d() && icurve->Curve_3d()->isSpecies("Polyline")) {
         SdaiPolyline *polycurve = SdaiPolyline::castdown(icurve->Curve_3d());

         position minpos (1.0e10,1.0e10,1.0e10);
         position maxpos (-1.0e10, -1.0e10, -1.0e10);
         EntityNode *enext = (EntityNode *)polycurve->Points()->GetHead();
         while (enext) 
         {
            SdaiCartesian_point *point = SdaiCartesian_point::castdown(enext->node);
            PntCoords(point,x1,y1,z1)
            minpos.x()=MIN(minpos.x(),x1); minpos.y()=MIN(minpos.y(),y1); minpos.z()=MIN(minpos.z(),z1);
            maxpos.x()=MAX(maxpos.x(),x1); maxpos.y()=MAX(maxpos.y(),y1); maxpos.z()=MAX(maxpos.z(),z1);
            enext = (EntityNode *)(enext->NextNode());
         }

         position pos1(10,10,10);
         position pos2(-10,-10,-10);

         SdaiEdge_curve *edge = edgeCurveOfCurve  (scurve, instance_list);
         if (edge) {
            {
               SdaiCartesian_point *pnt1 = SdaiCartesian_point::castdown(SdaiVertex_point::castdown(edge->Edge_start())->Vertex_geometry());
               PntCoords(pnt1,x1,y1,z1)
               pos1.x()=x1; pos1.y()=y1; pos1.z()=z1;
            }
            {
               SdaiCartesian_point *pnt2 = SdaiCartesian_point::castdown(SdaiVertex_point::castdown(edge->Edge_end())->Vertex_geometry());
               PntCoords(pnt2,x2,y2,z2)
               pos2.x()=x2; pos2.y()=y2; pos2.z()=z2;
            }
         }
         SURFACE *acis_surface1 = create_acis_surface (hashtable, surface1);
         SURFACE *acis_surface2 = create_acis_surface (hashtable, surface2);
         if (acis_surface1 && acis_surface2 && !(acis_surface1->equation() ==  acis_surface2->equation())) {

            minpos.x()=MIN(pos1.x(),minpos.x()); minpos.y()=MIN(pos1.y(),minpos.y()); minpos.z()=MIN(pos1.z(),minpos.z());
            maxpos.x()=MAX(pos1.x(),maxpos.x()); maxpos.y()=MAX(pos1.y(),maxpos.y()); maxpos.z()=MAX(pos1.z(),maxpos.z());
            minpos.x()=MIN(pos2.x(),minpos.x()); minpos.y()=MIN(pos2.y(),minpos.y()); minpos.z()=MIN(pos2.z(),minpos.z());
            maxpos.x()=MAX(pos2.x(),maxpos.x()); maxpos.y()=MAX(pos2.y(),maxpos.y()); maxpos.z()=MAX(pos2.z(),maxpos.z());
            if (is_equal (minpos.x(),maxpos.x())) { minpos.x() -= .05; maxpos.x() += .05; }
            if (is_equal (minpos.y(),maxpos.y())) { minpos.y() -= .05; maxpos.y() += .05; }
            if (is_equal (minpos.z(),maxpos.z())) { minpos.z() -= .05; maxpos.z() += .05; }
         	box region_of_interset (minpos, maxpos);

            surf_surf_int *ssi = int_surf_surf( acis_surface2->equation(), (FACE *)NULL, *(transf *)NULL,
                                                acis_surface1->equation(), (FACE *)NULL, *(transf *)NULL,
                                                region_of_interset);

            if (is_intcurve ( ssi->cur )) {
               intcurve *crv = (intcurve *)ssi->cur;
               logical p1_on_cur = crv->test_point(pos1);
               logical p2_on_cur = crv->test_point(pos2);

               if (p1_on_cur && p2_on_cur)
               {
                  double par_0 = crv->param(pos1);
                  double par_1 = crv->param(pos2);

                  if (par_1 < par_0) {
                     crv->negate();
                     par_0 = crv->param(pos1);
                     par_1 = crv->param(pos2);
                  }
                  crv->reparam(par_0, par_1);
               }
            	acis_curve = new INTCURVE( *crv );
            }
            else
              	acis_curve = new INTCURVE( *((intcurve *)ssi->cur) );

            delete ssi;
         }
      }
      else {
         SURFACE *acis_surface1 = create_acis_surface (hashtable, surface1);
         SURFACE *acis_surface2 = create_acis_surface (hashtable, surface2);

         position pos1(-10,-10,-10);
         position pos2(10,10,10);
         position bpos1(-10,-10,-10);
         position bpos2(10,10,10);
         
         SdaiEdge_curve *edge = edgeCurveOfCurve  (scurve, instance_list);
         if (edge) {
            {
               SdaiCartesian_point *pnt1 = SdaiCartesian_point::castdown(SdaiVertex_point::castdown(edge->Edge_start())->Vertex_geometry());
               PntCoords(pnt1,x1,y1,z1)
               pos1.x()=x1; pos1.y()=y1; pos1.z()=z1;
            }
            {
               SdaiCartesian_point *pnt2 = SdaiCartesian_point::castdown(SdaiVertex_point::castdown(edge->Edge_end())->Vertex_geometry());
               PntCoords(pnt2,x2,y2,z2)
               pos2.x()=x2; pos2.y()=y2; pos2.z()=z2;
            }
         }

         bpos1 = pos1;
         bpos2 = pos2;
         if (is_equal (bpos2.x(),bpos1.x())) { bpos1.x() -= .05; bpos2.x() += .05; }
         if (is_equal (bpos2.y(),bpos1.y())) { bpos1.y() -= .05; bpos2.y() += .05; }
         if (is_equal (bpos2.z(),bpos1.z())) { bpos1.z() -= .05; bpos2.z() += .05; }

      	box region_of_interset( bpos2, bpos1 );

         surf_surf_int *ssi = int_surf_surf( acis_surface2->equation(), (FACE *)NULL, *(transf *)NULL,
                                             acis_surface1->equation(), (FACE *)NULL, *(transf *)NULL,
                                             region_of_interset);

         if (is_intcurve ( ssi->cur )) {
            intcurve *crv = (intcurve *)ssi->cur;
            logical p1_on_cur = crv->test_point(pos1);
            logical p2_on_cur = crv->test_point(pos2);

            if (p1_on_cur && p2_on_cur)
            {
               double par_0 = crv->param(pos1);
               double par_1 = crv->param(pos2);

               if (par_1 < par_0) {
                  crv->negate();
                  par_0 = crv->param(pos1);
                  par_1 = crv->param(pos2);
               }
               crv->reparam(par_0, par_1);
            }

         	acis_curve = new INTCURVE( *crv );
         }
         else 
            acis_curve = NULL;
         delete ssi;
      }
   }
   if (PRINT) STEPattributeID (acis_curve, scurve->FileId());
   return acis_curve;
}


void print_acis_curve (CURVE *curve)
{

   if (is_STRAIGHT(curve))
   {
      STRAIGHT *straight = (STRAIGHT *) curve;
      position coords    = straight->root_point();
      unit_vector dir    = straight->direction();

      printf ("        line %d point (%.16f, %.16f, %.16f) dir (%.16f, %.16f, %.16f)\n",getSTEPattributeID(curve),coords.x(),coords.y(),coords.z(),dir.x(),dir.y(),dir.z());

   }
   else if (is_ELLIPSE(curve))
   {
      ELLIPSE *ellipse = (ELLIPSE *) curve;
      position coords    = ellipse->centre();
      unit_vector normal = ellipse->normal();
      double radius = ellipse->major_axis().len();
      if (ellipse->radius_ratio() == 1.0)
      {
         printf ("        circle %d radius = %.16f, ma = (%.16f, %.16f, %.16f) \n        point (%.16f, %.16f, %.16f) normal (%.16f, %.16f, %.16f)\n",
                         getSTEPattributeID(curve),radius,ellipse->major_axis().x(),ellipse->major_axis().y(),ellipse->major_axis().z(),
                         coords.x(),coords.y(),coords.z(),normal.x(),normal.y(),normal.z());
      }
      else
      {
         vector cross = normal * ellipse->major_axis();

         printf ("        ellipse %d radius = %.16f, radius_ratio = %.16f, \n        ma = (%.16f, %.16f, %.16f) point (%.16f, %.16f, %.16f) normal (%.16f, %.16f, %.16f)\n",getSTEPattributeID(curve),radius,ellipse->radius_ratio(),
                         ellipse->major_axis().x(),ellipse->major_axis().y(),ellipse->major_axis().z(),
                         coords.x(),coords.y(),coords.z(),normal.x(),normal.y(),normal.z());
      }
   }
}

void print_acis_surface (SURFACE *surface)
{
   if (is_PLANE(surface))
   {
      PLANE *plane = (PLANE *)surface;
      position coords = plane->root_point();
      unit_vector normal = plane->normal();
      printf ("    plane %d point (%.16f, %.16f, %.16f) normal (%.16f, %.16f, %.16f)\n",
              getSTEPattributeID(plane),coords.x(),coords.y(),coords.z(),normal.x(),normal.y(),normal.z());
   }
   else if (is_CONE(surface))
   {
      CONE *cone = (CONE *)surface;
      position coords = cone->root_point();
      unit_vector dir = cone->direction();
      double radius = cone->major_axis().len();
      if (cone->sine_angle() == 0.0)
      {
         printf ("    cylinder %d Radius %.16f, \n    point (%.16f, %.16f, %.16f) dir (%.16f, %.16f, %.16f)\n",
         getSTEPattributeID(cone),radius,coords.x(),coords.y(),coords.z(),dir.x(),dir.y(),dir.z());
      }
      else
      {
         printf ("    cone %d Radius %.16f, sa = %.16f, ca = %.16f, \n    point (%.16f, %.16f, %.16f) dir (%.16f, %.16f, %.16f)\n",
         getSTEPattributeID(cone),radius,cone->sine_angle(),cone->cosine_angle(),coords.x(),coords.y(),coords.z(),dir.x(),dir.y(),dir.z());
      }
   }
   else if (is_SPHERE(surface))
   {
      SPHERE *sphere = (SPHERE *) surface;
      position coords = sphere->centre();

      printf ("    sphere %d Radius %.16f, point (%.16f, %.16f, %.16f)\n",
              getSTEPattributeID(sphere),sphere->radius(),coords.x(),coords.y(),coords.z());
   }
   else if (is_TORUS(surface))
   {
      TORUS *torus = (TORUS *) surface;
      position coords = torus->centre();
      unit_vector normal = torus->normal();

      printf ("    torus %d major rad = %.16f, minor rad = %.16f, \n    point (%.16f, %.16f, %.16f) normal (%.16f, %.16f, %.16f)\n",
                        getSTEPattributeID(torus),torus->major_radius(),torus->minor_radius(),coords.x(),coords.y(),coords.z(),normal.x(),normal.y(),normal.z());
   }
}

void print_acis_vertex (VERTEX *vertex)
{
  POINT *point = vertex->geometry();
  position coords = point->coords();
  printf ("Vertex with STEP ID = %d, Point %d, (%.16f, %.16f, %.16f)\n",getSTEPattributeID(vertex),getSTEPattributeID(point),
                  coords.x(),coords.y(),coords.z());
}


void print_acis_edge (EDGE *edge)
{
   if (edge->geometry()) {
      printf("       edge %d has  sense = %s, curve %d of type '%s' (%d)\n",getSTEPattributeID(edge), SENSE (edge->sense()),
             getSTEPattributeID(edge->geometry()),
             edge->geometry()->type_name(),
             edge->geometry()->equation().type());
      print_acis_curve (edge->geometry());
   }
}

void print_acis_face (FACE *face)
{
   printf("    face %d has sense = %s, surface %d of type '%s' (%d)\n",getSTEPattributeID(face),SENSE (face->sense()) ,getSTEPattributeID(face->geometry()),face->geometry()->type_name(),face->geometry()->equation().type());
   for (LOOP* loop=face->loop(); loop; loop=loop->next())
   {
      printf("    face %d contains loop %d\n",getSTEPattributeID(face) ,getSTEPattributeID(loop) );
      print_acis_surface (face->geometry());
      COEDGE* costart = loop->start();
      for (COEDGE* coedge=loop->start(); coedge; coedge=coedge->next())
      {
         EDGE* edge = coedge->edge();

         if (coedge == coedge->next() && !edge->geometry() &&
             edge->start() == edge->end()) 
         {
            printf("     loop %d is a vertex loop containing vertex %ld\n",getSTEPattributeID(loop),getSTEPattributeID(edge->start()));
         }
         else
         {
            printf("     loop %d contains coedge %ld \n",getSTEPattributeID(loop) ,getSTEPattributeID(coedge));
            printf("      coedge %d has sense = %s, contains edge %d\n",getSTEPattributeID(coedge), SENSE (coedge->sense()) ,getSTEPattributeID(edge) );
            if (edge->geometry()) {
               printf("       edge %d has  sense = %s, curve %d of type '%s' (%d)\n",getSTEPattributeID(edge), SENSE (edge->sense()),
                      getSTEPattributeID(edge->geometry()),
                      edge->geometry()->type_name(),
                      edge->geometry()->equation().type());
               print_acis_curve (edge->geometry());
            }
            else 
               printf("       edge %d has NO curve\n",getSTEPattributeID(edge));
#ifndef PRINT_LEVEL_EDGE
            printf("       edge %d contains vertex %ld\n",getSTEPattributeID(edge) ,getSTEPattributeID(edge->start()));
            printf("       edge %d contains vertex %ld\n",getSTEPattributeID(edge) ,getSTEPattributeID(edge->end()));
#endif
         } 
         if (costart == coedge->next()) break;
      } 
   }
}

