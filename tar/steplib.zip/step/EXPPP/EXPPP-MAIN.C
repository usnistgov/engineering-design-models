#include <stdio.h>
#include "express.h"
#include "exppp.h"

void
EXPRESSinit_init()
{
	EXPRESSbackend = EXPRESSout;
}

