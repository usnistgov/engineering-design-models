/* dir.h - define directions */

#define WEST	1
#define EAST	2
#define BOTTOM	4
#define TOP	8
#define SOUTH	16
#define NORTH	32

char *dir_print();	/* return printable version of direction */
