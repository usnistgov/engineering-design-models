/* face.c - implementing structure for maintaining faces */

/*

The idea here is incredibly trivial (and works great).  We allocate a
fixed-length array to keep track of the faces.  "face_last_used" keeps
track of the last used face in the array.  Whenever we create a new
face, we increment face_last_used.  To delete a face, we take whatever
face_last_used points to and copy it to the position where we are
deleting.  Lastly we decrement face_last_used.

/* unsorted heap via array */

#include "basic.h"
#include "dir.h"
#include "face.h"
#include "oct.h"
#ifdef ALLOC
#include "mem.h"
#endif ALLOC

struct face
	*faces,			/* faces array itself */
	*face_last_used,	/* last used face */
	*face_bad;		/* pointer one past end of array */

face_bootstrap(size)
int size;
{
#ifdef ALLOC
	chkn1(faces = (struct face *)sbrk(size*sizeof(struct face)),
		"face_bootstrap: out of memory");
#else
	chk(faces=(struct face *)malloc((unsigned)size * sizeof(struct face)),
		"face_bootstrap: out of memory");
#endif
	face_last_used = faces - 1;
	face_bad = faces + size;
	surface = 0;
}

struct face *
face_new(o,dir)
struct oct *o;
int dir;
{
	if (face_bad == ++face_last_used) {
		printf("face_new: ran out of face space\npausing...");
		pause();
	}
	face_last_used->oct = o;
	face_last_used->dir = dir;

	surface++;
	return(face_last_used);
}

face_delete(f)
struct face **f;
{
	struct face *f2;

	f2 = *f;	/* save pointer into face array */
	*f = 0;	/* old oct no longer has a face */

	if (f2 != face_last_used) {

		/* move last face to spot where we just deleted face */
		f2->dir = face_last_used->dir;
		f2->oct = face_last_used->oct;

		oct_face_change(f2->oct,f2->dir,f2);
	}

	surface--;

	face_last_used--;

#ifdef DEBUG
	printf("face_delete: f2 = %x(%d)  last_face_used = %x(%d)\n",
		f2,f2-faces,face_last_used,face_last_used-faces);
#endif
}

struct face *
face_choose()
{
	return(&faces[ran(surface)]);
}

/* I have taken the literal interpretation of computing the face distance.
   It is possible that the bsw corner is sufficient, rather than actual
   computing the face centers (which is much slower).
   One could also consider changing double to float in the following two
   procedures.  Some compilers would produce significant speedups
*/
/* return center of face f as x,y,z */
face_center(f,x,y,z)
struct face *f;
double *x, *y, *z;
{
	*x = f->oct->bsw.x;
	*y = f->oct->bsw.y;
	*z = f->oct->bsw.z;

	switch (f->dir) {
	case SOUTH:  *x += .5;	*y += .5;	    break;
	case NORTH:  *x += .5;	*y += .5; *z += 1;  break;
	case BOTTOM: *x += .5;		  *z += .5; break;
	case TOP:    *x += .5;	*y += 1;  *z += .5; break;
	case WEST:		*y += .5; *z += .5; break;
	case EAST:   *x += 1;	*y += .5; *z += .5; break;
	}
}

/* return string that we can print out stating least squares distance of
   faces from center */
char *
print_face_distance()
{
	char buf[80];

	struct face *f;
	double x,y,z;
	double xcm = 0, ycm = 0, zcm = 0;
	double xtotal = 0, ytotal = 0, ztotal = 0;

	for (f=faces;f<=face_last_used;f++) {
		face_center(f,&x,&y,&z);
		xcm += x;
		ycm += y;
		zcm += z;
	}

	xcm = xcm/surface;
	ycm = ycm/surface;
	zcm = zcm/surface;

	/* *cm now holds the center of mass of the faces */

	/* now compute the least squares distance */
	for (f=faces;f<=face_last_used;f++) {
		face_center(f,&x,&y,&z);
		xtotal += (x - xcm) * (x - xcm);
		ytotal += (y - ycm) * (y - ycm);
		ztotal += (z - zcm) * (z - zcm);
	}
	sprintf(buf,"face distance = %.0f,%.0f,%.0f",xtotal,ytotal,ztotal);
	return(buf);
}

#ifdef SPACE_PROFILE
/* generate statistics on space usage */
space_stats()
{
	int xmin, xmax, ymin, ymax, zmin, zmax;
	struct face *f;

	xmin = oct_root->bsw.x + oct_root_size;
	xmax = oct_root->bsw.x - oct_root_size;
	ymin = oct_root->bsw.y + oct_root_size;
	ymax = oct_root->bsw.y - oct_root_size;
	zmin = oct_root->bsw.z + oct_root_size;
	zmax = oct_root->bsw.z - oct_root_size;

	for (f=faces;f<=face_last_used;f++) {
		if (f->oct->bsw.x < xmin) xmin = f->oct->bsw.x;
		if (f->oct->bsw.x > xmax) xmax = f->oct->bsw.x;
		if (f->oct->bsw.y < ymin) ymin = f->oct->bsw.y;
		if (f->oct->bsw.y > ymax) ymax = f->oct->bsw.y;
		if (f->oct->bsw.z < zmin) zmin = f->oct->bsw.z;
		if (f->oct->bsw.z > zmax) zmax = f->oct->bsw.z;
	}
	printf("volume dimensions are %dx%dx%d\n",1+xmax-xmin,1+ymax-ymin,1+zmax-zmin);
	printf("alloc: oct = %d  faces = %d  children = %d\n",
			oct_freelist_head.count,
			faces_freelist_head.count,
			children_freelist_head.count);
}
#endif SPACE_PROFILE
