/* oct.c - octtree functions */

/*

These functions are motivated by the need for neighboring volume
detection.  Based on octtrees, they allow doubling ("octating"?) of
the tree at any time to allow the tree to grow to incorporate new
points falling outside the original tree.

Written by Don Libes, NBS, NIST, September 1988.

Public functions are:

void
oct_create(int x,int y,int z,struct oct *start_oct)

	returns cube at location (x,y,z).

	Creates cube if necessary.
	Depending upon implementation, may be possible to encounter old but
	unused cubes.  We will see.  If this turns out not to be the case,
	oct_create should be changed to generate an error, when the cube
	already exists.

	start_oct must always be a unit-level cube.

	see description of start_oct in oct_find().

void
oct_delete(struct oct *o)

	deletes oct o.  o must be a unit-level oct.

	Actual deletion of octs may be done either by marking them
	"unused" or by actual unlinking from the oct structure.

	Marking "unused" will be appropriate when deleting cubes outside
	the existing surface, while unlinking is appropriate when deleting
	cubes inside the existing surface.

oct_bootstrap()

	Initialize octtree with one cube at 0,0,0.
	Returns point to cube.

oct_face_change(struct oct *o,int dir,struct face *face)
	Utility function used by the face array maintainer.

	Given an oct, o and direction, dir, this function changes the
	face it points to.

	We do it in this way simply because it is good style, not to
	burden the face module with the innards of octs.

All other functions are private and local to this module.  One
particularly notable one is:

struct oct *
oct_find(int x,int y,int z,int oldsize,struct oct *start_oct,action,
			   int *newsize)

	returns cube at location (x,y,z).
	If no cube at this location, returns smallest enclosing oct.

	start_oct is a suggested point to start searching for oct.
	For example, when doing neighbor detection, we may have an oct
	that is physically adjacent to another oct.  This can be ignored
	by oct_find() if they turn out to be in totally different access
	paths.

	When start_oct is null, use root.

	oldsize is size of current oct.  If newsize is nonnull, it
	is set to size of oct being returned.

*/

#include "basic.h"
#include "dir.h"
#include "face.h"
#include "oct.h"
#ifdef ALLOC
#include "mem.h"
#endif ALLOC

extern double beta;

#ifdef DEBUG
int cycle = 1;	/* when was oct created */
extern int cubecount;	/* # of unit-level cubes */
#endif

struct children *children_new();
#define NULLCHILDREN ((struct children *)0)

enum children_status {
	full,	/* child is to be created with 8 0-faced children */
	empty	/* child is to be created with 8 null children */
};

#define NULLCHILDREN	((struct children *)0)

int oct_root_size = 1;

struct oct *oct_root,
	*oct_new(),	/* create a new oct */
	**pick_child(),	/* return handle to child of oct in given directions*/
	*oct_find();	/* find oct containing x,y,z */
void oct_root_new();	/* create a new root oct */

/* directions along the x,y,z axes are given names for human readability.
   The ones to the left (i.e., west) denote negative directions.
   The ones to the right (i.e., top) denote positive directions.
*/

enum xdir {too_west,	west,	east,	too_east};
enum ydir {too_bottom,	bottom, top,	too_top};
enum zdir {too_south,	south,	north,	too_north};

#ifdef ALLOC
#define destroy_oct(x)		destroy(&oct_freelist_head,(char *)x)
#define destroy_faces(x)	destroy(&faces_freelist_head,(char *)x)
#define destroy_children(x)	destroy(&children_freelist_head,(char *)x)
#else
#define destroy_oct(x)		free((char *)x)
#define destroy_faces(x)	free((char *)x)
#define destroy_children(x)	free((char *)x)
#endif

#ifdef OCTMAIN
main()
{
	struct oct *cube;

	face_bootstrap(10000);
	oct_bootstrap();
	printf("bootstrap completed\n");

	/* try creating some cubes */

	/* create one adjacent to 0,0,0 and inside oct_root */
	oct_find(-1,0,0,1,oct_root,create,(int *)0);

	/* create one adjacent to 0,0,0 but outside oct_root */
	cube = oct_find(0,0,1,1,oct_root,create,(int *)0);

	/* using handle of previous cube create a neighbor within
	   same oct */
	oct_find(-1,0,1,0,cube,create,(int *)0);

	/* again, but create a neighbor requiring a new root oct */
	/* oct_find(0,0,2,0,cube,create,(int *)0); */

	printf("oct_find's completed, pausing...\n");
	pause();

	return(0);
}
#endif

/* bootstrap oct structure into existence by creating one oct with
   subroot at 0,0,0 and one cube at 0,0,0
*/
oct_bootstrap()
{
	struct oct *oct2;		/* oct at 0,0,0 */

	/* create cube at 0,0,0 */
	oct2 = oct_new(NULLOCT,NULLCHILDREN,0,0,0,UNIT_LEVEL,0);
	oct2->faces.unit_level->west = face_new(oct2,WEST);
	oct2->faces.unit_level->east = face_new(oct2,EAST);
	oct2->faces.unit_level->bottom = face_new(oct2,BOTTOM);
	oct2->faces.unit_level->top = face_new(oct2,TOP);
	oct2->faces.unit_level->south = face_new(oct2,SOUTH);
	oct2->faces.unit_level->north = face_new(oct2,NORTH);

	/* create oct_root */
	oct_root_new(oct2,/*1,*/
		(enum xdir) too_west,
		(enum ydir) too_bottom,
		(enum zdir) too_south);
}

struct faces *
faces_new()
{
	struct faces *f;

#ifdef ALLOC
	f = (struct faces *)new(&faces_freelist_head);
#else
	chk(f = new(struct faces),"faces_new: out of space");
#endif

	f->west = NULL;
	f->east = NULL;
	f->bottom = NULL;
	f->top = NULL;
	f->south = NULL;
	f->north = NULL;

	return(f);
}

struct oct *
oct_new(parent,child,x,y,z,faces,childcount)
struct oct *parent;
struct children *child;
int x, y, z;
int faces;	/* if UNIT_LEVEL, initialize face ptrs, else set as is */
int childcount;	/* really char */
{
	struct oct *oct;

#ifdef ALLOC
	oct = (struct oct *)new(&oct_freelist_head);
#else
	chk(oct = new(struct oct),"oct_new: out of space");
#endif

#ifdef DEBUG
	oct->cycle = ++cycle;
#endif
	oct->parent = parent;
	oct->child = child;
	oct->bsw.x = x;
	oct->bsw.y = y;
	oct->bsw.z = z;
	if (faces == UNIT_LEVEL) {
		oct->faces.unit_level = faces_new();
#ifdef DEBUG
		cubecount++;
#endif
	} else oct->faces.count = faces;
	oct->childcount = childcount;
	return(oct);
}

/* create new root oct, given one child (which is usually old root) */
/* x,y, and z dirs indication direction to grow */
/* Return oct_root just for consistency, so we can return NULL if error */
void
oct_root_new(child,/*size,*/xdir,ydir,zdir)
struct oct *child;
/*int size;*/
enum xdir xdir;	/* indicate where to make room for new cube */
enum ydir ydir;
enum zdir zdir;
{
	struct children *root_children;
	struct oct **root_child;/* handle to child of new root */
	int south_heavy;	/* indicates of half of the child is */
	int east_heavy;		/* heavier */
	int top_heavy;

	/* create new oct to become root */
	root_children = children_new(empty);

	if (xdir == too_west && ydir == too_bottom && zdir == too_south) {
		/* special case for bootstrap - it actually works without */
		/* this but this code forces first oct to be centered */
		/* around 0,0,0 and childcount stays at 1 instead of 2 */
		oct_root = oct_new(NULLOCT,root_children,-1,-1,-1,6,1);
		oct_root->child->tne = child;
		child->parent = oct_root;
		return;
	}

	oct_root = oct_new(NULLOCT,root_children,
		child->bsw.x,child->bsw.y,child->bsw.z,
		oct_root->faces.count,1);

	/* hard part here.  decide which child it is! */
	south_heavy = (2*weight_of_children(child,SOUTH,oct_root_size)>
			oct_root->faces.count);
	east_heavy =  (2*weight_of_children(child,EAST,oct_root_size)>
			oct_root->faces.count);
	top_heavy =   (2*weight_of_children(child,TOP,oct_root_size)>
			oct_root->faces.count);

	/* update our notion of tree depth.  From here on, the root is now */
	/* twice as large */
	oct_root_size = oct_root_size * 2;

	/* There are four cases to look at in each of the 6 directions */
	/* For example, here is a bit of code that looks in the four
	   cases for the first direction.
	if (xdir == too_east) {
		if (south_heavy) {
			oct_root->bsw.z -= size;
			if (top_heavy) {
				oct_root->child->bnw = child;
			} else {
				oct_root->child->tnw = child;
				oct_root->bsw.y -= size;
			}
		} else {
			if (top_heavy) {
				oct_root->child->bsw = child;
			} else {
				oct_root->child->tsw = child;
				oct_root->bsw.y -= size;
			}
		}
	But we notice that pick_child encapsulates the same logic already.
	All we have to do is fiddle with the directions (as follows)
	and we can have pick_child do the work for us.

	Also, fix coords of oct_root while we are at it.
	Currently coords of oct_root match coords of bsw corner of child.
	So we move the oct_root coords over only in the cases that the child
	is in one of the east top or north directions.
	*/

	
	if (xdir == too_east || east_heavy) {
		xdir = west;
	} else {
		xdir = east;
		oct_root->bsw.x -= oct_root_size;
	}

	if (ydir == too_top || top_heavy) {
		ydir = bottom;
	} else {
		ydir = top;
		oct_root->bsw.y -= oct_root_size;
	}

	if (zdir == too_south || south_heavy) {
		zdir = north;
		oct_root->bsw.z -= oct_root_size;
	} else {
		zdir = south;
	}

#ifdef DEBUG
	printf("creating new root oct at %d,%d,%d  size is %d\n",
		oct_root->bsw.x,oct_root->bsw.y,oct_root->bsw.z,oct_root_size);
#endif DEBUG

	root_child = pick_child(oct_root,xdir,ydir,zdir);
	*root_child = child;
	child->parent = oct_root;	/* tell child about new parent */

	return;
}

/* VARARGS */
struct children *
children_new(type,p,size)
enum children_status type;
struct oct *p;	/* parent, this and 3rd arg only used when type == full */
int size;	/* if 0, this is unit level */
{
	struct children *child;

#ifdef ALLOC
	child = (struct children *)new(&children_freelist_head);
#else
	chk(child = new(struct children),
			"children_new: out of space");
#endif

	if (type == empty) {
		child->tne = NULL;
		child->tse = NULL;
		child->tnw = NULL;
		child->tsw = NULL;
		child->bne = NULL;
		child->bse = NULL;
		child->bnw = NULL;
		child->bsw = NULL;
	} else {
		/* full */
		int x = p->bsw.x, y = p->bsw.y, z = p->bsw.z;
		int faces = (size==1?UNIT_LEVEL:0);

		child->tne = oct_new(p,NULLCHILDREN,x+size,y+size,z+size,faces,0);
		child->tse = oct_new(p,NULLCHILDREN,x+size,y+size,z,faces,0);
		child->tnw = oct_new(p,NULLCHILDREN,x,y+size,z+size,faces,0);
		child->tsw = oct_new(p,NULLCHILDREN,x,y+size,z,faces,0);
		child->bne = oct_new(p,NULLCHILDREN,x+size,y,z+size,faces,0);
		child->bse = oct_new(p,NULLCHILDREN,x+size,y,z,faces,0);
		child->bnw = oct_new(p,NULLCHILDREN,x,y,z+size,faces,0);
		child->bsw = oct_new(p,NULLCHILDREN,x,y,z,faces,0);
	}
	return(child);
}

/* general oct finding utility */
/* starts at given oct (or root if NULL) and stops at x,y,z
   creating if appropriate

   returns oct
*/

#ifdef DEBUG
/* bound depth of oct finder */
struct oct *oct_find2();
#endif DEBUG

/* VARARGS */
struct oct *
oct_find(x,y,z,size,o,action,newsize,status)
int x, y, z;
int size;	/* size of this oct's octant, = 0 for the unit level */
struct oct *o;	/* current oct we are searching in */
enum action action;
/* following args are only used when action == bestfit */
int *newsize;
enum find_status *status;	/* how well did we do? */
{
#ifdef DEBUG
	return(oct_find2(0,x,y,z,size,o,action,newsize,status));
}

struct oct *
oct_find2(level,x,y,z,size,o,action,newsize,status)
int level;	/* for debugging */
int x, y, z;
int size;	/* size of this oct's octant, = 0 for the unit level */
struct oct *o;	/* current oct we are searching in */
enum action action;
/* following args are only used when action == bestfit */
int *newsize;
enum find_status *status;	/* how well did we do? */
{
#endif DEBUG

#ifdef DEBUG
	int cc;	/* tmp for debugging childcount */
#endif DEBUG
	enum xdir xdir;
	enum ydir ydir;
	enum zdir zdir;
	struct oct **child;	/* handle to child of oct */

	int out_of_range = FALSE;	/* TRUE if cube falls outside o */

#ifdef DEBUG
	if (level > 10) {
		printf("loop in oct_find detected...pausing\n");
		pause();
	}
#endif DEBUG

	if (o == NULL) {
		o = oct_root;
		size = oct_root_size;
	}
	/* this substitution is useful for when we are asked to find a
	   cube, this is not in the domain of the current oct_root.
	   Then our request for a bestfit will have returned NULL */

	/* found correct unit cube? */

	if (size == 0 && x == o->bsw.x && y == o->bsw.y && z == o->bsw.z) {
		if (action == bestfit) {
			if (newsize) *newsize = 0;
			if (status) *status = exact;
		}

		return(o);
	}

	/* figure out what octant we are dealing with */
	if (x < o->bsw.x + size) {
		if (x >= o->bsw.x) xdir = west;
		else {xdir = too_west; out_of_range = TRUE;}
	} else {
		if (x < o->bsw.x + 2*size) xdir = east;
		else {xdir = too_east; out_of_range = TRUE;}
	}

	if (y < o->bsw.y + size) {
		if (y >= o->bsw.y) ydir = bottom;
		else {ydir = too_bottom; out_of_range = TRUE;}
	} else {
		if (y < o->bsw.y + 2*size) ydir = top;
		else {ydir = too_top; out_of_range = TRUE;}
	}

	if (z < o->bsw.z + size) {
		if (z >= o->bsw.z) zdir = south;
		else {zdir = too_south; out_of_range = TRUE;}
	} else {
		if (z < o->bsw.z + 2*size) zdir = north;
		else {zdir = too_north; out_of_range = TRUE;}
	}

	/* deal with octs lying outside */
	if (out_of_range) {

		if (o->parent) {
			return(
#ifdef DEBUG
				oct_find2(level+1,x,y,z,
#else
				oct_find(x,y,z,
#endif
				/* force next size above 0 to be 1 */
				size == 0?1:size*2,
				o->parent,action,newsize,status));
		} else if (action == bestfit) {
			/* nowhere in tree */
			if (status) *status = failed;
			return(NULL);
		} else if (action == null) {
			/* nowhere in entire tree */
			return(NULL);
		} else { /* action == create */
			/* create new root */
			oct_root_new(oct_root,/*size,*/xdir,ydir,zdir);
			return(
#ifdef DEBUG
				oct_find2(level+1,
#else
				oct_find(
#endif
					x,y,z,size*2,oct_root,action));
		}
	}

	/* we are about to descend down to the child, so first check that */
	/* any exist */
	if (o->child == NULL) {
		switch (action) {
		case create_empty:
			o->child = children_new(empty);
			o->childcount = 0;	/* this is temporary */
			break;
		case create:
		case create_full: /* full */
			o->child = children_new(full,o,size);
/*					size==1?UNIT_LEVEL:0);*/
			o->childcount = 8;
			break;
		case bestfit:
			if (o->faces.count == 0) {
				/* within but gc'd */
				if (newsize) *newsize = size;
				if (status) *status = within;
				return(o);
			} else {
				/* doesn't exist */
				if (status) *status = failed;
				return(NULL);
			}
		case null:
			return(NULL);
		}
	}

#ifdef DEBUG
cc = ((o->child->tne != 0)
		       + (o->child->tnw != 0)
		       + (o->child->tse != 0)
		       + (o->child->tsw != 0)
		       + (o->child->bne != 0)
		       + (o->child->bnw != 0)
		       + (o->child->bse != 0)
		       + (o->child->bsw != 0));
if (o->childcount != cc) {
	printf("childcount(%d) doesn't match actual # (%d)...pausing\n",
	       o->childcount, cc);
	pause();
}
#endif DEBUG

	child = pick_child(o,xdir,ydir,zdir);

	if (*child == NULL) {
		switch (action) {
#ifdef DEBUG
		case create_full: /* can't happen */ pause();
#endif DEBUG
		case create:
		case create_empty:
			/* no such oct, so create it (empty) */
			*child = oct_new(o,NULLCHILDREN,
				o->bsw.x + (xdir == east?size:0),
				o->bsw.y + (ydir == top?size:0),
				o->bsw.z + (zdir == north?size:0),
				/* if size is 1, child is going to be a */
				/* unit-level cube and will need pointers */
				/* for faces */
				size==1?UNIT_LEVEL:0,
				0);
			action = create_empty;

			/* congratulations, you have a new child! */
			o->childcount++;
#ifdef DEBUG
			if (o->childcount > 8) {
				printf("childcount > 8...pausing\n");
				pause();
			}
#endif
			break;
		case bestfit:
			if (status) *status = failed;
			if (newsize) *newsize = size;
			return(o);
		case null:
			return(NULL);
		}
	}
	return(
#ifdef DEBUG
		oct_find2(level+1,
#else
		oct_find(
#endif
			x,y,z,size/2,*child,action,newsize,status));
}

/* given an oct and directions, returns child of oct
This routine is supposed to encapsulate all the stupid exhaustive
casing of choosing children based on x, y, z directions
*/
struct oct **
pick_child(o,xdir,ydir,zdir)
struct oct *o;
enum xdir xdir;
enum ydir ydir;
enum zdir zdir;
{
	struct oct **child;

	if (xdir == east) {
	    if (zdir == north) {
		if (ydir == top) child = &o->child->tne;
		else child = &o->child->bne;
	    } else { /* south */
		if (ydir == top) child = &o->child->tse;
		else child = &o->child->bse;
	    }
	} else { /* west */
	    if (zdir == north) {
		if (ydir == top) child = &o->child->tnw;
		else child = &o->child->bnw;
	    } else { /* south */
	        if (ydir == top) child = &o->child->tsw;
		else child = &o->child->bsw;
	    }
	}

	return(child);
}

/* return total weight of children by one level down */
/* note that this is obviously only an estimate */
weight_of_children(c,dir,size)
struct oct *c;
int dir;
int size;	/* if size is 1, then we check for face values differently */
{
	int w = 0;

	if (c->child == NULL) {
		return(face_count(c,size));
	}

	if (dir & (TOP|NORTH|WEST)) {
		if (c->child->tnw) w += face_count(c->child->tnw,size);
	}

	if (dir & (TOP|NORTH|EAST)) {
		if (c->child->tne) w += face_count(c->child->tne,size);
	}

	if (dir & (TOP|SOUTH|WEST)) {
		if (c->child->tsw) w += face_count(c->child->tsw,size);
	}

	if (dir & (TOP|SOUTH|EAST)) {
		if (c->child->tse) w += face_count(c->child->tse,size);
	}

	if (dir & (BOTTOM|NORTH|WEST)) {
		if (c->child->bnw) w += face_count(c->child->bnw,size);
	}

	if (dir & (BOTTOM|NORTH|EAST)) {
		if (c->child->bne) w += face_count(c->child->bne,size);
	}

	if (dir & (BOTTOM|SOUTH|WEST)) {
		if (c->child->bsw) w += face_count(c->child->bsw,size);
	}

	if (dir & (BOTTOM|SOUTH|EAST)) {
		if (c->child->bse) w += face_count(c->child->bse,size);
	}

	return(w);
}

void
oct_create(x,y,z,start_oct)
int x, y, z;
struct oct *start_oct;	/* unit-level cube */
{
	int new_face_count;	/* number of new faces that will be created */

	struct oct *b;	/* best fitting oct, with creating o */
	int size;	/* size of b */

	struct oct *o;	/* new unit-level oct and it's neighbors */
	struct oct *west, *east, *bottom, *top, *south, *north;

	/* find the closest oct to goal as starting point for all searches */
	b = oct_find(x,y,z,1,start_oct->parent,bestfit,&size,NULLFS);

#ifdef DEBUG
	if (b) printf("found best fitting oct(%d,%d,%d) size = %d\n",b->bsw.x,b->bsw.y,b->bsw.z,size);
	else printf("no best fitting oct\n");
#endif

	/* check our six facing neighbors */
	/* the following 6 "if"s can be done in parallel */
	if (start_oct->bsw.x == x-1) west = start_oct;
	else west = oct_find(x-1,y,z,size,b,null);

	if (start_oct->bsw.x == x+1) east = start_oct;
	else east = oct_find(x+1,y,z,size,b,null);

	if (start_oct->bsw.y == y-1) bottom = start_oct;
	else bottom = oct_find(x,y-1,z,size,b,null);

	if (start_oct->bsw.y == y+1) top = start_oct;
	else top = oct_find(x,y+1,z,size,b,null);

	if (start_oct->bsw.z == z-1) south = start_oct;
	else south = oct_find(x,y,z-1,size,b,null);

	if (start_oct->bsw.z == z+1) north = start_oct;
	else north = oct_find(x,y,z+1,size,b,null);

#ifdef DEBUG
	printf("neighbors: ");
	if (west) printf("west ");
	if (east) printf("east ");
	if (north) printf("north ");
	if (south) printf("south ");
	if (top) printf("top ");
	if (bottom) printf("bottom ");
	putchar('\n');
#endif DEBUG

	/* check R2, R3 and energy conditions */
	/* Note that these can be done in any order, or even in parallel */
	/* First should be ones that are fastest with highest probability */
	/* of rejecting operation */
	/* No need to check R1, since oct/face structure cannot generate */
	/* faces not on the surface */

	/* check surface conditions */
	new_face_count = !east + !west + !north + !south + !top + !bottom;
	if (0 == energy_check(new_face_count)) return;

	/* check for violation of R3 */
#define r3check(a,b,c,d,e,f) ((!a && !b  && c && d && e && f ) || \
			     (a && b && !c && !d && !e && !f))
	if (r3check(top,bottom,west,east,north,south)
	 || r3check(east,west,top,bottom,north,south)
	 || r3check(north,south,east,west,top,bottom)) {
		/* violated R3 */
		if (verbose) printf("violated R3\n");
		return;
	}

	/* check for violation of R2 */
	/* oct_find(...null)s can be done in parallel */
	/* R2 can be done in parallel with R3, though R3 takes little time */
	if ((!top	&& !west	&& oct_find(x-1,y+1,z,size,b,null))
	 || (!top	&& !south	&& oct_find(x,y+1,z-1,size,b,null))
	 || (!top	&& !east	&& oct_find(x+1,y+1,z,size,b,null))
	 || (!top 	&& !north	&& oct_find(x,y+1,z+1,size,b,null))
	 || (!bottom	&& !west	&& oct_find(x-1,y-1,z,size,b,null))
	 || (!bottom	&& !south	&& oct_find(x,y-1,z-1,size,b,null))
	 || (!bottom	&& !east	&& oct_find(x+1,y-1,z,size,b,null))
	 || (!bottom	&& !north	&& oct_find(x,y-1,z+1,size,b,null))
	 || (!west	&& !south	&& oct_find(x-1,y,z-1,size,b,null))
	 || (!south	&& !east	&& oct_find(x+1,y,z-1,size,b,null))
	 || (!east	&& !north	&& oct_find(x+1,y,z+1,size,b,null))
	 || (!north	&& !west	&& oct_find(x-1,y,z+1,size,b,null))) {
		/* violated R2 */
		if (verbose) printf("violated R2\n");
		return;
	}

	/* cube has now passed R1, R2, R3 and energy conditions */

	/* create unit-level oct */
	o = oct_find(x,y,z,size,b,create);
	/* install the faces */

	/* propagate addition in faces up through our ancestors */
	/* note that this must precede face deletions below, which */
	/* might prematurely unlink our parent */
	/* This call to unoct_c will never gc and therefore could be */
	/* replaced with a simpler, more efficient routine */
	unoct_c(o->parent,new_face_count,PARENT_OF_UNIT_LEVEL);

	/* for each neighbor that exists, reset the face bordering "o" */
	/* so that it is no longer on the surface.  If the neighbor */
	/* doesn't exist, mark "o" as being on the surface. */

	if (bottom) oct_face_reset(bottom,TOP);
	else o->faces.unit_level->bottom = face_new(o,BOTTOM);

	if (top) oct_face_reset(top,BOTTOM);
	else o->faces.unit_level->top = face_new(o,TOP);

	if (south) oct_face_reset(south,NORTH);
	else o->faces.unit_level->south = face_new(o,SOUTH);

	if (north) oct_face_reset(north,SOUTH);
	else o->faces.unit_level->north = face_new(o,NORTH);

	if (east) oct_face_reset(east,WEST);
	else o->faces.unit_level->east = face_new(o,EAST);

	if (west) oct_face_reset(west,EAST);
	else o->faces.unit_level->west = face_new(o,WEST);

#if 0
	/* can no longer be used with oct_delete */
	vol_record(x,y,z);
#endif

	return;	/* was return(o) */
}

void
oct_delete(o)
struct oct *o;
{
	int new_face_count; /* count of new faces that will be created */

	/* all of the following are for convenience and efficiency only */
	struct oct *op = o->parent;
	struct face *wface = o->faces.unit_level->west;
	struct face *eface = o->faces.unit_level->east;
	struct face *nface = o->faces.unit_level->north;
	struct face *sface = o->faces.unit_level->south;
	struct face *tface = o->faces.unit_level->top;
	struct face *bface = o->faces.unit_level->bottom;
	int x = o->bsw.x;
	int y = o->bsw.y;
	int z = o->bsw.z;

	enum find_status tmpstatus;		/* for #within macro */

	if (surface == 6) {
		if (verbose) printf("attempt to delete last cube rejected\n");
		return;
	}

	/* check R2, R3 and energy conditions */
	/* Note that these can be done in any order, or even in parallel */
	/* First should be ones that are fastest with highest probability */
	/* of rejecting operation */
	/* No need to check R1, since oct/face structure can not generate */
	/* faces not on the surface */

	/* check surface conditions */
	new_face_count = !eface + !wface + !nface + !sface + !tface + !bface;
	if (0 == energy_check(new_face_count)) return;

	/* check for violation of R3 */
	/* no need to check faces, because we are guaranteed by its
	   existence, that its face facing towards o is on the surface */
	if (r3check(tface,bface,wface,eface,nface,sface)
	 || r3check(eface,wface,tface,bface,nface,sface)
	 || r3check(nface,sface,eface,wface,tface,bface)) {
		/* violated R3 */
		if (verbose) printf("violated R3\n");
		return;
	}

	/* neighbor checking here is slightly more complicated then when */
	/* creating a cube because neighboring octs may possibly not be */
	/* on the surface */

	/* Thus, we must search using bestfit instead of null */

#define within(x,y,z) \
	(oct_find(x,y,z,1,op,bestfit,(int *)0,&tmpstatus) && \
		tmpstatus != failed)

	/* check for violation of R2 */
	/* all within's can be done in parallel as can R3 with R2 */
	if ((!tface && !wface && !within(x-1,y+1,z))
	 || (!tface && !sface && !within(x,y+1,z-1))
	 || (!tface && !eface && !within(x+1,y+1,z))
	 || (!tface && !nface && !within(x,y+1,z+1))
	 || (!bface && !wface && !within(x-1,y-1,z))
	 || (!bface && !sface && !within(x,y-1,z-1))
	 || (!bface && !eface && !within(x+1,y-1,z))
	 || (!bface && !nface && !within(x,y-1,z+1))
	 || (!wface && !sface && !within(x-1,y,z-1))
	 || (!sface && !eface && !within(x+1,y,z-1))
	 || (!eface && !nface && !within(x+1,y,z+1))
	 || (!nface && !wface && !within(x-1,y,z+1))) {
		/* violated R2 */
		if (verbose) printf("violated R2\n");
		return;
	}

	/* we've now passed R1, R2, R3 and energy conditions */

	/* give up faces */
	if (!bface) oct_face_set(TOP,x,y-1,z,op);
	else face_delete(&o->faces.unit_level->bottom);

	if (!tface) oct_face_set(BOTTOM,x,y+1,z,op);
	else face_delete(&o->faces.unit_level->top);

	if (!eface) oct_face_set(WEST,x+1,y,z,op);
	else face_delete(&o->faces.unit_level->east);

	if (!wface) oct_face_set(EAST,x-1,y,z,op);
	else face_delete(&o->faces.unit_level->west);

	if (!nface) oct_face_set(SOUTH,x,y,z+1,op);
	else face_delete(&o->faces.unit_level->north);

	if (!sface) oct_face_set(NORTH,x,y,z-1,op);
	else face_delete(&o->faces.unit_level->south);

	/* While unoct_c may get called upon o during oct_face_reset, it */
	/* will not cause any harm.  since if the parent childcount == 8, */
	/* then one of the children will have inherited an surface, and */
	/* faces.count will be non-zero */

	/* This cube is no longer in the volume so destroy it */
	gc_volume(o,new_face_count-6,UNIT_LEVEL);
}

/* always starts with a unit-level oct that is being destroyed, and */
/* proceeds upwards looking to collapse nodes that are thus no longer */
/* any part of the volume */
gc_volume(o,df,level_type)
struct oct *o;
int df;
int level_type;		/* unit_level or not */
{
	if (level_type == UNIT_LEVEL) {
		destroy_faces(o->faces.unit_level);
	} else {
#ifdef DEBUG
		if (o->faces.count < 0) {
			printf("faces.count < 0...pausing\n");
			pause();
		}
#endif DEBUG

		o->faces.count += df;

#ifdef DEBUG
		if (o->faces.count < 0) {
			printf("faces.count < 0...pausing\n");
			pause();
		}
#endif DEBUG
	}

	if (o->childcount == 0) {
		/* detach ourselves from the parent */
		if      (o->parent->child->tne == o) o->parent->child->tne = NULL;
		else if (o->parent->child->tse == o) o->parent->child->tse = NULL;
		else if (o->parent->child->tnw == o) o->parent->child->tnw = NULL;
		else if (o->parent->child->tsw == o) o->parent->child->tsw = NULL;
		else if (o->parent->child->bne == o) o->parent->child->bne = NULL;
		else if (o->parent->child->bse == o) o->parent->child->bse = NULL;
		else if (o->parent->child->bnw == o) o->parent->child->bnw = NULL;
		else				     o->parent->child->bsw = NULL;

		o->parent->childcount--;

		gc_volume(o->parent,df,!UNIT_LEVEL);
#ifdef DEBUG
		if (o->faces.count < 0) {
			printf("faces.count < 0...pausing\n");
			pause();
		}
#endif DEBUG
		/* release remaining storage */
		if (o->child) destroy_children(o->child);
		destroy_oct(o);
	} else {
		/* propagate df up through ancestors */
		for (o = o->parent;o;o = o->parent) {
			o->faces.count += df;
		}
	}
}

/* utility routine demanded by face maintainer */
/* given oct and direction, change face it points to */
oct_face_change(o,dir,face)
struct oct *o;
int dir;
struct face *face;
{
	switch (dir) {
	case EAST: o->faces.unit_level->east = face; break;
	case WEST: o->faces.unit_level->west = face; break;
	case NORTH: o->faces.unit_level->north = face; break;
	case SOUTH: o->faces.unit_level->south = face; break;
	case TOP: o->faces.unit_level->top = face; break;
	case BOTTOM: o->faces.unit_level->bottom = face; break;
	}
}

/* mark this oct as having a face in this direction */
/* VARARGS */
oct_face_set(dir,x,y,z,start_oct)
int dir;
/* remaining parameters are only used if find_status == within */
int x,y,z;	/* coordinate of final oct */
struct oct *start_oct;	/* assumed to be parent of unit-level oct!!! */
{
	struct oct *o;

	o = oct_find(x,y,z,1,start_oct,create);

	switch (dir) {
	case EAST: o->faces.unit_level->east = face_new(o,dir); break;
	case WEST: o->faces.unit_level->west = face_new(o,dir); break;
	case NORTH: o->faces.unit_level->north = face_new(o,dir); break;
	case SOUTH: o->faces.unit_level->south = face_new(o,dir); break;
	case TOP: o->faces.unit_level->top = face_new(o,dir); break;
	case BOTTOM: o->faces.unit_level->bottom = face_new(o,dir); break;
	}

	unoct_c(o->parent,1,PARENT_OF_UNIT_LEVEL);
}

/* mark this oct as not having a face in this direction */
oct_face_reset(o,dir)
struct oct *o;
int dir;
{
	switch (dir) {
	case EAST:	face_delete(&o->faces.unit_level->east);	break;
	case WEST:	face_delete(&o->faces.unit_level->west);	break;
	case NORTH:	face_delete(&o->faces.unit_level->north);	break;
	case SOUTH:	face_delete(&o->faces.unit_level->south);	break;
	case TOP:	face_delete(&o->faces.unit_level->top);		break;
	case BOTTOM:	face_delete(&o->faces.unit_level->bottom);	break;
	}

#ifdef DEBUG
	if ((o->parent->faces.count - 1 == 0)
	    && (o->parent->childcount == 8)) {
		cubecount -= 8;
	}
#endif DEBUG

	unoct_c(o->parent,-1,PARENT_OF_UNIT_LEVEL);
}

/* version of unoct used during oct_create. */
/* Should only be called on non-unit-level cubes. */
unoct_c(o,df,type)
struct oct *o;
int df;		/* change in face counts */
int type;
{
	if (o == NULL) return;	/* hit root */

#ifdef DEBUG
	if (o->faces.count < 0) {
		printf("faces.count < 0...pausing\n");
		pause();
	}
#endif DEBUG

	o->faces.count += df;

#ifdef DEBUG
	if (o->faces.count < 0) {
		printf("faces.count < 0...pausing\n");
		pause();
	}
#endif DEBUG

	if (o->faces.count == 0) {
		if (o->childcount == 8) {
			/* the only possible way this could happen is */
			/* if all children have 0 face counts.  e.g. */
			/* assert o->child->tnw->faces.count == 0 */
			if (type == PARENT_OF_UNIT_LEVEL) {
				destroy_faces(o->child->tnw->faces.unit_level);
				destroy_faces(o->child->tne->faces.unit_level);
				destroy_faces(o->child->tsw->faces.unit_level);
				destroy_faces(o->child->tse->faces.unit_level);
				destroy_faces(o->child->bnw->faces.unit_level);
				destroy_faces(o->child->bne->faces.unit_level);
				destroy_faces(o->child->bsw->faces.unit_level);
				destroy_faces(o->child->bse->faces.unit_level);
			}
			destroy_oct(o->child->tnw);
			destroy_oct(o->child->tne);
			destroy_oct(o->child->tsw);
			destroy_oct(o->child->tse);
			destroy_oct(o->child->bnw);
			destroy_oct(o->child->bne);
			destroy_oct(o->child->bsw);
			destroy_oct(o->child->bse);
			destroy_children(o->child);
			o->child = NULL;
			o->childcount = 0;
			unoct_c(o->parent,df,!PARENT_OF_UNIT_LEVEL);
		} /* else childcount == 0 */
	} else {
		/* finish propagation of df through remaining ancestors */
		for (o = o->parent;o;o = o->parent) {
			o->faces.count += df;
		}
	}
}
