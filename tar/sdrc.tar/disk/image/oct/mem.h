/* mem.h - defs for fixed size block memory allocator */

typedef long Align;

union freelist {
	union freelist *next;	/* next block on freelist */
	char memory;		/* user data */
	Align aligner;		/* force alignment of blocks */
};

typedef union freelist Freelist;

#ifdef __STDC__
#include <stdlib.h>
typedef size_t size_type;
#else
typedef int size_type;
void *malloc();
#endif

struct freelist_head {
	size_type size;		/* size of a single elt incl. next ptr */
	size_type bytes;	/* if we run out, allocate memory by this
				   many bytes */
	Freelist *freelist;
#if SPACE_PROFILE
	int count;
#endif
};

char *sbrk();
char *new();
