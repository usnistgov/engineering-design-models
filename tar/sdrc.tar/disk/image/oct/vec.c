/* vec.c - vector functions for graphics */

void
makevec(v, x, y, z)
  float v[3];
  float x, y, z;
{
  v[0] = x;
  v[1] = y;
  v[2] = z;
}

void
negvec(v)
  float v[3];
{
  v[0] = -v[0];
  v[1] = -v[1];
  v[2] = -v[2];
}

void
subvec(c, a, b)
  float c[3], a[3], b[3];
{
  c[0] = a[0] - b[0];
  c[1] = a[1] - b[1];
  c[2] = a[2] - b[2];
}

double
vnorm(v)
  float v[3];
{
  double d;
  double sqrt();
  d = sqrt((v[0]*v[0])+(v[1]*v[1])+(v[2]*v[2]));
  return(d);
}

void
norvec(v)
  float v[3];
{
  double d;
  d = vnorm(v);
  if (d != 0.0) {
    v[0] = v[0]/d;
    v[1] = v[1]/d;
    v[2] = v[2]/d;
}
}
