/* canv.c - Create a window and canvas to draw octs on */

#include <suntool/sunview.h>
#include <suntool/panel.h>
#include <suntool/canvas.h>
#include <sunwindow/window_hs.h>
#include <usercore.h>

#include "face.h"
#include "oct.h"

#define WINDOW_LABEL	"oct tree & random surface viewer - Don Libes, NIST"
static short icon_image[] = {
#include "oct.icon"
};
DEFINE_ICON_FROM_IMAGE(oct_icon,icon_image);

int pixwindd();
struct vwsurf vsurf = DEFAULT_VWSURF(pixwindd);

static void view_proc();
static void quit_proc();
static void draw_proc();
static void surface_proc();
extern int hide, uflag;

static void scale_proc();
extern float scale;
Panel_item scale_item;

static int first_time_drawn;

Frame frame;
Panel ppanel, qpanel;
Panel_item px_item, py_item, pz_item;
Canvas canvas;
Pixfont *bold;
Pixwin *pw;
struct screen screen;
char name[WIN_NAMESIZE];

extern float px, py, pz;

draw_octs()
{
	char infostring[80];
	extern float beta;
	extern int perspective;
	extern int surface, cycles;
	char px_item_buf[80], py_item_buf[80], pz_item_buf[80];
	char scale_item_buf[80];

	bold = pf_open("/usr/lib/fonts/fixedwidthfonts/screen.b.12");
	if (bold == NULL) exit(1);

	frame = window_create(NULL, FRAME,
			FRAME_LABEL,		WINDOW_LABEL,
			FRAME_ICON,		&oct_icon,
			WIN_ERROR_MSG,		"Can't create window.",
			0);

	qpanel = window_create(frame, PANEL, WIN_FONT, bold, 0);
	panel_create_item(qpanel, PANEL_BUTTON,
		PANEL_LABEL_IMAGE, panel_button_image(qpanel, "Draw", 0, 0),
		PANEL_ITEM_Y,ATTR_ROW(0),
		PANEL_NOTIFY_PROC, draw_proc, 0);

	panel_create_item(qpanel, PANEL_BUTTON,
		PANEL_LABEL_IMAGE, panel_button_image(qpanel, "Quit", 0, 0),
		PANEL_ITEM_Y,ATTR_ROW(0),
		PANEL_NOTIFY_PROC, quit_proc, 0);

	scale_item = panel_create_item(qpanel, PANEL_TEXT,
		PANEL_LABEL_STRING, "scale (.01-100):",
		PANEL_VALUE_DISPLAY_LENGTH,10,0);
	sprintf(scale_item_buf,"%g",scale);
	panel_set_value(scale_item,scale_item_buf);

	panel_create_item(qpanel, PANEL_CHOICE,
		PANEL_LABEL_STRING, "projection:",
		PANEL_CHOICE_STRINGS, "parallel", "perspective", 0,
		PANEL_DISPLAY_LEVEL, PANEL_CURRENT,
		PANEL_ITEM_Y,ATTR_ROW(1) + 2,
		PANEL_ITEM_X,0,
		PANEL_NOTIFY_PROC, view_proc, 0);

	panel_create_item(qpanel, PANEL_CHOICE,
		PANEL_LABEL_STRING, "surface:",
		PANEL_CHOICE_STRINGS, "cubes", "hidden", "oct tree", 0,
		PANEL_DISPLAY_LEVEL, PANEL_CURRENT,
		PANEL_ITEM_Y,ATTR_ROW(1) + 2,
		PANEL_NOTIFY_PROC, surface_proc, 0);

	sprintf(infostring,"|S| = %d  cycles = %d  beta = %.3f",
		surface,cycles,beta);
	panel_create_item(qpanel, PANEL_MESSAGE,
		PANEL_ITEM_Y,ATTR_ROW(2) + 3,
		PANEL_ITEM_X,0,
		PANEL_LABEL_STRING, infostring, 0);

	ppanel = window_create(frame, PANEL, WIN_FONT, bold, 
		WIN_RIGHT_OF, qpanel,0);

	panel_create_item(ppanel,PANEL_MESSAGE,
		PANEL_LABEL_STRING, "viewpoint              ",0);
		/* pad out window a bit to make canvas large */
	
	px_item = panel_create_item(ppanel,PANEL_TEXT,
		PANEL_LABEL_STRING,"x:",
		PANEL_ITEM_Y,ATTR_ROW(1) - 6,
		PANEL_VALUE_DISPLAY_LENGTH,10,0);
	py_item = panel_create_item(ppanel,PANEL_TEXT,
		PANEL_LABEL_STRING,"y:",
		PANEL_ITEM_Y,ATTR_ROW(2) - 12,
		PANEL_VALUE_DISPLAY_LENGTH,10,0);
	pz_item = panel_create_item(ppanel,PANEL_TEXT,
		PANEL_LABEL_STRING,"z:",
		PANEL_ITEM_Y,ATTR_ROW(3) - 18,
		PANEL_VALUE_DISPLAY_LENGTH,10,0);
	sprintf(px_item_buf,"%g",px);
	sprintf(py_item_buf,"%g",py);
	sprintf(pz_item_buf,"%g",pz);
	panel_set_value(px_item,px_item_buf);
	panel_set_value(py_item,py_item_buf);
	panel_set_value(pz_item,pz_item_buf);

	canvas = window_create(frame, CANVAS,0);
	window_set(canvas,WIN_WIDTH,WIN_EXTEND_TO_EDGE,0);

	window_fit(ppanel);
	window_fit(qpanel);

	window_set(ppanel,WIN_RIGHT_OF,qpanel,0);
	window_set(ppanel,WIN_Y,0,0);

	window_set(canvas,WIN_X,0,0);
	window_set(canvas,WIN_BELOW,ppanel,0);
	window_fit_width(frame);

	window_set(canvas,WIN_WIDTH,WIN_EXTEND_TO_EDGE,0);
	window_set(canvas,WIN_HEIGHT,(int)window_get(canvas,WIN_WIDTH),0);
	window_set(canvas,CANVAS_HEIGHT,1000,0);
	window_set(canvas,CANVAS_WIDTH,1000,0);
	window_fit(canvas);

	window_fit_height(frame);

	pw = canvas_pixwin(canvas);

	first_time_drawn = TRUE;
	window_main_loop(frame);
}

static void scale_proc(item,value,event)
Panel_item item;
int value;
Event *event;
{
	scale = value/2.0;
}

static void view_proc(item,value,event)
Panel_item item;
int value;
Event *event;
{
	switch (value) {
	case 0:
		perspective = FALSE;
		break;
	case 1:
		perspective = TRUE;
		break;
	}
}

static void surface_proc(item,value,event)
Panel_item item;
int value;
Event *event;
{
	switch (value) {
	case 0:	/* cubes */
		hide = FALSE;
		uflag = 1;
		break;
	case 1:
		hide = TRUE;
		break;
	case 2:
		hide = FALSE;
		uflag = 0;
		break;
	}
}

static void quit_proc()
{
	if (!first_time_drawn) close_graphics();
	window_set(frame, FRAME_NO_CONFIRM, TRUE, 0);
	window_destroy(frame);
}

static void draw_proc()
{
	char win_name[30];
	extern double atof();

	win_fdtoname(win_get_fd(canvas),win_name);
	if (first_time_drawn) first_time_drawn = FALSE;
	else close_graphics();

	px = atof((char *)panel_get_value(px_item));
	py = atof((char *)panel_get_value(py_item));
	pz = atof((char *)panel_get_value(pz_item));
	scale = 1.0/atof((char *)panel_get_value(scale_item));
	init_graphics(win_get_fd(canvas),win_name);
	draw_all_octs();
}
