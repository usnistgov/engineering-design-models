/* drawfns - functions to draw oct trees using Sun Core */

#define TRUE 1
#define FALSE 0

#include <stdio.h>
#include <math.h>

/* all just for screen */
#include <suntool/sunview.h>
#include <suntool/panel.h>
#include <suntool/canvas.h>
#include <sunwindow/window_hs.h>

#include <usercore.h>
#include "face.h"
#include "oct.h"

int pixwindd();
static struct vwsurf vsurf = DEFAULT_VWSURF(pixwindd);

/*************************************************************************/
/* init_graphics
/*	This is called after allocating the frame and
/*	subwindows; the idea here is to startup Suncore and attach it
/*	to Sunview so that we can draw on the Sunview canvas.
/*	Makes a call to the Suncore initialize_core routine;if this fails
/*	we abort. Otherwise fill in the elements of the view surf
/*	structure corresponding to the canvas window file descriptor and
/*	the canvas window name (e.g. /dev/win5); these values are
/*	obtained in the main program via Sunview inquiries on the canvas
/*	after the canvas is allocated. Now when the Suncore
/*	initialize_view_surface is called it is ensured that the view
/*	surface we want to be drawing on will be the canvas we previously
/*	got from Sunview. If all that doesn't kill we
/*	finally do some minimal setup of the viewing params.
/*************************************************************************/
struct screen screen;

struct {
	float vwrefpt[3];
	float vwplnorm[3];
	float viewdis;
	float frontdis;
	float backdis;
	int projtype;
	float projdir[3];
	float window[4];
	float vwupdir[3];
	float viewport[6];
} view_parms = {
	0.0, 0.0, 0.0,		/* view reference point */
	0.0, 0.0, -1.0,		/* view plane normal */
	0.0,			/* view distance */
	0.0,			/* front distance */
	100.0,			/* back distance */
	0,			/* projection type */
	0.0, 0.0, 0.0,		/* projection dir */
	0.0, 1.0, 0.0, 1.0,	/* window coords in uv-space */
	0.0, 1.0, 0.0,		/* view up direction */
	0.0, 1.0, 0.0, 1.0, 0.0, 1.0	/* view port */
};

void
init_graphics(win_fd, win_name)
  int win_fd;
  char win_name[];
{
  if (initialize_core(DYNAMICB, SYNCHRONOUS, THREED)) abort();

  vsurf.windowfd = win_fd;
  win_screenget(vsurf.windowfd,&screen);
  strncpy(vsurf.screenname,screen.scr_fbname,DEVNAMESIZE);
  strcpy(vsurf.windowname, win_name);

  vsurf.instance = 0;	/* manuals claim this will be done by init_core  ha */
  if (initialize_view_surface(&vsurf, FALSE)) abort();

  if (select_view_surface(&vsurf)) abort();

  set_ndc_space_3(1.0, 1.0, 1.0);
  set_coordinate_system_type(RIGHT);

  /* don't know why, but this has to be after set_ndc_space..() */
  initialize_device(LOCATOR,1);
  set_echo_surface(LOCATOR,1,&vsurf);
  set_echo(LOCATOR,1,1);
}

/*************************************************************************/
/* close_graphics							 */
/*	Supposed to shutdown suncore stuff in an orderly manner.	 */
/*	Called when quitting window
/*************************************************************************/
void
close_graphics()
{
  terminate_device(LOCATOR,1);

  deselect_view_surface(&vsurf);
  terminate_view_surface(&vsurf);
  terminate_core();
}

extern int hide;	/* if true, do hidden surface routine */

float radius;
float scale = 1.0;

void
draw_all_octs()
{
	extern int perspective;
	extern float px, py, pz;
	extern double vnorm();


	makevec(view_parms.projdir,px,py,pz);
	subvec(view_parms.vwplnorm,view_parms.projdir,view_parms.vwrefpt);
	norvec(view_parms.vwplnorm);
	negvec(view_parms.vwplnorm);

	if (perspective) {
		view_parms.projtype = PERSPECTIVE;
	} else {
		view_parms.projtype = PARALLEL;
		negvec(view_parms.projdir);
	}
	radius = vnorm(view_parms.projdir) * scale;
	view_parms.window[0] = -radius;
	view_parms.window[1] = radius;
	view_parms.window[2] = -radius;
	view_parms.window[3] = radius;

	set_viewing_parameters(&view_parms);

	/* amazing facts: Sun Core won't give accurate return codes for
	   create_temporary_segment, even though it will blather all over
	   stderr.  So we use create_retained_segment just to check that
	   the view spec is ok.  Sheesh!
	*/
	if (0 != create_retained_segment(1)) return;
	close_retained_segment(1);
	delete_all_retained_segments();
	create_temporary_segment();
	draw_axis();
	if (hide == 1) draw_faces();
	else draw_oct(oct_root,oct_root_size,0);
	close_temporary_segment();
}

draw_axis()
{
	move_abs_3(0.,0.,0.);
	line_abs_3(radius/2.0,0.,0.);
	text("x");
	move_abs_3(0.,0.,0.);
	line_abs_3(0.,radius/2.0,0.);
	text("y");
	move_abs_3(0.,0.,0.);
	line_abs_3(0.,0.,-(radius/2.0));
	text("z");
}

draw_oct(o,size,depth)
struct oct *o;
int size;
int depth;
{
	extern int show_surface;
	struct children *child;
	struct coord3 *bsw;
	float x,y,z, s2;

	float df;	/* depth factor */
	extern int uflag;

	if (!o) return;
	x = o->bsw.x;
	y = o->bsw.y;
	z = o->bsw.z;
	s2 = (size == 0?1:size*2);
	df = depth*.125;

	if (s2 == 1 && show_surface) {
		if (!o->faces.unit_level->bottom == !o->faces.unit_level->south) {
			move_abs_3(x,y,-z);
			line_abs_3(x+s2,y,-z);
		}
		if (!o->faces.unit_level->bottom == !o->faces.unit_level->east) {
			move_abs_3(x+s2,y,-z);
			line_abs_3(x+s2,y,-(z+s2));
		}
		if (!o->faces.unit_level->bottom == !o->faces.unit_level->north) {
			move_abs_3(x+s2,y,-(z+s2));
			line_abs_3(x,y,-(z+s2));
		}
		if (!o->faces.unit_level->bottom == !o->faces.unit_level->west) {
			move_abs_3(x,y,-(z+s2));
			line_abs_3(x,y,-z);
		}

		if (!o->faces.unit_level->top == !o->faces.unit_level->south) {
			move_abs_3(x,y+s2,-z);
			line_abs_3(x+s2,y+s2,-z);
		}
		if (!o->faces.unit_level->top == !o->faces.unit_level->east) {
			move_abs_3(x+s2,y+s2,-z);
			line_abs_3(x+s2,y+s2,-(z+s2));
		}
		if (!o->faces.unit_level->top == !o->faces.unit_level->north) {
			move_abs_3(x+s2,y+s2,-(z+s2));
			line_abs_3(x,y+s2,-(z+s2));
		}
		if (!o->faces.unit_level->top == !o->faces.unit_level->west) {
			move_abs_3(x,y+s2,-(z+s2));
			line_abs_3(x,y+s2,-z);
		}

		if (!o->faces.unit_level->west == !o->faces.unit_level->south) {
			move_abs_3(x,y,-z);
			line_abs_3(x,y+s2,-z);
		}
		if (!o->faces.unit_level->west == !o->faces.unit_level->top) {
			move_abs_3(x,y+s2,-z);
			line_abs_3(x,y+s2,-(z+s2));
		}
		if (!o->faces.unit_level->west == !o->faces.unit_level->north) {
			move_abs_3(x,y+s2,-(z+s2));
			line_abs_3(x,y,-(z+s2));
		}
		if (!o->faces.unit_level->west == !o->faces.unit_level->bottom) {
			move_abs_3(x,y,-(z+s2));
			line_abs_3(x,y,-z);
		}

		if (!o->faces.unit_level->east == !o->faces.unit_level->south) {
			move_abs_3(x+s2,y,-z);
			line_abs_3(x+s2,y+s2,-z);
		}
		if (!o->faces.unit_level->east == !o->faces.unit_level->top) {
			move_abs_3(x+s2,y+s2,-z);
			line_abs_3(x+s2,y+s2,-(z+s2));
		}
		if (!o->faces.unit_level->east == !o->faces.unit_level->north) {
			move_abs_3(x+s2,y+s2,-(z+s2));
			line_abs_3(x+s2,y,-(z+s2));
		}
		if (!o->faces.unit_level->east == !o->faces.unit_level->bottom) {
			move_abs_3(x+s2,y,-(z+s2));
			line_abs_3(x+s2,y,-z);
		}

		if (!o->faces.unit_level->south == !o->faces.unit_level->bottom) {
			move_abs_3(x,y,-z);
			line_abs_3(x+s2,y,-z);
		}
		if (!o->faces.unit_level->south == !o->faces.unit_level->east) {
			move_abs_3(x+s2,y,-z);
			line_abs_3(x+s2,y+s2,-z);
		}
		if (!o->faces.unit_level->south == !o->faces.unit_level->top) {
			move_abs_3(x+s2,y+s2,-z);
			line_abs_3(x,y+s2,-z);
		}
		if (!o->faces.unit_level->south == !o->faces.unit_level->west) {
			move_abs_3(x,y+s2,-z);
			line_abs_3(x,y,-z);
		}

		if (!o->faces.unit_level->north == !o->faces.unit_level->bottom) {
			move_abs_3(x,y,-(z+s2));
			line_abs_3(x+s2,y,-(z+s2));
		}
		if (!o->faces.unit_level->north == !o->faces.unit_level->east) {
			move_abs_3(x+s2,y,-(z+s2));
			line_abs_3(x+s2,y+s2,-(z+s2));
		}
		if (!o->faces.unit_level->north == !o->faces.unit_level->top) {
			move_abs_3(x+s2,y+s2,-(z+s2));
			line_abs_3(x,y+s2,-(z+s2));
		}
		if (!o->faces.unit_level->north == !o->faces.unit_level->west) {
			move_abs_3(x,y+s2,-(z+s2));
			line_abs_3(x,y,-(z+s2));
		}

	} else if ((s2 == 1 || uflag == 0 || o->child == 0)) {
		if (uflag && s2 == 1) df = .125;
		move_abs_3(x+df,y+df,-(z+df));
		line_abs_3(x+s2-df,y+df,-(z+df));
		line_abs_3(x+s2-df,y+s2-df,-(z+df));
		line_abs_3(x+df,y+s2-df,-(z+df));
		line_abs_3(x+df,y+df,-(z+df));
		line_abs_3(x+df,y+df,-(z+s2-df));
		line_abs_3(x+s2-df,y+df,-(z+s2-df));
		line_abs_3(x+s2-df,y+s2-df,-(z+s2-df));
		line_abs_3(x+df,y+s2-df,-(z+s2-df));
		line_abs_3(x+df,y+df,-(z+s2-df));
		move_abs_3(x+s2-df,y+df,-(z+df));
		line_abs_3(x+s2-df,y+df,-(z+s2-df));
		move_abs_3(x+s2-df,y+s2-df,-(z+df));
		line_abs_3(x+s2-df,y+s2-df,-(z+s2-df));
		move_abs_3(x+df,y+s2-df,-(z+df));
		line_abs_3(x+df,y+s2-df,-(z+s2-df));
	}

	if (0 == (child = o->child)) return;
	draw_oct(child->tnw,size/2,depth+1);
	draw_oct(child->tne,size/2,depth+1);
	draw_oct(child->tsw,size/2,depth+1);
	draw_oct(child->tse,size/2,depth+1);
	draw_oct(child->bnw,size/2,depth+1);
	draw_oct(child->bne,size/2,depth+1);
	draw_oct(child->bsw,size/2,depth+1);
	draw_oct(child->bse,size/2,depth+1);
}

facecmp(f,g)
struct face **f, **g;
{
	double fx, fy, fz, gx, gy, gz;
	double fdist, gdist;

	face_center(*f,&fx,&fy,&fz);
	face_center(*g,&gx,&gy,&gz);

	fdist = (fx - px) * (fx - px) +
		(fy - py) * (fy - py) +
		(fz + pz) * (fz + pz);
	gdist = (gx - px) * (gx - px) +
		(gy - py) * (gy - py) +
		(gz + pz) * (gz + pz);
	return(fdist<gdist);
}

draw_faces()
{
	struct face **sorted_faces;
	extern struct face *faces;
	int i;

	/* set up new array to hold sorted faces */
	sorted_faces = (struct face **)malloc(surface*sizeof(struct face *));

	for (i=0;i<surface;i++) {
		sorted_faces[i] = &faces[i];
	}

	qsort(sorted_faces,surface,sizeof(struct face *),facecmp);

	for (i=0;i<surface;i++) {
		draw_face(sorted_faces[i]);
	}
	free(sorted_faces);
}

#include "dir.h"

/* original */
draw_face(f)
struct face *f;
{
	extern int fill_index;	/* temp while selecting textures */
	float x[5], y[5], z[5];
	/* convert face to Suncore-style polygon */
	struct coord3 *bsw = &f->oct->bsw;
	extern int fill_index_east, fill_index_top, fill_index_south;
	extern int fill_index_west, fill_index_bottom;

	switch (f->dir) {
	case SOUTH:
		if (!perspective && view_parms.projdir[2] >= 0) return;
		set_fill_index(fill_index_south);
		x[0] = bsw->x;y[0] = bsw->y;z[0] = -bsw->z;
		x[1] = bsw->x+1;y[1] = bsw->y;z[1] = -bsw->z;
		x[2] = bsw->x+1;y[2] = bsw->y+1;z[2] = -bsw->z;
		x[3] = bsw->x;y[3] = bsw->y+1;z[3] = -bsw->z;
		break;
	case NORTH:
		if (!perspective && view_parms.projdir[2] <= 0) return;
		set_fill_index(fill_index_south); /* rarely shown anyway */
		x[0] = bsw->x;y[0] = bsw->y;z[0] = -(bsw->z+1);
		x[1] = bsw->x+1;y[1] = bsw->y;z[1] = -(bsw->z+1);
		x[2] = bsw->x+1;y[2] = bsw->y+1;z[2] = -(bsw->z+1);
		x[3] = bsw->x;y[3] = bsw->y+1;z[3] = -(bsw->z+1);
		break;
	case EAST:
		if (!perspective && view_parms.projdir[0] >= 0) return;
		set_fill_index(fill_index_east);
		x[0] = bsw->x+1;y[0] = bsw->y;z[0] = -bsw->z;
		x[1] = bsw->x+1;y[1] = bsw->y;z[1] = -(bsw->z+1);
		x[2] = bsw->x+1;y[2] = bsw->y+1;z[2] = -(bsw->z+1);
		x[3] = bsw->x+1;y[3] = bsw->y+1;z[3] = -bsw->z;
		break;
	case WEST:
		if (!perspective && view_parms.projdir[0] <= 0) return;
		set_fill_index(fill_index_west);
		x[0] = bsw->x;y[0] = bsw->y;z[0] = -bsw->z;
		x[1] = bsw->x;y[1] = bsw->y;z[1] = -(bsw->z+1);
		x[2] = bsw->x;y[2] = bsw->y+1;z[2] = -(bsw->z+1);
		x[3] = bsw->x;y[3] = bsw->y+1;z[3] = -bsw->z;
		break;
	case TOP:
		if (!perspective && view_parms.projdir[1] >= 0) return;
		set_fill_index(fill_index_top);
		x[0] = bsw->x;y[0] = bsw->y+1;z[0] = -bsw->z;
		x[1] = bsw->x+1;y[1] = bsw->y+1;z[1] = -bsw->z;
		x[2] = bsw->x+1;y[2] = bsw->y+1;z[2] = -(bsw->z+1);
		x[3] = bsw->x;y[3] = bsw->y+1;z[3] = -(bsw->z+1);
		break;
	case BOTTOM:
		if (!perspective && view_parms.projdir[1] <= 0) return;
		set_fill_index(fill_index_bottom);
		x[0] = bsw->x;y[0] = bsw->y;z[0] = -bsw->z;
		x[1] = bsw->x+1;y[1] = bsw->y;z[1] = -bsw->z;
		x[2] = bsw->x+1;y[2] = bsw->y;z[2] = -(bsw->z+1);
		x[3] = bsw->x;y[3] = bsw->y;z[3] = -(bsw->z+1);
		break;
	}

	polygon_abs_3(x,y,z,4);

	/* polygon closes automatically, polyline doesn't */
	x[4] = x[0]; y[4] = y[0]; z[4] = z[0];
	polyline_abs_3(x,y,z,5);
}

FILE *dumpfile;

/* dump coordinates of faces - used by Richard Freemire for DGL */
dump_faces()
{
	char filename[BUFSIZ];

	extern struct face *faces;
	int i;

	printf("file to stored face coordinates: ");
	fgets(filename,BUFSIZ,stdin);
	filename[strlen(filename)-1] = '\0';

	if (0 == (dumpfile = fopen(filename,"w"))) {
		perror(filename);
		return;
	}

	for (i=0;i<surface;i++) {
		dump_face(&faces[i]);
	}

	fclose(dumpfile);

}

dump_face(f)
struct face *f;
{
	int x[5], y[5], z[5];
	/* convert face to Suncore-style polygon */
	struct coord3 *bsw = &f->oct->bsw;

	switch (f->dir) {
	case SOUTH:
		x[0] = bsw->x;y[0] = bsw->y;z[0] = -bsw->z;
		x[1] = bsw->x+1;y[1] = bsw->y;z[1] = -bsw->z;
		x[2] = bsw->x+1;y[2] = bsw->y+1;z[2] = -bsw->z;
		x[3] = bsw->x;y[3] = bsw->y+1;z[3] = -bsw->z;
		break;
	case NORTH:
		x[0] = bsw->x;y[0] = bsw->y;z[0] = -(bsw->z+1);
		x[1] = bsw->x+1;y[1] = bsw->y;z[1] = -(bsw->z+1);
		x[2] = bsw->x+1;y[2] = bsw->y+1;z[2] = -(bsw->z+1);
		x[3] = bsw->x;y[3] = bsw->y+1;z[3] = -(bsw->z+1);
		break;
	case EAST:
		x[0] = bsw->x+1;y[0] = bsw->y;z[0] = -bsw->z;
		x[1] = bsw->x+1;y[1] = bsw->y;z[1] = -(bsw->z+1);
		x[2] = bsw->x+1;y[2] = bsw->y+1;z[2] = -(bsw->z+1);
		x[3] = bsw->x+1;y[3] = bsw->y+1;z[3] = -bsw->z;
		break;
	case WEST:
		x[0] = bsw->x;y[0] = bsw->y;z[0] = -bsw->z;
		x[1] = bsw->x;y[1] = bsw->y;z[1] = -(bsw->z+1);
		x[2] = bsw->x;y[2] = bsw->y+1;z[2] = -(bsw->z+1);
		x[3] = bsw->x;y[3] = bsw->y+1;z[3] = -bsw->z;
		break;
	case TOP:
		x[0] = bsw->x;y[0] = bsw->y+1;z[0] = -bsw->z;
		x[1] = bsw->x+1;y[1] = bsw->y+1;z[1] = -bsw->z;
		x[2] = bsw->x+1;y[2] = bsw->y+1;z[2] = -(bsw->z+1);
		x[3] = bsw->x;y[3] = bsw->y+1;z[3] = -(bsw->z+1);
		break;
	case BOTTOM:
		x[0] = bsw->x;y[0] = bsw->y;z[0] = -bsw->z;
		x[1] = bsw->x+1;y[1] = bsw->y;z[1] = -bsw->z;
		x[2] = bsw->x+1;y[2] = bsw->y;z[2] = -(bsw->z+1);
		x[3] = bsw->x;y[3] = bsw->y;z[3] = -(bsw->z+1);
		break;
	}

	fprintf(dumpfile,"%d %d %d",x[0],y[0],z[0]);
	fprintf(dumpfile," %d %d %d",x[1],y[1],z[1]);
	fprintf(dumpfile," %d %d %d",x[2],y[2],z[2]);
	fprintf(dumpfile," %d %d %d\n",x[3],y[3],z[3]);
}

