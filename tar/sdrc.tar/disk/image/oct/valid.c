#include <stdio.h>

#include "oct.h"
#include "face.h"

extern struct face *faces;


trap(msg)
char *msg;
{
	fprintf(stderr,"error in data structure: ");
	fprintf(stderr,msg);
	fprintf(stderr,"press ^C now to trap to debugger...");
	pause();
}

void valid_oct();

void
valid()
{
	int i;

	for (i=0;i<surface;i++) {
		faces[i].checked = 0;
	}

	valid_oct(oct_root,oct_root_size);

	for (i=0;i<surface;i++) {
		if (!faces[i].checked) trap("found oct-less face!\n");
	}
}

#define valid_child(x,size) if (o->child->x) { \
		valid_oct(o->child->x,size); \
		childcount++; \
		}

#define valid_face(dir) if (o->faces.unit_level->dir && \
		(o->faces.unit_level->dir->oct != o)) { \
		   trap("oct has face which does not point back to oct\n"); \
		} else { \
		   o->faces.unit_level->dir->checked = 1; \
		}

void
valid_oct(o,size)
struct oct *o;
int size;
{
	int halfsize;

	if (size != 0) {
		if (o->child) {
			int childcount;

			printf("size = %d\n",size);
			halfsize = size/2;
			valid_child(tnw,halfsize);
			valid_child(tne,halfsize);
			valid_child(tsw,halfsize);
			valid_child(tse,halfsize);
			valid_child(bnw,halfsize);
			valid_child(bne,halfsize);
			valid_child(bsw,halfsize);
			valid_child(bse,halfsize);
			if (childcount != o->childcount)
			     trap("childcount does not match # of children");
		}
	} else {
/* could also check direction, but this is hard */

		valid_face(west);
		valid_face(east);
		valid_face(bottom);
		valid_face(top);
		valid_face(south);
		valid_face(north);
	}
}
