/* oct.h - octtree structures */

struct children {
	struct oct *tnw;	/* top north west */
	struct oct *tne;
	struct oct *tsw;
	struct oct *tse;
	struct oct *bnw;	/* bottom north west */
	struct oct *bne;
	struct oct *bsw;
	struct oct *bse;
};

/* The primitive data type used by coord3 could be changed depending upon
   the computer and the size of the oct tree.  "int" and "short" are the
   obvious choices.  Performance analysis should be done on each machine.
   Since each oct has a coord3, this can potentially make a big difference.
*/
struct coord3 {			/* damn, Sun already stole "coord" */
	int x, y, z;
};

struct face;			/* halt recursive declaration */

struct faces {
	struct face *west;
	struct face *east;
	struct face *bottom;
	struct face *top;
	struct face *south;
	struct face *north;
};

/* the !! converts a pointer to a 1 if pointer valid, 0 if NULL */
#define face_count(oct,size) (size != 1?oct->faces.count: \
	!!oct->faces.unit_level->west + !!oct->faces.unit_level->east + \
	!!oct->faces.unit_level->bottom + !!oct->faces.unit_level->top + \
	!!oct->faces.unit_level->south + !!oct->faces.unit_level->north)

struct oct {
#ifdef DEBUG
	int cycle;		/* when oct was created */
#endif
	struct oct	*parent;
	struct children	*child;

	/* This is really just a convenience, so we don't have to carry */
	/* around/pass/computer coordinates of oct all the time.  */
	struct coord3	bsw;	/* bottom-south-west corner */

	/* When the oct is at the unit level, "unit_level" is used to */
	/* point to the faces.  At all other times, "count" holds a count */
	/* of all the faces in this oct tree */
	union {
		struct faces *unit_level;
		int count;	/* 0 indicates oct has no faces but is */
				/* entirely within volume */
	} faces;

	/* count of non-null children at and only at this level */
	/* I.e. values are 0 to 6 */
	char    childcount;	/* count of children that are non-NULL */
};

#define NULLOCT ((struct oct *)0)

/* what do we do when the oct we are looking for oct doesn't exist? */
enum action {
	create,		/* create the oct */
	create_full,	/* create oct with all children (full) */
	create_empty,	/* create oct with no children (empty) */
	null,		/* don't create, return null */
	bestfit		/* return best fitting oct */
};

/* how close did oct_find come? */
enum find_status {
	exact,		/* found exact oct */
	within,		/* oct totally enclosed within an oct, which */
			/* itself has no surface cubes */
	failed,		/* didn't exist */
};

#define NULLFS	(enum find_status *)0	/* null find_status */

extern struct oct *oct_root;
extern int oct_root_size;

/* Other notes:

When there are no faces in an oct (such as when an oct becomes totally
enclosed beneath the surface), its pointer to faces should be free'd
and it's parent should be requested to try and coallesce all the
children.  If all the children have no faces, they should be
destroyed.

This should be done recursively.

When there are no children in an oct (such as when an oct loses its
last face from the surface), its pointer to children should be free'd
and childcount set to zero.  The parent should be requested to try and
coallesce all the children.  If all the children, have empty children,
they should be destroyed.

This should be done recursively.

In a static sense, the data structure can be interpreted this way:

If oct == 0,			oct is totally not in volume (nor on surface).
If oct->faces.count != 0,	oct is partially in the volume.
If oct->faces.count = 0,	oct is totally in the volume (not on surface).

*/

void oct_create(), oct_delete();

#define UNIT_LEVEL -1		/* denotes that we need to create unit_level
				   pointer, for unit level faces */
#define PARENT_OF_UNIT_LEVEL	-3

#ifdef ALLOC
extern struct freelist_head oct_freelist_head,
			    children_freelist_head,
			    faces_freelist_head;
#endif

