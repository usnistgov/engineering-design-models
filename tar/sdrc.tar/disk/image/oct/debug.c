/* debug.c - some helpful functions, unnecessary for production version */

#include "basic.h"
#include "dir.h"
#include "face.h"
#include "oct.h"

extern float radius;

struct coord3 *first_vol, *last_vol, *v;
char *malloc();

/* stop if we encounter a cube that we have created before. */
/* Call vol_record() everytime a cube has been created. */
/* This is only useful for testing oct_create */
vol_check(x,y,z)
int x,y,z;
{
	for (v=first_vol;v<=last_vol;v++) {
		if (v->x == x && v->y == y && v->z == z) {
			printf("checking known vol (%d,%d,%d)...pausing\n",x,y,z);
			pause();
		}
	}
}

/* record this volume as being added */
vol_record(x,y,z)
int x,y,z;
{
	static int vol_first_time = 1;
	struct coord3 *vol;

	if (vol_first_time) {
		vol_first_time = 0;
		first_vol = (struct coord3 *)malloc(10000*sizeof(struct coord3));
		last_vol = first_vol - 1;
	}

	for (v=first_vol;v<=last_vol;v++) {
		if (v->x == x && v->y == y && v->z == z) {
			printf("recording known vol (%d,%d,%d)...pausing\n",x,y,z);
			pause();
		}
	}
	last_vol++;
	last_vol->x = x;
	last_vol->y = y;
	last_vol->z = z;
}

/* check integrity of faces.  Performs following checks:
1) Looks at each face in face array and checks that oct it points to,
   points back to the same face in the same direction.
2) Looks at each face in face array and checks that oct it points to
   is in oct tree
3) Pauses if face array ever receives a face with coords:
   xfacestop, yfacestop, zfacestop and direction: dirfacestop.
4) Pauses if face array ever gets an oct outside a given radius.
*/
face_check()
{
	int i;
	struct face *f;
	extern struct face *faces;
	extern int xfacestop, yfacestop, zfacestop;
	extern char dirfacestop;
	struct faces *f2;

	for (i=0;i<surface;i++) {
		f = &faces[i];
		f2 = f->oct->faces.unit_level;
		if (f != f2->bottom
		    && f != f2->top
		    && f != f2->north
		    && f != f2->south
		    && f != f2->east
		    && f != f2->west) {
			printf("faces[%d] points to face whose oct does not point back...pausing\n",i);
			pause();
		}

		if (!oct_find(f->oct->bsw.x,f->oct->bsw.y,f->oct->bsw.z,
				0,NULLOCT,null)) {
			printf("faces[%d] points to oct which is not in tree...pausing\n",i);
			pause();
		}
		if (f->oct->bsw.x == xfacestop
		    && f->oct->bsw.y == yfacestop
		    && f->oct->bsw.z == zfacestop
		    && f->dir == dirfacestop) {
			printf("faces[%d]->dir = %s of %d,%d,%d\n",i,dir_print(f->dir),f->oct->bsw.x,f->oct->bsw.y,f->oct->bsw.y);
			printf("pausing by request\n");
			pause();
		}
#if 0
		if ((f->oct->bsw.x > radius)
		    || (f->oct->bsw.y > radius)
		    || (f->oct->bsw.z > radius)) {
			printf("faces[%d] points to oct %d,%d,%d...pausing\n",
				i,f->oct->bsw.x,f->oct->bsw.y,f->oct->bsw.z);
			pause();
		}
#endif
	}
}

int oct_stats[8];	/* hold statistics collected by oct_print() */

/* prints # of terminal octs and at what level they occur in oct tree.
   This is particularly useful to verify that coallescing is occurring.
*/
oct_print()
{
	int i;
	for (i=0;i<8;i++) oct_stats[i] = 0;
	
	oct_print2(oct_root,0);
	printf("   level         # of\n");
	printf("(0 == root)       octs\n");
	for (i=0;i<8;i++) {
		printf("    %d             %d\n",i,oct_stats[i]);
	}
}

/* utility function for oct_print() */
oct_print2(o,depth)
struct oct *o;
int depth;
{
	struct oct_children *child;

	if (!o) return;

	if (o->child) {
		oct_print2(o->child->tnw,depth+1);
		oct_print2(o->child->tne,depth+1);
		oct_print2(o->child->tsw,depth+1);
		oct_print2(o->child->tse,depth+1);
		oct_print2(o->child->bnw,depth+1);
		oct_print2(o->child->bne,depth+1);
		oct_print2(o->child->bsw,depth+1);
		oct_print2(o->child->bse,depth+1);
	} else {
		/* terminal oct */
		oct_stats[depth]++;
	}
}

/* counts faces by actually looking at face pointers and comparing that */
/* to face counts stored in faces.count.  Pauses if there are any */
/* discrepancies */
oct_check2(o,level)
struct oct *o;
int level;
{
	int fc = 0;	/* face count */

	if (!o) return(0);

	if (level == 0) return(
			       !!o->faces.unit_level->bottom
			       + !!o->faces.unit_level->top
			       + !!o->faces.unit_level->east
			       + !!o->faces.unit_level->west
			       + !!o->faces.unit_level->north
			       + !!o->faces.unit_level->south);

	if (!o->child) {
		if (o->faces.count == 0) return(0);
		else pause();
	}
	fc = oct_check2(o->child->bsw,level/2)
		+ oct_check2(o->child->bse,level/2)
		+ oct_check2(o->child->bne,level/2)
		+ oct_check2(o->child->bnw,level/2)
		+ oct_check2(o->child->tsw,level/2)
		+ oct_check2(o->child->tnw,level/2)
		+ oct_check2(o->child->tne,level/2)
		+ oct_check2(o->child->tse,level/2);
	if (fc != o->faces.count) {
		printf("faces.count (%d) != actual faces (%d)...pausing\n",
			o->faces.count,fc);
		pause();
	}
}

/* return 1 if o is non-NULL, 0 if not */
/* Verifies that childcount reflects actual number of children present */
oct_check(o)
struct oct *o;
{
	int cc = 0;	/* number of children actually found */

	if (!o) return(0);

	/* check that childcount is valid */
	if (o->child) {
		cc += oct_check(o->child->tnw);
		cc += oct_check(o->child->tne);
		cc += oct_check(o->child->tsw);
		cc += oct_check(o->child->tse);
		cc += oct_check(o->child->bnw);
		cc += oct_check(o->child->bne);
		cc += oct_check(o->child->bsw);
		cc += oct_check(o->child->bse);
		if (o->childcount == 0) {
			printf("node has 0 recorded child but child pointer is valid...pausing\n");
			pause();
		}
	}

	if (o->childcount == cc) return(1);	/* cool */

	printf("unexpected child count...pausing()\n");
	pause();

#if 0
	if (o->childcount == EMPTY) {
		printf("node marked as having EMPTY child...pausing\n");
		pause();
	}
#endif
}

/* the following subroutines checks that the number of octs, children and
   faces structs in the tree are the same number that have been allocated
   and not free'd.  Good for finding memory leaks.
   This can be run with the real code.
*/
mem_chk()
{
	int c;

	if (oct_freelist_head.count != (c = count_oct(oct_root)))
		printf("oct: recorded (%d) != found (%d)\n",
			oct_freelist_head.count,c);
	if (children_freelist_head.count != (c = count_children(oct_root)))
		printf("children: recorded (%d) != found (%d)\n",
			children_freelist_head.count,c);
	if (faces_freelist_head.count != (c = count_faces(oct_root,oct_root_size)))
		printf("faces: recorded (%d) != found (%d)\n",
			faces_freelist_head.count,c);
}

/* Counts oct structs in use in tree */
count_oct(o)
struct oct *o;
{
	int oc = 0;	/* oct count */

	if (!o) return(0);
	oc++;

	if (o->child) {
		oc += count_oct(o->child->tnw);
		oc += count_oct(o->child->tne);
		oc += count_oct(o->child->tsw);
		oc += count_oct(o->child->tse);
		oc += count_oct(o->child->bnw);
		oc += count_oct(o->child->bne);
		oc += count_oct(o->child->bsw);
		oc += count_oct(o->child->bse);
	}
	return(oc);
}

/* counts children structs in use in tree */
count_children(o)
struct oct *o;
{
	int cc = 0;	/* children count */

	if (!o) return(0);
	if (o->child) {
		cc += count_children(o->child->tnw);
		cc += count_children(o->child->tne);
		cc += count_children(o->child->tsw);
		cc += count_children(o->child->tse);
		cc += count_children(o->child->bnw);
		cc += count_children(o->child->bne);
		cc += count_children(o->child->bsw);
		cc += count_children(o->child->bse);
		cc++;
	}
	return(cc);
}

/* counts faces structs in use in tree */
count_faces(o,level)
struct oct *o;
int level;
{
	int fc = 0;	/* face count */

	if (!o) return(0);	/* nothing here */

	if (level == 0) return(1);	/* reached face level */

	if (o->child == 0) return(0);	/* no one below us */

	return(	count_faces(o->child->bsw,level/2) +
	       count_faces(o->child->bse,level/2) +
	       count_faces(o->child->bne,level/2) +
	       count_faces(o->child->bnw,level/2) +
	       count_faces(o->child->tsw,level/2) +
	       count_faces(o->child->tse,level/2) +
	       count_faces(o->child->tnw,level/2) +
	       count_faces(o->child->tne,level/2));
}
