/* energy.c - surface energy checking */

float unit_random();
extern float betapow2, betapow4;	/* precomputed in main() */

/* returns 0 if energy check dictates that we should not follow through */
/* this particular version is defined as follows:
   If |S'| > |S|, P = beta**(|S'| - |S|)
   else           P = 1

   Also, there is an additional "unbiasing" so that cubes are accepted 
   probability proportional to their chance of being selected by cubes
   rather than by faces.
*/
energy_check(appear)
int appear;	/* faces that will appear */
{
	int df = 2 * (appear - 3);	/* |S'| - |S| = delta faces */
	float p;

	/* unbias based on number of faces we could have chosen to get here */
	/* That is "6 - appear" ways */

	/* skip case where only one way to appear (i.e. appear == 5) */
	if (appear != 5) {
		switch (appear) {
		case 4: p = 1.0/2.0; break;
		case 3: p = 1.0/3.0; break;
		case 2: p = 1.0/4.0; break;
		case 1: p = 1.0/5.0; break;
		}
		if (unit_random() > p) return(0);
	}

	switch(df) {
	case 4: p = betapow4; break;
	case 2: p = betapow2; break;
	default: return(1); break;
	}
	return(unit_random() < p);
}

/* Note that interface to energy_check has changed.  All other versions
   should be modified to compute "df" based on "appear".
*/

#if 0
/* returns 0 if energy check dictates that we should not follow through */
/* this particular version is defined as follows:
   If |S'| > |S|, P = beta**(|S'| - |S|)
   else           P = 1
*/
energy_check(df)
int df;		/* |S'| - |S| */
{
	float p;

	switch (df) {
	case 4: p = betapow4; break;
	case 2: p = betapow2; break;
	default: return(1); break;
	}
	return(unit_random() < p);
}
#endif

#if 0
/* returns 0 if energy check dictates that we should not follow through */
/* this particular version is defined as follows:
   If |S'| >= |S|, P = 1/|S|
   else           P = (beta**(|S| - |S'|))/|S|
*/
energy_check1(df)
int df;
{
	float numerator;
	extern int surface;

	switch (df) {
	case 4: numerator = betapow4; break;
	case 2: numerator = betapow2; break;
	default: numerator = 1.0; break;
	}
	return(unit_random < numerator/surface);
}
#endif

#if 0
/* earlier, literal implementation of energy check */
energy_check(df)
int df;
{
	double pow();
	if (0 <= df) {		/* new surface larger or equal */
		if (unit_random() >= 1.0/surface) return(0);
	} else {		/* new surface smaller */
		if (unit_random() >= pow(beta,(double)df)/surface) return(0);
	}
	return(1);
}
#endif 0

