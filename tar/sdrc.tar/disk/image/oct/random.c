/* random.c - generate random numbers */

long random();

random_init(x)
int x;
{
	srandom(x);	/* initialize random() */
}

int
ran(max)
{
	return(random()%max);
}

/* generate a random number from [0 to 1) */
float
unit_random()
{
	/* current implementation is pathetic but works */
	/* 99991 is largest prime in my CRC - can't hurt, eh? */
	return(ran(99991)/99991.0);
}
