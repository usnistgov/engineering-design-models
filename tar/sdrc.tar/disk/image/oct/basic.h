/* basic.h - base junk likely to be used by all sources */

#define TRUE	1
#define FALSE	0


#ifndef ALLOC
char *malloc();

#define new(x)	(x *)malloc(sizeof(x))
#define Free(x)	free((char *)x)
#endif ALLOC


#define chk(x,string) if ((x,string)==0) {printf("%d\npausing...\n",string);}
#define chkn1(x,string) if ((x,string)==(char *)-1) {printf("%d\npausing...\n",string);}

#ifndef NULL
#define NULL 0
#endif

extern int verbose;
