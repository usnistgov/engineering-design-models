/* main.c - main routine for lg simulation */

#include "stdio.h"
#include "basic.h"
#ifdef ALLOC
#include "mem.h"
#endif
#include "dir.h"
#include "face.h"
#include "oct.h"
#ifdef TIME_PROFILE
#include "signal.h"
#endif TIME_PROFILE

int surface;		/* size of surface in faces */
float beta = .6;
float betapow2;		/* beta**2 */
float betapow4;		/* beta**4 */
double atof();
int seed = 1;		/* for random number generator */
int max_faces = 10000;
int quantum = 1000;	/* after this many operations, compute statistics */
int verbose = FALSE;
int cycles = 0;
int cycle_limit = 1000000000;	/* pause after this many cycles.  This should
			be divisible by quantum to work right */

#ifdef ALLOC
struct freelist_head	oct_freelist_head,
			faces_freelist_head,
			children_freelist_head;
#endif

#ifdef DRAW
float px = 3.;		/* default perspective viewpoint */
float py = 7.;
float pz = 20;
int uflag = 1;		/* show unit-level cubes only */
int perspective = FALSE;/* TRUE if show in perspective */
int show_surface = 0;
int hide = FALSE;	/* do hidden surface stuff if TRUE */

#define WHITE			0	/* or 252 */

#define VERY_LIGHT_STIPPLE	188	/* or 251 */

#define LIGHT_STIPPLE		187
#define LIGHT_CRUFT		156	/* or 155 */

#define MEDIUM_LIGHT_CRUFT	153

#define MEDIUM_MESH		143	/* or 136 */
#define MEDIUM_STRIPE		170

#define MEDIUM_DARK_WEB		102
#define MEDIUM_DARK_MESH	119

#define DARK_STRIPE		95
#define DARK_MESH		68

#define BLACK			15	/* or 240 */

int fill_index = -1;	/* texture of surfaces, 0 for auto-incr., -1 for no */
int fill_index_top = WHITE;
int fill_index_south = LIGHT_CRUFT;
int fill_index_east = MEDIUM_STRIPE;
int fill_index_west = MEDIUM_LIGHT_CRUFT;
int fill_index_bottom = DARK_MESH;
extern int num_views;	/* 1 or 4 */
#endif

#ifdef DEBUG
int cubecount = 0;
int drawflag = 0;

int eflag = TRUE;	/* do energy surface computations */
int bflag = 0;		/* bounds on growing cubes */
int xstop = 0;		/* stop if find ourselves creating this cube */
int ystop = 0;
int zstop = 0;
int dirfacestop = -1;
int xfacestop = -1;
int yfacestop = -1;
int zfacestop = -1;
#endif DEBUG

char *optarg;

#ifdef TIME_PROFILE
sighandler()
{
	printf("caught sig\n");
	exit();
}
#endif TIME_PROFILE

main(argc,argv)
int argc;
char **argv;
{
	struct face *f;
	int c;
	int x,y,z;
	int i;
	int max_surface = 0;	/* record max surface */
	int max_cycle = 0;	/* and when we saw it */

#if defined(DEBUG) || defined(DRAW)
	while (EOF != (c = getopt(argc,argv,"eb:c:f:q:p:s:x:y:z:B:v:"))) {
#else
	while (EOF != (c = getopt(argc,argv,"b:c:f:q:s:v:"))) {
#endif
		switch (c) {
		case 'b': beta = atof(optarg); break;
		case 'c': cycle_limit = atoi(optarg); break;
		case 'f': max_faces = atoi(optarg); break;
		case 'q': quantum = atoi(optarg); break;
		case 's': seed = atoi(optarg); break;
		case 'v': verbose = atoi(optarg); break;
#ifdef DRAW
		case 'p': perspective = TRUE; break;
		case 'x': px = atof(optarg); break;
		case 'y': py = atof(optarg); break;
		case 'z': pz = atof(optarg); break;
#endif
#ifdef DEBUG
		case 'e': eflag = FALSE; break;
		case 'B': bflag = atoi(optarg); break;
#endif DEBUG
		}
	}

#ifdef ALLOC
	memory_init(&oct_freelist_head,sizeof(struct oct),600,300);
	memory_init(&faces_freelist_head,sizeof(struct faces),400,200);
	memory_init(&children_freelist_head,sizeof(struct children),200,100);
#endif

	face_bootstrap(max_faces);	/* must precede oct_bootstrap */
	oct_bootstrap();
	random_init(seed);

	betapow2 = beta*beta;
	betapow4 = betapow2*betapow2;

#ifdef TIME_PROFILE
	signal(SIGINT,sighandler);	/* flush profiler data on ^C */
#endif TIME_PROFILE

	while (TRUE) {
	    for (i=0;i<quantum;i++) {
		f = face_choose();

		if (ran(2)) {
			/* create oct */
			x = f->oct->bsw.x;
			y = f->oct->bsw.y;
			z = f->oct->bsw.z;
			if (verbose) printf("chose %s face on oct(%d,%d,%d)\n",
						dir_print(f->dir),x,y,z);
			switch (f->dir) {
			case EAST:	x++; break;
			case WEST:	x--; break;
			case BOTTOM:	y--; break;
			case TOP:	y++; break;
			case SOUTH:	z--; break;
			case NORTH:	z++; break;
			}
			if (verbose) printf("create new oct at (%d,%d,%d)\n",
						x,y,z);
			oct_create(x,y,z,f->oct);
#ifdef DEBUG
			mem_chk();
			face_check();
#endif
		} else {
			/* delete oct */
			if (verbose) printf("delete old oct at (%d,%d,%d)\n",
				f->oct->bsw.x,f->oct->bsw.y,f->oct->bsw.z);
			oct_delete(f->oct);
		}
		if (surface > max_surface) {
			max_surface = surface;
			max_cycle = cycles + i;
		}
#ifdef VALIDATE
		valid();
#endif
	    }
	    printf("cycles = %d  |S| = %d  %s\n",
			cycles += quantum,surface,print_face_distance());
	    printf("oct root radius = %d  sbrk(0) = %x\n",
			oct_root_size,sbrk(0));
	    printf("max surface of %d at cycle %d\n",max_surface,max_cycle);
#ifdef SPACE_PROFILE
	    space_stats();
#endif
	    if (cycles >= cycle_limit) {
		printf("cycle limit reached\n");
#ifdef TIME_PROFILE
		exit();
#else
		printf("pausing...\n");
		pause();
#endif
	    }
	}
}

