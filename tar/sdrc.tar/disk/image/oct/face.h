/* face.h - structures for maintaining faces */

struct oct;

struct face {
	struct oct *oct;
	char dir;
#ifdef VALIDATE
	char checked;
#endif
};

struct face *face_new();	/* generate new face, given oct and dir */
struct face *face_choose();	/* choose random face */

/* take a face and assign it to a new oct */
#define face_oct_new(f,o)	(f)->oct = (o)

extern int surface;	/* size of surface in faces */

char *print_face_distance();
