/* dir.c - Things that only have to do with directions */

#include "dir.h"

/* return a printable string corresponding to the direction.  Only used */
/* in diagnostics. */
char *
dir_print(d)
int d;
{
	switch(d) {
	case EAST: return("east");
	case WEST: return("west");
	case NORTH: return("north");
	case SOUTH: return("south");
	case TOP: return("top");
	case BOTTOM: return("bottom");
	}
	/* NOTREACHED */
}
