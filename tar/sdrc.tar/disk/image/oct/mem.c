/* mem.c - memory allocator for fixed size blocks */

/*

This code is replacement for malloc() and free().  It takes advantage
of the fact that all of my memory allocation is of known fixed-size
blocks.  This particular implementation, however, is extremely general
and will do allocation of any number of different fixed-size blocks.

I will just give a simple example here.  To allocate struct foo's, declare a handle to the foo space as:

	struct freelist_head foo_freelist;

Initialize it:

	memory_init(&foo_freelist,sizeof(struct foo),1000,200);

Here we have asked for an initial allocation of 1000 foo's.  When that
runs out, further allocations will automatically be performed 200
foo's at a time.  (Each allocation calls sbrk() so you want to
minimize them.)

To actually allocate and deallocate foo's, it helps to define two
macros as follow:

	#define foo_new()	(struct foo *)new(&foo_freelist)
	#define foo_destroy(x)	destroy(&oct_freelist_head,(char *)(struct foo *)x)

Now you can say things like:

	foo1 = foo_new();
	foo_destroy(foo1);

*/

/* just in case we are compiling by hand */
#ifndef ALLOC
#define ALLOC
#endif ALLOC

#include <stdio.h>
#include "basic.h"
#include "mem.h"

print_freelist(flh)
struct freelist_head *flh;
{
	Freelist *current;

	current = flh->freelist;
	while (current) {
		printf("-> %x",current);
		current = current->next;
	}
	putchar('\n');
}

/* chop up big block into linked list of small blocks */
static Freelist * /* return 0 for failure */
create_freelist(flh,bytes)
struct freelist_head *flh;	/* freelist head */
size_type bytes;		/* new memory size */
{
	Freelist *current = (Freelist *)sbrk(bytes);
	if ((Freelist *)-1 == current) return(0);

	flh->freelist = current;

	while ((char *)current + flh->size <
			((char *)flh->freelist + bytes)) {
		current->next = (Freelist *)(&current->memory + flh->size);
		current = current->next;
	}
	current->next = NULL;
	return(current);
}

memory_init(flh,size,alloc1,alloc2)
struct freelist_head *flh;
size_type size;			/* size of a single element */
int alloc1;			/* number to allocate initially */
int alloc2;			/* number to allocate if we run out */
{
        /* make block large enough to hold the linked list pointer */
	flh->size = (size>sizeof(Freelist *)?size:sizeof(Freelist *));
	/* set up for future allocations */
	flh->bytes = flh->size * alloc2;

        if (0 == create_freelist(flh,flh->size*alloc1)) {
                fprintf(stderr,"memory_init: out of space");
                exit(-1);
	}

#if SPACE_PROFILE
	flh->count = 0;
#endif SPACE_PROFILE
}

char *
new(flh)
struct freelist_head *flh;
{
	char *obj;

	if (flh->freelist == NULL && 0 == create_freelist(flh,flh->bytes)) {
		fprintf(stderr,"new: out of space");
		return(0);
	}

	obj = &flh->freelist->memory;
	flh->freelist = flh->freelist->next;

#if SPACE_PROFILE
	flh->count++;
#endif SPACE_PROFILE

	return(obj);
}

destroy(flh,link)
struct freelist_head *flh;
void *link;
{
	Freelist *flink = link;

	flink->next = flh->freelist;
	flh->freelist = flink;

#ifdef SPACE_PROFILE
	flh->count--;
#endif SPACE_PROFILE
}

#ifdef ALLOC_MAIN
struct freelist_head oct_freelist;

#define new_oct()	 (struct oct *)new(&oct_freelist)
#define destroy_oct(oct) (destroy(&oct_freelist,(char *)(struct oct *)oct))

struct oct {
	char a[16];
};

main()
{
	struct oct *o1,*o2,*o3,*o4,*o5,*o6;

	memory_init(&oct_freelist, sizeof(struct oct), 5,2);

	o1 = new_oct(); printf("o1 = %x\n",o1);
	o2 = new_oct(); printf("o2 = %x\n",o2);
	o3 = new_oct(); printf("o3 = %x\n",o3);
	o4 = new_oct(); printf("o4 = %x\n",o4);
	o5 = new_oct(); printf("o5 = %x\n",o5);
	o6 = new_oct(); printf("o6 = %x\n",o6);
	destroy_oct(o1);
	destroy_oct(o2);
	o1 = new_oct(); printf("o1 = %x\n",o1);
	o2 = new_oct(); printf("o2 = %x\n",o2);
	o3 = new_oct(); printf("o3 = %x\n",o3);
	o4 = new_oct(); printf("o4 = %x\n",o4);
	o5 = new_oct(); printf("o5 = %x\n",o5);
}
#endif ALLOC_MAIN
