#define has_null_byte(x) (((x) - magic1) & ~(x) & magic2)

char *real_fast_strcpy(dest,src)
char *dest, *src;
{
	register long *d = (long *)dest;
	register long *s = (long *)src;
	register long magic1 = 0x01010101;
	register long magic2 = 0x80808080;
	register char *dc, *sc;
	/* copy four bytes at a time */
	while (!has_null_byte(*s)) {
		*d++ = *s++;
	}
	/* prepare to copy remaining chars */
	dc = (char *)d;
	sc = (char *)s;
	while (*dc++ = *sc++) ;
	return(dest);
}
