#ifndef DUMP_H
#define DUMP_H

#include "proto.h"				/* define PROTO */
void dump PROTO((char *,int,char *));

#endif /* DUMP_H */
