/* dump.c - dump from file or memory */

#include <stdio.h>
#include <ctype.h>
#include "dump.h"

#define ROWLENGTH 16

#ifdef MAIN
static FILE *ifp;				/* shared by main and file_reader */

int
file_reader()
{
	return(getc(ifp));
}

int main(argc,argv)
int argc;
char **argv;
{
	if (argc == 1) ifp = stdin;
	else if (argc != 2) {
		printf("usage: dump file\n");
		exit(1);
	} else if (!(ifp = fopen(argv[1],"r"))) {
		perror(argv[1]);
		exit(1);
	}

	/* nonportable assumption that internal null ptr == 0 */
	/* if incorrect, only display will suffer slightly */
	real_dump((char *)0,file_reader,stdout);
	return 0;
}

#else

static int length;					/* shared by dump(), mem_reader() */
static char *address;					/* ditto */
static int count;					/* ditto */

int
mem_reader()
{
	if (count++ >= length) return(EOF);
	else return((int)*address++);
}

void
dump(address_parm,length_parm,outfile)
char *address_parm;
int length_parm;
char *outfile;
{
	char outfilebuffer[80];
	FILE *ofp;

	if (!outfile) {
		printf("output file (<cr> for stdout): ");
		gets(outfile = outfilebuffer);
	}

	if (*outfile) {
		if (!(ofp = fopen(outfile,"w"))) {
			perror(outfile);
			exit(1);
		}
	} else ofp = stdout;
	
	count = 0;
	length = length_parm;
	address = address_parm;

	real_dump(address,mem_reader,ofp);

	if (outfile && *outfile) fclose(ofp);
}

#endif

real_dump(address,infunc,ofp)
char *address;
int (*infunc)();
FILE *ofp;
{
	int i, row[ROWLENGTH];

	while (1) {
		for (i=0;i<ROWLENGTH;i++)
			row[i] = (*infunc)();
		if (row[0] == EOF) break;

		/* first print address */
		fprintf(ofp,"%lx: ",address);

		/* then print hex */
		for (i=0;i<ROWLENGTH;i++)
			fprintf(ofp,
				(row[i] != EOF) ? "%02x ":"   ",
				row[i]);

		/* lastly print characters */
		fprintf(ofp,"   ");
		for (i=0; i<ROWLENGTH; i++) {
			if (row[i] == EOF) break;
			if (isprint(row[i])) putc(row[i],ofp);
			else putc('.',ofp);
		}
		putc('\n',ofp);
		address += ROWLENGTH;
	}
}

#ifdef TEST
/* here is something to dump */
/* as well as containing a file to dump to */
char foo[] = {
'f', 'o', 'o', 0x0, 0x10, 'a', 'b', 0x18, 0xff, 0, 0x4
};

main()
{
}
#endif
