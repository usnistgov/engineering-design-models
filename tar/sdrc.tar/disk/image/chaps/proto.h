#ifndef PROTO_H
#define PROTO_H

#if __STDC__==1 || PROTOTYPES_EXIST
#define PROTO(A)  A
#else
#define PROTO(A)  ()
#endif /* has prototypes */

#if __STDC__==1
#include <stdlib.h>
#include <stddef.h>
typedef void *Generic;
typedef size_t Size;
#else
typedef char *Generic;
typedef int Size;
Generic malloc PROTO((unsigned));
Generic realloc PROTO((Generic,Size));
Generic calloc PROTO((Size,Size));
void free PROTO((Generic));
#endif /* _STDC__==1 */

#endif /* PROTO_H */
