#include <stdio.h>
#include "byteord.h"

/*
 * there are 4 possibilities (that we care about):
 *                                      MSB   LSB
 * Order in memory                       3 2 1 0
 *
 * Order in memory if you stepped a char * ptr thru the long
 *	- noswap:                           3 2 1 0    68K, 370
 *	- byteswap: (swap bytes in short)   2 3 0 1    PDP-11
 *	- halfswap: (swap shorts in long)   1 0 3 2    ?
 *	- bothswap: (swapbyte && halfswap)  0 1 2 3    VAX, 8086
 */

static long test_value = 0x03020100;
long longbothswap PROTO((long));
long longbyteswap PROTO((long));
long longhalfswap PROTO((long));
short byteswap PROTO((short));

void
byteorder_init()
{
	char *cp = (char *) &test_value;
	switch (*cp) {
	case 03:	
		htonl_func = 0;
		htons_func = 0;
		break;
	case 02:
		htonl_func = longbyteswap;
		htons_func = byteswap;
		break;
	case 01:
		htonl_func = longhalfswap;
		htons_func = 0;
		break;
	case 00:
		htonl_func = longbothswap;
		htons_func = byteswap;
		break;
	}
}

long
longbothswap(l)				/* swap bytes 3<->0 and 2<->1 */
long l;
{
	register char		*sp,	/* source pointer */
		     		*dp;	/* dest pointer in r */
	long r;

	sp = (char *) &l;
	dp = (char *) &r;

	*dp++ = sp[3];
	*dp++ = sp[2];
	*dp++ = sp[1];
	*dp   = sp[0];
	return r;
}

long
longbyteswap(l)			/* swap bytes 0 with 1 and 2 with 3 */
long l;
{
	register char		*sp,	/* source pointer */
		     		*dp;	/* dest pointer in r */
	long r;

	sp = (char *) &l;
	dp = (char *) &r;

	*dp++ = sp[1];
	*dp++ = sp[0];
	*dp++ = sp[3];
	*dp   = sp[2];
	return r;
}

long
longhalfswap(l)			/* swap bytes 0 with 2 and 1 with 3 */
long l;
{
	register char		*sp,	/* source pointer */
		     		*dp;	/* dest pointer in r */
	long r;

	sp = (char *) &l;
	dp = (char *) &r;

	*dp++ = sp[2];
	*dp++ = sp[3];
	*dp++ = sp[0];
	*dp   = sp[1];
	return r;
}

/* swap bytes 0 with 1 */
#if __STDC__==1 || PROTOTYPES_EXIST
short byteswap(short s)
#else
short byteswap(s)
short s;
#endif
{
	register char		*sp,	/* source ptr */
		      		*dp;	/* dest ptr */
	short r;

	sp = (char *) &s;
	dp = (char *) &r;
	*dp++ = sp[1];
	*dp   = sp[0];
	return r;
}
