/* byteorder.h */
#ifndef BYTEORDER_H
#define BYTEORDER_H
#include "proto.h"			/* define PROTO */

#define ntohs(x)			(htons(x))
#define ntohl(x)			(htonl(x))

#define htons(x)			(htons_func?(*htons_func)(x):x))
#define htonl(x)			(htonl_func?(*htonl_func)(x):x))

short (*htons_func) PROTO((short));
long (*htonl_func) PROTO((long));
void byteorder_init PROTO((void));

#endif /* BYTEORDER_H */
