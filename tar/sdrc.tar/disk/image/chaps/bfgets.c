#include <stdio.h>
#include "proto.h"				/* define malloc and friends */
#define GROW_BY 256

char *big_fgets(fp)
FILE *fp;
{
	int c;
	Size string_length = 0;						/* including NULL */
	Size buffer_length;
	char *buffer, *new;

     if (!(buffer = malloc(buffer_length = GROW_BY)))
			return(NULL);

	while (EOF != (c = getc(fp))) {
		buffer[string_length++] = c;
		/* if no more space in buffer for more */
		/* chars, increase the size of the buffer */
		if (string_length >= buffer_length) {
			buffer_length += GROW_BY;
			if (!(new = realloc(buffer,buffer_length))) {
				free((Generic)buffer);
				return(NULL);
			}
		}
		if (c == '\n') break;
	}
	/* check for EOF */
	if (string_length == 0) {
		free((Generic)buffer);
		return(NULL);
	}
	buffer[string_length++] = '\0';
	/* Now that we know what size the string is, */
	/* make do with a smaller buffer */
	new = realloc(buffer,buffer_length);
	return(new?new:buffer);
}
