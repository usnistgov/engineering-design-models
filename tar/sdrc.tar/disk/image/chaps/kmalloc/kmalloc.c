#include <stdio.h>
#include "kmalloc.h"

/* The following km_link structure is used to build up a singly
linked list.  Each link in the list points to one malloc'd item as well as the key it depends upon.  Thus, it is a simple operation to scan during a key_free to find all the links and their data that should be freed.
*/

static struct km_link {
	Generic data;		/* pointer to malloc'd memory for user */
	Generic key;		/* pointer to what it depends on */
	struct km_link *next;				/* next km_link */
} *first_km_link = 0;				/* initially empty list */

static struct km_link *delete_km_link();

#define new(type) (type *)malloc(sizeof(type))

Generic
key_malloc(key,size)			/* returns data or 0 if none left */
Generic key;
Size size;
{
	struct km_link *link;

	if (!(link = new(struct km_link))) return(0);
	if (!(link->data = malloc(size))) {
		free((Generic)link);
		return(0);
	}
	link->key = key;

	/* insert link into linked list of km_links in no */
	/* particular order.  Easiest is in front of list. */
	link->next = first_km_link;
	first_km_link = link;

	return(link->data);
}

void key_change(key,buffer)
Generic key;
Generic buffer;
{
	struct km_link *link;

	for (link = first_km_link;link;link=link->next) {
		if (link->data == buffer) {
			link->key = key;
			return;
		}
	}
	fprintf(stderr,"key_change: no buffer with that key\n");
}

struct km_link *
key_free(key)
Generic key;			/* may be both data and a key */
{
	struct km_link *link;
	struct km_link *next = 0;

	/* look for nodes dependent upon key */
	for (link=first_km_link;link;) {
		if (key != link->key) link = link->next;
		else link = key_free(link->data);
	}

	/* if key was also key_malloc'd, free it (and its link) */
	for (link=first_km_link;link;link=link->next) {
		if (key == link->data) {
			next = delete_km_link(link);/* remove from list */
			free(key);		/* free the (now) data */
			free((Generic)link);	/* free link */
			break;
		}
	}
	return(next);
}

/* remove this link from the linked list of km links */
static struct km_link *			/* return next valid link */
delete_km_link(p)
struct km_link *p;
{
	struct km_link **link;

	for (link = &first_km_link;*link;link = &(*link)->next) {
		if (*link == p) { /* found it */
			return(*link = (*link)->next);
		}
	}
	/*NOTREACHED*/
}
