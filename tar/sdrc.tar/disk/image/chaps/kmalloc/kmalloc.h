#ifndef KEYMALLOC_H
#define KEYMALLOC_H
#include "../proto.h"		/* define PROTO, Generic, malloc, etc */
Generic key_malloc PROTO((Generic key, Size size));
struct km_link *key_free PROTO((Generic data_or_key));
void key_change PROTO((Generic key, Generic data));
#endif /* KEYMALLOC_H */
