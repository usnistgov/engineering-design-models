#include <stdio.h>
#include "linklist.h"

Linked_list *LIST_new() {
	return((Linked_list *)malloc(sizeof(Linked_list)));
}

Link *LINK_new() {
	return((Link *)malloc(sizeof(Link)));
}

#define LINK_destroy(x) free((Generic)x)
#define LIST_destroy(x) free((Generic)x)

Linked_list *
LISTcreate()
{
	Linked_list *list = LIST_new();
	list->head = LINK_new();
	list->head->next = list->head->prev = list->head;
	return(list);
}

Generic
LISTadd_first(list,data)
Linked_list *list;
Generic data;
{
	Link *link = LINK_new();
	link->data = data;
	(link->next = list->head->next)->prev = link;
	(list->head->next = link)->prev = list->head;
	return data;
}

void
LISTfree(list)
Linked_list *list;
{
	Link *p, *q = list->head->next;

	for (p = q->next; p != list->head; q = p, p = p->next) {
		LINK_destroy(q);
	}
	if (q != list->head) LINK_destroy(q);
	LINK_destroy(list->head);
	LIST_destroy(list);
}

Generic
LISTadd_last(list,data)
Linked_list *list;
Generic data;
{
	Link *link = LINK_new();
	link->data = data;
	(link->prev = list->head->prev)->next = link;
	(list->head->prev = link)->next = list->head;
	return data;
}

Generic
LISTremove_first(list)
Linked_list *list;
{
	Generic data;
	Link *link = list->head->next;

	if (link == list->head) {
		fprintf(stderr,"empty list: can't remove element\n");
		return NULL;
	}
	data = link->data;
	(list->head->next = link->next)->prev = list->head;
	LINK_destroy(link);
	return data;
}

/*ARGSUSED*/
void
LISTremove(list,link)
Linked_list *list;
Link *link;
{
	Generic data;

	link->next->prev = link->prev;
	link->prev->next = link->next;
	data = link->data;
	LINK_destroy(link);
}

/* first is 0 */
Generic
LISTget_nth(list,n)
Linked_list *list;
int n;
{
	int count = 0;
	Link *link = list->head->next;

	for (;link != list->head;link = link->next) {
		if (n == count++) return(link->data);
	}
	fprintf(stderr,"list element %d does not exist\n",n);
	return NULL;
}

Generic
LISTadd_after(list,link,data)
Linked_list *list;
Link *link;
Generic data;
{
	Link *link2;

	if (link == 0) 		LISTadd_first(list, data);
	else {
		link2 = LINK_new();
		link2->data = data;
		(link2->next = link->next)->prev = link2;
		(link->next = link2)->prev = link;
	}
	return data;
}
