#include "proto.h"

typedef struct Link {
	struct Link *next;
	struct Link *prev;
	Generic data;
} Link;

typedef struct {
	Link *head;
} Linked_list;

#define LISTdo(list,elt,type) {					\
  struct Linked_list *LIST = (list);				\
  type elt;							\
  Link *LINK;							\
  for (LINK = LIST->head; (LINK = LINK->next) != LIST->head;) { \
	(elt) = (type)(LINK->data); {

#define LISTod }}}

#define LISTdo_links(list,link) {				\
  Linked_list *LIST = (list);					\
  Link *link;							\
  for ((link) = LIST->head;					\
		((link) = (link)->next) != LIST->head; ) {{

Linked_list *LISTcreate PROTO((void));
Generic LISTadd_first PROTO((Linked_list *,Generic));
void LISTfree PROTO((Linked_list *));
Generic LISTadd_last PROTO((Linked_list *,Generic));
Generic LISTremove_first PROTO((Linked_list *));
void LISTremove PROTO((Linked_list *,Link *));
Generic LISTget_nth PROTO((Linked_list *,int n));
Generic LISTadd_after PROTO((Linked_list *,Link *,Generic));




