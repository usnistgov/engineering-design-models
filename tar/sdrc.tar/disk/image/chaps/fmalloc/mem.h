/* mem.h - defs for fixed size block memory allocator */
#ifndef MEM_H
#define MEM_H
#include "proto.h"  /* define PROTO, malloc and friends */

typedef long Align;

union freelist {
	union freelist *next;					/* next block on freelist */
	char memory;					/* user data */
	Align aligner;				/* force alignment of blocks */
};

typedef union freelist Freelist;

struct freelist_head {
	Size size;			/* size of single elt incl next ptr */
	Size bytes;			/* if we run out, alloc mem by */
			 	/* this many bytes */
	Freelist *freelist;
};

Generic new PROTO((struct freelist_head *));
void memory_init PROTO((struct freelist_head *,Size,int,
								int));
void delete PROTO((struct freelist_head *, Generic));
#endif /* MEM_H */
