/* mem.c - subroutines to allocate fixed-size blocks */

#include <stdio.h>
#include "mem.h"

/* chop up big block into linked list of small blocks */
static Freelist * 					/* return 0 for failure */
create_freelist(flh,bytes)
struct freelist_head *flh;						/* freelist head */
Size bytes;						/* new memory size */
{
	Freelist *current = (Freelist *)malloc(bytes);
	if (0 == current) return(0);
	flh->freelist = current;
	while ((char *)current + flh->size <
			((char *)flh->freelist + bytes)) {
		current->next = (Freelist *)
			(&current->memory + flh->size);
		current = current->next;
	}
	current->next = NULL;
	return(current);
}

void
memory_init(flh,size,alloc1,alloc2)
struct freelist_head *flh;						/* freelist head */
Size size;			/* size of a single element */
int alloc1;			/* number to allocate initially */
int alloc2;			/* number to allocate if we run out */ {
	/* make block large enough to hold linked list ptr */
	flh->size = (size >
		sizeof(Freelist *)?size:sizeof(Freelist *));
	/* set up for future allocations */
	flh->bytes = flh->size * alloc2;

	if (0 == create_freelist(flh,flh->size*alloc1)) {
		fprintf(stderr,"memory_init: out of space");
		exit(1);
	}
}

Generic new(flh)
struct freelist_head *flh;
{
	Generic obj;
	if (flh->freelist == NULL && (flh->bytes == 0 ||
	    0 == create_freelist(flh,flh->bytes))) {
		fprintf(stderr,"new: out of space");
		return(0);
	}
	obj = &flh->freelist->memory;

	flh->freelist = flh->freelist->next;

	return(obj);
}

void
delete(flh,link)
struct freelist_head *flh;
Generic link;
{
	Freelist *flink = link;

	flink->next = flh->freelist;
	flh->freelist = flink;
}
