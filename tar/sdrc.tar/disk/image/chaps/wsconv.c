#include <stdio.h>
#include <ctype.h>

#define TRUE					1
#define FALSE					0

#define LF					'\n'
#define CR					'\r'
#define SOFT_HYPHEN					0x1f	/* inserted to break words */
							/* at eol */

#define TABSIZE					8

#define CONTROL(x)					(1 + (x) - 'A')
#define BOLD					(CONTROL('B'))
#define SUPERSCRIPT					(CONTROL('T'))
#define SUBSCRIPT					(CONTROL('V'))
#define UNDERSCORE					(CONTROL('S'))

#define BOLD_BEGIN					"<<<"
#define BOLD_END					">>>"
#define UNDERSCORE_BEGIN					"<_"
#define UNDERSCORE_END					"_>"
#define SUBSCRIPT_BEGIN					"<<"
#define SUBSCRIPT_END					">>"
#define SUPERSCRIPT_BEGIN					"<^"
#define SUPERSCRIPT_END					"^>"

typedef int bool;
bool wscntrl();				/* true if arg is WS control char */
int column;				/* column to output next character */

bool superscript = FALSE;						/* if we are superscripting */
bool subscript = FALSE;						/* if we are subscripting */
bool bold = FALSE;						/* if we emboldening */
bool underscore = FALSE;						/* if we are underscoring */
bool msb_was_set;	  		/* if char had most significant bit set */
bool soft_space = FALSE;						/* if we are between words */
	/* and have seen a soft space, but no other spaces */
bool soft_hyphen = FALSE;						/* if we are in the middle */
	/* of a word that was hyphenated by WS */
bool dotcmd = FALSE;				/* if we in the middle of a dot cmd */
bool wrap_soon = FALSE;						/* if we should wrap as */
	/* soon as we get to the end of the current word */
int spacerun = 0;				/* number of spaces seen in a row */
void space_out(), newline(), do_wscntrl(); /* utility fns */

int main() {
	int c;			/* last character read */
	while (EOF != (c = getchar())) {
		/* look at single characters */

		/* remember if most significant bit set */
		if (msb_was_set = 0x80 & c) {
			c &= 0x7f;			/* turn off most sig. bit */
		}
		if (c == CR) continue;					/* LF always follows */
		if (c == LF) {
			if (soft_hyphen) {
				wrap_soon = TRUE;
			} else newline();
		} else if (dotcmd) {
			/* throw away chars while in a dot cmd */
			continue;
		} else if (c == ' ') {
			/* ignore blanks with msb - they are soft */
			if (msb_was_set) {					/* a real space */
				soft_space = FALSE;
				spacerun++;
				column++;
				if (wrap_soon) {				/* wrap now! */
					newline();
					wrap_soon = FALSE;
				}
			} else soft_space = TRUE;
		} else if (c == SOFT_HYPHEN) {
			/* handle hyphens with msb - they are soft */
			soft_hyphen = TRUE;
		} else if (c == '.' && column == 0) {
			/* text processing directive */
			dotcmd = TRUE;
		} else if (wscntrl(c)) {
			/* placeholder to handle WS print control */
			/* chars e.g. ^S (underscore), ^B (bold) */
			do_wscntrl(c);
		} else if (iscntrl(c)) {
			/* unknown control character - ignore */
			continue;
		} else { /* normal character */
			/* if we encountered a soft space, stick */
			/* in at least one space */
			if (soft_space) {
				spacerun = 1;
				column++;
				soft_space = FALSE;
			}
			if (spacerun) {				/* beginning of word */
				/* calculate tabs/blanks to lay down */
				space_out(column - spacerun, column);
					spacerun = 0;
				}
				putchar(c);
				column++;
			}
		}
		return 0;
	}
	/* print out least number of spaces and tabs to move us */
	/* from "oldpos" to "newpos" */
	void space_out(oldpos,newpos)
	int oldpos;			/* old position */
	int newpos;			/* new position */
	{
		int spaces, tabs;  /* number of spaces/tabs to print */
		int i;

		if (oldpos >= newpos) return;		/* no space in between */

		/* first calculate tabs */
		tabs = newpos/TABSIZE - oldpos/TABSIZE;

		/* now calulate spaces */
		/* if old&new follow same tab stop, use simple diff */
		if (tabs == 0) spaces = newpos - oldpos;
		/* if not, then it's remainder from nearest tab stop */
		else spaces = newpos % TABSIZE;

		for (i = 0; i < tabs; i++) putchar('\t');
		for (i = 0; i < spaces; i++) putchar(' ');
	}

	/* true if WordStar control character */
	bool
	wscntrl(c)
	int c;
	{
		return ((c == BOLD) ||
			(c == UNDERSCORE) ||
			(c == SUPERSCRIPT) ||
			(c == SUBSCRIPT));
	}

	void newline()
	{
		if (!dotcmd) putchar('\n');
		column = 0;
		spacerun = 0;
		dotcmd = FALSE;
	}

	void do_wscntrl(c)
	int c;
	{
		switch (c) {			/* print control character */
		case BOLD:
			if (bold) printf(BOLD_END);
			else printf(BOLD_BEGIN);
			bold = !bold;
			break;
		case UNDERSCORE:
			if (underscore) printf(UNDERSCORE_END);
			else printf(UNDERSCORE_BEGIN);
			underscore = !underscore;
			break;
		case SUBSCRIPT:
			if (subscript) printf(SUBSCRIPT_END);
			else printf(SUBSCRIPT_BEGIN);
			subscript = !subscript;
			break;
		case SUPERSCRIPT:
			if (superscript) printf(SUPERSCRIPT_END);
			else printf(SUPERSCRIPT_BEGIN);
			superscript = !superscript;
			break;
		default:
			/* unknown - ignore for now */
			break;
		}
	}
