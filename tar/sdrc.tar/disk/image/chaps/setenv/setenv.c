static char id[] = "@(#)setenv.c 2.1 89/02/22 Maarten Litmaath";
/* setenv.c - Sorted environment package. */

#include		<stdio.h>
#include		"setenv.h"

static char		*envbuf[MAX_ENV] = { 0 };
static int		initialized = 0;
int			_envc = 0;

static int i_strcmp(p, q)    /* indirect strcmp */
char **p, **q;
{
	register char *s1 = *p, *s2 = *q;

	while (*s1 == *s2++)
		if (!*s1++) return 0;
	return *s1 - *--s2;
}

static int
initenv()
{
	register char			**p = environ, **env = envbuf;
	extern char			*strcpy();
	static int			error = 0;
	
	if (error == -1) return -1;

	if (p)
		while (*p && p < environ + MAX_ENV) 			
			if (!(*env = malloc(strlen(*p)+1)))
				return error = -1;
			else
				(void) strcpy(*env++, *p++);

	if (p >= environ + MAX_ENV - 1)
		return error = -1;

	*env = 0;
	_envc = env - envbuf;
	qsort((char *)envbuf,_envc,sizeof *envbuf,i_strcmp);
	environ = envbuf;
	initialized = 1;
	return 0;
}

static int envsearch(var, n, pos)
register char			*var;
register int			n;
char			***pos;
{
	register char			**env,
				**first = envbuf,
				**last = envbuf + _envc;
	register int			m;
	extern int			strncmp();

	while (first < last) {
		env = first + ((last - first)/2);
		if ((m = strncmp(*env, var, n)) < 0) {
			first = env + 1;
			continue;
		}
		if (m > 0) { 
			last = env;
			continue;
		}
		if ((m = (*env)[n] - '=') == 0) {
			*pos = env;
			return 0;
		}
		if (m < 0) {
			first = env + 1;
			continue;
		}
		last = env;
	}
	*pos = last;
	return 1;
}

char *setenv(var, value)
char *var, *value;
{
	char	**env, *buf;
	int	n;
 
	if (!initialized && initenv() == -1) return NULL;
	if (!value) value = "";
	n = strlen(var);

	if (!(buf = malloc(n + strlen(value) + 2)))
		return NULL;

	(void) sprintf(buf, "%s=%s", var, value);

	if (envsearch(var, n, &env) == 0) {
		free(*env);				/* unsetenv old value */
		*env = buf;				/* setenv new value */
	} else if (_envc == MAX_ENV)
			return NULL;
	else {					/* *env > var */ 
		register char			**p, **q;

		p = envbuf + _envc++;
		q = p++;
		while (q > env)
			*--p = *--q;			/* shift down */
		*env = buf;				/* insert new var */ 
	}
	return buf;
}

int
unsetenv(var)
char *var;
{
	register char			**p, **q;
	char			**env;

	if (!var)
		if (!initialized) {
			initialized = 1;
			environ = envbuf;
			return 0;
		} else {
			for (p = envbuf; *p; ) free(*p++);
			*envbuf = 0;
			_envc = 0;
			return 0;
		}

	if (!initialized && initenv() == -1) return -1;

	if (envsearch(var, strlen(var), &env) == 1) return 0;
	free(*env);				/* unsetenv var */

	p = env++;
	q = env;
	while (*p++ = *q++)		/* shift up rest of environment */
		;
	--_envc;
	return 0;
}
