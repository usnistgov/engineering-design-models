#ifndef SETENV_H
#define SETENV_H

#include "proto.h"			/* define PROTO, malloc and friends */
#define		MAX_ENV		256

extern char			**environ;
extern char			*setenv PROTO((char *var,char *value));
extern int			unsetenv PROTO((char *var));
int			_envc;

#endif /* !SETENV_H */
