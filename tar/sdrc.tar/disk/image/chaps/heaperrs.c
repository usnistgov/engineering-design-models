#include <stdio.h>

#define ERROR_MAX_SPACE				4000
static char error_string_base[ERROR_MAX_SPACE];
static char *error_string = error_string_base;
#define ERROR_MAX_STRLEN			200

#define ERROR_MAX				100

static struct heap_element {
	int line;
	char *msg;
} heap[ERROR_MAX+1];

void eflush();

static int error_count = 0;

#include <stdarg.h>

/* 1st arg is format, 2nd is line #, other args are whatever is */
/* demanded by the format */
void
eprintf(char *fmt, int line, ...)
{
	int child, parent;
	va_list arg;
	va_start(arg,line);

	child = ++error_count;
	parent = child/2;
	while (parent) {
		if (line < heap[parent].line) {
			heap[child] = heap[parent];
		} else break;
		child = parent;
		parent = child/2;
	}
	heap[child].line = line;
	heap[child].msg = error_string;

	vsprintf(error_string,fmt,arg);
	error_string += strlen(error_string) + 1;

	if (error_string + ERROR_MAX_STRLEN >
					error_string_base + ERROR_MAX_SPACE
	    || error_count == ERROR_MAX) {
		eflush();
	}
	
	va_end(arg);
}

void
eflush()
{
	while (error_count) {
		struct heap_element *replace;
		int parent, child;

		fprintf(stderr,"line %d: %s\n",heap[1].line,
								heap[1].msg);

		replace = &heap[error_count--];

		child = 1;
		while (1) {
			parent = child;
			if (child > error_count) break;
			if (child+1 <= error_count) {
                       if (heap[child].line > heap[child+1].line)
						child++;
			}
			if (replace->line <= heap[child].line) break;
			heap[parent] = heap[child];
		}
		heap[parent] = *replace;
	}
}
