#include "bigset.h"
#include "smallset.h"

bigset_union(s1,s2,s3)					/* s1 = s2 U s3 */
struct bigset_param *s1, *s2, *s3;
{
	int i;
	for (i=0;i<s1->number;i++)
		s1->data[i] = s2->data[i] UNION s3->data[i];
}

void
bigset_print(s)
struct bigset_param *s;
{
	int i, j;
	for (i=0;i<s->number;i++) {
		for (j=0;j<BITS_PER_SUBSET;j++) {
			putchar(s->data[i] INTERSECT elt(j)?'1':'0');
		}
	}
}

void
bigset_set(s,i)				/* turn on element i in set s */
struct bigset_param *s;
int i;
{
	s->data[i/BITS_PER_SUBSET] |= elt(i%BITS_PER_SUBSET);
}

bigset(readcyls,100);
bigset(writecyls,100);
bigset(activecyls,100);

main()
{
	/* request cylinders 1 and 10 to be read */
	bs_set(readcyls,1);
	bs_set(readcyls,10);

	printf("cylinders to read: ");
	bs_print(readcyls);
	putchar('\n');

	/* request cylinder 4 to be written */
	bs_set(writecyls,4);
	printf("cylinders to write: ");
	bs_print(writecyls);
	putchar('\n');

	/* find out cylinders requiring action */
	bs_union(activecyls,readcyls,writecyls);
	printf("cylinders requiring I/O: ");
	bs_print(activecyls);
	putchar('\n');
}
