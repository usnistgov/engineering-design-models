#include "../proto.h"

#define bigset(name,bits)   struct {\
			int number;		/* of subsets */\
			SUBSET data[1 + ((bits)-1)/BITS_PER_SUBSET];\
		} name = {1 + ((bits)-1)/BITS_PER_SUBSET}

#ifndef CHAR_BIT
#define CHAR_BIT					8
#endif
#define SUBSET					unsigned long
#define BITS_PER_SUBSET				(CHAR_BIT * sizeof(SUBSET))

struct bigset_param {
	int number;
	SUBSET data[1];
};

void bigset_print PROTO((struct bigset_param *s));
#define bs_print(s) bigset_print((struct bigset_param *)&s)
#define bs_set(s,i) bigset_set((struct bigset_param *)&s,i)
#define bs_union(s1,s2,s3) bigset_union((struct bigset_param *)&s1, \
			(struct bigset_param *)&s2, \
			(struct bigset_param *)&s3)
