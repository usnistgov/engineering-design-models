#define UNION		|
#define INTERSECT	&
#define elt(x)       	((unsigned)1<<(x))
#define member(s,x)	(0 != ((s) INTERSECT elt(x)))
