#include "smallset.h"

int min_elt(x)
int x;
{
	int i;

	/* first check if set is empty */
	if (x == 0) return(-1);
	for (i=0; member(x,elt(i)); i++) ;
	return(i);
}
