#include <stdio.h>
#include <ctype.h>
#include "getopt/getopt.h" /* see page 32 in chapter 6 */

#define TRUE							1
#define FALSE							0
#define LINE_BUFFER_LENGTH					80
#define MULTILINE_BUFFER_LENGTH					(80*24)
char input[MULTILINE_BUFFER_LENGTH]; /* input buffer */

/* constants for selecting a modem */
#define MODEM_FIRST						4
#define MODEMS							3
#define MODEM_MASK						"/dev/tty%i"
/* constants for dialing a Rixon R212A modem */
#define MODEM_WAKEUP						"\r\r"
#define MODEM_PROMPT						"$ "
#define MODEM_PROMPT_TIMEOUT					20
#define MODEM_ONLINE						"7"
#define MODEM_ONLINE_TIMEOUT					45
#define MODEM_BUSY						'5'
#define MODEM_NUMBER_PREFIX					"<k"
#define MODEM_NUMBER_SUFFIX					"\r>"
#define MODEM_SPEED						B1200

/* constants for talking to the Naval Observatory */
#define NAVO_PHONE						"2026531079"
#define NAVO_LOGIN_REQUEST					"PLS IDENTIFY"
#define NAVO_LOGIN_REQUEST_TIMEOUT				60
#define NAVO_REQUEST_TIME					"@TIM\r"
  /* first string sent out after actual time */
#define NAVO_TIME_INDICATOR					"YYYY"
#define NAVO_TIME_INDICATOR_TIMEOUT				10
#define NAVO_LOGOUT						"@BYE\r"
#define NAVO_PROMPT						"*\r\n"
#define NAVO_PROMPT_TIMEOUT					10
#define IDENTITY				"DONLIBES/SELF/HOMETOWN,USA\r"

int timed_out;			/* true if the read was interrupted by alarm */
int set_time = FALSE;		/* true if we are going to try and set */
				/* system time */
int verbose = FALSE;		/* true if conversation should be printed */
int debug = FALSE;		/* this implies verbose */

char modem[LINE_BUFFER_LENGTH] = "";	/* name of modem in /dev */
FILE *mp = 0;			/* stream corresponding to modem */

void
options(argc,argv)
int argc;
char **argv;
{
	while (EOF != getopt (argc, argv, "dvsl:")) {
		switch (optopt) {
			case 'd':
				debug = TRUE;
				verbose = TRUE;
				printf ("debugging enabled\n");
				break;
			case 'v':
				verbose = TRUE;
				break;
			case 'l': /* line */
				strcpy (modem, optarg);
				break;
			case 's': /* set system time */
				set_time = TRUE;
				break;
			default:
				printf ("unknown option: %c (%x)\n", optopt,
											optopt);
				printf ("usage: naval [-dvls]\n");
				exit(0);
		}
	}
}

/* following two functions are BSD UNIX specific.  See article */
/* text for how to rewrite for other systems */
#include <sgtty.h>
struct sgttyb ttybuf;
struct sgttyb oldttybuf;	/* save original tty config here */

void
setup_modem()
{
	ioctl(fileno(mp),TIOCGETP,&oldttybuf);
	ttybuf = oldttybuf;
	ttybuf.sg_flags |= RAW;		/* raw */
	ttybuf.sg_flags &= ~ECHO;	/* no echo */
	/* for debugging purposes, use /dev/tty, but don't */
	/* change the speed! */
	if (strcmp("/dev/tty",modem)) {
		ttybuf.sg_ispeed = ttybuf.sg_ospeed = MODEM_SPEED;
	}
	ioctl(fileno(mp),TIOCSETP,&ttybuf);
}

void
cleanup()
{
	/* if we are using /dev/tty for testing, clean up */
	if (mp && !strcmp("/dev/tty",modem)) {
		ioctl(fileno(mp),TIOCSETP,&oldttybuf);
		fclose(mp);
	}
	exit(0);
}

void
select_modem()
{
	int i;

	if (strcmp(modem,"")) {		/* user has specified modem */
		if (NULL != (mp = fopen(modem,"rw"))) {
			printf("failed to open %s",modem);
			perror("open");
			cleanup();
		}
	} else {
		for (i=MODEM_FIRST;i<MODEM_FIRST+MODEMS;i++) {
			sprintf(modem,MODEM_MASK,i);
			if (debug) printf("trying %s\n",modem);
			if (NULL != (mp = fopen(modem,"rw"))) break;
		}
		if (mp == 0) {
			printf("no modems available\n");
			cleanup();
		}
	}
}

void
send(buf)
char *buf;
{
	int i;
	int cc;
	int length = strlen(buf);

	if (verbose) {
		fwrite(buf,1,length,stdout);
		fflush(stdout);
	}

	/* make even parity */
	for (i=0;i<length;i++) buf[i] = even(buf[i]);
	cc = fwrite(buf,1,length,mp);

	if (cc != length) printf("fwrite(,,%d) = %d?\n",length,cc);
}

void
dialup()
{
	send(MODEM_WAKEUP);

	if (!waitfor(MODEM_PROMPT,MODEM_PROMPT_TIMEOUT)) {
		printf("failed to establish connection with modem\n");
		printf("make sure one is connected to %s\n",modem);
		printf("If it is, try resetting it.\n");
		cleanup();
	}

	send(MODEM_NUMBER_PREFIX);
	send(NAVO_PHONE);
	send(MODEM_NUMBER_SUFFIX);

	printf("dialing Naval Observatory...\n");

	if (!waitfor(MODEM_ONLINE,MODEM_ONLINE_TIMEOUT)) {
		printf("failed to connect to Naval Observatory\n");
		printf("last message: %s\n",input);
		printf("reason: ");
		switch (*input & 0x7f) { /* strip off parity */
		case MODEM_BUSY:
		    printf("busy.  Try again later.");
		    break;
		default:
		    printf("unexpected response <%c>\n",*input & 0x7f);
		    break;
		}		
		cleanup();
	}
}

void
login()
{
	if (!waitfor(NAVO_LOGIN_REQUEST,NAVO_LOGIN_REQUEST_TIMEOUT)) {
		printf("did not get request for identification\n");
		printf("instead, got %s\n",input);
		cleanup();
	}
	send(IDENTITY);
}

int year, day, hour, minute, second, msec;

void
gettime()
{
	int i;

	if (!waitfor(NAVO_PROMPT,NAVO_PROMPT_TIMEOUT)) {
		printf("N.O. failed to prompt %s\n");
		printf("instead got %s\n",input);
		cleanup();
	}
	send(NAVO_REQUEST_TIME);
	if (!waitfor(NAVO_TIME_INDICATOR,NAVO_TIME_INDICATOR_TIMEOUT)) {
		printf("N.O. failed to respond with time\n");
		printf("instead got %s\n",input);
		cleanup();
	}

	/* back up to beginning of time indicator */
	for (i=strlen(input)-strlen(NAVO_TIME_INDICATOR);i>=0;i--) {
		if (0 == strcmp(NAVO_TIME_INDICATOR,input+i)) {
			i -= 2; /* skip crlf */
			break;
		}
	}
	/* back up to beginning of actual date and time */
	for (;i>=0;i--) if (input[i] == '\n') break;

	if (6 != (sscanf(&input[i],"%d %d %d %d %d %d",
			&year,&day,&hour,&minute,&second,&msec))) {
		printf("failed to find date in <%s>\n",&input[i]);
		cleanup();
	}
}

void
logout()
{
	send(NAVO_LOGOUT);
	sleep(10);
}

void
settime() {
	int month;
	char command[80];		/* long enough, I hope */

	month_day(year,day,&month,&day); /* from K&R - see text */
	if (set_time) {
		/* DOS specific */
		sprintf(command,"TIME %d:%d:%d.%d",
				hour,minute,second,msec/10);
		system(command);
		sprintf(command,"DATE %d-%d-%d",month,day,year);
		system(command);
	}
}

void
dump(s,n)
char *s;
int n;
{
	int i;

	for (i=0;i<n;i++,s++) {
		*s &= 0x7f;
		if (isprint(*s) || *s == ' ') putchar(*s);
		else if (*s == '\r') printf("<cr>");
		else if (*s == '\n') printf("<lf>");
		else printf("<%x>",*s);
	}
}

/* the following two functions are specific to UNIX systems */
/* which do not restart reads.  See page 60 in chapter 9 */
/* for other approaches. */
#include <signal.h>

/*ARGSUSED*/
void alarm_handler(sig)
int sig;
{
	timed_out = TRUE;
}

/* waitfor() watches the input stream for occurrences of s */
/* it will timeout after "period" seconds */
int
waitfor(s,period)
char *s;
int period;
{
	int bytes_read = 0;		/* number of bytes read since */
					/* entering this routine */
	int slen = strlen(s);		/* length of string being */
					/* searched for */

	signal(SIGALRM,alarm_handler);
	timed_out = FALSE;
	alarm(period);
	for (;;) {
		int cc;
		char *p, *start_searching = input;
		/* alarm can go off in code AFTER the read, in which */
		/* case we must check for it here */
		if (timed_out) return(FALSE);
		cc = fread(input+bytes_read,1,LINE_BUFFER_LENGTH,mp);
		/* if alarm went off, or some other signal occurred */
		/* or read failed, give up. */
		if (cc == 0) {
			alarm(0);
			return(FALSE);
		}

		if (verbose) fwrite(input+bytes_read,1,cc,stdout);
		for (p = start_searching;
				p <= (&input[bytes_read+cc])-slen; p++) {
			/* move over one character and try again */
			if (debug) {
				printf("searching for ");
				dump(s,slen);
				printf(" in ");
				dump(p,slen);
				printf("\r\n");
			}
			if (!strncmp(s,p,slen)) {
				alarm(0);
				return(TRUE);
			}
		}
		start_searching = (&input[bytes_read+cc]) - slen;
		bytes_read += cc;
		/* if we have filled up the buffer without finding */
		/* the string, it's probably hopeless. */
		if (bytes_read + LINE_BUFFER_LENGTH >
				MULTILINE_BUFFER_LENGTH) {
			alarm(0);
			return(FALSE);
		}
	}
}

int
even(c)			/* return given character with even parity */
int c;
{
	int i, pbit = 0;

	for (i=0;i<7;i++) {
		if ((c>>i)&1) pbit = !pbit;
	}

	c &= 0x7f;
	if (pbit) c |= 1<<7;
	return(c);
}

int main(argc,argv)
int argc;
char **argv;
{
	options(argc,argv);
	select_modem();
	setup_modem();
	dialup();
	login();
	gettime();
	settime();
	logout();
	cleanup();
	return 0;
}
