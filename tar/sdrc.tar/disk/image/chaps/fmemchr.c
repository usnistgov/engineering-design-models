#include "proto.h"		/* define Generic, Size */

Generic fast_memchr(s,c,n)
Generic s;
int c;
Size n;
{
	unsigned char uc = c, lastc;
	unsigned char *us = s, *t;

	if (n == 0) return 0;
	lastc = us[--n];
	us[n] = uc;
	while (uc != *us) us++;
	t = s;
	t[n] = lastc;
	if (us != t+n || lastc == uc) return us;
	else return 0;
}
