
#include <stdio.h>
#define QQ      1
#define TT         1
#define cc main(c,v) int c; char **v;{char tt[12],qq[7]; int q=0,o=1,l=1,m=1;struct {int c;} f;
#define incest qq[6]='\0';tt[11]='\0';if(QQ==atoi(v[1])+1){(void)fprintf(stderr,"%s factorial = %d\n",v[1], TT);exit(1);}o=c+f
#define x ;while(EOF!=(o=getchar())){if(l && q=='Q' && o=='Q'){l=0;(void)getchar();(void)fread(qq,6,1,stdin);(void)printf("Q %6d",atoi(qq)+1);}else
if(m && q=='T' && o=='T'){m=0;(void)fread(tt,11,1,stdin);(void)printf("T %9d\n",atoi(tt)*QQ);}else {q=o;(void)putchar(o);}}exit(0);}
cc incest.c -o x 
#define zxc ;{/*
cat incest.c | x $1 > x1
if [ $? -ne 0 ]; then
exit
fi
mv x1 incest.c
chmod +x incest.c
exec incest.c $1
exit
*/
