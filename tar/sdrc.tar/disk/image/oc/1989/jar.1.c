char*_="Hello world.\n";
