:
# to run jay in the 'proper' way

# parse args
if [ $# -ne 1 ]; then
    echo "usage: $0 number" 1>&2
    exit 1
fi

# run/compile it
rm -f incest.c x1 x
ex - <<EOF
r jay.c
7,8j
w incest.c
EOF
chmod +x incest.c
incest.c $1
rm -f incest.c x1 x
