 typedef struct A*B,*(*C)();struct A{C(*d)();B e;}*v(),*b;C n[256];
# include <stdio.h>
#define a (d->e)
#define o (B)printf
#define X(_){return _;}
#define Y(_,A)B _(d,e)B d,e;X(A)
#define Z(P)C P(f,g,h,i)C f,g,h,i;X(P)
#define c(_)(b=(B)malloc(sizeof(*b)),b->d=_,b->e=d,b)
#define _(D,E,F,G,H)B D();Y(D/**/f,E)Y(D/**/g,F)Y(D/**/h,G)Y(D/**/i,H)Y(D,(*(*d->d)(D/**/f,D/**/g,D/**/h,D/**/i))(d,e))
Z(f)
Z(g)
Z(h)
Z(i)
_(j,d,d,j a,j a)
_(k,d,c(h),c(h),c(h))
_(l,c(i),d,c(i),c(i))
_(m,c(g),c(f),l(m a),k(m a))
_(p,d,l(m(d)),k(p a),l(m a))
_(q,l(p(d)),m(d),l a,k(q a))
_(r,m(d),k(mf a),l(r a),k a)
_(s,d,e,o("0",s a),o("1",s a))
_(t,d,p(e),k(t(a,e)),v(k(t(a,e)),e))
_(u,k(e),l(r(e)),k(v(a,e)),l(v(a,e)))
_(v,e,r(e),u(e,a),u(q(e),a))
_(w,o("0"),d,s(d),s(d))
_(x,(*n[getchar()])(d),o("-1"),w(p(d,o("-"))),xh(d))
_(y,xf(mg()),v(d,p(yf())),v(d,yf()),t(d,yf()))
_(z,xf(yf()),(*(*j(d)->d)(w,x))(d),xf(k(d)),xf(l(d)))
main(){
n['(']=zf;n['x']=yi;n['-']=yg;
n['+']=yh;n['0']=zh;n['1']=zi;
n[' ']=xf;n[')']=n['\n']=kf;
o("\n",zg(yf()));}
