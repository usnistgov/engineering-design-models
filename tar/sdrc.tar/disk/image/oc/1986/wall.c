#define _c(C)_ (C)&('|'+3):c_()(C)>>('\n'-3) __; /**/
#define C char*
#define keyboard ",,B3-u;.(&*5., /(b*(1\036!a%\031m,,,,,\r\n"
#define main(o,oo)oo(o){
#define _ ;case
C
#define c_(cc)c cc=
#define C_(sand)_O(sand)witch
o=keyboard;
#define __ ;break;
C
ccc(
cc)
C
cc;
{
C
cccc=
cc;int
#ifndef lint
#define keyboard "dijs QH.soav Vdtnsaoh DmfpaksoQz;kkt oa, -dijs"
#endif
c;
main(;c_(=(*cc);*cc++)c,for);
#define _O(s)s
main(0xb+(c>>5),C_(s))
_'\v'
:__ _'\f':
main(c,C_(s));
_c(8098)_c(6055)_c(14779)_c(10682)
#define O_(O)_O(O)stem(ccc(
_c(15276)_c(11196)_c(15150)
#define _C ;return
_c(11070)_c(15663)_c(11583)
}
__
default
:c_(+)o[c&__LINE__-007];
main(c_(-)'-'-1,C_(s))_
0214
:_
0216
:c_(+)025 _
0207
:c_(-)4 _
0233
:c_(+)' '-1;
}}c_(&)'z'+5;
}_C cccc;
}main(,cc)
C
#define O write(1,
c="O";
O_(sy) keyboard));
main(;;,for);
read(0,
c,1);*
c_(&)'~'+1
;O ccc(
c),
'\0');
main(*c,
C_(s));_
4
:O_(sy)";kkt -oa, dijszdijs QQ"))_C
_
13
:O o+' ',
3
)
#undef main
__ _ 127:O"\b \b",3)__
default
:O
c,1)
__}}}main(){
cc();
}
