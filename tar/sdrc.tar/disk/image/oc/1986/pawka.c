#include "stdio.h"
#define xyxx char
#define xyyxx putchar
#define xyyyxx while
#define xxyyyx int
#define xxxyyx main
#define xyxyxy if
#define xyyxyy '\n'
xyxx *xyx [] = {
"]I^x[I]k\\I^o[IZ~\\IZ~[I^|[I^l[I^j[I^}[I^n[I]m\\I]h",
"]IZx\\IZx[IZk\\IZk[IZo_IZ~\\IZ~[IZ|_IZl_IZj\\IZj]IZ}]IZn_IZm\\IZm_IZh",
"]IZx\\IZx[I^k[I\\o]IZ~\\IZ~\\I]|[IZl_I^j]IZ}]I^n[IZm\\IZm_IZh",
"]IZx\\IZx[IZk\\IZk[IZo_IZ~\\IZ~_IZ|[IZl_IZj\\IZj]IZ}]IZn_IZm\\IZm]IZh",
"]I^x[I]k\\IZo_I^~[I^|[I^l[IZj\\IZj]IZ}]I^n[I]m^IZh",'\0'};/*xyyxyxyxxxyxxxyy*/
xyxx *xyyx; xxyyyx xyyyx,xyyyyx,xyyyyyx=0x59,xyyyyyyx=0x29,/*yxxyxyyyxxyyyxyy*/
xxyx=0x68;xxxyyx(){xyyyyx=0;xyyyxx(xyx[xyyyyx]){xyyx=xyx[xyyyyx++];/*xyyyxxyx*/
xyyyxx(*xyyx){xyyyx= *xyyx++-xyyyyyx;xyyyxx(xyyyx--)xyyxx(*xyyx-xyyyyyyx);/*x*/
xyxyxy(*xyyx==xxyx)xyyxx(xyyxyy);*xyyx++;}}}/*xyxyxyyyyxxyxxxyyyxyyyxyxxyyy*/
