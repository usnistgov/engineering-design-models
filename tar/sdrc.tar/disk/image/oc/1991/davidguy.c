#define _ define
#_ u unsigned
#_ w char*
#_ j(x)(*(*(x*)&T)++)
#_ H j(short*)
#_ K j(w)
#_ e j(u*)
#_ r register u
#_ R(b)write(A,T=h,4*b);
#_ S (u*)sbrk(Q*4+U*8)+U
#_ E(a,b,c)a=c&1<<31|b/2;c=c*2|b&1;
#_ V q= *L;L+=F;E(d,q,x)E(f,d,s)g=f&q;f^=q
#_ W while(
#_ Z q=I&f;M|=q&c;c^=q;I^=f;M|=g&c;c^=g
#_ Y W(F= *s++)&16)*T=10**T+F-'0';T++
#_ D(q,s)c);W q>s)G= *--q,*q= *s,*s++=G;
#_ P if(i^z){x=Q+(n=D(x,n)
#_ C if(i){q=Q*4+(s=(w)D(q,s)
u A,U,Q,J,X[9999];main(a,b)w*b;{r*c,*d,y,f,g,F,G,I,M,N,z,*x,*n,i;w q,*h=(w)X,*
T,*s=".slo.-W00,tmhw.W/";T=h;if(a>1){H=2;K=23;K=112;s=b[1];Y;Y;Y;Y;}else{H=1;W
*s)K=1+*s++;}connect(A=socket(a,1,0),T=h,24-a*4);H=17004;H=11;e=0;e=0;i=66==*h
;R(3)read(A,h,8);e;H;read(A,h,4*H);T=h;e;F=e;e;e;I=11+H;f=H-6;K;U=K;i^=K;z=!K;
T+=I/4*4+8*U;I=e;T+=16;U=H/32;J=H/30*30;T+=14;M=K;f/=U;T=h;K=55;K;H=4;e=F;e=I;
e=0;R(4)N=F+8192;K=53;K=M;H=4;e=N;e=I;H=U*32;H=J;R(4)K=2;K;H=4;e=I;e=1;e=N;R(4
)Q=J*U;c=S;d=S;L(c);W 1){P}C}y=0;W y<J){K=72;K=0;g=J-y;H=6+U*(g>f?g=f:g);e=N;e
=F;H=U*32;H=g;H=0;H=y;K=0;K=1;R(6)write(A,c+y*U,g*U*4);y+=g;}K=61;K=0;H=4;e=I;
e=0;e=0;R(4)C}P}v(c,d);}}L(A)r*A;{r*T=A+Q,X=getpid();W A<T)*A++=X=3*X^X/2;}v(n
,O)u*n,*O;{r*A,F=U,*L=n-F,*G=L+Q,I,c,d,M,f,g,N,q,i=0,X,T,v,s,x,*y,*z;W L<n){*L
= *G;G++[F]=L++[F];}W i<J){z=O+i*F;y=n+i*F-F;i+=30;L=y-1;A=L+U*32;W L<A){L+=F;
E(X,*L,x)E(q,X,s)}X=0;W X++<F){L=y++;G=z++;V;c=g|f&d;I=f^d;V;W L<=A){M=0;Z;N=d
;T=f;v=g;V;Z;c^=I&d;*G=c&~M&(I^d|N);G+=F;c=v|T&N;I=T^N;}}}z=O;y=n;I=J;W--I!=-1
){f= *z>>31;G=z+F;L=y+F;W G>z){M= *--G;*--L=(M*2)+f;f=M>>31;}z+=F;y+=F;}}
