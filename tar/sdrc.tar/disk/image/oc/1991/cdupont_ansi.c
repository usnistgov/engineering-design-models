   /* common sense  to nohonest programmer */
#include <stdio.h>
main(){int x  ,gi=4,i,f,ri=1,httxkbl=1,m=012;long cd=0x5765248d,n;
   char u[0x50][032];FILE *ind;
      ind=fopen(s,t); for(i=0; i<0x1a; i++){goto daswjhkls;vhjsgfdy1l1gjhd:;}
/*borntorun.*/goto c0g0;cOgO:i=0;fclose(ind);c0gO:
x=  u [gi][m]; sorryfor_this_unused_but_very_needed_label:
     if(  m==gi){x=0x70;f=0x68;}else goto cOg0 ; b:putchar(x); if(
!(n-httxkbl++))
#define yank(x) putchar(x)
  {httxkbl=1;       yank(' ');goto
   hxi;}goto bl;
           /* hardlyundrstandable, but
likely to be missed if removed */
    daswjhkls:    fgets(u[i], 0120, ind);
  /*obfuscated, eh? */goto
    vhjsgfdy1l1gjhd;
          c0g0 : n=cd&0x40000000L>>0x1e;
 goto         cOgO;   g6w:
                 if(x!=0x2e){i++;goto c0gO;}else /*
injail*/yank('\n');goto vhjsgfdyl1lgjhd;
cOg0 :
f=u[m][gi];goto b;bl:m=(i+1)*(4*
x+3*f)%032;gi=(i+1)*(x+2*f)%0x1a; goto g6w;
  hxi:cd^=        n=  cd&(7<<3*(014-++ri));
n >>=3*(12-ri); goto bl;vhjsgfdyl1lgjhd:;}
