#include <stdio.h>
#define D define
#D H(x,y,z) f(p){--p;c=x-_+1];f(c>0){y+1]=z[c];z[c]=y];y]=y+1];}}
#D O(x,y) F(x,int U;int T=0;d=M(U=1);W{f(c==y)b g[T++]=c;f(T==U)g=realloc(g,U<<=1);}g[T]=0;)
#D W Y((c=k?K[--k]:getchar())-EOF)
#D S i[q
#D F(w,z) f(c==w){z h}
#D f if
#D P p>1&&(c=u,
#D _ s[p
#D C =G
#D g S]
#D J(x,y) F(I[x],y)
#D Q P e
#D Y while
#D b break;
#D u _--]
#D m p&&
#D R char*
#D l Z[c]
#D L strlen
#D d i[++q]
#D G c)
#D h ;continue;
#D N s[++p]
#D e _]
#D j x;{R r=M(L(
#D v return
#D w [256]
#D V f(k>o||p>o||q>o)v 2;
R I="I'd love ta win: the most useful !$>%`/#<&*|^ _OBFUSCATED_ utility. Pleez?";U(y,x)R y;R*j*x)+L(y)+1);sprintf(r,"%s%s",*x,y);*x=r;}R T(x)R j x)+1);strcpy(r,x);v
r;}R(i w);static R(Z w);K w;main(a,A)int a;R*A;{int s w,p=0,q=0,n=0,c,k=0;W{V
f(c>='0'&&c<='9'){f(!n)N=0;n=1;e=10*e+(c-'0')h}n=0;J(39,m
sprintf(d=M(13),"%d",e))
J(37,q&&puts(g))J(34,q&&printf("%s",g))J(27,H(p,_,s))O('[',']')J(56,f(p){c=e;N=c;})J(2,m--p)J(10,N=a)J(4,f(q){N=L(g);X(S--]);})J(1,f(q){S+1]=T(g);++q;})J(53,m
e>=0&&e<a&&(d=T(A[u])))
J(54,q>1&&(--q,U(S+1],i+q)))J(5,q&&p>1&&(_-1]=open(g,_-1],e),--p,X(S--])))J(47,m
close(u))
J(26,m(e=dup(e)))O('"','"')J(51,H(q,S,i))J(49,N=fork())J(12,wait(&N)+1||(e=-1))J(68,{++p;pipe(s+p++)==-1&&(e=-1);})F('q',v
0)
F('=',W{R x;f(m u)f(x=l){k+=n=L(x);V;Y(*x)K[--k]=*x++;k+=n;n=0;}b})J(15,f(q)W{l&&X(l);l=T(g);b})J(33,f(c=q){*i=g;g=0;Y(--q&&**(i+q))g++;f(q){N=execvp(*i,i+q+1);q=c;}})J(38,P
c&&(e/C))
J(35,Q=e>G)F('+',Q+C)J(42,Q*C)J(41,Q=~(e&G))J(57,m(e=-e))J(3,)F('\n',)putchar(c);puts(73+I);}}
