#include <stdio.h>
#define H(x,y,z) f(p){--p;c=x-_+1];f(c>0){y+1]=z[c];z[c]=y];y]=y+1];}}
#define O(x,y) F(x,int U;int T=0;d=M(U=1);W{f(c==y)b g[T++]=c;f(T==U)g=realloc(g,U<<=1);}g[T]=0;)
#define W Y((c=k?K[--k]:getchar())-EOF)
#define S i[q
#define F(w,z) f(c==w){z h}
#define f if
#define P p>1&&(c=u,
#define _ s[p
#define C =G
#define g S]
#define J(x,y) F(I[x],y)
#define Q P e
#define Y while
#define b break;
#define u _--]
#define m p&&
#define R char*
#define l Z[c]
#define L strlen
#define d i[++q]
#define G c)
#define h ;continue;
#define N s[++p]
#define e _]
#define j x;{R r=M(L(
#define v return
#define w [256]
#define V f(k>o||p>o||q>o)v 2;
R I="I'd love ta win: the most useful !$>%`/#<&*|^ _OBFUSCATED_ utility. Pleez?";U(y,x)R y;R*j*x)+L(y)+1);sprintf(r,"%s%s",*x,y);*x=r;}R T(x)R j x)+1);strcpy(r,x);v
r;}R(i w);static R(Z w);int K w;main(a,A)int a;R*A;{int s w,p=0,q=0,n=0,c,k=0;W{V
f(c>='0'&&c<='9'){f(!n)N=0;n=1;e=10*e+(c-'0')h}n=0;J(39,m
sprintf(d=M(13),"%d",e))
J(37,q&&puts(g))J(34,q&&printf("%s",g))J(27,H(p,_,s))O('[',']')J(56,f(p){c=e;N=c;})J(2,m--p)J(10,N=a)J(4,f(q){N=L(g);X(S--]);})J(1,f(q){S+1]=T(g);++q;})J(53,m
e>=0&&e<a&&(d=T(A[u])))
J(54,q>1&&(--q,U(S+1],i+q)))J(5,q&&p>1&&(_-1]=open(g,_-1],e),--p,X(S--])))J(47,m
close(u))
J(26,m(e=dup(e)))O('"','"')J(51,H(q,S,i))J(49,N=fork())J(12,wait(&N)+1||(e=-1))J(68,{++p;pipe(s+p++)==-1&&(e=-1);})F('q',v
0)
F('=',W{R x;f(m u)f(x=l){k+=n=L(x);V;Y(*x)K[--k]=*x++;k+=n;n=0;}b})J(15,f(q)W{l&&X(l);l=T(g);b})J(33,f(c=q){*i=g;g=0;Y(--q&&**(i+q))g++;f(q){N=execvp(*i,i+q+1);q=c;}})J(38,P
c&&(e/C))
J(35,Q=e>G)F('+',Q+C)J(42,Q*C)J(41,Q=~(e&G))J(57,m(e=-e))J(3,)F('\n',)putchar(c);puts(73+I);}}
