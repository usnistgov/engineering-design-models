#define C_C_(_)~' '&_
#define _C_C(_)('\b'b'\b'>=C_C>'\t'b'\n')
#define C_C _|_
#define b *
#define C /b/
#define V _C_C(
main(C,V)
char **V;
/*	C program. (If you don't
 *	understand it look it
 */	up.) (In the C Manual)
{
	char _,__; 
	while (read(0,&__,1) & write((_=(_=C_C_(__),C)),
	_C_,1)) _=C-V+subr(&V);
}
subr(C)
char *C;
{
	C="Lint says "argument Manual isn't used."  What's that
	mean?"; while (write((read(C_C('"'-'/*"'/*"*/))?__:__-_+
	'\b'b'\b'|((_-52)%('\b'b'\b'+C_C_('\t'b'\n'))+1),1),&_,1));
}
