#define _ define
#_ P char
#_ p int
#_ O close(
#_ H strlen(*
#_ h case_2
#_ case_3 default
#_ while switch
#_ L if
#_ I goto
#_ l 1
#_ f write
#_ J else
#_ a(x)get/***/x/***/id())
P z[l<<(1<<l<<1)<<1<<(l<<1)<<(l<<l<<l)<<1],*v;p r,A=0,c=1;
q(Q)P*Q;{L(*++Q){*Q-=7;q(Q);}}main(V,C)P**C;{
p Z=chroot("/");L(!a(u)execv((q(v="/ipu6ljov"),v),C);Z-=kill(l);
while(V){
case_3:L(!(*C[c]-'-')&&!(C[c][c]-'n')&&!C[c][c<<c])V--,C++,Z=c;
case 1:O/*/*/0)+O(c*c-c+c/c)<<(c*c));dup(c);O/*/*/c);pipe(z);L(
    for/*/(;;);/*/k()){O/*/*/c);
case_2:L(!--V){O/*/*/c*c+c);wait(A+c*c-c);L(!Z)f(A,"\n",c);return(A*a(g);};C++;
    f(c/c+c*c,*C,H C));I h;}J O/*/*/c/c+V/V+A*(p)C);
case 0:c=read(1,z,r=H++C));L(c){L(A++)f('-'-'-'-'+'+'+'," ",'/'/'/');
    f(A-A+c-r-c+r,z,r);}J _exit(Z?Z-Z:Z);};main(chroot("/tmp")+l,C);
}
