main(){}
#define P define
#P U ifdef
#P main Si
#U y
#undef y
#include "isaak.c"
Pb
#else
char*K="4499999;8	9+jW*':'TZhD m:*h.4-j'9(z7Q>r*:G#FS]mATIdMZY^HaKFZZ\
JyJw:X49@eJj1,Z'\\c^jGU@IXTF@9P2i:gAZx0pD*W3\\<ZZs1:.~Z8U:P<\\:ZOI0GBPZ7",*H
,S[5202],*B="oA9BA6iN`]`Ph>5F4::M6A69@6I{g[Za__]NPV``aV\177E4C5CG;4C<BEJG;\
?LGlSZ[Y_!oYi@uXPzLFyPOYP][]`RTaQo86564CAHCG4ES",*F,N;int Bk,V;Y
#endif
#P C K/16-2
(){char*H;F O=-263;for(H="$+---+|||";*++H;)*(F O=(*H+5&129)+1)= *H;F
#P W sprintf(
O= -132;}I/**/r(){if((N= *IO/**/O%(21 O -5)+81 O 16)==107)N+=
#undef I
*K++&15;*F++=N;return*K;}
#undef O
#P I K
#P O +
#U N
exit(N){F=WH=S,"%5060d")+385;while(Br(),++B,Kr())F+=(N=
*B++/26-1)?(")21["[N]-46)*N*4-22:-3194;while(*--K!=9){while(!(*++H+5&64));
F=(40-"(\206/"[((H-S)%130+45)/57]<<3)+H;*F++=*H++;*F=
*H==106?32:*H;Y();W WF-131,"%-3d",++Bk)+260,"%3d",V+=
*C?*C:"hijpqv"[*--C]-106);Pb();}for(H=S;*H||(int)_exit(0);H+=130)write(1,1+W
F+3,"%c%-73.73s\n",0,H),74);}
#endif
#undef U
#P U ifndef
#include <stdio.h>
