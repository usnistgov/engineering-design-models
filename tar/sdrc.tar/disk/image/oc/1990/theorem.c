#include <stdio.h>
#include <math.h>
#define X
#define Y {}
#define C  }
#define o {
#undef main
char m[500][99],v[99],R;
int*a,b,n,i,j,W,A;
float Q,G,D,M,T,B,O,U,V,N,y,e();
P(g,R,u)float*g,R,u;{int c;for(*g=1,c=u;c--;*g*=R);}
X
K(g,R,u)float*g,u;char R;
o
if(R=='+')*g+=u;
if(R=='-')*g-=u;
if(R=='*')*g*=u;
if(R=='/')*g/=u;
if(R=='^')P(g,*g,u);
C
w(g,R,u)float*g,u;char R;
/**/{int b,f;A=atoi(*++a);b=atoi(*++a);while((f=A+b)<15000){printf("%d\n",f);A=b;b=f;}}
main(A,a)int A;char*a[];
o o
if(!strcmp(*++a,"-r"))S();
D=atof(*++a);
T=atof(*++a);
B=atof(*++a);
M=atof(*(4+(a-=3)));
C
while(D<T)
o
U=e((G=B/2,*a),D,M,a);
V=e(*a,Q=D+G,M+G*U,a);
/*/
z;/*/
N=2*e(*a,Q,M+G*V,a);
M+=B*V/3+B*N/6+B*e(*a,D+=B,M+G*N,a)/6+G*U/3;
printf("%f %f\n",D,M);
C
while(T=0)
;
W=D=1;
;
while(W!=1)
o o
strcpy(j+m,v);
o 
if((j-=W)<=W)break;
strcpy(j+m,m+j-W);
C
while(strcmp(m+j-W,v)>0)
j=i;
strcpy(v,i+m);
C
for(i=(W/=3)-1;++i<n;)
;
C
do
;
while(0);
for(W=1;(W=W*3+1)<n;);
C
float e(f,D,M,a)char*f,*a[];float D,M;
o
#define main L
O=0;
R='+';
for(;*f;f++)
if(*f=='y')K(&O,R,M);
else if((*f>='0')&&(*f<='9'))K(&O,R,(float)*f-'0');
else if(*f=='x')K(&O,R,D);
else if(1)R=*f;
if(1);
return O;
for(j=0;j<n;puts(j++[m]));
e("",O,&O,a);
n=j-(O=1);
while(gets(j++[m]));
if(!strcmp(*++a,"-r"))S();
C
/**/main(A,a)int A;char*a[];
Y
S(){while(gets(b++[m]));for(b--;b--;puts(b[m]));}
char*f,m[500][99],R,v[99];
int b,W,n,i,j,z;
float Q,G,D,M,T,O,B,U,V,N,e();
#define Y
#define X {}
#define o }
#define C {
#include <stdio.h>
#include <math.h>
