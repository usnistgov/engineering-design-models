#include<stdio.h>
#include<time.h>
#define S(q)B(*e=0),q,p);
#define W(w)if((w)<22)v= -v;else v-=10;else
#define F for(r=d;r<d+N;
#define H(v,g)v=h(v,*g++= *r++),*g=0;
#define B(n)b(l,n),(V)printf(l
V
exit();char*g,c[M],d[N],q[N],p[N],*e,*r=d+N,l[M],*t="??",*k,*m="DEATHISDSev2oinpohae3ttsluuln4a?uibfe 5l\0rtlfrb6 ?a?el:e7$!n\0?e t8%ccp\0.%s9deelc.s T.@?-t.\t<J /\0=a\nP=Q Sex \0l KW Sin a$\0ane-lay% ge#-slediefuk ar  r$via-:o ?+}:r? n \0:) ee%lone 1-esy666!-~v\n.!^`'~@#\0\np~===:=q";b(o,n)char*o;{for(k=n+m;*o++=*k;k+=9);}int
y=M*2,v,x,s,f,j,o;u(s){B(s));if(!gets(l))exit(0);return(o=
*l)=='y'||o=='Y'||o!='n'&&o!='N'&&u(s);}h(v,m){for(k=c;*k!='J';)if(m==*k++)break;m=k-c;if(v<0)W(v=m-v)
if(m==1)W(v+=11)
v+=m;return
v;}main(w,z)char**z;{b(c,2)*X;for(--w&&(y=atoi(1[z]));y>1;){if(r-d>N*3/4){B(8));F++r)*r=c[(r-d)%13];F)w=
*(g=d+rand()%N),*g=
*r,*r++=w;r=d;}for(;;){B(3),y);if(!gets(l)||(w=atoi(l))<1)exit(0);if(w&1||w>M||w>y)B(1),y<M?y:M);else
break;}y-=w,s=f=j=x=v=0,g=q,e=p;H(x,g)H(x,g)H(v,e)H(v,e)*t=
*q;S(t)*q=='A'&&y>=w/2&&u(5)&&(y+=(3*(h(0,1[q])==10)-1)*w/2);if(x==-21)goto
_;if(v==-21){y+=w/2;goto
_;}while(x>-17&&x<17)H(x,g)while((v==20||*p==-1[e])&&y>=w&&u(6)){y-=w;++s;for(g=e++;2[g]=
*g,g!=p;)--g;*g++=
*e;*g=' ';i:v=h(h(0,*p),*e++=
*r++);S(t)if(*p=='A'&&-1[e]!=
*p)goto
_;}if(f=y>=w&&u(7))y-=w,H(v,e)while(!f&&v<22&&u(4)){H(v,e)if(v<22)S(t)}_:x<0&&(x=
-x);v<0&&(v=
-v);if(v<22)if(v==x)j+=w*++f;else
if(x>21||v>x)j+=w*2*++f;if(s--){*e++=' ';*e++=
*p;*e=0;for(e=p;*e=2[e];)e++;goto
i;}y+=j;S(q)};}
