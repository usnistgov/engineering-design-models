char*lie;

	double time, me= !0XFACE,

	not; int rested,   get, out;

	main(ly, die) char ly, **die ;{

	    signed char lotte,


dear; (char)lotte--;

	for(get= !me;; not){

	1 -  out & out ;lie;{

	char lotte, my= dear,

	**let= !!me *!not+ ++die;

	    (char*)(lie=


"The gloves are OFF this time, I detest you, snot\n\0sed GEEK!");

	do {not= *lie++ & 0xF00L* !me;

	#define love (char*)lie -

	love 1s *!(not= atoi(let

	[get -me?

	    (char)lotte-


(char)lotte: my- *love -
	
	'I'  -  *love -  'U' -

	'I'  -  (long)  - 4 - 'U' ])- !!
	
	(time  =out=  'a'));} while( my - dear

	&& 'I'-1l  -get-  'a'); break;}}

	    (char)*lie++;


(char)*lie++, (char)*lie++; hell:0, (char)*lie;

	get *out* (short)ly   -0-'R'-  get- 'a'^rested;

	do {auto*eroticism,

	that; puts(*( out

	    - 'c'
	
-('P'-'S') +die+ -2 ));}while(!"you're at it");


for (*((char*)&lotte)^=

	(char)lotte; (love ly) [(char)++lotte+

	!!0xBABE];){ if ('I' -lie[ 2 +(char)lotte]){ 'I'-1l ***die; }

	else{ if ('I' * get *out* ('I'-1l **die[ 2 ])) *((char*)&lotte) -=

	'4' - ('I'-1l); not; for(get=!


get; !out; (char)*lie  &  0xD0- !not) return!!

	(char)lotte;}


(char)lotte;

	do{ not* putchar(lie [out

	*!not* !!me +(char)lotte]);

	not; for(;!'a';);}while(

	    love (char*)lie);{


register this; switch( (char)lie

	[(char)lotte] -1s *!out) {

	char*les, get= 0xFF, my; case' ':

	*((char*)&lotte) += 15; !not +(char)*lie*'s';

	this +1s+ not; default: 0xF +(char*)lie;}}}

	get - !out;

	if (not--)

	goto hell;

	    exit( (char)lotte);}
