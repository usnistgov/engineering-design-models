#include <stdio.h>

#define d define

#d b12(x) 12 x
#d a13(x) x 13
#d a16(x) x 16
#d a32(x) x 32
#d acb(x) x]
#d acc(x) x}
#d aco(x) x:
#d bco(x) :x
#d acp(x) x)
#d bef(x) EOF x
#d aeq(x) x=
#d afo(x) x for
#d age(x) x fgetc
#d asi(x) x stdin
#d aso(x) x stdout
#d bgt(x) >x
#d ai(x) x i
#d aj(x) x j
#d al(x) x l
#d ami(x) x-
#d bne(x) !=x
#d aob(x) x[
#d aop(x) x(
#d apl(x) x+
#d bpu(x) fputc x
#d bqm(x) ?x
#d aqm(x) x?
#d aqu(x) x'
#d ase(x) x;
#d awh(x) x while
#d axo(x) x^
#d a0(x) x 0
#d b13(x) 13 x
#d b16(x) 16 x
#d b19(x) 19 x
#d b48(x) 48 x
#d a64(x) x 64
#d b66(x) 66 x
#d bcb(x) ]x
#d bch(x) char x
#d bcm(x) ,x
#d acm(x) x,
#d bcp(x) )x
#d beq(x) =x
#d bex(x) extern x
#d bi(x) i x
#d bin(x) int x
#d bix(x) index x
#d bj(x) j x
#d bl(x) l x
#d alt(x) x<
#d bma(x) main x
#d bob(x) [x
#d boc(x) {x
#d bop(x) (x
#d bpl(x) +x
#d app(x) x++
#d bqu(x) 'x
#d bse(x) ;x
#d bst(x) *x
 
bma(acp(bop(app(bcp(ai(boc(ase(bch(a16(bl(alt(bob(ai(b66(ase(bcb(a0(bcm(aeq(bst(acb(bj(a64(bse(aob(bin(al(bi(aeq(bse(ai(bex(aop(bch(afo(bst(ase(bix(())))))))))))))))))))))))))))))))))))))))
bl(ai(bob(aob(bi(al(bcb(aop(beq(apl(b13(a13(bpl(aeq(bop(acb(bl(bob(a32(bi(bpl(apl(b16(bcb(ai(beq(b19(aob(bpl(bop(l))))))))))))))))))))))))))))))
bpl(acp(b48(acp(asi(bcb(aop(beq(age(bop(aeq(bi(ai(bgt(aop(b12(aop(bqm(awh(b12(ase(bco(acp(bi(acp(bcp(acp(bpl(aqu(bqu(A))))))))))))))))))))))))))))))
bne(acc(bef(ase(bcp(acp(aso(bpu(acm(ai(bop(aco(bop(acb(bj(al(beq(ami(bix(aj(axo(bop(a16(aob(bl(al(aqm(bcm(acp(acp(i))))))))))))))))))))))))))))))
