
#define D ,close(

char              *c,q              [512              ],m[              256
],*v[           99], **u,        *i[3];int         f[2],p;main       (){for
 (m[m        [60]=   m[62      ]=32   ]=m[*      m=124   [m]=       9]=6;
  e(-8)     ,gets      (1+(    c=q)     )||      exit      (0);     r(0,0)
   )for(    ;*++        c;);  }r(t,      o){    *i=i        [2]=    0;for
     (u=v  +98           ;m[*--c]         ^9;m [*c]          &32  ?i[*c
       &2]=                *u,u-             v^98              &&++u:

	3	)if(!m[*c]){for(*++c=0;!m[*--c];);
	*	--u= ++c;}u-v^98?strcmp(*u,"cd")?*c?pipe(f),o=f[
	1	]:
	4	,(p=fork())?e(p),o?r(o,0)D o)D*f):
	1	,wait(0):(o?dup2(*f,0)D*f)D o):*i?
	5	D 0),e(open(*i,0)):
	9	,t?dup2(t,1)D t):i[
	2	]?
	6	D 1),e(creat(i[2],438)):
	5	,e(execvp(*u,u))):e(chdir(u[1])*2):
	3	;}e(x){x<0?write(2,"?\n$ "-x/4,2),x+1||exit(1):
	5	;}
