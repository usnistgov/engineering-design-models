#include <stdio.h>
#include <math.h>
#include <sys/time.h>

/* Type "humanly", using the Weibull distribution.  Reciprocal of
constant is average inter-arrival time for example, want average
interarrival time to 1/2 second, k = 2.

alpha   scaling factor (i.e., interarrival time)
c       shape of distribution (i.e., c = 2 gives asymmetric distribution)
min     minimum time between keystrokes

t = (((-log(x))^(1/c))*alpha)+min

This program requires the math library as well as a function that can
pause for a given number of microseconds.
*/

char *s = "The quick brown fox jumped over the lazy dog.\n";

/* generate a random number from [0 to 1) */
float
unit_random()
{
	/* current implementation is pathetic but works */
	/* 99991 is largest prime in my CRC - can't hurt, eh? */
	return((float)(rand()%99991)/99991.0);
}

/* Sleep a given number of microseconds. */
/* The following definition is for a BSD-based UNIX system and will almost */
/* certainly have to be rewritten for other systems. */
quick_sleep(timeout)
double timeout;		/* microseconds */
{
	struct timeval t;
	double integer, fraction;

	fraction = modf(timeout,&integer);
	t.tv_sec = integer;
	t.tv_usec = 1000000*fraction;
	(void) select(32, 0, 0, 0, &t);
}

main()
{
	float alpha, c, min, c_recip, max;
	int i;
	char in[100];
	char *sp;

	srand(getpid());

	printf("parameters are avg interarrival (seconds), shape (.1 is very jump, 1 is so-so, 10 is very smooth), min and max time between keystrokes\n");
	while (1) {
		printf("parameters: ");
		fflush(stdout);
		gets(in);
		sscanf(in,"%f %f %f %f",&alpha,&c,&min,&max);
		c_recip = 1/c;

		for (sp = s;*sp;sp++) {
			double t;
			t = (pow(-log(unit_random()),c_recip)*alpha)+min;
			if (t>max) t = max;
			quick_sleep(t);
			write(1,sp,1);
		}
	}
}

