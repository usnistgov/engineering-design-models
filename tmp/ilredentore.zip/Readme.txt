Il Redentore

Rayshade model of the interior of Palladio's Il Redentore in Venice,
created by Nathan G B O'Brien, for his undergraduate dissertation 
"Building Preservation and Three Dimensional Computer Modelling".

A number of images made from this model may be found at
http://www.fbe.unsw.edu.au/Exhibits/Rayshade/Church/

All of this work is Copyright (C) Nathan G. B. O'Brien and 
School of Architecture, The University of New South Wales, Australia.

If this work is used please send a note to Nathan at the email
address below.

Nathan O'Brien
no13@no13.net
http://www.no13.net/

or

Stephen Peter     
Faculty of the Built Environment, UNSW
S.Peter@unsw.edu.au
http://www.fbe.unsw.edu.au/Staff/Stephen.Peter/

This document was last edited on 19 June 1998.
(originally 27 October 1993)

----------------------------------------------------------

Listed below are the files that make up the model.
Note that the "primary" file is "final.ray".
The descriptions are taken from the files.

----------------------------------------------------------

a6.ray     The many required ballustrades.
b7.ray     The side bay.
bb8.ray    A single complete side bay without any wall icons.
bc7.ray    Column and entablature arrangements for the side bay.
c7.ray     Corinthian capital based on a capital from the Pantheon, Rome.
ca6.ray    The leaves for the capitals.
cb6.ray    Column bases.
cc8.ray    Assembled columns, circular, square, without base and fluted.
cd2.ray    Special corinthian column based on a capital from the Pantheon, Rome.
d6.ray     Side altar.
e7.ray     The various types of entablature.
f6.ray     The ground floor plane of various sections.
ff1.ray    Main floor pattern under the dome.
final.ray  The full interior of the church.
g7.ray     Main seats and kneelers.
h6.ray     Collections of furniture arrangements
i2.ray     Side chapel gateway.
j2.ray     The holy water font to the left and right of the entrance. 
k7.ray     The keystone for the side arches.
l7.ray     Various lamps.
m5.ray     The several types of wall object to be found int the church.
n6.ray     Nitch details for the side walls.
o4.ray     The end wall of the church.
p6.ray     Various wall icons.
q6.ray     Side dome and walls of major crossing.
qa2.ray    Dome and walls behind the main altar.
qb1.ray    The proto choir, behind main altar.
r7.ray     The different types of arches required.
s10.sur    Surface definitions.
t2.ray     Main altar at crossing. Base located at origin.
u4.ray     Central dome and walls.
ua1.ray    The base form for the major dome.
ub2.ray    The upper part of the major dome.
v1.ray     The ceiling of the nave.
w7.ray     The various windows for the side bay.
x2.ray     The timber balustrade and gate in front of the main dome.
----------------------------------------------------------
