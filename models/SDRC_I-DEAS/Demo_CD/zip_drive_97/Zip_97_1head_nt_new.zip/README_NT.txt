Differences between NT and Unix

1. In 'ws1\demo_backup' directory, make sure to rename the I-DEAS archive file to 
   have a '.arc' extension.

2. Put in line display mode before meshless solving.

3. The VRML portion will not work without the Netscape CosmosPlayer plug-in.

4. The 'util' directory contains Winzip, QuickTime player installer, JPEG viewer, 
   CosmoPlayer, and I-DEAS Background.

5. Practice, Practice, Practice


