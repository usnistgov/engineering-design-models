1 Put bitmap file in Winnt40 directory
2 Control Panels, Display, select the bitmap
