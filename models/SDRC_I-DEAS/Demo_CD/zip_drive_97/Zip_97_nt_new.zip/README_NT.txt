Differences between NT and Unix

1. In 'ws1\demo_backup' directory, make sure to rename the I-DEAS archive file to have a '.arc' extension.
   In 'ws2\demo_backup' directory, make sure to rename the I-DEAS archive file to have a '.arc' extension.
2. To work around an NT issue, you may have to do the 'OPTIONAL'  FE meshing steps.  Let your practice
   be your guide.
3. The VRML portion neds the CosmoPlayer Netscape plug-in.
4. The 'util' directory contains Winzip, QuickTime player installer, JPEG viewer, 
   I-DEAS Background, CosmoPlayer
5. Practice, Practice, Practice

