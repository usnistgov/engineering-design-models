   /* This program will read the status file indicated and present a 
      status report */

   /* Usage:     astatus  platform product                                */
   /* Examples:  astatus  sun fem                                         */

#include <stdio.h>
#include <ctype.h>
#include <time.h>


#define NULLCHARPTR (char *) 0
#define MAXLINES 5000

main(argc, argv)
int argc;
char *argv[];
{

/***************************************************************/

   FILE *fpstatin, *fpstatout, *ofp;
   char fpname[50];
   char statchr;
   char todays_date[10];
   char linebuf[134], pstring[10], sstring[8], statname[80];
   int  i, totlines=0;
   int  tpass, tok, tfail, tbug, tnot, tcrash, totpas, totfal, gratot;
   float ppass, pok, pfail, pbug, pnot, pcrash, perpas, perfal, graper;
   time_t now;
   char *ctime();

/***************************************************************/


   if (argc != 4) { 
       printf ("\n");
       printf ("Description: \n");
       printf ("\n");
       printf ("  This script generates statistics for a given status file.\n");
       printf ("\n");
       printf ("Usage: statman platform product status_filename\n");
       printf ("\n");
       exit();
   }
   
   
   /* Open the status file */
   sprintf(fpname,"%s.status",argv[3]);

   if ((fpstatin=fopen("xstatx.stat", "r")) == NULL) {
        printf("Error: cant open %s\n", fpname);
        exit();
   }            

   /* Open the output file */

   time(&now);
   strcpy(statname, argv[1]);
   strcat(statname, argv[2]);
   strftime(todays_date, 10, "%b%d%Y", localtime(&now) );
   strcat(statname, todays_date );
   strcat(statname, ".out" );
   ofp = fopen( statname, "w" );
   if ( ofp == NULL ) 
       {
        printf( "\n%s\n", "Error opening output file" );  
        exit();
       }

   tpass = tok = tfail = tbug = tnot = tcrash = 0;
   ppass = pok = pfail = pbug = pnot = pcrash = 0.0;

   for (i=0; i<MAXLINES && fgets(linebuf,134,fpstatin)!=NULLCHARPTR; ++i) {
   
        sscanf(linebuf, "%s %s ", pstring, sstring);

/*  Check to see if the testcase is "commented" out with an asterisk   */

        if ( pstring[0] == '*' || pstring[1] == '*' ) goto skip_testcase;

/*  Testcase is not commented, so get status and count them  */

        statchr = isupper(sstring[0]) ? tolower(sstring[0]) : sstring[0];

        switch(statchr)
        {
          case 'p': 
            tpass++;
          break;

          case 'o':
            tok++;
          break;

          case 'f':
            tfail++;
          break;

          case 'b':
            tbug++;
          break;
    
          case 'c':
            tcrash++;
          break;
          
          case 'n':
            tnot++;
          break;

          default:
            fprintf(ofp, "Error: invalid character found: %c\n", sstring[0]);
          break;
        }

        ++totlines;
        skip_testcase: ;
   }     

   fclose(fpstatin);


/*  Write out status totals   */

   fprintf(ofp, "\nPlatform: %s\n", argv[1]); 
   fprintf(ofp, "Product:  %s\n", argv[2]);
   fprintf(ofp, "Date:     %s\n", ctime(&now));      
   fprintf(ofp, "Total Number Of Testcases: %d\n\n",    totlines);

   if ( totlines == 0 ) totlines=1;

   ppass = (float)tpass/(float)totlines*100.00;
   pok  = (float)tok/(float)totlines*100.00;
   pfail = (float)tfail/(float)totlines*100.00;
   pbug  = (float)tbug/(float)totlines*100.00;
   pcrash= (float)tcrash/(float)totlines*100.00;
   pnot  = (float)tnot/(float)totlines*100.00;
 
   totpas = tpass + tok;                                       
   perpas = ppass + pok;
   totfal = tfail + tbug + tcrash;
   perfal = pfail + pbug + pcrash;
   gratot = totpas + totfal + tnot;
   graper = perpas + perfal + pnot;

   fprintf(ofp, "Automation Terminology:\n");
   fprintf(ofp, " Passed  ...... %4d %6.2f%%\n", tpass,  ppass);
   fprintf(ofp, " Ok      ...... %4d %6.2f%%\n", tok, pok);
   fprintf(ofp, "                 ===========\n" );
   fprintf(ofp, " Total   ...... %4d %6.2f%%\n", totpas, perpas);
   fprintf(ofp, " ----------------------------\n" );
   fprintf(ofp, " Failed  ...... %4d %6.2f%%\n", tfail,  pfail);
   fprintf(ofp, " Bug     ...... %4d %6.2f%%\n", tbug,   pbug);
   fprintf(ofp, " Crashed ...... %4d %6.2f%%\n", tcrash, pcrash);
   fprintf(ofp, "                 ===========\n" );
   fprintf(ofp, " Total   ...... %4d %6.2f%%\n", totfal, perfal);
   fprintf(ofp, " ----------------------------\n" );
   fprintf(ofp, " Not Run ...... %4d %6.2f%%\n", tnot,   pnot);
   fprintf(ofp, " ============================\n" );
   fprintf(ofp, " Grand Total .. %4d %6.2f%%\n", gratot, graper);

/*   fprintf(ofp, "\nTraditional Definitions:\n");
   fprintf(ofp, " Passed  ...... %4d %6.2f%%\n", tpass+tok, ppass+pok);
   fprintf(ofp, " Failed  ...... %4d %6.2f%%\n", tbug,   pbug);
   fprintf(ofp, " Run     ...... %4d %6.2f%%\n", tcrash+tfail, pcrash+pfail);
   fprintf(ofp, " Never   ...... %4d %6.2f%%\n", tnot,   pnot);  */
  
   fclose(ofp);
   printf("\nAQA test-case statistics have been successfully recorded in\n");
   printf("the output file \"%s\" located on your working directory.\n", 
            statname);
}

