/* SDRC Source File Description Block ------------------------------------
 *
 * aqa_revue
 * (26-DEC-1994) SDRC/David Mowery
 *
 * ***********************************************************
 * *****              COPYRIGHT (C) 1994               *******
 * *****     BY STRUCTURAL DYNAMICS RESEARCH CORP.     *******
 * *****             ALL RIGHTS RESERVED               *******
 * ***********************************************************
 *
 * Subsystem Description:
 *
 *  Acquires user input and processes it for AQA_REVIEW procedure
 *  
 *
 *  Usage on UNIX:   aqa_revue  status_file new_status_file textfile
 *
 *  Note :
 *
 *    Input:
 *     argv[1] = status_file - old status file being processed (full path)
 *     argv[2] = new_status_file - new status file being created (full path)
 *     argv[3] = textfile - file containing testcase information extracted
 *                          from REP files (full path needed)
 *
 *    Output:
 *     None
 *
 * Global functions defined in this source file:
 *
 *    aqa_revue - replacement for NODUP command procedure
 *
 *
 * Global data defined in this file:
 *
 *    None
 *
 *
 * Internal functions defined in this source file:
 *
 *    None
 *
 *
 * History
 *
 *  28-DEC-1994 SDRC /David Mowery/ Original creation.
 *
 *
 * -----------------------------------------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_CHARS 256

/*
 *  PRINT_LINE function:
 *    Writes characters in "line" to file specified by "outfp"
 */

int print_line ( char line[], FILE *outfp )
{

  int c, i;

  for ( i=0; i < MAX_CHARS+1; ++i )
       {
        c = (int) line[i];
        if ( line[i] == '\n' )
            {
             fputc( c, outfp );
             return 0;
            }
        else
            {
             fputc( c, outfp );
            }
       }
   
  return 0;
}

/*
 *  MAIN function:
 *
 */

main ( int argc, char *argv[] )

{

  char textfile[133], status_file[133], new_status_file[133];
  char status_line[MAX_CHARS], status_line_new[MAX_CHARS], text_line[MAX_CHARS];
  char old_testcase[81], old_status[81], old_date[81], old_stat[81];
  char cur_testcase[81], cur_status[81], cur_date[81], cur_stat[81];
  char old_test[81], old_status_letter[2];
  char old_comment[MAX_CHARS - 23], old_testcase_name[81], cur_test[81];
  char mv_command[40], text_line_orig[MAX_CHARS], temp;
  char *tmpPtr, *pirc, *pirc2;
  FILE *ifp, *ofp, *ifptxt, *ofptxt;
  int i, j, count, found_it, cur_day, cur_month, old_day, old_month;


/*
 * Initialize variables
 */

  strcpy(status_file, argv[1]);
  strcpy(new_status_file, argv[2]);
  strcpy(textfile, argv[3]);
/*
 * Begin reading old status file.
 * Also, open new status file for appending.
 */

  count = 0;

  if ( (ifp = fopen( status_file, "r" )) == NULL )
      {
       printf ( "%s could not be opened.\n", status_file );
       exit(EXIT_FAILURE);
      }
  if ( (ofp = fopen( new_status_file, "w" )) == NULL )
      {
       printf ( "%s could not be opened.\n", new_status_file );
       exit(EXIT_FAILURE);
      }

  while ( (pirc = fgets( status_line, MAX_CHARS, ifp )) != NULL )
         {
          
/*
 * Skip the old status file header
 */
          ++count;
          if ( count <= 4 )
              {
               continue;
              }

          found_it = 0;

/*
 * Break up old status line into testcase, status, date, and comment
 */

          tmpPtr = strtok( status_line, " " );
          if ( tmpPtr != NULL )
               strcpy( old_testcase_name, tmpPtr );
          else
               strcpy( old_testcase_name, "ERROR" );
          tmpPtr = strtok( NULL, " " );
          if ( tmpPtr != NULL )
               strcpy( old_status, tmpPtr );
          else
               strcpy( old_status, "UNKNOWN" );
          tmpPtr = strtok( NULL, " " );
          if ( tmpPtr != NULL )
               strcpy( old_date, tmpPtr );
          else
               strcpy( old_date, "00/00" );
          tmpPtr = strtok( NULL, " " );
          if ( tmpPtr != NULL )
              {
               strcpy( old_comment, tmpPtr );
              }
          else
              {
               strcpy( old_comment, " " );
              }

          while ( tmpPtr != NULL )
                 {
                  tmpPtr = strtok( NULL, " " );
                  if ( tmpPtr != NULL )
                      {
                       strcat( old_comment, " " );
                       strcat( old_comment, tmpPtr );
                      }
                 }
          strcat( old_comment, "\n" );
          tmpPtr = NULL;


/*
 * If testcase name has a "*" in front of it, then redefine the testcase name
 */

          if ( old_testcase_name[0] == '*' )
              {
               tmpPtr = old_testcase_name;
               ++tmpPtr ;
               strcpy( old_testcase, tmpPtr );
               tmpPtr = NULL;
              }
          else
              {
               strcpy( old_testcase, old_testcase_name ); 
              }
/*
 * Open the "textfile" file and search for any occurrence of old_testcase.
 * If found, then compare month and day to determine which testcase status is
 * most recent (is it from textfile, or from old status file?).
 * Write the result of the check to the new status file.
 */

          if ( (ifptxt = fopen( textfile, "r" )) == NULL )
              {
               printf ( "%s could not be opened.\n", textfile );
               exit(EXIT_FAILURE);
              }
          if ( (ofptxt = fopen( "temptxt", "w" )) == NULL )
              {
               printf ( "tmptxt could not be opened.\n" );
               exit(EXIT_FAILURE);
              }


          while ( (pirc2 = fgets( text_line, MAX_CHARS, ifptxt )) != NULL )
                 { 
/*
 * Save the text_line, then break up text line into testcase, status, and date
 */

                  strcpy( text_line_orig, text_line );
                  tmpPtr = strtok( text_line, " " );
                  if ( tmpPtr != NULL )
                       strcpy( cur_testcase, tmpPtr );
                  else
                       strcpy( cur_testcase, "T_ERROR" );
                  tmpPtr = strtok( NULL, " " );
                  if ( tmpPtr != NULL )
                       strcpy( cur_status, tmpPtr );
                  else
                       strcpy( cur_status, "UNKNOWN" );
                  tmpPtr = strtok( NULL, " " );
                  if ( tmpPtr != NULL )
                       strcpy( cur_date, tmpPtr );
                  else
                       strcpy( cur_date, "00/00" );
                  tmpPtr = NULL;
/*
 * If the testcase names from status file and text file do NOT match,
 *  then keep line in textfile. Else, process the testcase.
 */

                  if ( (strcmp( cur_testcase, old_testcase )) != 0 )
                      {
                       print_line( text_line_orig, ofptxt );
                       continue;
                      }
                  else
                      {
                       found_it = 1;

/*
 * Convert string values of dates to actual integers
 */

                       cur_day = ( (int) cur_date[3] ) * 10 +
                                   ( (int) cur_date[4] );
                       cur_month = ( (int) cur_date[0] ) * 10 +
                                     ( (int) cur_date[1] );
                       if ( old_date[1] == '/' )
                           {
                            old_date[1] = old_date[0];
                            old_date[0] = '0';
                            temp = old_date[3];
                            old_date[3] = old_date[2];
                            old_date[4] = temp;
                            old_date[2] = '/';
                            old_date[5] = '\0';
                           }
                       if ( old_date[4] == '\0' )
                           {
                            temp = old_date[3];
                            old_date[3] = '0';
                            old_date[4] = temp;
                            old_date[5] = '\0';
                           } 
                            
                       old_day = ( (int) old_date[3] ) * 10 +
                                   ( (int) old_date[4] );
                       old_month = ( (int) old_date[0] ) * 10 +
                                     ( (int) old_date[1] );
                       cur_date[5] = '\0';
                       old_date[5] = '\0';

/*
 * Pad spaces at end of testcase & status names less than 8 characters long
 */
                       for ( i=0; i < 9; ++i )
                            {
                             if ( cur_testcase[i] == '\0' && i < 8 )
                                 {
                                  for ( j=i; j < 9; ++j )
                                       {
                                        cur_test[i] = ' ';
                                        i=j;
                                       }
                                 }
                             else
                                 {
                                  cur_test[i] = cur_testcase[i];
                                 }

                             if ( i == 8 )
                                 cur_test[i] = '\0';

                            }
                       for ( i=0; i < 8; ++i )
                            {
                             if ( old_status[i] == '\0' && i < 7 )
                                 {
                                  for ( j=i; j < 8; ++j )
                                       {
                                        old_stat[i] = ' ';
                                        i=j;
                                       }
                                 }
                             else
                                 {
                                  old_stat[i] = old_status[i];
                                 }

                             if ( i == 7 )
                                 old_stat[i] = '\0';

                            }
                       for ( i=0; i < 8; ++i )
                            {
                             if ( cur_status[i] == '\0' && i < 7 )
                                 {
                                  for ( j=i; j < 8; ++j )
                                       {
                                        cur_stat[i] = ' ';
                                        i=j;
                                       }
                                 }
                             else
                                 {
                                  cur_stat[i] = cur_status[i];
                                 }

                             if ( i == 7 )
                                 cur_stat[i] = '\0';

                            }


/*
 * Compare dates on testcases (old status file vs. textfile). Use the newest
 *  testcase information.
 */

                       if ( (old_month < cur_month) ||
                               (old_day <= cur_day && old_month == cur_month) )
                           {
                            if ( cur_status[0] == 'c' || cur_status[0] == 'C' ||
                                  cur_status[0] == 'f' || cur_status[0] == 'F' ) 
                                {
                                 strcpy( status_line_new, cur_test );
                                 strcat( status_line_new, " " );
                                 strcat( status_line_new, cur_stat );
                                 strcat( status_line_new, " " );
                                 strcat( status_line_new, cur_date );
                                 strcat( status_line_new, " [prev " );
                                 old_status_letter[0] = 
                                   (char)(tolower( (int)old_stat[0] ));
                                 old_status_letter[1] = '\0';
                                 strcat( status_line_new, old_status_letter );
                                 strcat( status_line_new, " " );
                                 strcat( status_line_new, old_date );
                                 strcat( status_line_new, "] " );
                                 strcat( status_line_new, old_comment );
                                 print_line( status_line_new, ofp );
                                }
                            else
                                {
                                 strcpy( status_line_new, cur_test );
                                 strcat( status_line_new, " " );
                                 strcat( status_line_new, cur_stat );
                                 strcat( status_line_new, " " );
                                 strcat( status_line_new, cur_date );
                                 strcat( status_line_new, " \n" );
                                 print_line( status_line_new, ofp );
                                }
                           }

                       else
                           {
                            strcpy( status_line_new, cur_test );
                            strcat( status_line_new, " " );
                            strcat( status_line_new, old_stat );
                            strcat( status_line_new, " " );
                            strcat( status_line_new, old_date );
                            strcat( status_line_new, " " );
                            strcat( status_line_new, old_comment );
                            print_line( status_line_new, ofp );
                           }

                      }
/*
 * END OF Textfile LOOP
 */

                 }   

          fclose ( ifptxt );
          fclose ( ofptxt );

          strcpy( mv_command, "mv temptxt " );
          strcat( mv_command, textfile );

          system( mv_command );
          

/*
 * Write old status file line to new status file if testcase not found 
 *  in textfile. Make sure to pad testcase name and status with necessary 
 *  number of spaces.
 */

          if ( found_it == 0 )
              {
               for ( i=0; i < 9; ++i )
                    {
                     if ( old_testcase[i] == '\0' && i < 8 )
                         {
                          for ( j=i; j < 9; ++j )
                               {
                                old_test[i] = ' ';
                                i=j;
                               }
                         }
                     else
                         {
                          old_test[i] = old_testcase[i];
                         }

                     if ( i == 8 )
                         old_test[i] = '\0';

                    }
               for ( i=0; i < 8; ++i )
                    {
                     if ( old_status[i] == '\0' && i < 7 )
                         {
                          for ( j=i; j < 8; ++j )
                               {
                                old_stat[i] = ' ';
                                i=j;
                               }
                         }
                     else
                         {
                          old_stat[i] = old_status[i];
                         }

                     if ( i == 7 )
                         old_stat[i] = '\0';

                    }

               strcpy( status_line_new, old_test );
               strcat( status_line_new, " " );
               strcat( status_line_new, old_stat );
               strcat( status_line_new, " " );
               strcat( status_line_new, old_date );
               strcat( status_line_new, " " );
               strcat( status_line_new, old_comment );
               print_line( status_line_new, ofp );
              }

/*
 * END OF Status file LOOP
 */

         }

/*
 * Close old_status file and new_status file
 */

  fclose ( ifp );
  fclose ( ofp );

/*
 *  Exit
 */
  
}
