/* SDRC Source File Description Block ------------------------------------
 *
 * extract_rep_info
 * (29-DEC-1994) SDRC/David Mowery
 *
 * ***********************************************************
 * *****              COPYRIGHT (C) 1994               *******
 * *****     BY STRUCTURAL DYNAMICS RESEARCH CORP.     *******
 * *****             ALL RIGHTS RESERVED               *******
 * ***********************************************************
 *
 * Subsystem Description:
 *
 *  Acquires REP file info for AQA_REVIEW procedure
 *  
 *
 *  Usage on UNIX:   extract_rep_info rep_file textfile
 *
 *  Note :
 *
 *    Input:
 *     argv[1] = rep_file - AQA Report file being processed (full path)
 *     argv[2] = textfile - Text file being created to contain extracted REP 
 *                          info (NOTE: textfile must already exist!)
 *
 *    Output:
 *     cur_month/cur_day   (e.g., Dec09 )
 *
 * Global functions defined in this source file:
 *
 *    extract_rep_info -- extracts REP file information
 *
 *
 * Global data defined in this file:
 *
 *    None
 *
 *
 * Internal functions defined in this source file:
 *
 *    None
 *
 *
 * History
 *
 *  29-DEC-1994 SDRC /David Mowery/ Original creation.
 *
 *
 * -----------------------------------------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_CHARS 256

/*
 *  PRINT_LINE function:
 *    Writes characters in "line" to file specified by "outfp"
 */

int print_line ( char line[], FILE *outfp )
{

  int c, i;

  for ( i=0; i < MAX_CHARS+1; ++i )
       {
        c = (int) line[i];
        if ( line[i] == '\n' )
            {
             fputc( c, outfp );
             return 0;
            }
        else
            {
             fputc( c, outfp );
            }
       }
   
  return 0;
}

/*
 *  MAIN function:
 *
 */

main ( int argc, char *argv[] )

{

  char rep_file[133], textfile[133];
  char rep_line[MAX_CHARS], text_line[MAX_CHARS], cur_prg[81];
  char cur_day[81], cur_month[81], cur_testcase[10], bar[81], cur_status[81];
  char temp_day, cur_stat[10], cur_test[10], cur_mon[10];
  char *tmpPtr, *pirc;
  FILE *ifp, *ofp;
  int c, i, not_a_testcase, j, line_num;
  double d;


/*
 * Initialize variables
 */

  strcpy(rep_file, argv[1]);
  strcpy(textfile, argv[2]);

/*
 * Begin reading Report file. Open "textfile.txt" for writing.
 */

  line_num = 1;

  if ( (ifp = fopen( rep_file, "r" )) == NULL )
      {
       printf ( "%s could not be opened.\n", rep_file );
       exit(EXIT_FAILURE);
      }
  if ( (ofp = fopen( textfile, "a" )) == NULL )
      {
       printf ( "%s could not be opened.\n", textfile );
       exit(EXIT_FAILURE);
      }


  while ( (pirc = fgets( rep_line, MAX_CHARS, ifp )) != NULL )
         {
         
          if ( line_num == 11 )
              {
               
/*
 * Extract cur_month and cur_day variables (cur_weekday is read, but not
 *  saved)
 */

               tmpPtr = strtok( rep_line, " " );
               tmpPtr = strtok( NULL, " " );
               if ( tmpPtr != NULL )
                    strcpy( cur_month, tmpPtr );
               else
                    strcpy( cur_month, "UNK" );
               tmpPtr = strtok( NULL, " " );
               if ( tmpPtr != NULL )
                    strcpy( cur_day, tmpPtr );
               else
                    strcpy( cur_day, "UNK" );

               tmpPtr = NULL;

/*
 * Convert cur_month string to decimal equivalent
 */
               
               strcpy( cur_mon, cur_month );

               if ( (c = strcmp( cur_month, "Jan" )) == 0 )
                          strcpy( cur_month, "01" );
               if ( (c = strcmp( cur_month, "Feb" )) == 0 )
                          strcpy( cur_month, "02" );
               if ( (c = strcmp( cur_month, "Mar" )) == 0 )
                          strcpy( cur_month, "03" );
               if ( (c = strcmp( cur_month, "Apr" )) == 0 )
                          strcpy( cur_month, "04" );
               if ( (c = strcmp( cur_month, "May" )) == 0 )
                          strcpy( cur_month, "05" );
               if ( (c = strcmp( cur_month, "Jun" )) == 0 )
                          strcpy( cur_month, "06" );
               if ( (c = strcmp( cur_month, "Jul" )) == 0 )
                          strcpy( cur_month, "07" );
               if ( (c = strcmp( cur_month, "Aug" )) == 0 )
                          strcpy( cur_month, "08" );
               if ( (c = strcmp( cur_month, "Sep" )) == 0 )
                          strcpy( cur_month, "09" );
               if ( (c = strcmp( cur_month, "Oct" )) == 0 )
                          strcpy( cur_month, "10" );
               if ( (c = strcmp( cur_month, "Nov" )) == 0 )
                          strcpy( cur_month, "11" );
               if ( (c = strcmp( cur_month, "Dec" )) == 0 )
                          strcpy( cur_month, "12" );


/*
 * Convert day if it is less than 10
 */
               d = atof( cur_day );
               if ( d < 10.0 )
                   {
                    temp_day = cur_day[0]; 
                    cur_day[0] = '0';
                    cur_day[1] = temp_day;
                    cur_day[2] = '\0';
                   }
              }

/*
 * Get testcase and status
 */

          if ( line_num > 16 )
              {
              
               tmpPtr = strtok( rep_line, " " );
               if ( tmpPtr != NULL )
                    strcpy( cur_prg, tmpPtr );
               else
                    strcpy( cur_prg, "ERROR" );
               tmpPtr = strtok( NULL, " " );
               if ( tmpPtr != NULL )
                    strcpy( bar, tmpPtr );
               else
                    strcpy( bar, " " );
               tmpPtr = strtok( NULL, " " );
               if ( tmpPtr != NULL )
                    strcpy( cur_status, tmpPtr );
               else
                    strcpy( cur_status, "UNKNOWN" );
               tmpPtr = strtok( NULL, " " );
               if ( tmpPtr != NULL )
                    strcpy( bar, tmpPtr );
               else
                    strcpy( bar, " " );

               tmpPtr = NULL; 

               not_a_testcase = 0;
               for( i=0; i<10; ++i )
                   {
                    if ( ! isspace( (int) cur_prg[i] ) &&
                            cur_prg[i] != '.' )
                        {
                         cur_testcase[i] = cur_prg[i];
                        }
                    else if ( cur_prg[i] == '.' )
                        {
                         cur_testcase[i] = '\0' ;
                         not_a_testcase = 999;
                         break;
                        }
                    else
                        break;
                   }

               if ( not_a_testcase < 1 )
                   {
                    break;
                   }
               else
                   {

/*
 * Pad spaces onto testcase and status names. then, write out the
 *  line to the text file.
 */


                     for ( i=0; i < 9; ++i )
                          {
                           if ( cur_testcase[i] == '\0' && i < 8 )
                               {
                                for ( j=i; j < 9; ++j )
                                     {
                                      cur_test[i] = ' ';
                                      i=j;
                                     }
                               }
                           else
                               {
                                cur_test[i] = (char)(tolower(
                                      (int)cur_testcase[i] ));
                               }

                           if ( i == 8 )
                               cur_test[i] = '\0';

                          }
                     for ( i=0; i < 8; ++i )
                          {
                           if ( cur_status[i] == '\0' && i < 7 )
                               {
                                for ( j=i; j < 8; ++j )
                                     {
                                      cur_stat[i] = ' ';
                                      i=j;
                                     }
                               }
                           else
                               {
                                cur_stat[i] = (char)(tolower( 
                                      (int)cur_status[i] ));
                               }

                           if ( i == 7 )
                               cur_stat[i] = '\0';

                          }
                    strcpy( text_line, cur_test );
                    strcat( text_line, " " );
                    strcat( text_line, cur_stat );
                    strcat( text_line, " " );
                    strcat( text_line, cur_month );
                    strcat( text_line, "/" );
                    strcat( text_line, cur_day );
                    strcat( text_line, "  \n" );
                    print_line( text_line, ofp );
                    
                    strncpy( cur_test, "\0", 10 );
                    strncpy( cur_stat, "\0", 10 );
                                        
                   }

              }

/*
 * END OF rep_line READ LOOP
 */

              ++line_num;
         }  

/*
 * Close old_status file and new_status file
 */

  fclose ( ifp );
  fclose ( ofp );

/*
 *  Exit (return last "cur_month/cur_day")
 */
 
}
