/* SDRC Source File Description Block ------------------------------------
 *
 * aqa_review_go
 * (02-MAY-1995) SDRC/David Mowery
 *
 * ***********************************************************
 * *****              COPYRIGHT (C) 1995               *******
 * *****     BY STRUCTURAL DYNAMICS RESEARCH CORP.     *******
 * *****             ALL RIGHTS RESERVED               *******
 * ***********************************************************
 *
 * Subsystem Description:
 *
 *  Acquires user input and processes it for AQA_REVIEW_GO procedure
 *
 *
 *  Usage on UNIX:   aqa_review_go  old_status_file new_status_file
 *
 *  Note :
 *
 *    Input:
 *     argv[1] = old_status_file - old status file being processed (full path)
 *     argv[2] = new_status_file - new status file being created (full path)
 *
 *    Output:
 *     None
 *
 * Global functions defined in this source file:
 *
 *    aqa_review_go -  searches for keyword error messages within DIF or LOG
 *                     and adds comment to testcase line in old_status_file
 *
 *
 * Global data defined in this file:
 *
 *    None
 *
 *
 * Internal functions defined in this source file:
 *
 *    None
 *
 *
 * History
 *
 *  02-MAY-1995 SDRC /David Mowery/ Original creation.
 *
 *
 * -----------------------------------------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_CHARS 256

/*
 *  PRINT_LINE function:
 *    Writes characters in "line" to file specified by "outfp"
 */

int print_line ( char line[], FILE *outfp )
{

  int c, i;

  for ( i=0; i < MAX_CHARS+1; ++i )
       {
        c = (int) line[i];
        if ( line[i] == '\n' )
            {
             fputc( c, outfp );
             return 0;
            }
        else
            {
             fputc( c, outfp );
            }
       }
   
  return 0;
}

/*
 *  MAIN function:
 *
 */

main ( int argc, char *argv[] )

{

  char old_status_file[133], status_file[133], diflog_file[133];
  char prgfile[81];
  char status_line[MAX_CHARS], perm_status_line[MAX_CHARS+81];
  char diflog_line[MAX_CHARS], comment[80];
  char *tmpPtr, *pirc, *pirc2, *tokPtr;
  FILE *ifp, *ofp, *ifpdif;
  int count;


/*
 * Initialize variables
 */

  strcpy(old_status_file, argv[1]);
  strcpy(status_file, argv[2]);

/*
 * Begin reading old status file.
 * Also, open new status file for writing.
 */


  if ( (ifp = fopen( old_status_file, "r" )) == NULL )
      {
       printf ( "%s could not be opened.\n", old_status_file );
       exit(EXIT_FAILURE);
      }
  if ( (ofp = fopen( status_file, "w" )) == NULL )
      {
       printf ( "%s could not be opened.\n", status_file  );
       fclose( ifp );
       exit(EXIT_FAILURE);
      }


  while ( (pirc = fgets( status_line, MAX_CHARS-1, ifp )) != NULL )
         {
          
/*
 * Break up old status line into testcase, status, date, and comment
 */

          strcpy( perm_status_line, status_line);
          tokPtr = strtok( status_line, " " );
          if (tmpPtr != NULL )
               strcpy( prgfile, tokPtr );
              
     /*
      *  Open DIF file, if it exists
      */

          strcpy( diflog_file, prgfile );
          strcat( diflog_file, ".dif" );

          if ( (ifpdif = fopen( diflog_file, "r" )) == NULL )
              {
            /*
             * Open LOG file, if it exists
             */
               strcpy( diflog_file, prgfile );
               strcat( diflog_file, ".log" );

               if ( (ifpdif = fopen( diflog_file, "r" )) == NULL )
                   {
                    print_line( perm_status_line, ofp );
                    continue;
                   }
              }

     /*
      * Start reading either DIF or LOG, whichever had been found
      */
 
          strcpy( comment, " \n" );
  
          while ( (pirc2 = fgets( diflog_line, MAX_CHARS-1, ifpdif )) != NULL )
                 {

     /*
      * List of "keyword" errors to check for
      */

                  if ( (tmpPtr = 
                       strstr( diflog_line, "errors encountered in last run" ))
                          != NULL )
                      {
                       strcpy( comment, "errors encountered in last run\n" );
                       break;
                      } 
             
                  if ( (tmpPtr= strstr( diflog_line, "rror" )) != NULL )
                      {
                       strcpy( comment, "Error ??\n" );
                       break;
                      }
                  if ( (tmpPtr= strstr( diflog_line, "Invalid command" )) 
                                                         != NULL )
                      {
                       strcpy( comment, "Invalid command\n" );
                       break;
                      }
                  if ( (tmpPtr= strstr( diflog_line, "nvalid" )) != NULL )
                      {
                       strcpy( comment, "Invalid entry ??\n" );
                       break;
                      }
                  if ( (tmpPtr= strstr( diflog_line, "array name not known" ))
                                                         != NULL )
                      {
                       strcpy( comment, "Variable/array name not known\n" );
                       break;
                      }
                 }

/*
 * Append comment to status line, then write it to new status file
 */

            fclose( ifpdif );

            for ( count=0; count < MAX_CHARS ; ++count )
                 {
                  if ( perm_status_line[count] == '\n' )
                      {
                       perm_status_line[count] = ' ';
                       break;
                      }
                 }

            strcat(perm_status_line, comment);    
            print_line( perm_status_line, ofp );

         }   


/*
 * Close old_status file and new_status file
 */

  fclose ( ifp );
  fclose ( ofp );

/*
 *  Exit
 */
  
}
